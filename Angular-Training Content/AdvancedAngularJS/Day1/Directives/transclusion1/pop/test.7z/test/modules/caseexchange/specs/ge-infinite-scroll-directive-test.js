define(['angular', 'angular-mocks', 'widgets/ge-infinite-scroll/ge-infinite-scroll-directive'], function() {
    var expect = chai.expect;

    beforeEach(module('InfiniteScrollDirective'));

    describe('Infinite Scroll Directive ::', function() {
       var scope;
       var element =
           angular.element('<div style="height: 450px;" ge-infinite-scroll geis-callback="callbackFn">' +
           '    <div style="height: 500px;">dummy content</div>' +
           '</div>');

       beforeEach(inject(
           function($rootScope, $compile){
               // set up the scope to use with the directive
               scope = $rootScope.$new();
               scope.callbackFn =
                   function() {
                       scope.isFetching = true;
                   };
               scope.isFetching = false;
               $compile(element)(scope);
           }
       ));

       it('directive scope should have "callback" and "available" attributes', function() {
           element.isolateScope().$apply();
           expect(element.isolateScope().callback).not.to.be.undefined;
       });

       it('directive should be able to call provided "callback" function', function() {
           element.isolateScope().$apply(element.isolateScope().callback);
           expect(scope.isFetching).to.be.true;
       });

       it('directive should call provided callback', function(){
           var callbackSpy = sinon.spy(element.isolateScope(), 'callHandler');

           element.triggerHandler('scroll');
           assert(callbackSpy.called, 'callback function was not called upon scroll event');
       })
    });
});
