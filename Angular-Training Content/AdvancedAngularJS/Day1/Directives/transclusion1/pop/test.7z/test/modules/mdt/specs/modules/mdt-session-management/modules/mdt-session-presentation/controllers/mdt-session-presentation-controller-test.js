/*
 * mdt-session-presentation-controller-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/**
 * Created by 212408578 on 2015.11.04..
 */

define(['angular', 'angular-mocks', 'ng-sortable', 'mdt/modules/mdt-session-management/modules/mdt-session-presentation/controllers/mdt-session-presentation-controller'], function () {
    'use strict';

    describe('MDT Session Presentation controller test cases', function () {
        var scope, stateParams, state, controller, MdtSessionPresentationService, NotificationService, MdtSessionDataService, successHandler, errorHandler;

        beforeEach(function () {
            angular.module('Platform.Directive.Notification', []);
            angular.module('Platform.Directive.GeLoadingSpinner', []);
            angular.module('Platform.Services.NotificationService', []);

            module('Mdt.Module.MdtSessionPresentationController', function ($provide) {});
            module('Mdt.Module.MdtSessionDataService');

            inject(function ($rootScope, $controller, _MdtSessionDataService_) {
                scope = $rootScope.$new();
                stateParams = {
                    sessionId: 1,
                    caseId: 2};
                state = {};
                MdtSessionPresentationService = {
                    then: function(fn){
                        fn({
                            getDetails: function (id, success, error) {
                                successHandler = success;
                                errorHandler   = error;
                                return {caseList : []};
                            },
                            getCaseDetails: sinon.spy(),
                            markCaseAsReviewed: sinon.spy()
                        })
                    }
                };
                NotificationService = {
                    addErrorMessage: sinon.spy()
                };
                MdtSessionDataService = _MdtSessionDataService_;
                var session = {
                    meetingId: 6677,
                    cases: [
                        {id: 1122,
                            outcome: 'outcome1122'},
                        {id: 3344,
                            outcome: 'outcome3344'}
                    ]
                };
                MdtSessionDataService.updateItemList([session]);
                MdtSessionDataService.retrieveSelectedItem(6677);

                //Initialize the controller
                controller =
                    $controller('MdtSessionPresentationListController', {
                        $scope: scope,
                        $stateParams: stateParams,
                        $state: state,
                        MdtSessionPresentationService: MdtSessionPresentationService,
                        MdtSessionDataService: MdtSessionDataService,
                        NotificationService: NotificationService
                    });

            });
        });

        it("should have a controller defined", function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it("should handle received session details", function(){
            var result = {
                data: {
                    name: 'Lorem Pista'
                }
            };

            successHandler(result);
            expect(scope.sessionDetails.name).to.be.equal(result.data.name);
        });

        it("should handles error", function(){
            errorHandler();
            expect(scope.sessionDetails).to.be.empty;
            expect(NotificationService.addErrorMessage.calledOnce).to.be.true;
        })
    });
});
