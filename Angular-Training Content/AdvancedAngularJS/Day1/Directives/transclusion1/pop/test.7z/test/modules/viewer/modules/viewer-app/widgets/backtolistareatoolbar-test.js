define([ 'angular', 'angular-mocks', 'platformMock', 'viewerModule/widgets/backtolist-area-toolbar/backtolist-area-toolbar' ], function() {
    'use strict';

    describe('backtolistAreaToolbar :', function() {
        var scope, element, isolatedScope, location;

        beforeEach(module('cloudav.viewerApp.widgets'));
        beforeEach(module('templates'));
        beforeEach(module('platform'));

        beforeEach(inject(function($compile, $rootScope, $location) {
            var html = '<backtolist-area-toolbar></backtolist-area-toolbar>';
            scope = $rootScope.$new();
            element = $compile(html)(scope);
            location = $location;
            scope.$digest();
            isolatedScope = element.isolateScope();
        }));

        it('should have a directive', function() {
            assert.isDefined(element, 'backtolistAreaToolbar Directive is not defined');
        });

        it('should have a backtolistBtns property in scope', function() {
            assert.isDefined(isolatedScope.backtolistBtns, 'backtolistAreaToolbar Directive should have a backtolistBtns property in scope');
        });

        it('should have backtolistBtns of type simple-bar', function() {
            expect(isolatedScope.backtolistBtns.type).to.equal('simple-bar', 'The backtolistBtns property should be of type simple-bar');
        });

        it('should have one button in the backtolistBtns.buttons array', function() {
            expect(isolatedScope.backtolistBtns.buttons.length).to.equal(1, 'backtolistBtns was not created with a buttons array with one button.');
        });

        it('should have a onclick function in the backtolistBtns property', function() {
            expect(typeof isolatedScope.backtolistBtns.buttons[0].onclick).to.equal('function', 'The button in backtolistBtns do not have a onclick function');
        });

        it('should have a button of type toolBtn in the backtolistBtns.buttons array', function() {
            expect(isolatedScope.backtolistBtns.buttons[0].type).to.equal('toolBtn', 'The button in backtolistBtns is not of type toolBtn');
        });

        it('should have an icon for the button in the backtolistBtns.buttons array', function() {
            expect(typeof isolatedScope.backtolistBtns.buttons[0].icon).to.equal('object', 'The button in backtolistBtns do not have an icon');
        });

        it('should broadcast an event when clicking on the backtolistBtns', function() {
            isolatedScope.$on('viewerSessionClosed', function() {
                 isolatedScope.eventBroadcasted = true;
             });
            isolatedScope.backtolistBtns.buttons[0].onclick();
            expect(isolatedScope.eventBroadcasted).to.equal(true);
        });
    });
});
