/*
 * @ngdoc object
 * @name viewer.object:karma-conf
 * @author Benoit Laurent <Benoit.Laurent@ge.com>
 * @description This is the karma unit test configuration file for the {@link Viewer} module.
 */
module.exports = function (config) {
    'use strict';

    config.set({

        // base path that will be used to resolve all patterns (eg. files, exclude)
        basePath : '../../..',

        // frameworks to use
        // available frameworks: https://npmjs.org/browse/keyword/karma-adapter
        frameworks : [ 'mocha', 'requirejs', 'chai-as-promised', 'sinon-chai', 'chai' ],

        logLevel: config.LOG_INFO,

        // list of files / patterns to load in the browser
        files : [
        'public/uaf/3rdparty/angular/angular.js',
        'public/modules/viewer/tracing/rjs-tracing.js',
        'public/modules/viewer/tracing/angular-tracing.js',
        {
            pattern : 'public/uaf/**/*.js',
            included : false
        }, {
            pattern : 'public/3rdparty/xjtweb/1.0.0/jsjami.js',
            included : false
        }, {
            pattern : 'test/modules/xjtweb-platform/mocks/**/*.js',
            included : false
        }, {
            pattern : 'public/modules/viewer/**/*.js',
            included : false
        }, {
            pattern : 'test/modules/viewer/**/*-test.js',
            included : false
        }, {
            pattern : 'test/modules/viewer/mocks/*.js',
            included : false
        }, 'public/modules/viewer/modules/viewer-app/widgets/**/*.html', 'public/modules/viewer/modules/mousemanagement/widgets/**/*.html', 'test/modules/viewer/test-main.js' ],

        // list of files to exclude
        exclude : [ 'public/xjtweb/**/!(jsjami).js' ],

        // preprocess matching files before serving them to the browser
        // available preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor
        preprocessors : {
            'public/modules/viewer/**/!(three).js' : 'coverage',
            'public/modules/viewer/modules/viewer-app/widgets/**/*.html' : [ 'ng-html2js' ],
            'public/modules/viewer/modules/mousemanagement/widgets/**/*.html' : [ 'ng-html2js' ]
        },

        junitReporter : {
            outputFile : 'test/modules/viewer/report/junit/TESTS-xunit.xml',
            suite : ''
        },

        // test results reporter to use
        // possible values: 'dots', 'progress'
        // available reporters: https://npmjs.org/browse/keyword/karma-reporter
        reporters: ['progress', 'coverage', 'junit'],

        /**
         * ng-html2js options
         */
        ngHtml2JsPreprocessor : {
            // strip this from the file path
            stripPrefix : 'public/',

            // setting this option will create only a single module that contains templates
            // from all the files, so you can load them all with module('foo')
            moduleName : 'templates'
        },

        // web server port
        port : 9876,

        // enable / disable colors in the output (reporters and logs)
        colors : true,

        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO ||
        // config.LOG_DEBUG

        // enable / disable watching file and executing tests whenever any file changes
        autoWatch : true,

        // start these browsers
        // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
        browsers : [ 'PhantomJS' ],
        captureTimeout : 90000,

        coverageReporter : {
            dir : 'test/modules/viewer/report/coverage',
            reporters : [ {
                type : 'lcovonly',
                subdir : 'lcovonly'
            }, {
                type : 'html',
                subdir : 'html'
            } ]
        },

        client: {
            captureConsole: true
        },

        // Continuous Integration mode
        // if true, Karma captures browsers, runs the tests and exits
        singleRun: true,
        plugins: [
            'karma-chrome-launcher',
            'karma-phantomjs-launcher',
            'karma-requirejs',
            'karma-mocha',
            'karma-chai',
            'karma-chai-as-promised',
            'karma-sinon-chai',
            'karma-coverage',
            'karma-ng-html2js-preprocessor',
            'karma-junit-reporter'
        ]
    });
};
