define(['angular-mocks', 'modules/platform/directives/touch-click'], function (ngMocks, tc) {

    describe('Test touchClick directive', function () {

        var $compile,
            $rootScope,
            $window,
            oldNavigator,
            userAgent = {
                desktop: 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36',
                iPad: 'Mozilla/5.0 (iPad; CPU OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53'
            };

        beforeEach(module('platform.directive.touch-click'));
        beforeEach(module('templates'));

        beforeEach(inject(function (_$compile_, _$rootScope_, _$window_) {
            $compile = _$compile_;
            $rootScope = _$rootScope_;
            $window = _$window_;

            oldUserAgent = $window.navigator.userAgent;
        }));

        afterEach(function () {
            // Reset the user agent
            $window.navigator = {
                userAgent: oldUserAgent
            };
        });

        it('should evaluate the attributes on mousedown event if event-on-start parameter is true', function () {

            // Create the scope and the element which contains the touch-click directive
            var scope = $rootScope.$new();
            var element = $compile('<div touch-click="evaluated = true" event-on-start="true"></div>')(scope);
            $rootScope.$digest();

            scope.evaluated = false;

            // Create and dispatch event manually
            var event = document.createEvent('MouseEvent');
            event.initMouseEvent('mousedown');
            element[0].dispatchEvent(event);
            scope.$apply();

            // Check if the touch-click attributes have been evaluated
            expect(scope.evaluated).to.equal(true);
        });

        it('should evaluate the attributes on touchstart event if event-on-start parameter is true', function () {

            // Create the scope and the element which contains the touch-click directive
            var scope = $rootScope.$new();
            var element = $compile('<div touch-click="evaluated = true" event-on-start="true"></div>')(scope);
            $rootScope.$digest();

            scope.evaluated = false;

            // Create and dispatch event manually
            var event = document.createEvent('MouseEvent');
            event.initMouseEvent('touchstart');
            element[0].dispatchEvent(event);
            scope.$apply();

            // Check if the touch-click attributes have been evaluated
            expect(scope.evaluated).to.equal(true);
        });

        it('should evaluate the attributes on click event on desktop if event-on-start parameter is not set', function () {

            // Create the scope and the element which contains the touch-click directive
            var scope = $rootScope.$new();
            var element = $compile('<div touch-click="evaluated = true"></div>')(scope);
            $rootScope.$digest();

            scope.evaluated = false;

            // Create and dispatch event manually
            var event = document.createEvent('MouseEvent');
            event.initMouseEvent('click');
            element[0].dispatchEvent(event);
            scope.$apply();

            // Check if the touch-click attributes have been evaluated
            expect(scope.evaluated).to.equal(true);
        });

        it('should evaluate the attributes on touchend event on Apple devices if event-on-start parameter is not set', function () {

            // Set the user agent
            $window.navigator = {
                userAgent: userAgent.iPad
            };

            // Create the scope and the element which contains the touch-click directive
            var scope = $rootScope.$new();
            var element = $compile('<div touch-click="evaluated = true"></div>')(scope);
            $rootScope.$digest();

            scope.evaluated = false;

            // Create and dispatch event manually
            var event = document.createEvent('MouseEvent');
            event.initMouseEvent('touchend');
            element[0].dispatchEvent(event);
            scope.$apply();

            // Check if the touch-click attributes have been evaluated
            expect(scope.evaluated).to.equal(true);
        });

        it('should not evaluate the touch-click attributes after a movement (x axis) on Apple devices', function () {

            // Set the user agent
            $window.navigator = {
                userAgent: userAgent.iPad
            };

            // Create the scope and the element which contains the touch-click directive
            var scope = $rootScope.$new();
            var element = $compile('<div touch-click="evaluated = true"></div>')(scope);
            $rootScope.$digest();

            /* Test on x */

            scope.evaluated = false;

            // Create and dispatch event manually
            var touchstartEvent = document.createEvent('MouseEvent');
            touchstartEvent.initMouseEvent('touchstart');
            element[0].dispatchEvent(touchstartEvent);

            // Create and dispatch event manually
            var touchmoveEvent = document.createEvent('MouseEvent');
            var delta = 20;
            touchmoveEvent.initMouseEvent('touchmove', false, false, null, null, delta, 0, delta, 0);
            element[0].dispatchEvent(touchmoveEvent);

            // Create and dispatch event manually
            var touchendEvent = document.createEvent('MouseEvent');
            touchendEvent.initMouseEvent('touchend');
            element[0].dispatchEvent(touchendEvent);

            // Check if the touch-click attributes have been evaluated
            expect(scope.evaluated).to.equal(false);
        });

        it('should not evaluate the touch-click attributes after a movement (y axis) on Apple devices', function () {

            // Set the user agent
            $window.navigator = {
                userAgent: userAgent.iPad
            };

            // Create the scope and the element which contains the touch-click directive
            var scope = $rootScope.$new();
            var element = $compile('<div touch-click="evaluated = true"></div>')(scope);
            $rootScope.$digest();

            scope.evaluated = false;

            // Create and dispatch event manually
            var touchstartEvent = document.createEvent('MouseEvent');
            touchstartEvent.initMouseEvent('touchstart');
            element[0].dispatchEvent(touchstartEvent);

            // Create and dispatch event manually
            var touchmoveEvent = document.createEvent('MouseEvent');
            var delta = 20;
            touchmoveEvent.initMouseEvent('touchmove', false, false, null, null, 0, delta, 0, delta);
            element[0].dispatchEvent(touchmoveEvent);

            // Create and dispatch event manually
            var touchendEvent = document.createEvent('MouseEvent');
            touchendEvent.initMouseEvent('touchend');
            element[0].dispatchEvent(touchendEvent);

            // Check if the touch-click attributes have been evaluated
            expect(scope.evaluated).to.equal(false);
        });
    });
});
