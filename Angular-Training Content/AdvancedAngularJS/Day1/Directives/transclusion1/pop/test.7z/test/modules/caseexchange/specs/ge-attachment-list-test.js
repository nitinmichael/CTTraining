/*
 *  message-field-directive-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jignesh Parekh<jignesh.parekh@ge.com>
 *  Monique Shotande<moniqueshotande@ge.com>
 */

/**
 * Spec file for Case Exchange > widgets > ge-control-group directive
 */
'use strict';

define(['angular', 'angular-mocks',
        'widgets/ge-attachment-list/ge-attachment-list-directive'],
    function () {
    'use strict';
    describe('GE Attachment List Directive Test Suite::', function () {

        var $compile,
            $rootScope;

        beforeEach(function () {
            // Load actual module
            module('Directive.geAttachmentList');

            // Load Templates
            module('templates');
        });

        describe('Directive fields', function() {
            var element, $compile, rootScope, scope, isolateScope, spy;

            beforeEach(
                inject(function (_$compile_, _$rootScope_) {
                    // The injector unwraps the underscores (_) from around the parameter names when matching
                    $compile = _$compile_;
                    $rootScope = _$rootScope_;
                })
            );

            var elementTemplate, element, scope;

            it('should delete file', function () {
                scope = $rootScope.$new();
                var actFileList = ['first', 'second', 'third'];
                scope.actFileList = actFileList;
                scope.actCallback = sinon.stub();

                elementTemplate = '<ge-attachment-list id="An id" view="false"'
                    + 'header-text="Header Text" attachment-type="DocumentReference"'
                    + 'file-list="actFileList" callback="actCallback()"></ge-attachment-list>';
                element = $compile(elementTemplate)(scope);
                scope.$digest();

                var isolated = element.isolateScope();

                isolated.deleteFile('second');
                expect(isolated.fileList).to.be.an('array');
                expect(isolated.fileList).to.have.length(2);
                expect(scope.actFileList).to.be.an('array');
                expect(scope.actFileList).to.have.length(2);
            });

        });

    });

});
