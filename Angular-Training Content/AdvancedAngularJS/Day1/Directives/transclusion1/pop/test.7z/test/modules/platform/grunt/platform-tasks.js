/**
 * @ngdoc object
 * @name platform.object:platform-tasks
 * @author Benjamin Beeman
 *
 * @description This is the grunt task configuration file for the {@link platform} module.
 */
module.exports = {

    copy:{
        // Only copies the files specific to a module
        expand: true,
        //cwd: 'public/',
        dest: 'bin/',
        src: ['shell/*']
    },
    compress:{
        options: {
            archive: function () {
                return 'bin/platform.zip';
            }
        },
        files: [{ expand: true, src: ['public/modules/platform/*'] }]
    },

    /**
     * @ngdoc property
     * @name karma
     * @propertyOf platform.object:platform-tasks
     *
     * @description Sets up the path to the karma.conf.js file for the platform module unit tests.
     */
    karma : {
        configFile : 'test/modules/platform/karma.conf.js'
    },

    /**
     * @ngdoc property
     * @name shell
     * @propertyOf platform.object:platform-tasks
     *
     * @description Sets up the platform module grunt shell command.
     */
    shell : {
        command : 'pwd && cd test/modules/platform && pwd && mkdir -pv report/junit/test-report && java -jar /workspace/pfhtools_dev/sonar-karma-junit-parser1.0.0/parser.jar specs report/junit/TESTS-xunit.xml report/junit/test-report test.js'
    }
};
