define([ 'angular-mocks', 'modules/platform/directives/dom-element' ], function(ngMocks) {
    describe('Test  domElement', function() {
        var $compile;
        var $rootScope;

        beforeEach(module('platform.directive.dom-element'));

        beforeEach(inject(function(_$compile_, _$rootScope_) {
            $compile = _$compile_;
            $rootScope = _$rootScope_;
        }));

        it('Replaces the element with the appropriate content', function() {

            var testContent = 'MYELEMENT-CONTENTS';
            var scope = $rootScope.$new();
            scope.myelement = {
                contents : function() {
                    return testContent;
                }
            };

            var element = $compile("<div dom-element='myelement'></div>")(scope);
            $rootScope.$digest();
            var html = element.html();
            expect(html).to.contain(testContent);
        });
    });
});