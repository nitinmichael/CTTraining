/*
 *  karma.conf.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Eduardo Mioto<eduardo.miotoh@ge.com>
 */

/**
 * Karma configuration file for Patient View module
 */
module.exports = function (config) {
    'use strict';
    config.set({
        basePath: '../../..',
        // list of files / patterns to load in the browser
        
        // frameworks to use
        // available frameworks: https://npmjs.org/browse/keyword/karma-adapter
        frameworks: ['mocha',  'requirejs','chai-as-promised', 'sinon-chai', 'chai'],
        
        files: [
            // loading the anguler library first to avoid angular dependent library error
            'public/uaf/3rdparty/angular/angular.js',

            // load all the file patterns
            { pattern: 'public/uaf/**/*.js', included: false },
            { pattern: 'public/modules/patient-view/**/*.js', included: false },
            'public/modules/patient-view/widgets/**/*.html',
            { pattern: 'test/modules/patient-view/specs/**/*-test.js', included: false },
            // This is a main test config file
            'test/modules/patient-view/test-main.js'
        ],
        // list of files to exclude
        exclude: [
            //'public/uaf/3rdparty/**/*.min.js',
        ],

        // preprocess matching files before serving them to the browser
        // available preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor
        preprocessors: {
            'public/modules/patient-view/**/*.js': ['coverage']
        },

        /**
         * Code Coverage Reporter Plug-in options
         */
        coverageReporter: {
            // Directory path (relative to base path) to store the generated report
            dir: 'test/modules/patient-view/report/coverage',

            // Type of a report to generate
            reporters: [
              {type : 'lcovonly',subdir: 'lcovonly'},
              {type : 'html',subdir: 'html'}
          ]
        },

        /**
         * JUnit Reporter options
         */
        junitReporter: {
            outputFile: 'test/modules/patient-view/report/junit/TESTS-xunit.xml',
            suite: ''
        },

        reporters: ['progress','coverage','junit'],


        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
        logLevel: config.LOG_DEBUG,

        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: true,

        // web server port
        port: 9876,


        // enable / disable colors in the output (reporters and logs)
        colors: true,

        // start these browsers
        // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
        browsers: ['PhantomJS'],


        // Continuous Integration mode
        // if true, Karma captures browsers, runs the tests and exits
        singleRun: false
    });
};
