/*
 * ge-transaction-list-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define([ 'angular-mocks',  'modules/platform/directives/ge-transaction-list/ge-transaction-list-directive' ], function() {
    'use strict';

    describe('Transaction list controller', function () {
        var scope, controller, location, state;

        beforeEach(function() {
            module('platform.directive.ge-transaction-list-directive', function ($provide) {
                $provide.value('$state', {
                    transitionTo: function (url) {
                    },
                    go: function (url) {
                    },
                    current: {
                        params: {},
                        name: 'current'
                    }
                });
            });
        });

        beforeEach(function () {
            module('platform.directive.ge-transaction-list-directive');
            inject(function ($rootScope, $location, _$controller_) {
                scope = $rootScope.$new();
                location = $location;
                state = {
                    go: sinon.spy(),
                    current: {
                        params: {},
                        name: 'current'
                    }
                };
                controller = _$controller_('geTransactionListCtrl', {
                    $scope: scope,
                    $location: location,
                    $state: state
                });
            });
        });

        it("should have a controller defined", function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it("should have an openViewer method defined", function() {
            assert.isDefined(scope.openViewer);
        });

        it("should open non-dicom viewer", function() {
            var nonDicomAttachment = {
                type: 'DocumentReference',
                uri: 'a/b/c/d/caseId1/e/attachmentId1',
                description: 'Test non-dicom attachment'
            };

            scope.openViewer(nonDicomAttachment);

            var path = location.path();
            var searchObject = location.search();

            expect(state.go.calledOnce).to.be.true;
        });

        it("should open dicom viewer", function() {
            scope.caseId = 'caseId2';

            var dicomAttachment = {
                type: 'ImagingStudy',
                uri: 'a/b/c/d/caseId2/e/attachmentId2',
                description: 'Test dicom attachment',
                studyId: 'studyId2'
            };

            scope.openViewer(dicomAttachment);

            expect(state.go.calledOnce).to.be.true;
        });
    });

    describe('Transaction list directive', function() {
        var $compile;
        var $rootScope;

        beforeEach(module('templates'));
        beforeEach(module('platform.directive.ge-transaction-list-directive', function ($provide) {
            ['translateFilter', 'gePatientNameFilter'].forEach(function(f){
                $provide.value(f, function(val){
                    return val;
                });
            });

            $provide.value('$state', {
                transitionTo: function (url) {
                },
                go: function (url) {
                },
                current: {
                    params: {}
                }
            });
        }));

        beforeEach(inject(function(_$compile_, _$rootScope_) {
            $compile = _$compile_;
            $rootScope = _$rootScope_;
        }));

        it('should be defined', function() {
            var scope = $rootScope.$new();
            console.log(scope);

            scope.transactions = [
                {
                    createdDate: 1446556085141,
                    creator: {
                        name: 'Test Creator1'
                    },
                    documentType: 'Transaction',
                    message: 'Test message 1'
                },
                {
                    createdDate: 1446556059005,
                    creator: {
                        name: 'Test Creator2'
                    },
                    documentType: 'transaction',
                    message: 'Case for MDT'
                }];
            scope.caseId = 'abc123';

            var element = $compile("<ge-transaction-list transactions='transactions' case-id='caseId'></ge-transaction-list>")(scope);
            $rootScope.$digest();
            var html = element.html();
            expect(html).to.have.length.of.at.least(1);
        });
    });
});