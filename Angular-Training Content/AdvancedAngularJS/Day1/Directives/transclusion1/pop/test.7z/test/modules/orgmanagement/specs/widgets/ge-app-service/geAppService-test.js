define(['angular','postal','angular-mocks','orgMgmnt/widgets/ge-app-service/geAppService'],
    function (ng) {
        'use strict';
        describe('Tests ge-app-service controller', function(){
            var scope, geAppServiceCtrl,event,rootScope,compile,templateCache,appServiceObj,_$timeout,keys;
            var createControllerScopeUsingIsolatedScope=function(str){
                var ele=angular.element('<ge-app-service mode-type="'+str+'"></ge-app-service>');
                inject(function($rootScope,$compile,$templateCache,$controller,appServiceFactory,$timeout){
                    var templateHtml = $templateCache.get('./modules/orgmanagement/widgets/ge-app-service/geAppService.html');
                    if(!templateHtml) {
                       templateHtml = '<div data-ng-controller="geAppServiceCtrl"></div>',
                        $templateCache.put('./modules/orgmanagement/widgets/ge-app-service/geAppService.html', templateHtml);
                    }
                    keys = [];
                    rootScope=$rootScope;
                    _$timeout = $timeout;
                    scope = $rootScope.$new();
                    scope.modeType=str;
                    $compile(ele)(scope);
                //    scope.$digest();
                    geAppServiceCtrl = $controller('geAppServiceCtrl', {$scope:scope,$timeout:_$timeout});
                    appServiceObj = appServiceFactory;

                });
            };
            beforeEach( function(){
                module('listOfApplicationServiceModules');
            });

            describe('Test mode type scenarios', function () {
              var listofAppServices={};
              listofAppServices.status =false;
              it('checks mode type variable if context is specified', function(){
                createControllerScopeUsingIsolatedScope('edit');
                  chai.expect(scope.modeType).to.equal('edit');
              });

              it('click on cancel button on list of appService', function(){
                scope.cancelAppServiceEditable();
                chai.expect(scope.modeType).to.equal('view');
              });



              it('factory set and get list of app for user', function(){
                  var responseObj =[{"title":null,"id":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","content":{"resourceType":"ResourcesApplicationService","type":"dicom-send","name":"CPACS","endpoint":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae0411","display":"YKSITE1"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}},{"title":null,"id":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","content":{"resourceType":"ResourcesApplicationService","type":"dicom-query-retrieve","name":"CPACS","endpoint":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE1"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}}];
                  var selectedStatus={"check":true,"obj":{"title":null,"id":"df5f2880-cc71-4401-8868-d85509eae041","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>This is a test site</div>"},"name":"YKSITE1","address":[{"line":["3354, uuy","yyu"],"city":"BSD","state":"ALABAMA","zip":"66789","country":"United States of America"}],"partOf":{"reference":"organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}}}};
                  var temp ={"responseObj":[{"title":null,"id":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","content":{"resourceType":"ResourcesApplicationService","type":"dicom-send","name":"CPACS","endpoint":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE1"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}},{"title":null,"id":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","content":{"resourceType":"ResourcesApplicationService","type":"dicom-query-retrieve","name":"CPACS","endpoint":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE1"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}}],"status":{"check":true,"obj":{"title":null,"id":"df5f2880-cc71-4401-8868-d85509eae041","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>This is a test site</div>"},"name":"YKSITE1","address":[{"line":["3354, uuy","yyu"],"city":"BSD","state":"ALABAMA","zip":"66789","country":"United States of America"}],"partOf":{"reference":"organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}}}}};
                  appServiceObj.setmanageObject(responseObj,selectedStatus);
                  chai.expect(appServiceObj.getmanageObject().responseObj).to.equal(responseObj);
                  });

                  it('factory set and get list of app for user if value is undefined', function(){
                      var responseObj = undefined;
                      var responseObj1 =[{"title":null,"id":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","content":{"resourceType":"ResourcesApplicationService","type":"dicom-send","name":"CPACS","endpoint":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae0411","display":"YKSITE1"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}},{"title":null,"id":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","content":{"resourceType":"ResourcesApplicationService","type":"dicom-query-retrieve","name":"CPACS","endpoint":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE1"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}}];
                      var selectedStatus=undefined;
                      var temp ={"responseObj":[{"title":null,"id":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","content":{"resourceType":"ResourcesApplicationService","type":"dicom-send","name":"CPACS","endpoint":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE1"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}},{"title":null,"id":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","content":{"resourceType":"ResourcesApplicationService","type":"dicom-query-retrieve","name":"CPACS","endpoint":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE1"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}}],"status":{"check":true,"obj":{"title":null,"id":"df5f2880-cc71-4401-8868-d85509eae041","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>This is a test site</div>"},"name":"YKSITE1","address":[{"line":["3354, uuy","yyu"],"city":"BSD","state":"ALABAMA","zip":"66789","country":"United States of America"}],"partOf":{"reference":"organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}}}}};
                      appServiceObj.setmanageObject(responseObj,selectedStatus);
                      chai.expect(appServiceObj.getmanageObject().responseObj.length).to.equal(responseObj1.length);

                      });



              it('updateViewAppObj true', function(){
                var  listofAppServices={"responseObj":[
                  {"title":null,"id":"1365fec6-a6a8-49a2-8772-5f342cca724f","content":{"resourceType":"ResourcesApplicationService","type":"hl7-send","name":"CPACS1","endpoint":"1365fec6-a6a8-49a2-8772-5f342cca724f","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE3"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}},{"title":null,"id":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","content":{"resourceType":"ResourcesApplicationService","type":"dicom-send","name":"CPACS","endpoint":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE3"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}},{"title":null,"id":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","content":{"resourceType":"ResourcesApplicationService","type":"dicom-query-retrieve","name":"CPACS","endpoint":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE3"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}}],
                  "status":{"check":true,"obj":{"title":null,"id":"8f24e3e9-0cd4-4b10-b61d-2de4d4374a1a","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>This is a test site</div>"},"name":"YKSITE3","address":[{"line":["3354, uuy","yyu"],"city":"BSD","state":"ALABAMA","zip":"66789","country":"United States of America"}],"partOf":{"reference":"organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}}}}};
                scope.updateViewAppObj(listofAppServices);
              });

              it('updateViewAppObj false', function(){

                var  listofAppServices={"responseObj":[{"title":null,"id":"1365fec6-a6a8-49a2-8772-5f342cca724f","content":{"resourceType":"ResourcesApplicationService","type":"hl7-send","name":"CPACS1","endpoint":"1365fec6-a6a8-49a2-8772-5f342cca724f","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE3"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}},{"title":null,"id":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","content":{"resourceType":"ResourcesApplicationService","type":"dicom-send","name":"CPACS","endpoint":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE3"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}},{"title":null,"id":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","content":{"resourceType":"ResourcesApplicationService","type":"dicom-query-retrieve","name":"CPACS","endpoint":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE3"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}}],"status":{"check":false,"obj":{"title":null,"id":"8f24e3e9-0cd4-4b10-b61d-2de4d4374a1a","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>This is a test site</div>"},"name":"YKSITE3","address":[{"line":["3354, uuy","yyu"],"city":"BSD","state":"ALABAMA","zip":"66789","country":"United States of America"}],"partOf":{"reference":"organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}}}}};
                scope.updateViewAppObj(listofAppServices);

              });
              it('updateViewAppObj if no appservice', function(){
                var  listofAppServices=undefined;
                scope.updateViewAppObj(listofAppServices);
              });

              it('updateViewAppObj if  remove appservice', function(){
                scope.output=[{"siteName":"GE Healthcare San Ramon","siteId":"350143e8-80b3-47df-9411-f90befae04e3","appServiceList":[{"id":"074b1d9e-f9ee-45ef-8aec-05cc81cd9181","name":"EA San Ramon","serviceType":"dicom","capabilityArray":["send"],"capabilityArrayJSON":[{"name":"send"}]},{"id":"468afae6-3074-4da5-9115-613743047e35","name":"PACS San Ramon","serviceType":"dicom","capabilityArray":["send","query-retrieve"],"capabilityArrayJSON":[{"name":"send"},{"name":"query-retrieve"}]}]}];
                var  listofAppServices={"responseObj":[{"title":null,"id":"1365fec6-a6a8-49a2-8772-5f342cca724f","content":{"resourceType":"ResourcesApplicationService","type":"hl7-send","name":"CPACS1","endpoint":"1365fec6-a6a8-49a2-8772-5f342cca724f","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE3"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}},{"title":null,"id":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","content":{"resourceType":"ResourcesApplicationService","type":"dicom-send","name":"CPACS","endpoint":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE3"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}},{"title":null,"id":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","content":{"resourceType":"ResourcesApplicationService","type":"dicom-query-retrieve","name":"CPACS","endpoint":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/350143e8-80b3-47df-9411-f90befae04e3","display":"YKSITE3"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}}],
                "status":{"check":false,"obj":{"title":null,"id":"350143e8-80b3-47df-9411-f90befae04e3","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>This is a test site</div>"},"name":"YKSITE3","address":[{"line":["3354, uuy","yyu"],"city":"BSD","state":"ALABAMA","zip":"66789","country":"United States of America"}],"partOf":{"reference":"organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}}}}};
                scope.updateViewAppObj(listofAppServices);
              });

              it('Merge App check capabilities',function()
              {
                var capabilities1 =["send","retrieve"];
                var capabilities2 =["send"];
                scope.compareApplicationServiceCapabilitiesList(capabilities1,capabilities2);
              });

              it('compareApplicationServiceList ',function()
              {
                var appList1 =[{
        "id": "074b1d9e-f9ee-45ef-8aec-05cc81cd9181",
        "name": "EA San Ramon",
        "serviceType": "dicom",
        "capabilityArray": [
          "send"
        ],
        "capabilityArrayJSON": [
          {
            "name": "send"
          }
        ]
      }];

      var appList2 =[{
"id": "074b1d9e-f9ee-45ef-8aec-05cc81cd9181",
"name": "EA San Ramon",
"serviceType": "dicom",
"capabilityArray": [
"send"
],
"capabilityArrayJSON": [
{
  "name": "send"
}
]
}];
  scope.compareApplicationServiceList(appList1,appList2);
});
              it('test set and get App Service Title factory ', function(){
                  appServiceObj.setAppServiceTitle("EDGE");
                  chai.expect(appServiceObj.getAppServiceTitle()).to.equal('EDGE');
              });

              it('factory set and get list of app for list of sites    ', function(){
                var temp =[{"title":null,"id":"870a98ff-0628-4bbf-bd9c-f31b9a4dce91","content":{"resourceType":"Organization","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"Concord Medical Center"}]}}}];
                appServiceObj.setBulkApplicationService(temp);
                chai.expect(appServiceObj.getBulkApplicationService()).to.equal(temp);
                });

                it('factory set and get list of app for user', function(){
                  var temp =[{"title":null,"id":"870a98ff-0628-4bbf-bd9c-f31b9a4dce91","content":{"resourceType":"Organization","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"Concord Medical Center"}]}}}];
                  createControllerScopeUsingIsolatedScope('edit');
                  appServiceObj.setDisplyApplicationService(temp);
                  chai.expect(appServiceObj.getDisplyApplicationService()).to.equal(temp);
                  });


                  it('Crate Object list of app Service for sites matching case', function(){
                //  var output =[{"siteId":"be94f53a-607b-41f5-b904-b28b2294bbf3t","siteName":"name2","appServiceList":[{"capabilities":["send"],"name":"EDGE","serviceType":"dicom"}]},

                //{"siteId":"1be94f53a-607b-41f5-b904-b28b2294bbf3","siteName":"name2","appServiceList":[{"capabilities":["send"],"name":"EDGE","serviceType":"dicom"}]}];
                keys = ["site/350143e8-80b3-47df-9411-f90befae04e3"]
                var output=[{"siteName":"GE Healthcare San Ramon","siteId":"350143e8-80b3-47df-9411-f90befae04e3","appServiceList":[{"id":"074b1d9e-f9ee-45ef-8aec-05cc81cd9181","name":"EA San Ramon","serviceType":"dicom","capabilityArray":["send"],"capabilityArrayJSON":[{"name":"send"}]},{"id":"468afae6-3074-4da5-9115-613743047e35","name":"PACS San Ramon","serviceType":"dicom","capabilityArray":["send","query-retrieve"],"capabilityArrayJSON":[{"name":"send"},{"name":"query-retrieve"}]}]}];

                  var tempobj =[{
                  "title": null,
                  "id": "1230a5af-cfcb-490c-933f-2e1df35293b6",
                  "content": {
                    "resourceType": "ResourcesApplicationService",
                    "type": "dicom",
                    "capability": [
                      "send",
                      "query-retrieve"
                    ],
                    "name": "nammo",
                    "endpoint": "1230a5af-cfcb-490c-933f-2e1df35293b6",
                    "gateway": {
                      "reference": "device/bbe35397-9141-4792-af10-0557fbc6cf6a",
                      "display": "TEST DEVICE ABCD"
                    },
                    "owner": {
                      "reference": "site/350143e8-80b3-47df-9411-f90befae04e3",
                      "display": "TEST SITE ABCD"
                    },
                    "networkAddress": {
                      "ip": "1.2.3.4",
                      "entityName": "ae",
                      "port": 900
                    }
                  }
                },    {
      "title": null,
      "id": "15c37cc3-f2f8-46f3-a225-3f414a7da774",
      "content": {
        "resourceType": "ResourcesApplicationService",
        "type": "hl7",
        "capability": [
          "send",
          "query-retrieve"
        ],
        "name": "Namrata servcie app",
        "endpoint": "15c37cc3-f2f8-46f3-a225-3f414a7da774",
        "gateway": {
          "reference": "device/bbe35397-9141-4792-af10-0557fbc6cf6a",
          "display": "test device"
        },
        "owner": {
          "reference": "site/350143e8-80b3-47df-9411-f90befae04e3",
          "display": "ge hc"
        },
        "networkAddress": {
          "ip": "123.44.55.66",
          "entityName": "test1",
          "port": 89
        }
      }
    }
];
                  scope.CreateObject(tempobj);
                  });


                  it('edit application services', function(){
                  var temp =[{"title":null,"id":"1230a5af-cfcb-490c-933f-2e1df35293b6","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"nammo","endpoint":"1230a5af-cfcb-490c-933f-2e1df35293b6","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"ae","port":900}}},{"title":null,"id":"15c37cc3-f2f8-46f3-a225-3f414a7da774","content":{"resourceType":"ResourcesApplicationService","type":"hl7","capability":["send","query-retrieve"],"name":"Namrata servcie app","endpoint":"15c37cc3-f2f8-46f3-a225-3f414a7da774","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"test device"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"ge hc"},"networkAddress":{"ip":"123.44.55.66","entityName":"test1","port":89}}},{"title":null,"id":"2477016c-80a8-4806-849b-bf300ce46133","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"happy","endpoint":"2477016c-80a8-4806-849b-bf300ce46133","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"111","port":112}}},{"title":null,"id":"407c8467-a2b8-4ec0-bbba-0bda2b50b9aa","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"nammo","endpoint":"407c8467-a2b8-4ec0-bbba-0bda2b50b9aa","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"ae","port":900}}},{"title":null,"id":"569c1c94-623c-4b84-842f-0bd54870e08b","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"update test","endpoint":"569c1c94-623c-4b84-842f-0bd54870e08b","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"111111","port":1}}},{"title":null,"id":"63d08076-063e-43fa-b77c-554812a3c14e","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"update test","endpoint":"63d08076-063e-43fa-b77c-554812a3c14e","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"111111","port":1}}},{"title":null,"id":"7d93acd4-9a2d-4088-91eb-076a6d4be566","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"update test","endpoint":"7d93acd4-9a2d-4088-91eb-076a6d4be566","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"111111","port":1}}},{"title":null,"id":"7e09f1c2-2720-4b9a-a1ba-26fb3716f3f0","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"roy","endpoint":"7e09f1c2-2720-4b9a-a1ba-26fb3716f3f0","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"roy title","port":700}}},{"title":null,"id":"8d0bd34d-3c74-49a2-9b53-4a84b83251ed","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"update test","endpoint":"8d0bd34d-3c74-49a2-9b53-4a84b83251ed","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"111111","port":1}}},{"title":null,"id":"9c0d5b5a-9d35-47f9-b34b-ebc24631840a","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"nammo","endpoint":"9c0d5b5a-9d35-47f9-b34b-ebc24631840a","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"ae","port":900}}},{"title":null,"id":"aa010ccf-a863-494e-843c-3d044fd7e84b","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"nammo","endpoint":"aa010ccf-a863-494e-843c-3d044fd7e84b","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"ae","port":900}}},{"title":null,"id":"abbaf670-8bbc-467c-8e2d-fbceafd4c3d9","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"update test","endpoint":"abbaf670-8bbc-467c-8e2d-fbceafd4c3d9","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"111111","port":1}}},{"title":null,"id":"b3b64015-fb1a-4903-bfa2-b540b199bd2d","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"update test","endpoint":"b3b64015-fb1a-4903-bfa2-b540b199bd2d","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"111111","port":1}}},{"title":null,"id":"b43181e9-0222-4310-bd24-3113b4809a0a","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"roy","endpoint":"b43181e9-0222-4310-bd24-3113b4809a0a","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"roy title","port":700}}},{"title":null,"id":"be741d39-4eaa-447c-8838-fb5a6b302deb","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"update test","endpoint":"be741d39-4eaa-447c-8838-fb5a6b302deb","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"111111","port":1}}},{"title":null,"id":"be3700db-cfe5-4942-b262-cccbc1f38838","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"update test","endpoint":"be3700db-cfe5-4942-b262-cccbc1f38838","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"111111","port":1}}},{"title":null,"id":"d2693227-8d66-420f-a1b4-29b680df3e7c","content":{"resourceType":"ResourcesApplicationService","type":"dicom","capability":["send","query-retrieve"],"name":"HOLY","endpoint":"d2693227-8d66-420f-a1b4-29b680df3e7c","gateway":{"reference":"device/bbe35397-9141-4792-af10-0557fbc6cf6a","display":"TEST DEVICE ABCD"},"owner":{"reference":"site/be94f53a-607b-41f5-b904-b28b2294bbf3","display":"TEST SITE ABCD"},"networkAddress":{"ip":"1.2.3.4","entityName":"AA","port":123}}}];

                  appServiceObj.setBulkApplicationService(temp);
                  scope.sitesWithAppServices = [{"siteName":"GEHealthcareSTO-I","appServiceList":[{"capabilities":["send","retrieve"],"name":"EDGE","serviceType":"dicom"},{"capabilities":["send","retrieve"],"name":"EDGE","serviceType":"HL7"},{"capabilities":["send","retrieve"],"name":"CPACS","serviceType":"HL7"}]},{"siteName":"Fantastic","appServiceList":[{"capabilities":["send","retrieve"],"name":"CPACS","serviceType":"dicom"},{"capabilities":["send","retrieve"],"name":"EGDE","serviceType":"HL7"},{"capabilities":["send","retrieve"],"name":"DCD251X","serviceType":"dicom"}]},{"siteName":"World Health","appServiceList":[{"capabilities":["send"],"name":"DCD251X","serviceType":"dicom"},{"capabilities":["retrieve"],"name":"DCD251X","serviceType":"HL7"}]}];
                  scope.editApplicationServices();
                  createControllerScopeUsingIsolatedScope('edit');
                  chai.expect(scope.modeType).to.equal('edit');
                  });

                  it('edit application services', function(){
                  var temp =[{"title":null,"id":"2287ec33-3a6b-4654-85e3-81d4389ea8d8","content":{"resourceType":"ResourcesApplicationService","type":"dicom-send","name":"EDGE","endpoint":"2287ec33-3a6b-4654-85e3-81d4389ea8d8","gateway":{"reference":"device/14a346f2-6c9d-4339-b8df-e8dc29665d5b","display":"Sparx"},"owner":{"reference":"site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1","display":"GEHealthcareSTO-I"},"networkAddress":{"ip":"3.39.74.34","entityName":"AE_LHK_VNV_EDG2","port":104}}},{"title":null,"id":"81d4389ea8d8-3a6b-4654-85e3-2287ec33","content":{"resourceType":"ResourcesApplicationService","type":"dicom-retrieve","name":"EDGE1","endpoint":"2287ec33-3a6b-4654-85e3-81d4389ea8d8","gateway":{"reference":"device/14a346f2-6c9d-4339-b8df-e8dc29665d5b","display":"Sparx"},"owner":{"reference":"site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1","display":"GEHealthcareSTO-I"},"networkAddress":{"ip":"3.39.74.34","entityName":"AE_LHK_VNV_EDG2","port":104}}},{"title":null,"id":"2287ec33-3a6b-4654-85e3-81d4389ea8d8","content":{"resourceType":"ResourcesApplicationService","type":"HL7-send","name":"EDGE","endpoint":"2287ec33-3a6b-4654-85e3-81d4389ea8d8","gateway":{"reference":"device/14a346f2-6c9d-4339-b8df-e8dc29665d5b","display":"Sparx"},"owner":{"reference":"site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1","display":"GEHealthcareSTO-I"},"networkAddress":{"ip":"3.39.74.34","entityName":"AE_LHK_VNV_EDG2","port":105}}},{"title":null,"id":"81d4389ea8d8-3a6b-4654-85e3-2287ec33","content":{"resourceType":"ResourcesApplicationService","type":"HL7-retrieve","name":"EDGE","endpoint":"2287ec33-3a6b-4654-85e3-81d4389ea8d8","gateway":{"reference":"device/14a346f2-6c9d-4339-b8df-e8dc29665d5b","display":"Sparx"},"owner":{"reference":"site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1","display":"GEHealthcareSTO-I"},"networkAddress":{"ip":"3.39.74.34","entityName":"AE_LHK_VNV_EDG2","port":105}}},{"title":null,"id":"2287ec33-3a6b-4654-85e3-81d4389ea8d8","content":{"resourceType":"ResourcesApplicationService","type":"HL7-send","name":"CPACS","endpoint":"2287ec33-3a6b-4654-85e3-81d4389ea8d8","gateway":{"reference":"device/14a346f2-6c9d-4339-b8df-e8dc29665d5b","display":"Sparx"},"owner":{"reference":"site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1","display":"GEHealthcareSTO-I"},"networkAddress":{"ip":"3.39.74.34","entityName":"AE_LHK_VNV_EDG2","port":106}}},{"title":null,"id":"81d4389ea8d8-3a6b-4654-85e3-2287ec33","content":{"resourceType":"ResourcesApplicationService","type":"HL7-retrieve","name":"CPACS","endpoint":"2287ec33-3a6b-4654-85e3-81d4389ea8d8","gateway":{"reference":"device/14a346f2-6c9d-4339-b8df-e8dc29665d5b","display":"Sparx"},"owner":{"reference":"site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1","display":"GEHealthcareSTO-I"},"networkAddress":{"ip":"3.39.74.34","entityName":"AE_LHK_VNV_EDG2","port":106}}},{"title":null,"id":"85adea60-61fe-4696-9628-e632b87fe0f0","content":{"resourceType":"ResourcesApplicationService","type":"dicom-send","name":"CPACS","endpoint":"/v1/application/hcig-14a346f2-6c9d-4339-b8df-e8dc29665d5b/configitem/AppConfig/revisionid/1","gateway":{"reference":"device/14a346f2-6c9d-4339-b8df-e8dc29665d5b","display":"Sparx"},"owner":{"reference":"site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1","display":"Fantastic"},"networkAddress":{"ip":"3.235.116.143","entityName":"AE_ARCH1","port":4100}}},{"title":null,"id":"e632b87fe0f0-61fe-4696-9628-85adea60","content":{"resourceType":"ResourcesApplicationService","type":"dicom-retrieve","name":"CPACS","endpoint":"/v1/application/hcig-14a346f2-6c9d-4339-b8df-e8dc29665d5b/configitem/AppConfig/revisionid/1","gateway":{"reference":"device/14a346f2-6c9d-4339-b8df-e8dc29665d5b","display":"Sparx"},"owner":{"reference":"site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1","display":"Fantastic"},"networkAddress":{"ip":"3.235.116.143","entityName":"AE_ARCH1","port":4100}}},{"title":null,"id":"85adea60-61fe-4696-9628-e632b87fe0f0","content":{"resourceType":"ResourcesApplicationService","type":"HL7-send","name":"EGDE","endpoint":"/v1/application/hcig-14a346f2-6c9d-4339-b8df-e8dc29665d5b/configitem/AppConfig/revisionid/1","gateway":{"reference":"device/14a346f2-6c9d-4339-b8df-e8dc29665d5b","display":"Sparx"},"owner":{"reference":"site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1","display":"Fantastic"},"networkAddress":{"ip":"3.235.116.143","entityName":"AE_ARCH1","port":410}}},{"title":null,"id":"e632b87fe0f0-61fe-4696-9628-85adea60","content":{"resourceType":"ResourcesApplicationService","type":"HL7-retrieve","name":"EGDE","endpoint":"/v1/application/hcig-14a346f2-6c9d-4339-b8df-e8dc29665d5b/configitem/AppConfig/revisionid/1","gateway":{"reference":"device/14a346f2-6c9d-4339-b8df-e8dc29665d5b","display":"Sparx"},"owner":{"reference":"site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1","display":"Fantastic"},"networkAddress":{"ip":"3.235.116.143","entityName":"AE_ARCH1","port":410}}},{"title":null,"id":"dea6085a-61fe-9628-4696-7fe0f0e632b8","content":{"resourceType":"ResourcesApplicationService","type":"dicom-send","name":"DCD251X","endpoint":"/v1/application/hcig-14a346f2-6c9d-4339-b8df-e8dc29665d5b/configitem/AppConfig/revisionid/1","gateway":{"reference":"device/14a346f2-6c9d-4339-b8df-e8dc29665d5b","display":"Sparx"},"owner":{"reference":"site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1","display":"Fantastic"},"networkAddress":{"ip":"3.235.116.143","entityName":"AE_ARCH1","port":107}}},{"title":null,"id":"dea6085a-61fe-9628-4696-7fe0f0e632b8","content":{"resourceType":"ResourcesApplicationService","type":"dicom-retrieve","name":"DCD251X","endpoint":"/v1/application/hcig-14a346f2-6c9d-4339-b8df-e8dc29665d5b/configitem/AppConfig/revisionid/1","gateway":{"reference":"device/14a346f2-6c9d-4339-b8df-e8dc29665d5b","display":"Sparx"},"owner":{"reference":"site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1","display":"Fantastic"},"networkAddress":{"ip":"3.235.116.143","entityName":"AE_ARCH1","port":107}}},{"title":null,"id":"dea6085a-61fe-9628-4696-7fe0f0e632b8","content":{"resourceType":"ResourcesApplicationService","type":"dicom-send","name":"DCD251X","endpoint":"/v1/application/hcig-14a346f2-6c9d-4339-b8df-e8dc29665d5b/configitem/AppConfig/revisionid/1","gateway":{"reference":"device/14a346f2-6c9d-4339-b8df-e8dc29665d5b","display":"Sparx"},"owner":{"reference":"site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1","display":"World Health"},"networkAddress":{"ip":"3.235.116.143","entityName":"AE_ARCH1","port":108}}},{"title":null,"id":"dea6085a-61fe-9628-4696-7fe0f0e632b8","content":{"resourceType":"ResourcesApplicationService","type":"HL7-retrieve","name":"DCD251X","endpoint":"/v1/application/hcig-14a346f2-6c9d-4339-b8df-e8dc29665d5b/configitem/AppConfig/revisionid/1","gateway":{"reference":"device/14a346f2-6c9d-4339-b8df-e8dc29665d5b","display":"Sparx"},"owner":{"reference":"site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1","display":"World Health"},"networkAddress":{"ip":"3.235.116.143","entityName":"AE_ARCH1","port":109}}}];
                  appServiceObj.setBulkApplicationService(temp);
                  scope.sitesWithAppServices = [{"siteName":"GEHealthcareSTO-I","appServiceList":[{"capabilities":[],"name":"EDGE","serviceType":"dicom"},{"capabilities":["send","retrieve"],"name":"EDGE","serviceType":"HL7"},{"capabilities":["send","retrieve"],"name":"CPACS","serviceType":"HL7"}]},{"siteName":"Fantastic","appServiceList":[{"capabilities":["send","retrieve"],"name":"CPACS","serviceType":"dicom"},{"capabilities":["send","retrieve"],"name":"EGDE","serviceType":"HL7"},{"capabilities":["send","retrieve"],"name":"DCD251X","serviceType":"dicom"}]},{"siteName":"World Health","appServiceList":[{"capabilities":["send"],"name":"DCD251X","serviceType":"dicom"},{"capabilities":["retrieve"],"name":"DCD251X","serviceType":"HL7"}]}];
                  scope.editApplicationServices();
                  createControllerScopeUsingIsolatedScope('edit');
                  chai.expect(scope.modeType).to.equal('edit');
                  });



                  it('factory set and get list of app for user if value is undefined3', function(){
                    var  listofAppServices={"responseObj":[
                      {"title":null,"id":"1365fec6-a6a8-49a2-8772-5f342cca724f","content":{"resourceType":"ResourcesApplicationService","type":"hl7-send","name":"CPACS1","endpoint":"1365fec6-a6a8-49a2-8772-5f342cca724f","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE3"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}},{"title":null,"id":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","content":{"resourceType":"ResourcesApplicationService","type":"dicom-send","name":"CPACS","endpoint":"bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE3"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}},{"title":null,"id":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","content":{"resourceType":"ResourcesApplicationService","type":"dicom-query-retrieve","name":"CPACS","endpoint":"fa5a4162-fcfd-4e36-8a25-89df29f40c3a","gateway":{"reference":"device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"},"owner":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE3"},"networkAddress":{"ip":"111.11.11.1111","entityName":"AE_PACS","port":8080}}}],"status":{"check":true,"obj":{"title":null,"id":"8f24e3e9-0cd4-4b10-b61d-2de4d4374a1a","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>This is a test site</div>"},"name":"YKSITE3","address":[{"line":["3354, uuy","yyu"],"city":"BSD","state":"ALABAMA","zip":"66789","country":"United States of America"}],"partOf":{"reference":"organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}}}}};
                      var selectedStatus1={"check":true,"obj":{"title":null,"id":"df5f2880-cc71-4401-8868-d85509eae041","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>This is a test site</div>"},"name":"YKSITE1","address":[{"line":["3354, uuy","yyu"],"city":"BSD","state":"ALABAMA","zip":"66789","country":"United States of America"}],"partOf":{"reference":"organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}}}};
                      appServiceObj.setmanageObject({"name":"ss"},{"aa":"sss"});
                      appServiceObj.getmanageObject();

                      });
                      it('factory set and get list of app for user if value is undefined2', function(){
                        var temp ={"status":"reset1"};
                          appServiceObj.setmanageObject(temp,{"aa":"sss"});
                          appServiceObj.getmanageObject();
                        })

                        it('factory set and get list of app for user if value is undefined1', function(){
                            var temp ={"status":"reset"};
                            createControllerScopeUsingIsolatedScope('view');
                            appServiceObj.setmanageObject(temp,{"aa":"sss"});
                            appServiceObj.getmanageObject();
                          })
                      it('timeout call ', function(){
                        _$timeout.flush();
                        });


                });

        });

    }
);
