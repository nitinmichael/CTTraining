/*
 *  patient-model-service-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define([
    'postal',
    'angular',
    'angular-mocks',
    'patient-view/services/patient'
], function (postal) {
    'use strict';

    describe('Patient Model test suite', function () {

        var Patient;
        var $httpBackend;
        var $Endpoint;
        var $q;
        var $rootScope;
        var UOMService;
        var UOMServiceMock;
        var IDENTIFIER;
        var RID = "678a7717-e8aa-4a72-811f-aaab5d6799dc";
        var postalMock;
        var endpointDeferred;

        var httpBackendVerify = function () {
            $httpBackend.flush();
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        };

        var resolveEndpoint = function () {
            endpointDeferred.resolve($Endpoint.getEndpoint());
        };

        var rejectEndpoint = function () {
            endpointDeferred.reject();
        }

        beforeEach(module('cloudav.patient-view.patient', function ($provide) {

            $provide.service('$Endpoint', function() {
                this.getEndpoint = function () {
                    return 'http://ge.test.fake.nonexistentdomain';
                };
                this.getEndpointAsync = function () {
                    return endpointDeferred.promise;
                };
            });
        }));

        beforeEach(inject(function (_Patient_, _$httpBackend_, _$Endpoint_, _UOMService_, _$q_, _$rootScope_) {
            Patient = _Patient_;
            $httpBackend = _$httpBackend_;
            $Endpoint = _$Endpoint_;
            $q = _$q_;
            $rootScope = _$rootScope_;
            UOMService = _UOMService_;
            UOMServiceMock = sinon.mock(UOMService);
            IDENTIFIER = [{
                system: 'patientview',
                value: '678a7717'
            },{
                system: '',
                value: '1234567890',
                use:'official'
            }];

            postalMock = sinon.mock(postal);
            endpointDeferred = $q.defer();
        }));

        afterEach(function () {
            UOMServiceMock.restore();
            postalMock.restore();
        });

        it('should get and set rid by the id attribute', function () {
            var patient = new Patient({ rid: '123' });

            expect(patient.rid).to.equal('123');
            expect(patient.id).to.equal('123');
            patient.id = '456';
            expect(patient.rid).to.equal('456');
            expect(patient.id).to.equal('456');
        });

        it('should extend the data argument on constructor', function () {
            var data = {
                identifier: { value: '123'},
                name: 'Callebe',
                birthDate: '2015-09-03T18:56:03+0000'
            };

            var patient = new Patient(data);

            expect(patient.identifier).to.equal(data.identifier);
            expect(patient.name).to.equal('Callebe');
        });

        it('should parse the birthDate attribute if presented', function () {
            var data = {
                birthDate: "2015-07-30T12:49:55Z"
            };

            var patient = new Patient(data);
            assert.isFunction(patient.birthDate.toDateString);

            patient = new Patient({});
            expect(patient.birthDate).to.equal('');
        });

        it('should define a getName method', function () {
            var patient = new Patient();
            assert.isDefined(patient.getFullName, 'getFullName is not defined');
            assert.isFunction(patient.getFullName, 'getFullName is not a function');
        });

        it('should return the PrefixName if presented', function () {
            var patient = new Patient();
            var data = {
                name: [{
                    prefix: ['Sr.', 'Prince']
                }]
            };

            expect(patient.getFullName()).to.equal('');

            patient = new Patient(data);
            expect(patient.getFullName()).to.equal('Sr. Prince');
        });

        it('should return the GivenName if presented', function () {
            var data = {
                name: [{
                    prefix: ['Sr.']
                }]
            };
            var patient = new Patient(data);
            expect(patient.getFullName()).to.equal('Sr.');

            patient.name[0].given = ['Callebe', 'Trindade'];
            expect(patient.getFullName()).to.equal('Sr. Callebe Trindade');

            patient.name[0].prefix = [];
            expect(patient.getFullName()).to.equal('Callebe Trindade');
        });

        it('should return the FamilyName if presented', function () {
            var data = {
                name: [{
                    given: ['Callebe', 'Trindade']
                }]
            };
            var patient = new Patient(data);
            expect(patient.getFullName()).to.equal('Callebe Trindade');

            patient.name[0].family = ['Gomes', 'Silva'];
            expect(patient.getFullName()).to.equal('Callebe Trindade Gomes Silva');            
        });

        it('should return the SuffixName if presented', function () {
            var data = {
                name: [{
                    given: ['Callebe', 'Trindade'],
                    family: ['Gomes']
                }]
            };
            var patient = new Patient(data);
            expect(patient.getFullName()).to.equal('Callebe Trindade Gomes');

            patient.name[0].suffix = ['Jr.'];
            expect(patient.getFullName()).to.equal('Callebe Trindade Gomes Jr.');            
        });

        it('should define a getAge method', function () {
            var patient = new Patient();
            assert.isDefined(patient.getAge, 'getAge is not defined');
            assert.isFunction(patient.getAge, 'getAge is not a function');
        });

        it('should return the patient age if the birthDate is presented', function () {
            var date = new Date();
            date.setFullYear(date.getFullYear() - 2);
            var patient = new Patient({ birthDate: date.toJSON() });
            expect(patient.getAge()).to.equal(2);

            date.setFullYear(date.getFullYear(), date.getMonth(), date.getDate() + 1);
            patient = new Patient({ birthDate: date.toJSON() });
            expect(patient.getAge()).to.equal(1);

            date.setFullYear(date.getFullYear(), date.getMonth(), date.getDate() - 1);
            patient = new Patient({ birthDate: date.toJSON() });
            expect(patient.getAge()).to.equal(2);

            date.setFullYear(date.getFullYear(), date.getMonth() + 1);
            patient = new Patient({ birthDate: date.toJSON() });
            expect(patient.getAge()).to.equal(1);

            date.setFullYear(date.getFullYear(), date.getMonth() - 1);
            patient = new Patient({ birthDate: date.toJSON() });
            expect(patient.getAge()).to.equal(2);
        });

        it('should return undefined if the birthDate is not presented', function () {
            var patient = new Patient();
            assert.isUndefined(patient.getAge(), 'getAge() should return undefined');
        });

        it('shoud define a getBirthDate method', function () {
            var patient = new Patient();
            assert.isDefined(patient.getBirthDate, 'getBirthDate is not defined');
            assert.isFunction(patient.getBirthDate, 'getBirthDate is not a function');
        });

        it('should return the birthDate formated if it is presented', function () {
            var patient = new Patient({
                birthDate: "2015-07-30T12:49:55Z"
            });

            expect(patient.getBirthDate()).to.equal('30 Jul 2015');

            patient.birthDate = '';
            expect(patient.getBirthDate()).to.equal('');
        });

        it('should define a getPatientViewIdentifier method', function () {
            var patient = new Patient({});
            assert.isDefined(patient.getPatientViewIdentifier, 'getPatientViewIdentifier it not defined');
            assert.isFunction(patient.getPatientViewIdentifier, 'getPatientViewIdentifier is not a function');
        });

        it('should return the patientView identifier', function () {
            var patient = new Patient({});
            assert.isNull(patient.getPatientViewIdentifier());

            patient.identifier = [{
                system: '678a7717-e8aa-4a72-811f-aaab5d6799dc',
                value: '1234567890'
            }];
            assert.isNull(patient.getPatientViewIdentifier());

            patient.identifier.push({
                system: 'patientview',
                value: '678a7717-e8aa-4a72-811f-aaab5d6799dc'
            });

            expect(patient.getPatientViewIdentifier()).to.eql({
                system: 'patientview',
                value: '678a7717-e8aa-4a72-811f-aaab5d6799dc'
            });
        });

        it('should define a getOfficialIdentifier method', function () {
            var patient = new Patient({});
            assert.isDefined(patient.getOfficialIdentifier, 'getOfficialIdentifier is not defined');
            assert.isFunction(patient.getOfficialIdentifier, 'getOfficialIdentifier is not a function');
        });

        it('should return the official identifier', function () {
            var patient = new Patient({});
            assert.isNull(patient.getOfficialIdentifier());

            patient.identifier = [];
            assert.isNull(patient.getOfficialIdentifier());

            patient.identifier.unshift({
                system: 'patientview',
                value: '678a7717-e8aa-4a72-811f-aaab5d6799dc'
            });
            assert.isNull(patient.getOfficialIdentifier());

            patient.identifier.unshift({
                system: '',
                value: '1234567890',
                use: 'official'
            });

            expect(patient.getOfficialIdentifier()).to.eql(patient.identifier[0]);
        });

        it('should define a getEndpoint method', function () {
            var patient = new Patient();
            assert.isDefined(patient.getEndpoint, 'getEndpoint is not defined');
            assert.isFunction(patient.getEndpoint, 'getEndpoint is not a function');
        });

        it('should return the endpoint', function () {
            var patient = new Patient({ rid: null });
            expect(patient.getEndpoint()).to.be.null;

            patient.rid = "678a7717-e8aa-4a72-811f-aaab5d6799dc";
            expect(patient.getEndpoint()).to.equal($Endpoint.getEndpoint() + '/patient-view/v1/mypatient/678a7717-e8aa-4a72-811f-aaab5d6799dc');
        });

        it('should encode the "/" to %2F', function () {
            var patient = new Patient({ rid: "678a7717-e8aa-4a72-811f-aaab5/6799dc" });

            expect(patient.getEndpoint()).to.equal($Endpoint.getEndpoint() + '/patient-view/v1/mypatient/678a7717-e8aa-4a72-811f-aaab5%2F6799dc');
        });

        /**
        * getStudies
        */

        it('should define a getStudies method', function () {
            var patient = new Patient({});
            assert.isDefined(patient.getStudies, 'getStudies is not defined');
            assert.isFunction(patient.getStudies, 'getStudies is not a function');
        });

        it('should return the patient details', function () {
            var patient = new Patient({});
            var studies = [{
                id: 'study1'
            }, {
                id: 'study2'
            }];

            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient/' + RID + '/studies')
                .respond(200, {
                    responseList: studies,
                    caseContainerId: '123456'
                });

            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.gettingStudies.call,
                data: patient
            }));
            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.gettingStudies.success,
                data: patient
            }));
            
            expect(patient.getStudies()).to.equal(patient.studies);
            assert.isUndefined(patient.gettingStudies, 'patient.gettingStudies should be undefined');

            patient.rid = RID;
            
            expect(patient.getStudies()).to.equal(patient.studies);
            expect(patient.gettingStudies).to.be.true;

            httpBackendVerify();

            expect(patient.studies).to.eql(studies);
            expect(patient.caseContainerId).to.equal('123456');
            assert.isUndefined(patient.gettingStudies, 'patient.studies should be undefined');
            postalMock.verify();
        });

        it('should not change the studies list if flag studiesUpdated is true', function () {
            var patient = new Patient({
                rid: RID,
                studies: [{attr:1}, {attr:2}],
                studiesUpdated: true
            });
            var studies = [{
                id: 'study1'
            }, {
                id: 'study2'
            }];

            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient/' + RID + '/studies')
                .respond(200, {
                    responseList: studies
                });

            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.gettingStudies.call,
                data: patient
            }));
            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.gettingStudies.success,
                data: patient
            }));
            
            expect(patient.getStudies()).to.equal(patient.studies);
            expect(patient.gettingStudies).to.be.true;

            httpBackendVerify();

            expect(patient.studies).to.not.eql(studies);
            postalMock.verify();
        });

        it('should call the postal when the updatedstudies call returns an error', function () {
            var patient = new Patient({
                rid: RID
            });

            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient/' + RID + '/studies')
                .respond(500);

            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.gettingStudies.call,
                data: patient
            }));
            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.gettingStudies.error,
                data: patient
            }));

            expect(patient.getStudies()).to.equal(patient.studies);
            expect(patient.gettingStudies).to.be.true;

            httpBackendVerify();

            expect(patient.gettingStudies).to.be.undefined;
            postalMock.verify();
        });


        /**
        * getUpdatedStudies
        */

        it('should define a getUpdatedStudies method', function () {
            var patient = new Patient({});
            assert.isDefined(patient.getUpdatedStudies, 'getUpdatedStudies is not defined');
            assert.isFunction(patient.getUpdatedStudies, 'getUpdatedStudies is not a function');
        });

        it('should return the patient details', function () {
            var patient = new Patient({});
            var studies = [{
                id: 'study1'
            }, {
                id: 'study2'
            }];

            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient/' + RID + '/studies/search')
                .respond(200, {
                    responseList: studies,
                    lastUpdate: '2015-01-01T00:00:00Z',
                    caseContainerId: '123456'
                });

            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.gettingUpdatedStudies.call,
                data: patient
            }));
            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.gettingUpdatedStudies.success,
                data: { patient: patient, diff: { currentStudies: studies, previousStudies: [] } }
            }));
            
            expect(patient.getUpdatedStudies()).to.equal(patient.studies);
            assert.isUndefined(patient.gettingUpdatedStudies, 'patient.gettingUpdatedStudies should be undefined');
            assert.isUndefined(patient.studiesUpdated, 'patient.gettingUpdatedStudies should be undefined');

            patient.rid = RID;
            
            expect(patient.getUpdatedStudies()).to.equal(patient.studies);
            expect(patient.gettingUpdatedStudies).to.be.true;

            httpBackendVerify();

            expect(patient.studies).to.eql(studies);
            expect(patient.caseContainerId).to.equal('123456')
            assert.isUndefined(patient.gettingUpdatedStudies, 'patient.studies should be undefined');
            expect(patient.studiesUpdated).to.be.true;
            
            postalMock.verify();
        });

        it('should call the postal when the updatedstudies call returns an error', function () {
            var patient = new Patient({ rid: RID });

            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient/' + RID + '/studies/search')
                .respond(500);

            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.gettingUpdatedStudies.call,
                data: patient
            }));
            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.gettingUpdatedStudies.error,
                data: patient
            }));

            expect(patient.getUpdatedStudies()).to.equal(patient.studies);
            expect(patient.gettingUpdatedStudies).to.be.true;

            httpBackendVerify();

            expect(patient.gettingUpdatedStudies).to.be.undefined;

            postalMock.verify();
        });

        /***/

        it('should define a getApplicationServiceInfo method', function () {
            var patient = new Patient({});
            assert.isDefined(patient.getApplicationServiceInfo, 'getApplicationServiceInfo is not defined');
            assert.isFunction(patient.getApplicationServiceInfo, 'getApplicationServiceInfo is not a function');
        });

        it('should return the UOMService.getMyApplicationServiceInfo return', function () {
            var patient = new Patient({
                identifier: [{
                    system: 'patientview',
                    value: '678a7717'
                }]
            });

            var info = { id: '1', type: 'DICOM', name: 'ABC' };

            UOMServiceMock.expects('getMyApplicationServiceInfo').withArgs('678a7717').returns(info);

            expect(patient.getApplicationServiceInfo()).to.eql(info);
            UOMServiceMock.verify();
        });

        it('should return undefine if patient does not have a patientViewIdentifier', function () {
            var patient = new Patient({});
            assert.isUndefined(patient.getApplicationServiceInfo());
        });

        it('should cache the info and does not call UOMService.getMyApplicationServiceInfo more then once', function () {
            var patient = new Patient({
                identifier: [{
                    system: 'patientview',
                    value: '678a7717'
                }]
            });

            var info = { id: '1', type: 'DICOM', name: 'ABC' };

            UOMServiceMock.expects('getMyApplicationServiceInfo').withArgs('678a7717').once().returns(info);

            // in the first time, call UOMService.getMyApplicationServiceInfo
            expect(patient.getApplicationServiceInfo()).to.eql(info);
            // in the first time, use the cached info
            expect(patient.getApplicationServiceInfo()).to.eql(info);

            UOMServiceMock.verify();
        });

        it('should define uploadStudy method', function () {
            var patient = new Patient({});
            assert.isDefined(patient.uploadStudy, 'patient.uploadStudy is not defined');
            assert.isFunction(patient.uploadStudy, 'patient.uploadStudy is not a function');
        });

        it('should throw an error when the study argument is not passed', function () {
            var patient = new Patient({});
            assert.throws(function () {
                patient.uploadStudy();
            }, 'study and study.identifier is required');
            assert.throws(function () {
                patient.uploadStudy({});
            }, 'study and study.identifier is required');
            assert.doesNotThrow(function () {
                patient.uploadStudy({ identifier: "{study-id}" });
            }, 'study and study.identifier is required');
        });

        it('should return null if there is not valid identifier', function () {
            var patient = new Patient({});
            expect(patient.uploadStudy({ identifier: "{studi-id}" })).to.be.null;
        });

        it('should call the upload study endpoint', function () {
            var patient = new Patient({ rid: RID });
            var study = { identifier: '{study-id}' };
            var successCb = sinon.spy();
            var errorCb = sinon.spy();

            //************************ ERROR CALL **************************/
            $httpBackend
                .expectPUT($Endpoint.getEndpoint() + '/patient-view/v1/mypatient/' + RID + '/studies/{study-id}/upload')
                .respond(500);

            expect(study.requestingUpload).to.be.undefined;
            var promise = patient.uploadStudy(study);
            expect(promise).to.be.defined;
            expect(study.requestingUpload).to.be.true;
            promise.then(successCb).catch(errorCb);

            httpBackendVerify();

            expect(successCb.called).to.be.false;
            expect(errorCb.calledOnce).to.be.true;
            expect(study.uploadStatus).to.be.undefined;
            expect(study.requestingUpload).to.be.undefined;

            //************************ SUCCESS CALL **************************/
            $httpBackend
                .expectPUT($Endpoint.getEndpoint() + '/patient-view/v1/mypatient/' + RID + '/studies/{study-id}/upload')
                .respond(200, {caseContainerId: "abcd"});

            expect(study.requestingUpload).to.be.undefined;
            promise = patient.uploadStudy(study);
            expect(promise).to.be.defined;
            expect(study.requestingUpload).to.be.true;
            promise.then(successCb).catch(errorCb);

            httpBackendVerify();

            expect(successCb.calledOnce).to.be.true;
            expect(errorCb.calledOnce).to.be.true;
            expect(study.uploadStatus).to.equal('IN_PROGRESS');
            expect(study.requestingUpload).to.be.undefined;
            expect(patient.caseContainerId).to.equal('abcd');
        });

        /**
         * tag method
         **/
        it('should define a tag method', function () {
            var patient = new Patient({});
            assert.isDefined(patient.tag, 'patient.tag is not defined');
            assert.isFunction(patient.tag, 'patient.tag is not a function');
        });

        it('should return undefined if the patient is already tagged', function () {
            var patient = new Patient({ tagged: true });
            expect(patient.tag()).to.be.undefined;
        });

        it('should return a promise and call backend', function () {
            var patient = new Patient({ identifier: IDENTIFIER });
            var spy = sinon.spy();
            $httpBackend
                .expectPOST($Endpoint.getEndpoint() + '/patient-view/v1/mypatient', IDENTIFIER)
                .respond(200);

            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.taggingPatient.call,
                data: patient
            }));
            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.taggingPatient.success,
                data: patient
            }));

            var promise = patient.tag();
            expect(promise).to.not.be.undefined;
            expect(patient.tagging).to.be.true;

            promise.then(spy);

            httpBackendVerify();

            expect(patient.tagging).to.be.undefined;
            expect(patient.tagged).to.be.true;
            expect(spy.calledWith(patient)).to.be.true;
            postalMock.verify();
        });

        it('should reject the promise and do not set the tagged attribute', function () {
            var patient = new Patient({ identifier: IDENTIFIER });
            var spy = sinon.spy();
            $httpBackend
                .expectPOST($Endpoint.getEndpoint() + '/patient-view/v1/mypatient', IDENTIFIER)
                .respond(500);

            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.taggingPatient.call,
                data: patient
            }));
            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.taggingPatient.error,
                data: patient
            }));

            patient.tag().catch(spy);
            httpBackendVerify();
            expect(patient.tagged).to.be.undefined;
            expect(spy.called).to.be.true;

            postalMock.verify();
        });

        /**
         * untag method
         **/
        it('should define a untag method', function () {
            var patient = new Patient({});
            assert.isDefined(patient.untag, 'patient.untag is not defined');
            assert.isFunction(patient.untag, 'patient.untag is not a function');
        });

        it('should return undefined if the patient is untagged', function () {
            var patient = new Patient({});
            expect(patient.untag()).to.be.undefined;
        });

        it('should return a promise and call backend', function () {
            var patient = new Patient({ rid: RID, tagged: true });
            var spy = sinon.spy();
            $httpBackend
                .expectDELETE($Endpoint.getEndpoint() + '/patient-view/v1/mypatient/' + RID)
                .respond(200);

            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.untaggingPatient.call,
                data: patient
            }));
            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.untaggingPatient.success,
                data: patient
            }));

            var promise = patient.untag();
            expect(promise).to.not.be.undefined;
            expect(patient.untagging).to.be.true;

            promise.then(spy);

            httpBackendVerify();

            expect(patient.untagging).to.be.undefined;
            expect(patient.tagged).to.be.undefined;
            expect(spy.calledWith(patient)).to.be.true;
            postalMock.verify();
        });

        it('should reject the promise and do not set the tagged attribute', function () {
            var patient = new Patient({ rid: RID, tagged: true });
            var spy = sinon.spy();
            $httpBackend
                .expectDELETE($Endpoint.getEndpoint() + '/patient-view/v1/mypatient/' + RID)
                .respond(500);

            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.untaggingPatient.call,
                data: patient
            }));
            postalMock.expects('publish').once().withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.untaggingPatient.error,
                data: patient
            }));

            patient.untag().catch(spy);
            httpBackendVerify();
            expect(patient.tagged).to.be.true;
            expect(spy.called).to.be.true;

            postalMock.verify();
        });

        it('should declare the clearStudies method', function () {
            var patient = new Patient();
            expect(patient.clearStudies).to.not.be.undefined;
            expect(patient.clearStudies).to.be.instanceof(Function);
        });

        it('should clear the studies', function () {
            var patient = new Patient();
            patient.studies = [1, 2, 3, 4, 5, 6, 7];
            patient.studiesUpdated = true;
            patient.clearStudies();
            expect(patient.studies).to.be.undefined;
            expect(patient.studiesUpdated).to.be.undefined;
        });

        it('should define the getPatient method', function () {
            expect(Patient.getPatient).to.be.defined;
            expect(Patient.getPatient).to.be.instanceof(Function);
        });

        it('should throw an error when getPatient does not receive a valid rid', function () {
            expect(Patient.getPatient).to.throw('rid invalid');
            expect(function () {
                Patient.getPatient("rid");
            }).to.not.throw('rid invalid');
        });

        it('should call GET /mypatient/{rid} endpoint', function () {
            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient/' + RID)
                .respond(200, { rid: RID });

            Patient.getPatient(RID);

            httpBackendVerify();
        });

        it('should call the success method of promise', function () {
            var p = null;
            var success_cb = sinon.spy(function (patient) {
                p = patient;
            });

            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient/' + RID)
                .respond(200, { rid: RID });

            Patient.getPatient(RID).then(success_cb);

            httpBackendVerify();

            expect(success_cb.called).to.be.true;
            expect(p).to.be.instanceof(Patient);
            expect(p.rid).to.equal(RID);
        });

        it('should call the error method of promise', function () {
            var error_cb = sinon.spy();

            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient/' + RID)
                .respond(500);

            Patient.getPatient(RID).catch(error_cb);

            httpBackendVerify();

            expect(error_cb.called).to.be.true;
        });

        it('should define listMyPatients', function () {
            expect(Patient.listMyPatients).to.be.defined;
            expect(Patient.listMyPatients).to.be.instanceof(Function);
        });

        it('should call GET /mypatient endpoint', function () {
            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient')
                .respond(200, { 
                    totalRecords: 1,
                    listPatientVO: [{ rid: RID }]
                });

            Patient.listMyPatients();
            resolveEndpoint();
            httpBackendVerify();
        });

        it('should call GET /mypatient?limit=10&offset=0 endpoint', function () {
            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient?limit=10&offset=0')
                .respond(200, { 
                    totalRecords: 1,
                    listPatientVO: [{ rid: RID }]
                });

            Patient.listMyPatients(0);
            resolveEndpoint();
            httpBackendVerify();
        });

        it('should call GET /mypatient?search=test endpoint', function () {
            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient?search=test')
                .respond(200, { 
                    totalRecords: 1,
                    listPatientVO: [{ rid: RID }]
                });

            Patient.listMyPatients("test");
            resolveEndpoint();
            httpBackendVerify();
        });

        it('should call GET /mypatient?limit=10&offset=0&search=test', function () {
            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient?limit=10&offset=0&search=test')
                .respond(200, { 
                    totalRecords: 1,
                    listPatientVO: [{ rid: RID }]
                });

            Patient.listMyPatients(0, 10, "test");
            resolveEndpoint();
            httpBackendVerify();
        });

        it('should call GET /mypatient?limit=10&offset=0&search=test', function () {
            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient?limit=10&offset=0&search=test')
                .respond(200, { 
                    totalRecords: 1,
                    listPatientVO: [{ rid: RID }]
                });

            Patient.listMyPatients(0, "test");
            resolveEndpoint();
            httpBackendVerify();
        });

        it('should call the success callbeck', function () {
            var d = null;
            var success_cb = sinon.spy(function (data) {
                d = data;
            });

            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient')
                .respond(200, { 
                    totalRecords: 1,
                    listPatientVO: [{ rid: RID }]
                });

            Patient.listMyPatients().then(success_cb);
            resolveEndpoint();
            httpBackendVerify();

            expect(success_cb.called).to.be.true;
            expect(d.totalRecords).to.equal(1);
            expect(d.listPatientVO.length).to.equal(1);
            expect(d.listPatientVO[0]).to.be.instanceof(Patient);
        });

        it('should call the error_cb when the GET /mypatient returns an error', function () {
            var error_cb = sinon.spy();

            $httpBackend
                .expectGET($Endpoint.getEndpoint() + '/patient-view/v1/mypatient')
                .respond(500);

            Patient.listMyPatients().catch(error_cb);
            resolveEndpoint();
            httpBackendVerify();

            expect(error_cb.called).to.be.true;
        });

        it('should call the error_cb when the getEndpointAsync fails', function () {
            var error_cb = sinon.spy();

            Patient.listMyPatients().catch(error_cb);
            rejectEndpoint();
            $rootScope.$apply();

            expect(error_cb.called).to.be.true;
        });
    });
});