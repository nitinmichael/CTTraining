/*
 *  Morpheus-controller-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jyothi Jayaraman<Jyothi.Jayaraman@ge.com>
 */

/**
 * Test specs for Morpheus User Controller
 */

define(['angular', 'angular-mocks', 'analyticsChart',
        'modules/caseexchange/modules/morpheus/modules/userdashboard/controllers/morpheus-user-controller'],
         function () {
    'use strict';

    var rootScope, scope, controller, morpheusService, caseExchangeDataService;
    var MODES = {
        create: 'AUTOCREATE'
    };

    var currentUser = {
        externalId : [ {},
            {value : '1'}
        ]
    };

    var userData = {
            casesByClinicalReason: [
                {
                    clinicalReason: 'Other',
                    numOfCases: 1
                }
            ],
            transactionByType: [
                {
                    transactionType: "CREATE_CASE",
                    numOfTransactions: 590
                }
            ],
            transactionByDay: [
                {
                    numOfTransactions: 402,
                    dayOfTransaction: 3,
                    dateOfTransaction: "2015-11-03T01:14:37.356Z"
                }
            ]
    };


    describe('Morpheus User Controller Test Suite::', function() {

        beforeEach(function () {

            module('cloudav.caseExchange.morpheusUserCtrl', function ($provide) {
                $provide.value('$state', {
                    transitionTo: function (url) {
                    },
                    current: {
                        params: {
                            mode: MODES.create
                        }
                    }
                });

                $provide.value('$stateParams', {
                    id: function () {
                    }
                });

                 $provide.factory('CaseExchangeDataService', ['$q', function ($q) {
                    function getCurrentUser() {
                        return currentUser;
                    }

                    return {
                        getCurrentUser: getCurrentUser
                    }
                }]);

                $provide.factory('MorpheusServices',  ['$q', function ($q) {
                    function getClinicianData(){
                        return {
                            then: function(callback){callback([userData]);}
                        };
                    }

                     return {
                        getClinicianData: getClinicianData
                    }
                }]);
            });
        });

        // Initialize the scope and controller variables
        beforeEach(inject(function($rootScope, $controller, _CaseExchangeDataService_, _MorpheusServices_ ) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            controller = $controller;
            caseExchangeDataService = _CaseExchangeDataService_;
            morpheusService = _MorpheusServices_;

            controller('MorpheusUserCtrl', {
                 $scope : scope,
                 morpheusServices : morpheusService,
                 caseExchangeDataService : caseExchangeDataService
            });

       }));

        it('should have a controller', function() {
            assert.isDefined(controller, 'Controller is not defined');
        });
    });

});