/**
 * @ngdoc service
 * @name cloudav.viewerApp.test:TEST_settings-area-toolbar
 *
 * @description This property is a unit test file located at: test > modules > viewer > modules > viewer-app > widgets >
 *              settings-area-toolbar-test.js This file contains unit tests for the
 *              {@link cloudav.viewerApp.directive:settingAreaToolbar settings-area-toolbar} directive.
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 *
 * @author: Stéphane Breton<stephane.breton@ge.com>; Beeman, Benjamin <benjamin.beeman@ge.com>
 */
define([ 'angular', 'angular-mocks', 'viewerModule/widgets/settings-area-toolbar/settings-area-toolbar', 'settingsAreaToolbarTestMocks' ], function() {
    'use strict';

    describe('settings Area Toolbar :', function() {
        var element, scope, isolatedScope, windowResizeCallBackMock, annotStateServiceMock, settings_btn_back_locationMock_testVal, resizeSpy;
        var selectedAnnotState_mock = 'selectedAnnotState_mock';
        var lastNotificationError_mock = 'lastNotificationError_mock';
        var lastNotificationMessage_mock = 'lastNotificationMessage_mock';

        var toolBtnObj_call_count = 0;
        var toolBtnObj_config_passed_count = 0;
        var toolBoxObj_call_count = 0;
        var toolBoxObj_config_passed_count = 0;

        beforeEach(module('cloudav.viewerApp.widgets'));
        beforeEach(module('settingsAreaToolbarTestMocks'));
        beforeEach(module('templates'));

        beforeEach(module(function($provide) {
            $provide.value('$toolFactory', {

                toolBtnObj : function(config) {
                    toolBtnObj_call_count++;
                    var passed = true;
                    var failed = function(message) {
                        console.error(message);
                        passed = false;
                        return false;
                    }

                    var toolBtnObj = this;
                    var validTypes = [ "toolBtn", "menuBtn", "iconBtn", "modalBtn" ];

                    this.type = (validTypes.indexOf(config.type) > -1 ? config.type : failed(config.type + " is not a valid type for a toolBtn."));
                    this.title = (typeof config.title === 'string' ? config.title : failed("toolBtnObj created without a title."));
                    this.onclick = (typeof config.onclick === 'function' ? config.onclick : console.debug("toolBtnObj " + config.id + " created without an onclick function."));
                    this.id = (typeof config.id === 'string' ? config.id : failed("toolBtnObj created without an id string."));
                    this.class = config.class;
                    this.content = (typeof config.content === 'string' ? config.content : '');
                    if (typeof config.modal === 'object') {
                        this.modal = (config.modal.passedMockTest ? config.modal : failed('modal failed mock test.'));
                    }
                    this.iconClassName = (typeof config.iconClassName === 'string' ? config.iconClassName : (config.type !== "iconBtn" ? null : failed("toolBtnObj " + config.id
                            + " has type of iconBtn and is created without a valid Icon Class Name")));
                    if (passed) {
                        toolBtnObj_config_passed_count++;
                    }

                    if (typeof config.onclick === 'function') {
                        config.onclick();
                    }
                },

                // Test the config parameter object
                toolBoxObj : function(config) {
                    toolBoxObj_call_count++;
                    var passed = true;
                    var failed = function() {
                        passed = false;
                        return false;
                    }
                    var validTypes = [ "bar", "quickTools", "simple-bar" ];
                    this.title = (typeof config.title === 'string' ? config.title : failed());
                    this.type = (validTypes.indexOf(config.type) > -1 ? config.type : failed());
                    this.buttons = config.buttons;
                    this.orientation = 'horizontal';
                    this.collapsedBtns = [];
                    this.totalBtns = this.buttons.length;
                    if (passed) {
                        toolBoxObj_config_passed_count++;
                    }
                },
                defaultToolBoxObj : function() {
                    this.defaultToolBoxMock = true;
                },
                toolModalObj : function(config) {

                    var passed = true;
                    var failed = function(message) {
                        console.error(message);
                        passed = false;
                        return false;
                    }
                    this.id = (typeof config.id === 'string' ? config.id : failed("toolBtnObj created without an id string."));
                    this.url = (typeof config.url === 'string' ? config.id : failed("toolBtnObj created without an url string."));
                    this.title = (typeof config.title === 'string' ? config.title : failed("toolBtnObj created without an title string."));
                    this.passedMockTest = passed;
                }
            });

            $provide.value('$window', {
                innerHeight : 400,
                innerWidth : 500
            });

            $provide.service('$windowResizeService', function() {
                this.addCBforOnResize = function(fn) {
                    windowResizeCallBackMock = fn;
                };
            });

            $provide.service('$location', function() {
                this.path = function(path) {
                    settings_btn_back_locationMock_testVal = path;
                };
            });

            $provide.service('annotStateService', function() {
                return {
                    selectedAnnotState : selectedAnnotState_mock,
                    lastNotificationError : lastNotificationError_mock,
                    lastNotificationMessage : lastNotificationMessage_mock
                }
            });
        }));

        beforeEach(inject(function($compile, $rootScope, annotStateService) {
            var html = '<settings-area-toolbar></settings-area-toolbar>';
            annotStateServiceMock = annotStateService;
            scope = $rootScope.$new();
            element = $compile(html)(scope);
            scope.$digest();
            isolatedScope = element.isolateScope();
            resizeSpy = sinon.spy(isolatedScope, 'resize');
            windowResizeCallBackMock();
        }));

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-initialization
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description This property is a unit test located in the settings-area-toolbar-TEST file. It is designed to
         *              test the initial creation of the settingAreaToolbar directive.
         *
         */
        it('should have a directive', function() {
            assert.isDefined(element, 'settings-area-toolbar Directive is not defined');
        });

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-toolBarItems_initialization
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description This property is a unit test located in the settings-area-toolbar-TEST file. It is designed to
         *              test the initial creation of the
         *              {@link cloudav.viewerApp.directive:settingAreaToolbar#toolBarItems toolBarItems} scope veriable
         *              object located in the settingAreaToolbar directive.
         *
         */
        it('should have a toolBarItems value', function() {
            assert.isDefined(isolatedScope.toolBarItems, 'settings-area-toolbar Directive does not have toolBarItems value defined');
        });

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-toolBarItems_defaultToolBoxMock
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description This property is a unit test located in the settings-area-toolbar-TEST file. It is designed to
         *              test that the {@link cloudav.viewerApp.directive:settingAreaToolbar#toolBarItems toolBarItems}
         *              was initialized using the $toolFactory.defaultToolBoxObj function.
         *
         */
        it('toolBarItems should be created by calling defaultToolBox ', function() {
            expect(isolatedScope.toolBarItems.defaultToolBoxMock).to.equal(true, 'toolBarItems was not created by calling the toolFactory defaultToolBox mocked function.');
        });

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-settingsBtns_initialization
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description This property is a unit test located in the settings-area-toolbar-TEST file. It is designed to
         *              test the initial creation of the settingsBtns scope veriable object located in the
         *              {@link cloudav.viewerApp.directive:settingAreaToolbar settingAreaToolbar} directive.
         *
         */
        it('should have a settingsBtns value', function() {
            assert.isDefined(isolatedScope.settingsBtns, 'settings-area-toolbar Directive does not have settingsBtns value defined');
        });

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-settingsBtns_title
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description This property is a unit test located in the settings-area-toolbar-TEST file. It is designed to
         *              test that the settingsBtns scope veriable object has a title value attached to it. The
         *              settingsBtns is located in the
         *              {@link cloudav.viewerApp.directive:settingAreaToolbar settingAreaToolbar} directive.
         *
         */
        it('should have a title value in settingsBtns', function() {
            assert.isDefined(isolatedScope.settingsBtns.title, 'settings-area-toolbar Directive does not have settingsBtns.title value defined');
        });

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-settingsBtns_type
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description This property is a unit test located in the settings-area-toolbar-TEST file. It is designed to
         *              test that the settingsBtns scope veriable object has a type value attached to it. The
         *              settingsBtns is located in the
         *              {@link cloudav.viewerApp.directive:settingAreaToolbar settingAreaToolbar} directive.
         *
         */
        it('should have a type value in settingsBtns', function() {
            assert.isDefined(isolatedScope.settingsBtns.type, 'settings-area-toolbar Directive does not have settingsBtns.type value defined');
        });

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-settingsBtns_buttons
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description This property is a unit test located in the settings-area-toolbar-TEST file. It is designed to
         *              test that the settingsBtns scope veriable object has a buttons object attached to it. The
         *              settingsBtns is located in the
         *              {@link cloudav.viewerApp.directive:settingAreaToolbar settingAreaToolbar} directive.
         *
         */
        it('should have a buttons value in settingsBtns', function() {
            assert.isDefined(isolatedScope.settingsBtns.buttons, 'settings-area-toolbar Directive does not have settingsBtns.buttons value defined');
        });

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-settingsBtns_backToList_onclick
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description This property is a unit test located in the settings-area-toolbar-TEST file. It is designed to
         *              test that the settingsBtns scope veriable object has a buttons object and the first button has
         *              an onclick function attached to it. This first button is the "Back to list" button.The
         *              settingsBtns is located in the
         *              {@link cloudav.viewerApp.directive:settingAreaToolbar settingAreaToolbar} directive.
         *
         */
        it('should have a onclick function for the Back to list button in settingsBtns', function() {
            var btnClick = isolatedScope.settingsBtns.buttons[0].onclick;
            var clickType = typeof (btnClick);
            expect(clickType).to.equal('function', 'settings-area-toolbar Directive does not have a function defined for the Back to list button in settingsBtns');
            btnClick();
        });

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-settingsBtns_SettingsBtn_onclick
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description This property is a unit test located in the settings-area-toolbar-TEST file. It is designed to
         *              test that the settingsBtns scope veriable object has a buttons object and the second button has
         *              an onclick function attached to it. This second button is the "Settings" button.The settingsBtns
         *              is located in the {@link cloudav.viewerApp.directive:settingAreaToolbar settingAreaToolbar}
         *              directive.
         *
         */
        it('should have a onclick function for the Settings button in settingsBtns', function() {
            var btnClick = isolatedScope.settingsBtns.buttons[1].onclick;
            var clickType = typeof (btnClick);
            expect(clickType).to.equal('function', 'settings-area-toolbar Directive does not have a function defined for the Settings button in settingsBtns');
            btnClick();
        });

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-settingsBtns_toolBtnObj_inspection
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description Every button object is created by calling using the $toolFactory service and calling the
         *              toolBtnObj to create a new tool button configuration object that will be passed into the tool
         *              button. This test ensures that everytime this funciton was called it was called with correct
         *              configuration parameters.
         *
         */
        it('All toolBtnObj configurations should pass an inspection. ', function() {
            expect(toolBtnObj_call_count).to.equal(toolBtnObj_config_passed_count, 'Every time a toolBtnObj is created it is not created with a correct configuration parameters.');

        });

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-settingsBtns_toolBoxObj_inspection
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description Every tool box object is created by calling using the $toolFactory service and calling the
         *              toolBoxObj to create a new tool button configuration object that will be passed into the tool
         *              box. This test ensures that everytime this funciton was called it was called with correct
         *              configuration parameters.
         *
         */
        it('All toolBoxObj configurations should pass an inspection. ', function() {
            expect(toolBoxObj_call_count).to.equal(toolBoxObj_config_passed_count, 'Every time a toolBoxObj is created it is not created with a correct configuration parameters.');
        });

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-settingsBtns_settings-btn-settings_onclick_selectedAnnotStateTemp
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description The settings-btn-settings onclick function uses the annotStateService and sets
         *              selectedAnnotStateTemp property. This test ensures this happens correctly through mocking the
         *              annotStateService.
         */
        it('settings-btn-settings onclick function test failure. ', function() {
            expect(annotStateServiceMock.selectedAnnotStateTemp).to.equal(selectedAnnotState_mock, 'annotStateServiceMock.selectedAnnotStateTemp should equal ' + selectedAnnotState_mock
                    + " after the onclick is activated.");
        });

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-settingsBtns_settings-btn-settings_onclick_lastNotificationErrorTemp
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description The settings-btn-settings onclick function uses the annotStateService and sets
         *              lastNotificationErrorTemp property. This test ensures this happens correctly through mocking the
         *              annotStateService.
         */
        it('settings-btn-settings onclick function test failure. ', function() {
            expect(annotStateServiceMock.lastNotificationErrorTemp).to.equal(lastNotificationError_mock, 'annotStateServiceMock.lastNotificationErrorTemp should equal ' + lastNotificationError_mock
                    + " after the onclick is activated.");
        });

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-settingsBtns_settings-btn-settings_onclick_lastNotificationMessageTemp
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description The settings-btn-settings onclick function uses the annotStateService and sets
         *              lastNotificationMessageTemp property. This test ensures this happens correctly through mocking
         *              the annotStateService.
         */
        it('settings-btn-settings onclick function test failure. ', function() {
            expect(annotStateServiceMock.lastNotificationMessageTemp).to.equal(lastNotificationMessage_mock, 'annotStateService.lastNotificationMessageTemp should equal '
                    + lastNotificationMessage_mock + " after the onclick is activated.");
        });

        /**
         * @ngdoc property
         * @name UNIT_TEST_settings-area-toolbar-resize
         * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
         *
         * @description The settings-area-toolbar has a $scope.resize function that is added to the $windowResizeService
         *              so that it can be called when the global $window has changed size. By mocking the
         *              $windowResizeService this unit test collects the resize call back function and then calls it.
         *              After that it ensures that it was called.
         */
        it("$scope.resize function should have been called on window resize mock test.", function() {
            chai.expect(resizeSpy.called).to.equal(true);
        });

    });
});
