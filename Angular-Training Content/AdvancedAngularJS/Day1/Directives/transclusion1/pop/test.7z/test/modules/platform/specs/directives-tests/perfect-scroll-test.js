define([ 'angular-mocks', 'modules/platform/directives/scrollBar/perfect-scroll' ], function(ngMocks) {
    describe('Test  perfect-scroll', function() {
        var $compile;
        var $rootScope;

        beforeEach(module('platform.directive.perfect-scroll'));

        beforeEach(module(function($provide) {
            $provide.factory('$cssService', function() {
                return {
                    'addCssOnce' : function() {

                    }
                }
            });
            $provide.factory('$logger', function() {
                return {

                }
            });
        }));

        beforeEach(inject(function(_$compile_, _$rootScope_) {
            $compile = _$compile_;
            $rootScope = _$rootScope_;
        }));

        it('Replaces the element with the appropriate content', function() {
            var scope = $rootScope.$new();
            var element = $compile("<div perfect-scroll></div>")(scope);
            $rootScope.$digest();
            var html = element.html();
            expect(html).to.contain('ps-scrollbar-x-rail');
        });
    });
});