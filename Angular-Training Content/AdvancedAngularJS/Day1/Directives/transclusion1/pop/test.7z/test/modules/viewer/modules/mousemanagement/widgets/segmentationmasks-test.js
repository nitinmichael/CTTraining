/*
 *  toolbar-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *   Stéphane Breton <stephane.breton@ge.com>
 */

/**
 * Spec file for Viewer > modules > mousemanagement > widgets > toolbar directive
 */

define(['angular', 'angular-mocks', 'jquery','mousemanagementModule/module',
        'mousemanagementModule/widgets/segmentationMasks'],
    function () {
        'use strict';

        describe('segmentationMasks Directive Test :', function () {
            var element, scope, segmentationService, portContentFactory, activeViewportSegmentationMask,mockSegmentationMasksThumbnails;

            beforeEach(module('templates'));
            beforeEach(module('cloudav.viewerApp.mousemanagement'));

            beforeEach(module(function($provide) {
                $provide.factory('portContentFactory', function() {
                    return {
                        'getActivePort' : function() {
                            return {
                                'viewPortObject' : {
                                    'renderEngine': {
                                        'setSegmentationMask': function(maskId) {
                                            activeViewportSegmentationMask = maskId
                                        }
                                    }
                                },
                                'updateViewportImage': function() {},
                                'portReady':true
                            };
                        }
                    }
                });
            }));

            beforeEach(module('cloudav.viewerApp.services', function($provide) {
                var mockSegmentationMasks = {
                    'masks': [{
                        "name": "mask3",
                        "id": "7"
                    },]
                };
                mockSegmentationMasksThumbnails =  {
                    "data":{
                        "width": 936,
                        "height": 149,
                        "orientation": "1/1/1/0/0/1",
                        "renderType": "VR",
                        "renderMode": "VR",
                        "pfh-vr-rendering-time": 68,
                        "ret": true,
                        "image": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCACVA6gDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4yooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAPdfAnw78H614X02+eznnuZolMpaSSNd2F3Zw2PvZAx2I6dB5N480uPR/Fd9YQW5ggR8wrliNpHYnkjqM+1e8/AHW7W1+HtuJ7mZZYpHQLnIcb2IXp157+o9K8u+P4EnjS3vY5I5IbuxSWMoCAoLv8pz/EOhHY8dq8vC1KrxM4yvY9TFKm8PCUUk9Oh53RRRXqHlhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAaGhWNtqN4LSa+itJXwIWnGIWb+675GwHpu6c8kDmu28PeHLTQdM8QeIde0gzvYkxadYXgAErFgDIy7gWVQ6HKkjk/WvOa6PQ9OsYNJm13XjefZkkW2tbeE7HuHK7m+Y/dRUZSeOfMXHXNYVk2tzooyV9vmeofCbX312KSJNM0a2uhI6v9ljNmkUIUOSxQEc4YZ25+UjuK5L42NibSYUa0kijjkCyQu7Fj8oO7fjB4HAVfXnNeh/CZtB1zQN1jocOjxRytGsQhErygAHe05ILfM2ApUgDvnAPHfGLSpL3RLbV7N3mGnytb38ZAzGzKu2QgAYDBVBPqDXFTnFYjltb+vuOupCToXvc8nooor1DzAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAK6T4faFDrmpXzXSvJbabp0+ozRo2GkWJd23OOAe59PfFc3W/4BG/xNBHMrNYuGXUFGObXH70c8Z2529923HOKipfkdi6fxq5o3WqeA9UVbm80DUtJul4ePTJ0aCYY64kGYznHTcOOmTmsrxX4gbWms7eG2+yadYQiCzt9+9lXuztgbnOBk4HQAAAAViU+GOSaZIYkLyOwVVA5JPAFKNKMXfsVKrKSsfS3wCtXm+F8BtoAZy8xDMuQ3ztgfeGO/PJ+7x3XzvVtafwv8aL2LWPMNhN5MN/A8asrxOiMQ8ZJDY3HjIPrjkV7j4UtdH8O+GrHQzpty8ttGsFwYpkYTsoG50DL8uWV+OSQwOAa8T+OWjpPrsPia6mHlzyLFqAih2TE55kCk7WJHH3hzjI6mvHw8oTrzUtpHqVozjRg4/ZON+KOi6d4e8ZXukacl1Gtu7JJHOQdjB2A2MD8yFdjDPIyQc4yeXrvvj2Tc/ES41iFJRY6pa2t5aNJ3SS3jbH4En+feuBr1sO3KlFvex5ddJVJJdwooorYyCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACnRyPGSUYqSpU47gjBFNooAK2/AkMU/jLSYp/L8s3SFvMkCLgHPJJA7evPSsSnRu8ciyRsyOpDKwOCCOhFKSumhxfK0z7l8JyWS6LveAFAGUeaiZdc528Yz398KOcCvH/2ktT09PDy2ihhdyzAJk9uC3A7YwPy9seueGYftPhu01GVEkN3brMzBcKhYAk9hye/txXy98fNRa88cG3jLfZrSLy4gY9gJ3MHb/aywPIz0x2r5vL6ftMTfse9jZ8lC3cy/iLdNe2PhS585mB0KGMoTwrRvJDwPdY15749q5Guj8ZbF0zwvEMCaPRwJ0zyjNczuufQmN43+jg965yvoaStGy8/zPEqO8rhRRRWhmFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABU+nravf26X0skNq0qieSNNzImRuIGRkgZ4zUFafhXT49V8TaZpk3m+TdXcUUpiXc4RmAYgeoGT+FKTsm2NK7sfZvga8ttM+HFgtzOpis7bYwTa5Pytt4HIPy45GOPfn5K+LGs2+t+Ob+eyQx2cLmGBCF+UAkvyPvAuzkE5OCM9K+ivit43tPCGq6Bp7WsUsN7eCa6MgBj8sFWIYHGfmYZyeg5J5z5n8S/AkXhzX08SWUMpjs2a5u4Hh8wJIo3R7wCPlZyisQejbvWvDwDVOTqSXxbHr41OcVBP4dzzT4gNKPFt5ayyeY1gI9PD5BytvGsC8jg8RjpWDSsSxLE5J5NJXtxXKkjyJO7bCiiiqEFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABXtH7NHgoX2qN4y1HK2OnMwiUgrvfHLbjhSADjHfnpgZ8o8N6ZJrOu2emRDm4kCnnHHU84PYHsa9m+Lni+Lw74GsvBPh547USczLBJnai8Bm5BDn1IJwWHynIrixblNKjDeXXsjrw0YxftZbL8zz74zeK5vFPja9kju5ZNNtpTHZwmUPEmAquyYOMMUzkdQFyTitj4bePhpMQtfE8hvLSXJhNwJHMaLG6dMEEHIVTyVKDoBXmNOd3cguzNgADJzgDoK2eHg6ap9EZKvJTc+rPoef4XeC/HmjrrHhHUI7GSQ7M/djL4xt2bRznHp17mvJfGPw48XeFVkm1LS3a0Q/wDHzCd8f5jkVv8A7OFzqz+PBpFokFxp93bSi+huZikaxYBZ16jzOFUcZO7GVzuFS3+JHiXwr4j1G00jVpL/AEmK8lWGC+HmoyB2CkgkkHHueveuSmsRSqOEZcyWuv8An/wDqm6FSCnJWfkeeUV6X8UdN0vVfB+kfEPS9PTTDqMxtbq1gXMIlXdlgTggnbyMEHrnOc+aV3UqiqRva3+Zx1Kfs5WCiiitDMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApVBYhVBJPAA70le3WyaZ8LPhjpmtixhvPE2up5kJuEBEEeAeFznAzg+p9sVjWrezskrt7I2o0vaXbdktzzHwAbm38eaLGimOaW9ih+YYwJGCH9GrU+Nttc2fxM1a0uXjZojGF8sYQAxq2FHYZJ4HGc11/h/4pWXiCaO08b6fp8ckDCWyv7eDy2hlU5UnGec9/wI5zXnvxE1oeIPF15qaSiVHWONXCbQwSNUzjtnaT+NY03UlWvKNrL169zWooRo2jK92c9RRRXYch0Ph7xXfaDoWpadpkEENzqG1HvgD5yRfxRqegBODkcjn1GE+Hvhm68W+K7PRrZHKOwe5dSB5cII3tk9MA/mRXP17D+ze0s+n+NtK0+dYdWvdKVbVs/NgFt+PXqtc2Il7GnKcd/6X4G9Be1nGEtjM+NWvaTFaaZ4B8NOkuk6Hu8ydTnz5yTls49zn3J9K8xqW7t57S5ktrmJ4ZomKujjBUjtUVaUaapwUV/w5FWbnJthRRRWpmFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAqqzHCgk4J4HYV7D+09Kkuo+GDA++3bSVeIrgowJ5II4OSO39a4T4VW0l78QdIsYrMXn2mVoHiIU5R0ZXI3cZCkke4Heuk/aXv4rz4sX0EEqPFYwx2iBc/IFGdvPoWPr9etcdR82Jguyb/Q6oe7h5Pu0v1PNKKKK7DlCiiigArQ8Pa1qWgatDqmlXLW9zF0YdCD1UjuD3FZ9FJpSVmNNp3R77o6+Efi/psMmtFNM8SCVo8WzKrSIu0rwf728gAjqrYrxHxBY3uma3eWOowCC6hmZZEVNig56qMD5T1HbBFavww1O+0nx/ot1p6s85vIo1jDY8zcwAU9jyQcHjIGa6/8Aak0+2sfi1czW3lgXtrDcsqDAUkFcY+ijuevrmuKknRr+zT91q68jrqSVWlztap6+Z5ZRRRXccYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHqf7LkEUnxZt5pjgW1pPMD6fLt/kx/8ArVxnxJv21P4ga/es27zNQm2nbj5Q5C8fQCvRP2V4rZPF17evKWnFnJEkQiY5OVYfN90bgr4yQfl9xXlfiRnfxFqTyZ3tdyls9c7zmuKGuKm/Jfqdc9MPFd2zPooortOQKKKKACiiigDU8ISxW/izR55yoijvoHfd02iRSc+2K9M/ajs7q58fDVYIZprY6fCZJFUskXLAAnsD2z7+leP19Ma5qKReKvCdtf3WdO8Q+HBbSRMB5TSNGNu8HGcbuPc8etcGJk6dWNRa6P8AzO3DxU6UoPuj5noqS5gmtrmW2uI2jmicpIjDBVgcEH3BqOu84tgooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAO++FvxCt/BELD+wP7Qme8S4kk+1+VvRVKiMjY3HzPznv04543WrxdR1m91BIfIW6uJJhFu3bAzE7c4GcZxmqdFZxpQjNzS1ZcqkpRUW9EFFFFaEBRRRQAUUUUAFd948+IkXijwzoelroZsb3SI4Yo71bvcSsce0gKEG3LYbOTjaB71wNFRKnGbUmtUXGpKKaXU1PFWrDXvEF3rBtUtZLthLMiHKmUqPMYcDAZtzY7Zxk4ycuiiqilFJIltyd2FFFFMQUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAf/Z"
                    }
                };
                segmentationService = {
                    segmentationMasks: sinon.stub().returns(mockSegmentationMasks),
                    getThumbnails: sinon.stub().returns(mockSegmentationMasksThumbnails)
                };

                $provide.value('segmentationService', segmentationService);
            }));

            beforeEach(
                inject(function ($compile, $rootScope, _portContentFactory_) {
                    portContentFactory = _portContentFactory_;
                    element = angular.element('<segmentation-masks></segmentation-masks>');
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$digest();
                })
            );

            it('should have a directive', function () {
                assert.isDefined(element, 'segmentationMasks Directive is not defined');
            });

            it('should have a selectedSegmentationMask value in scope', function () {
                expect(scope.selectedSegmentationMask).to.equal('None');
            });

            it('should apply segmentation mask', function () {
                var segmentationMasksObj = {
                    'masks': [{
                        'name': 'mask1',
                        'id': '1'
                    }]
                };

                scope.applySegmentationMask(segmentationMasksObj['masks'][0]);
                expect(scope.selectedSegmentationMask).to.equal('1');
                expect(activeViewportSegmentationMask).to.equal('1');
            });
        });
    });
