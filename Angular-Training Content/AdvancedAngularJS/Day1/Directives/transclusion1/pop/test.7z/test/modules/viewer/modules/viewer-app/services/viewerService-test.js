define(['angular', 'angular-mocks', 'deviceManagerServiceMock', 'viewerModelsMock', 'viewerModule/services/viewerService'], function(ng, mocks) {
    'use strict';

    describe('viewerService service test', function() {
        var viewerService, theNavigator, theWindow, iPadUserAgent, iPhoneUserAgent, androidDeviceUserAgent, desktopUserAgent;

        beforeEach(function() {

            module('cloudav.viewerApp.services');
            module('deviceManagerServiceMock');
            module('viewerModels');

            module(function($provide) {
                $provide.factory('$viewportParameterStorage', function() {
                    return {
                        getNumberOfPorts: function() {
                            return 16;
                        }
                    };
                });
            });

            inject(function(_$window_, _viewerService_) {
                theWindow = _$window_;
                viewerService = _viewerService_;
                theNavigator = theWindow.navigator;

                iPadUserAgent = 'Mozilla/5.0 (iPad; CPU OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53';
                iPhoneUserAgent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 8_0 like Mac OS X) AppleWebKit/600.1.3 (KHTML, like Gecko) Version/8.0 Mobile/12A4345d Safari/600.1.4';
                androidDeviceUserAgent = 'Mozilla/5.0 (Linux; Android 4.3; Nexus 10 Build/JSS15Q) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2307.2 Safari/537.36';
                desktopUserAgent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36';
            });
        });


        afterEach(function() {
            theWindow.navigator = theNavigator;
        });

        it('viewTypes should be defined', function() {
            assert(typeof(viewerService.viewTypes), 'object', 'viewerService service should have a viewTypes object defined');
        });

        it('renderingTypes should be defined', function() {
            assert(typeof(viewerService.renderingTypes), 'object', 'viewerService service should have a renderingTypes object defined');
        });

        it('reformatPoint should be defined', function() {
            assert(typeof(viewerService.reformatPoint), 'function', 'viewerService service should have a reformatPoint function defined');
        });

        it('reformatMeasure should be defined', function() {
            assert(typeof(viewerService.reformatMeasure), 'function', 'viewerService service should have a reformatMeasure function defined');
        });

        it('getDefaultViewportConfig should be defined', function() {
            assert(typeof(viewerService.getDefaultViewportConfig), 'function', 'viewerService service should have a getDefaultViewportConfig function defined');
        });

        it('reformatSaveState should be defined', function() {
            assert(typeof(viewerService.reformatSaveState), 'function', 'viewerService service should have a reformatSaveState function defined');
        });

        it('reformatPoint should return formated point', function() {
            var point = [1, 2, 3];
            var res = viewerService.reformatPoint(point);

            assert(typeof(res), 'object', 'reformatPoint should return an object');
            assert.isDefined(res.x, 'reformatPoint result should have "x" property');
            assert.isDefined(res.y, 'reformatPoint result should have "y" property');
            assert.isDefined(res.z, 'reformatPoint result should have "z" property');

            assert.equal(res.x, 1, 'x property should equal "1"');
            assert.equal(res.y, 2, 'y property should equal "2"');
            assert.equal(res.z, 3, 'z property should equal "3"');
        });

        it('reformatMeasure should return formated mesures', function() {
            var measure = {
                label: 'Dist. 1',
                measurementIndex: '1',
                normal: [0, 0, -1],
                type: 'distance',
                volumeIndex: 1,
                points: [{
                    0: 23.232544,
                    1: -41.767456,
                    2: -251.249969
                }, {
                    0: -22.470581,
                    1: -19.677612,
                    2: -251.249969
                }]
            };
            var volumes = [{
                groupUid: 'group_id0'
            }, {
                groupUid: 'group_id1'
            }, ];
            var res = viewerService.reformatMeasure(measure, volumes);

            assert(typeof(res), 'object', 'reformatMeasure should return an object');
            assert.isDefined(res.id, 'reformatMeasure result should have "id" property');
            assert.equal(res.parent_id, 'group_id1', 'parent_id property should be resolved to group id');

            assert.equal(res.id, 'Dist. 1', 'id property should equal "Dist. 1"');
        });

        it('getDefaultViewportConfig should return default viewer configuration', function() {
            var conf = viewerService.getDefaultViewportConfig();

            assert(typeof(conf), 'object', 'getDefaultViewportConfig should return an object');
            assert.equal(conf.length, 16, 'getDefaultViewportConfig should return 16 elements');

        });


        it('reformatSaveState should return formated save state', function() {
            expect(viewerService.reformatSaveState({
                correlationID: '3be64f80-a47f-444d-810e-a27ed8665ec8',
                senderID: 'SaveStateController UUID',
                viewports: [{
                    type: 'Oblique',
                    fov: 987.903992,
                    ww: 400,
                    wl: 40,
                    volumeIndex: 0,
                    orientation: [
                        0.886117,
                        0,
                        0.463461, -0.080663,
                        0.984738,
                        0.154224, -0.456388, -0.174044,
                        0.872593
                    ]
                }, {
                    type: 'Axial',
                    fov: 130,
                    ww: 400,
                    wl: 40,
                    volumeIndex: 0
                }, {
                    type: 'Sagittal',
                    fov: 987.903992,
                    ww: 400,
                    wl: 40,
                    volumeIndex: 0
                }, {
                    type: 'Coronal',
                    renderMode: 'hdmip',
                    fov: 987.903992,
                    ww: 400,
                    wl: 40,
                    volumeIndex: 0
                }],
                volumes: [{
                    spaceid: '25300391958837055805250',
                    groupUid: '1.2.840.113619.2.144.174778421.4233.1139390915.774',
                    imageUids: []
                }],
                header: {}
            })).to.eql([{
                index: 0,
                isSaveState: true,
                fov: 987.903992,
                annotLevel: undefined,
                viewType: '3D',
                rendererType: 'MPR',
                windowWidth: 400,
                windowLevel: 40,
                orientation: [
                    0.886117,
                    0,
                    0.463461, -0.080663,
                    0.984738,
                    0.154224, -0.456388, -0.174044,
                    0.872593
                ]
            }, {
                index: 1,
                isSaveState: true,
                fov: 130,
                annotLevel: undefined,
                viewType: 'INFERIOR',
                rendererType: 'MPR',
                windowWidth: 400,
                windowLevel: 40,
                orientation: undefined
            }, {
                index: 2,
                isSaveState: true,
                fov: 987.903992,
                annotLevel: undefined,
                viewType: 'LEFT',
                rendererType: 'MPR',
                windowWidth: 400,
                windowLevel: 40,
                orientation: undefined
            }, {
                index: 3,
                isSaveState: true,
                fov: 987.903992,
                annotLevel: undefined,
                viewType: 'ANTERIOR',
                rendererType: 'VR',
                windowWidth: 400,
                windowLevel: 40,
                orientation: undefined
            }]);
        });

        it('getDefaultLayoutConfiguration should return the configuration for the current device', function() {
            theWindow.navigator = {
                userAgent: desktopUserAgent
            };

            var config = viewerService.getDefaultLayoutConfiguration();
            expect(config.visiblePorts).to.equal(4);
            expect(config.cssLayout).to.equal('twoByTwo');

            theWindow.navigator = {
                userAgent: iPadUserAgent
            };

            config = viewerService.getDefaultLayoutConfiguration();
            expect(config.visiblePorts).to.equal(3);
            expect(config.cssLayout).to.equal('oneByTwoByTwo');

            theWindow.navigator = {
                userAgent: iPhoneUserAgent
            };

            config = viewerService.getDefaultLayoutConfiguration();
            expect(config.visiblePorts).to.equal(1);
            expect(config.cssLayout).to.equal('oneByOne');

            theWindow.navigator = {
                userAgent: androidDeviceUserAgent
            };

            config = viewerService.getDefaultLayoutConfiguration();
            expect(config.visiblePorts).to.equal(4);
            expect(config.cssLayout).to.equal('twoByTwo');
        });

        it('fixPortsConfiguration should not do anything if the config is complete', function() {
            var config = [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}];
            expect(viewerService.fixPortsConfiguration(config)).to.eql(config);
        });

        it('mapGroups should return formated group data', function() {
            expect(viewerService.mapGroups()).to.eql([]);
            expect(viewerService.mapGroups([{
                date: '1',
                description: '2',
                groupID: '3',
                imageType: '4',
                modality: '5',
                saveState: true,
                secondaryCapture: true,
                seriesUID: '6',
                spaceID: '7',
                studyUID: '8',
                instanceUIDs: ['0', '1'],
                pixelSpacing: {}
            }])).to.eql([{
                date: '1',
                description: '2',
                groupID: '3',
                imageType: '4',
                modality: '5',
                saveState: true,
                secondaryCapture: true,
                seriesUID: '6',
                spaceID: '7',
                studyUID: '8',
                firstInstanceUID: '0',
                nbImages: 2,
                pixelSpacing: {}
            }]);
        });

        it('mapVolumes should return formated volume data', function() {
            expect(viewerService.mapVolumes()).to.eql([]);
            expect(viewerService.mapVolumes([{
                defaultWindowLevel: 1,
                defaultWindowWidth: 2,
                dimensions: {},
                groupUid: '1',
                resampledDirX: {},
                resampledDirY: {},
                resampledOrigin: {},
                resampledSliceSpacing: 3,
                slices: [{
                    pixelSpacing: '1',
                    intercept: '2',
                    slope: '3'
                }],
                seriesModel: {
                    modality: '1',
                    seriesSOPInstanceUID: '2'
                },
                studyModel: {
                    studySOPInstanceUID: '1'
                }
            }])).to.eql([{
                defaultWindowLevel: 1,
                defaultWindowWidth: 2,
                dimensions: {},
                groupUid: '1',
                resampledDirX: {},
                resampledDirY: {},
                resampledOrigin: {},
                resampledSliceSpacing: 3,
                slicesNumber: 1,
                pixelSpacing: '1',
                intercept: '2',
                slope: '3',
                modality: '1'
            }]);
        });

        it('mapPatient should return formated patient data', function() {
            expect(viewerService.mapPatient()).to.equal(null);
            expect(viewerService.mapPatient({
                title: '1',
                birthDate: '2',
                age: '3',
                name: '4',
                sex: '5',
                id: '6'
            })).to.eql({
                title: '1',
                dob: '2',
                age: '3',
                name: '4',
                gender: '5',
                id: '6'
            });
        });

        it('mapSaveStates should return formated save state data', function() {
            expect(viewerService.mapSaveStates()).to.eql([]);
            expect(viewerService.mapSaveStates([{
                correlationID: '1',
                senderID: '2',
                body: {
                    volumes: {},
                    viewports: {},
                    measurements: {},
                    '3dcursors': {}
                }
            }])).to.eql([{
                correlationID: '1',
                senderID: '2',
                volumes: {},
                viewports: {},
                measurements: {},
                cursors: {}
            }]);
        });

        it('mapStudy should return formated study data', function() {
            expect(viewerService.mapStudy()).to.equal(null);
            expect(viewerService.mapStudy({
                date: '1',
                description: '2',
                instanceUID: '3'
            })).to.eql({
                studyDate: '1',
                studyDescription: '2',
                studyID: '3'
            });
        });
    });
});
