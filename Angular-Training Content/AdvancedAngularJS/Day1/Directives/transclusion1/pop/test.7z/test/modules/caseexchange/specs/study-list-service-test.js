/*
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * Spec file for Study List Service module
 */

define(['angular','angular-mocks', 'modules/caseexchange/modules/create-case/services/study-list-service', 'modules/caseexchange/services/case-exchange-data-service', 'mocks/fake-server', 'mocks/case-exchange-mock-service'], function (ng) {
    'use strict';

    var StudyListService, $mockServerLoader, q, httpBackend, defer, rootScope, stub, mockServer, sampleResponse;
    describe('Test Study List Service', function () {

        beforeEach(function() {
            // Load the Sinon fake server.
            module('cloudav.caseExchange.fakeServer');

            // Load the module for the mock data first
            module('cloudav.caseExchange.mocks');

            module('Services.studyListService', function($provide){
                $provide.factory('configurationService', ['$q', function($q){
                    return {
                        getProperty: function(){
                            return $q.when({});
                        }
                    }
                }]);
            });

            inject(function ($rootScope, _$q_, $MockServerLoader, $httpBackend, _StudyListService_, CaseExchangeMocks){
                StudyListService = _StudyListService_;
                $mockServerLoader = $MockServerLoader;
                httpBackend = $httpBackend;
                rootScope = $rootScope;
                sampleResponse = CaseExchangeMocks.getStudiesFromPacs().responseList[0];
                mockServer = $mockServerLoader.init();
            });
        });

        it('should define a service', function () {
            assert.isDefined(StudyListService, 'Study List Service is defined');
        });

        describe('Study List Service', function() {

            it('should reject promise on invalid input', function(){
                StudyListService.studyList("").then(function(){
                    assert(false, "Error should have been thrown");
                }, function(){
                });
            });

            it('should reject promise on http error', function(){
                $mockServerLoader.fakeStudyListCall(500, null);
                StudyListService.studyList({}).promise.then(function(){
                    assert(false, "Error should have been thrown");
                }, function(error){
                    expect(error.status).to.equal(500);
                });
                mockServer.respond();
                rootScope.$apply();
            });

            it('should return response on valid input', function(){
                $mockServerLoader.fakeStudyListCall(200, sampleResponse);
                StudyListService.studyList({}).promise.then(function(data){
                    expect(data.identifier).to.equal(sampleResponse.identifier);
                }, function(){
                    assert(false, "Error should not have been thrown");
                });
                mockServer.respond();
                rootScope.$apply();
            });

            it('should return null response on valid input', function(){
                $mockServerLoader.fakeStudyListCall(200, null);
                StudyListService.studyList({}).promise.then(function(data){
                    expect(data).to.equal(null);
                }, function(){
                    assert(false, "Error should not have been thrown");
                });
                mockServer.respond();
                rootScope.$apply();
            });

        });

    });
});  