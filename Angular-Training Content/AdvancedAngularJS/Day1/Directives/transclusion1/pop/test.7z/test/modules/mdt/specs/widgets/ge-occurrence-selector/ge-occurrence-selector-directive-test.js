/*
 * ge-occurrence-selector-directive-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular', 'angular-mocks', 'mdt/widgets/ge-occurrence-selector/ge-occurrence-selector-directive'], function () {
    'use strict';
    describe('directive: ge-occurrence-selector', function () {

        var $compile,
            $rootScope;

        beforeEach(function () {
            // Load actual module
            module('Directive.geOccurrenceSelector', function ($provide, $translateProvider) {
                // This will provide the mock translation to $translate provider
                $translateProvider.translations('en', {});
            });

            // Load Templates
            module('templates');
        });

        // Store references to $rootScope and $compile
        // so they are available to all tests in this describe block
        beforeEach(inject(function (_$compile_, _$rootScope_) {
            // The injector unwraps the underscores (_) from around the parameter names when matching
            $compile = _$compile_;
            $rootScope = _$rootScope_;
        }));

        var elementTemplate, element, scope;

        it("check id and title", function () {
            scope = $rootScope.$new();
            var schedulings = [
                {},
                {},
                {}
            ]

            scope.actSchedulings = schedulings;
            scope.id = "mdtGroupOccurrenceSelector";
            elementTemplate =
                '<ge-occurrence-selector id={{id}} title={{title}} schedulings="actSchedulings"></ge-occurrence-selector>';
            element = $compile(elementTemplate)(scope);
            scope.$digest();

            var isolated = element.isolateScope();

            expect(isolated.id).to.equal("mdtGroupOccurrenceSelector");
        });

        it("check values received from an initialized occurrence", function () {
            scope = $rootScope.$new();
            var schedulings = [
                {type: "Daily"},
                {type: "Daily"},
                {type: "Daily"}
            ];

            scope.actSchedulings = schedulings;
            elementTemplate =
                '<ge-occurrence-selector id="An id" title="A title" schedulings="actSchedulings"></ge-occurrence-selector>';
            element = $compile(elementTemplate)(scope);
            element.appendTo(document.body);
            scope.$digest();

            var isolated = element.isolateScope();

            expect(isolated.type()).to.equal("Daily");
            expect(isolated.schedulings).to.have.length(3);
            expect(isolated.schedulings).to.eql(scope.actSchedulings);
        });

        it("check values received from an occurrence without scheduling list - daily", function () {
            scope = $rootScope.$new();
            var schedulings = [
                {type: "Daily"}
            ];
            scope.actSchedulings = schedulings;
            elementTemplate =
                '<ge-occurrence-selector id="An id" title="A title" schedulings="actSchedulings"></ge-occurrence-selector>';
            element = $compile(elementTemplate)(scope);
            element.appendTo(document.body);
            scope.$digest();

            var isolated = element.isolateScope();

            expect(isolated.type()).to.equal("Daily");
            expect(isolated.schedulings).to.be.an('array');
            expect(isolated.schedulings).to.have.length(1);
            expect(scope.actSchedulings).to.be.an('array');
            expect(scope.actSchedulings).to.have.length(1);
        });

        it("check values received from an occurrence without scheduling list - monthly", function () {
            scope = $rootScope.$new();
            var schedulings = [
                {type: "Monthly"}
            ];
            scope.actSchedulings = schedulings;
            elementTemplate =
                '<ge-occurrence-selector id="An id" title="A title" schedulings="actSchedulings"></ge-occurrence-selector>';
            element = $compile(elementTemplate)(scope);
            element.appendTo(document.body);
            scope.$digest();

            var isolated = element.isolateScope();

            expect(isolated.type()).to.equal("Monthly");
            expect(isolated.schedulings).to.be.an('array');
            expect(isolated.schedulings).to.have.length(1);
            expect(scope.actSchedulings).to.be.an('array');
            expect(scope.actSchedulings).to.have.length(1);
        });

        it("check values received from an occurrence without scheduling list - weekly", function () {
            scope = $rootScope.$new();
            var schedulings = [
                {type: "Weekly"}
            ];
            scope.actSchedulings = schedulings;
            elementTemplate =
                '<ge-occurrence-selector id="An id" title="A title" schedulings="actSchedulings"></ge-occurrence-selector>';
            element = $compile(elementTemplate)(scope);
            element.appendTo(document.body);
            scope.$digest();

            var isolated = element.isolateScope();

            expect(isolated.type()).to.equal("Weekly");
            expect(isolated.schedulings).to.be.an('array');
            expect(isolated.schedulings).to.have.length(1);
            expect(scope.actSchedulings).to.be.an('array');
            expect(scope.actSchedulings).to.have.length(1);
        });

        it("check values received from an occurrence without scheduling list - on demand", function () {
            scope = $rootScope.$new();
            var schedulings = [];
            scope.actSchedulings = schedulings;
            elementTemplate =
                '<ge-occurrence-selector id="An id" title="A title" schedulings="actSchedulings"></ge-occurrence-selector>';
            element = $compile(elementTemplate)(scope);
            element.appendTo(document.body);
            scope.$digest();

            var isolated = element.isolateScope();

            expect(isolated.type()).to.equal("On demand");
            expect(isolated.schedulings).to.be.an('array');
            expect(isolated.schedulings).to.have.length(0);
            expect(scope.actSchedulings).to.be.an('array');
            expect(scope.actSchedulings).to.have.length(0);
        });

        it("check addScheduling - monthly", function () {
            scope = $rootScope.$new();
            var schedulings = [
                {type: "Monthly"}
            ];
            scope.actSchedulings = schedulings;
            elementTemplate =
                '<ge-occurrence-selector id="An id" title="A title" schedulings="actSchedulings"></ge-occurrence-selector>';
            element = $compile(elementTemplate)(scope);
            element.appendTo(document.body);
            scope.$digest();

            var isolated = element.isolateScope();

            isolated.addScheduling();
            expect(isolated.type()).to.equal("Monthly");
            expect(isolated.schedulings).to.be.an('array');
            expect(isolated.schedulings).to.have.length(2);
            expect(scope.actSchedulings).to.be.an('array');
            expect(scope.actSchedulings).to.have.length(2);
        });

        it("check removeScheduling - daily", function () {
            scope = $rootScope.$new();
            var schedulings = [
                {type: "Daily"}
            ];
            scope.actSchedulings = schedulings;
            elementTemplate =
                '<ge-occurrence-selector id="An id" title="A title" schedulings="actSchedulings"></ge-occurrence-selector>';
            element = $compile(elementTemplate)(scope);
            element.appendTo(document.body);
            scope.$digest();

            var isolated = element.isolateScope();

            isolated.removeScheduling(isolated.schedulings[0]);
            expect(isolated.type()).to.equal("Daily");
            expect(isolated.schedulings).to.be.an('array');
            expect(isolated.schedulings).to.have.length(0);
            expect(scope.actSchedulings).to.be.an('array');
            expect(scope.actSchedulings).to.have.length(0);
        });

        it("check typeSelectionListener - daily", function () {
            scope = $rootScope.$new();
            var schedulings = [
                {type: "Daily",
                 time: [12, 0]}
            ];
            scope.actSchedulings = schedulings;
            elementTemplate =
                    '<ge-occurrence-selector id="An id" title="A title" schedulings="actSchedulings"></ge-occurrence-selector>';
            element = $compile(elementTemplate)(scope);
            element.appendTo(document.body);
            scope.$digest();

            var isolated = element.isolateScope();

            isolated.typeSelectionListener();
            scope.$digest();
            expect(isolated.type()).to.equal("Daily");
            expect(isolated.schedulings).to.be.an('array');
            expect(isolated.schedulings[0].time).to.be.an('undefined');
            expect(scope.actSchedulings).to.be.an('array');
            expect(scope.actSchedulings[0].time).to.be.an('undefined');
        });

        it("check typeSelectionListener - weekly", function () {
            scope = $rootScope.$new();
            var schedulings = [
                {
                    type: "Weekly",
                    time: [12, 0],
                    day: "Monday"
                },
                {
                    type: "Weekly",
                    time: [12, 0],
                    day: "Friday"
                }
            ];
            scope.actSchedulings = schedulings;
            elementTemplate =
                '<ge-occurrence-selector id="An id" title="A title" schedulings="actSchedulings"></ge-occurrence-selector>';
            element = $compile(elementTemplate)(scope);
            element.appendTo(document.body);
            scope.$digest();

            var isolated = element.isolateScope();

            isolated.typeSelectionListener();
            scope.$digest();
            expect(isolated.type()).to.equal("Weekly");
            expect(isolated.schedulings).to.be.an('array');
            expect(isolated.schedulings).to.have.length(0);
            expect(scope.actSchedulings).to.be.an('array');
            expect(scope.actSchedulings).to.have.length(0);
        });

        it("check typeSelectionListener - monthly", function () {
            scope = $rootScope.$new();
            var schedulings = [
                {
                    type: "Weekly",
                    time: [12, 0],
                    day: "Monday",
                    ordinalInMonth: 1
                }
            ];
            scope.actSchedulings = schedulings;
            elementTemplate =
                '<ge-occurrence-selector id="An id" title="A title" schedulings="actSchedulings"></ge-occurrence-selector>';
            element = $compile(elementTemplate)(scope);
            element.appendTo(document.body);
            scope.$digest();

            var isolated = element.isolateScope();

            isolated.typeSelectionListener();
            scope.$digest();
            expect(isolated.type()).to.equal("Weekly");
            expect(isolated.schedulings).to.be.an('array');
            expect(isolated.schedulings).to.have.length(0);
            expect(scope.actSchedulings).to.be.an('array');
            expect(scope.actSchedulings).to.have.length(0);
        });

        it("check typeSelectionListener - On demand", function () {
            scope = $rootScope.$new();
            var schedulings = [];
            scope.actSchedulings = schedulings;
            elementTemplate =
                '<ge-occurrence-selector id="An id" title="A title" schedulings="actSchedulings"></ge-occurrence-selector>';
            element = $compile(elementTemplate)(scope);
            element.appendTo(document.body);
            scope.$digest();

            var isolated = element.isolateScope();

            isolated.typeSelectionListener();
            scope.$digest();
            expect(isolated.type()).to.equal("On demand");
            expect(isolated.schedulings).to.be.an('array');
            expect(isolated.schedulings).to.have.length(0);
            expect(scope.actSchedulings).to.be.an('array');
            expect(scope.actSchedulings).to.have.length(0);
        });


    });
});
