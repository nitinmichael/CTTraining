define(['angular'], function(angular) {
    angular.module('imageAreaToolbarFactoryMock', []).factory('imageAreaToolbarFactory', function() {
        var json = {
            "toolBarItems": {
                "title": "Image Area Toolbar",
                "type": "simple-bar",
                "collapsible": true,
                "buttons": [{
                    "title": "Measurements button",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_temp_measure.svg"
                    },
                    "panel": {
                        "id": "image-tools-measurement-panel",
                        "url": "./modules/viewer/modules/mousemanagement/widgets/templates/measurement-panel-template.html",
                        "title": "Measurement Popover",
                        "type": "popover",
                        "alignment": "horizontal"
                    },
                    "id": "image-tools-btn-measure"
                }, {
                    "title": "Sync button",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_sync.svg"
                    },
                    "id": "image-tools-btn-sync",
                    "parentId": "image-tools-btn-layout"
                }, {
                    "title": "Hang button",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_hang.svg"
                    },
                    "id": "image-tools-btn-hang",
                    "parentId": "image-tools-btn-layout"
                }, {
                    "title": "Layout button",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_layout.svg"
                    },
                    "panel": {
                        "id": "image-tools-layout-panel",
                        "url": "./modules/viewer/modules/mousemanagement/widgets/templates/layout-panel-template.html",
                        "title": "Layout Popover",
                        "type": "popover",
                        "alignment": "horizontal"
                    },
                    "groupPanel": {
                        "id": "image-tools-btn-sync-group-panel",
                        "url": "./modules/platform/directives/toolBox/collapsed-btns-template.html",
                        "title": "Collapsed buttons popover",
                        "type": "popover",
                        "alignment": "horizontal"
                    },
                    "id": "image-tools-btn-layout"
                }, {
                    "title": "Cam button",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_cam.svg"
                    },
                    "id": "image-tools-btn-cam",
                    "parentId": "image-tools-btn-layout"
                }, {
                    "title": "Max button",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_max.svg"
                    },
                    "id": "image-tools-btn-max"
                }]
            },
            "menu": {
                "title": "Mobile menu",
                "type": "mobile-menu",
                "collapsible": false,
                "buttons": [{
                    "title": "Measurements",
                    "type": "mobileMenuItem",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_plan_lg.svg"
                    },
                    "panel": {
                        "id": "mobile-menu-measurement-panel",
                        "url": "./modules/viewer/modules/mousemanagement/widgets/templates/measurement-panel-template.html",
                        "title": "Measurement Popover",
                        "type": "popover",
                        "alignment": "horizontal"
                    },
                    "id": "image-tools-btn-measure"
                }, {
                    "title": "Settings",
                    "type": "mobileMenuItem",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_settings1_sm.svg"
                    },
                    "panel": {
                        "id": "mobile-menu-settings-tools-panel",
                        "url": "./modules/viewer/modules/viewer-app/widgets/settings-area-toolbar/settings-modal-template.html",
                        "title": "Setting Popover",
                        "type": "popover",
                        "alignment": "horizontal"
                    },
                    "id": "settings-tools-btn-settings"
                }, {
                    "title": "Help",
                    "type": "mobileMenuItem",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_help_rnd_sm.svg"
                    },
                    "panel": {
                        "id": "mobile-menu-help-panel",
                        "url": "./modules/viewer/modules/mousemanagement/widgets/templates/help-panel-template.html",
                        "title": "Help Popover",
                        "type": "popover",
                        "alignment": "horizontal"
                    },
                    "id": "image-tools-btn-help"
                }]
            },
            "defaultLayouts": {
                "buttons": [{
                    "title": "1x1",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_layout_1x1.svg"
                    },
                    "id": "default-layout-1x1",
                    "content": {
                        "visiblePorts": 1,
                        "cssLayout": "oneByOne",
                        "usePredefinedLayout": true
                    }
                }, {
                    "title": "1x2",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_layout_1x2.svg"
                    },
                    "id": "default-layout-1x2",
                    "content": {
                        "visiblePorts": 2,
                        "cssLayout": "oneByTwo",
                        "usePredefinedLayout": true
                    }
                }, {
                    "title": "1+2",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_layout_1x2x2.svg"
                    },
                    "id": "default-layout-1x2x2",
                    "content": {
                        "visiblePorts": 3,
                        "cssLayout": "oneByTwoByTwo",
                        "usePredefinedLayout": true
                    }
                }, {
                    "title": "2x1",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_layout_2x1.svg"
                    },
                    "id": "default-layout-2x1",
                    "content": {
                        "visiblePorts": 2,
                        "cssLayout": "twoByOne",
                        "usePredefinedLayout": true
                    }
                }, {
                    "title": "2x2",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_layout_2x2.svg"
                    },
                    "id": "default-layout-2x2",
                    "content": {
                        "visiblePorts": 4,
                        "cssLayout": "twoByTwo",
                        "usePredefinedLayout": true
                    }
                }, {
                    "title": "4x4",
                    "icon": {
                        "url": "./modules/viewer/modules/mousemanagement/images/icons/ico_layout_4x4.svg"
                    },
                    "id": "default-layout-4x4",
                    "content": {
                        "visiblePorts": 16,
                        "cssLayout": "fourByFour",
                        "usePredefinedLayout": true
                    }
                }]
            }
        };
        return {
            success: function(callback) {
                callback(json);
            }
        };
    });
});
