angular.module('xjtweb-platform', [])
    .constant('linkingMocks', {
        linkingFilterMock: function($q) {
            var filters = {};
            filters.zoom = {};
            filters.zoom.filter = function(viewId, data) {
                return true;
            };
            filters.zoom2 = {};
            filters.zoom2.filter = function(viewId, data) {
                return false;
            };

            var createPromise = function(callback, viewId, data) {
                return $q(function(resolve, reject) {
                    if (callback(viewId, data)) {
                        resolve(true);
                    } else {
                        reject(false);
                    }
                });
            };


            return {
                check: function(eventName, viewId, data) {
                    var promises = [];
                    var eventFilters = filters[eventName];
                    for (var i in eventFilters) {
                        promises.push(createPromise(eventFilters[i], viewId, data));
                    }
                    return $q.all(promises);
                },
                add : function(eventName, filter, callback){}
            };
        },
        linkingSettingsMock: {
            LINKING_CHANNEL: 'LINKING_CHANNEL',
            SAME_TYPE_FILTER : 'SAME_TYPE_FILTER'
        },
        linkingManagerMock: function() {
            return {
                viewEventEmitter : null,
                publish : function() {},
                subscribe: function(){},
                unscrible : function(){},
                link: function(id){},
                unlink : function(){}
            };
        },
    });
