/*
 * This is an example of an Angular service.  Each module can have multiple services that provide different functionality 
 * to the application.  Each service should be stored in a separate JavaScript file and given a descriptive name.
 * 
 * The service is dependent on the existing caselist module.
 */
define([ 
    'angular',
    'mockModule' 
    ], function(ng) {
	
    'use strict';
    var worklist = ng.module('seed-project.caselist'); 
 
    //This service gets patient data through HTTP request. In this example, it retrieves the data from the nodejs web service.
    worklist.service('patientData', function($http) {
    		this.getPatientData = function () {
    			var patientData;
    			console.log("sending request");
    			return $http.get('/patientData').then(function (response) {

    				patientData = response.data;
                    return patientData;
 
                }, function(error) {
                    // promise rejected, could log the error with: console.log('error', error);
                    console.log("Failed to get resonse from server, error received: " + error);
                });

    		}
    		
    		return {getPatientData: this.getPatientData};
    })});
