 define(['angular', 'angular-mocks', 'modules/platform/services/device-manager-service'], function(ng, mocks) {
    'use strict';

    describe('$deviceManagerService', function() {
        // var element;
        // var scope;
        var theNavigator;
        var theWindow;
        var deviceManagerService;
        var iPadUserAgent;
        var iPhoneUserAgent;
        var androidDeviceUserAgent;
        var desktopUserAgent;

        beforeEach(module('platform.service.device-manager-service'));

        beforeEach(inject(function (_$window_, _$deviceManagerService_) {
            theWindow = _$window_;
            deviceManagerService = _$deviceManagerService_;

            theNavigator = theWindow.navigator;
            iPadUserAgent = 'Mozilla/5.0 (iPad; CPU OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53';
            iPhoneUserAgent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 8_0 like Mac OS X) AppleWebKit/600.1.3 (KHTML, like Gecko) Version/8.0 Mobile/12A4345d Safari/600.1.4';
            androidDeviceUserAgent = 'Mozilla/5.0 (Linux; Android 4.3; Nexus 10 Build/JSS15Q) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2307.2 Safari/537.36';
            desktopUserAgent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36';
        }));

        /**
         * @ngdoc method
         * @name DeviceManagerServiceTest
         * @methodOf platform.$deviceManagerService
         *
         * @description This test method determines that the $deviceManagerService return the good template
         * by device
        */
        describe('Testing $deviceManagerService', function() {
            afterEach(function () {
                theWindow.navigator = theNavigator;
            });

            it('getFileUrl should throw an error if the function parameter is not a string', function() {
                expect(function() {
                    deviceManagerService.getFileUrl(null);
                }).to.throw(TypeError, 'the parameter should be a string');
            });

            it('getFileUrl should return the desktop template', function() {
                var partialDesktopTemplate = 'mydesktoptemplate.html';
                var desktopTemplate = deviceManagerService.getFileUrl(partialDesktopTemplate);
                expect(desktopTemplate).to.equal('mydesktoptemplate.html');
            });

            it('getFileUrl should return the iPad template', function() {
                theWindow.navigator = {
                    userAgent: iPadUserAgent
                };

                var partialIpadTemplate = 'myipadtemplate.html';
                var iPadTemplate = deviceManagerService.getFileUrl(partialIpadTemplate);
                expect(iPadTemplate).to.equal('myipadtemplate-tablet.html');
            });

            it('getFileUrl should return the iPhone template', function() {
                theWindow.navigator = {
                    userAgent: iPhoneUserAgent
                };

                var partialIphoneTemplate = 'myiphonetemplate.html';
                var iPhoneTemplate = deviceManagerService.getFileUrl(partialIphoneTemplate);
                expect(iPhoneTemplate).to.equal('myiphonetemplate-tablet.html');
            });

            it('getFileUrl should return the desktop template if the device is a mobile device other than iPad/iPhone', function() {
                theWindow.navigator = {
                    userAgent: androidDeviceUserAgent
                };

                var partialTemplate = 'mytemplate.html';
                var template = deviceManagerService.getFileUrl(partialTemplate);
                expect(template).to.equal('mytemplate.html');
            });

            it('getSupportedDeviceName should return the name "desktop" if the device is a desktop computer', function() {
                theWindow.navigator = {
                    userAgent: desktopUserAgent
                };

                var name = deviceManagerService.getSupportedDeviceName();
                expect(name).to.equal('desktop');
            });

            it('getSupportedDeviceName should return the name "iPad" if the device is an iPad', function() {
                theWindow.navigator = {
                    userAgent: iPadUserAgent
                };

                var name = deviceManagerService.getSupportedDeviceName();
                expect(name).to.equal('iPad');
            });

            it('getSupportedDeviceName should return the name "iPhone" if the device is an iPad', function() {
                theWindow.navigator = {
                    userAgent: iPhoneUserAgent
                };

                var name = deviceManagerService.getSupportedDeviceName();
                expect(name).to.equal('iPhone');
            });

            it('getSupportedDeviceName should return the name "desktop" if the device is a mobile device other than iPad/iPhone', function() {
                theWindow.navigator = {
                    userAgent: androidDeviceUserAgent
                };

                var name = deviceManagerService.getSupportedDeviceName();
                expect(name).to.equal('desktop');
            });
        });
    });
});
