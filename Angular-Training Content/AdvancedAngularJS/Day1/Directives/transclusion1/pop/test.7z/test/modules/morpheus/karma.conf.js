/*
 *  karma.conf.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jignesh Parekh<jignesh.parekh@ge.com>
 */

/**
 * Karma configuration file for Case Exchange module
 */
module.exports = function (config) {
    'use strict';
    config.set({
        basePath: '../../..',
        // list of files / patterns to load in the browser
        files: [
            // TODO(JigneshP): load common requireJS file
            // 'public/uaf/appshell/require-config.js',
            // TODO(JigneshP): load module level requireJS file
            // 'public/modules/caseexchange/require-config.js',

            // loading the anguler library first to avoid angular dependent library error
            'public/uaf/3rdparty/angular/angular.js',

            // load all the file patterns
            { pattern: 'public/uaf/**/*.js', included: false },
            { pattern: 'public/modules/morpheus/**/*.js', included: false },
            'public/modules/morpheus/directives/**/*.html',
            { pattern: 'test/modules/morpheus/mocks/*.js', included: false },
            { pattern: 'test/modules/morpheus/specs/*-test.js', included: false },
            // This is a main test config file
            'test/modules/morpheus/test-main.js'
        ],
        // list of files to exclude
        exclude: [
            //'public/uaf/3rdparty/**/*.min.js',
        ],

        // test results reporter to use
        // possible values: 'dots', 'progress', 'coverage', 'junit'
        // available reporters: https://npmjs.org/browse/keyword/karma-reporter
        reporters: ['progress', 'coverage', 'junit'],

        // preprocess matching files before serving them to the browser
        // available preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor
        preprocessors: {
            'public/modules/morpheus/**/*.js': ['coverage'],
            'public/modules/morpheus/directives/**/*.html': ['ng-html2js']
        },

        /**
         * Code Coverage Reporter Plug-in options
         */

       coverageReporter: { dir : 'test/modules/morpheus/report/coverage',
          reporters: [
              {type : 'lcovonly',subdir: 'lcovonly'},
              {type : 'html',subdir: 'html'}
          ]},


        /**
         * JUnit Reporter options
         */
        junitReporter: {
            outputFile: 'test/modules/morpheus/report/junit/TESTS-xunit.xml',
            suite: 'unit'
        },

        /**
        * ng-html2js options
        */
        ngHtml2JsPreprocessor: {
            // strip this from the file path
            stripPrefix: 'public/',

            // setting this option will create only a single module that contains templates
            // from all the files, so you can load them all with module('foo')
            moduleName: 'templates'
        },


        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
        logLevel: config.LOG_DEBUG,

        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: false
    });
};
