/*
 *  selfRegistrationService-test.js
 *
 *  Copyright (c) 2016 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 */

/**
 * Specs for Self Registration Service Module
 */
define(['angular', 'angular-mocks', 'orgMgmnt/services/selfRegistrationService'], function(){
    'use strict';
    describe('Test suite for self registration service', function(){
        var selfRegistrationService;
        beforeEach(function(){
            module('Orgmanagement.Services.SelfRegistrationService');

            inject(function(_selfRegistrationService_){
                selfRegistrationService = _selfRegistrationService_;
            });
        });

        describe('Variable declaration test suite', function(){
            it('should have a getUserInformation method defined', function(){
                assert.isDefined(selfRegistrationService.getUserInformation, 'Service doesn\'t have "getUserInformation" method defined');
            });
        });
    });
});


