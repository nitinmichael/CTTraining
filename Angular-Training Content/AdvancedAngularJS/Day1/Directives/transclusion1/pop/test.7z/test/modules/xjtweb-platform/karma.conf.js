/**
 * @ngdoc object
 * @name xjtweb-platform.object:karma-conf
 * @author Benjamin Beeman
 *
 * @description This is the karma unit test configuration file for the {@link xjtweb-platform} module.
 */
module.exports = function(config) {
    'use strict';


    config.set({

        // base path that will be used to resolve all patterns (eg. files, exclude)
        basePath: '../../..',

        // frameworks to use
        // available frameworks: https://npmjs.org/browse/keyword/karma-adapter
        frameworks: ['mocha', 'requirejs', 'chai-as-promised', 'sinon-chai', 'chai'],

        // list of files / patterns to load in the browser
        files: ['public/uaf/3rdparty/angular/angular.js', {
                pattern: 'public/uaf/**/*.js',
                included: false
            }, {
                pattern: 'public/modules/xjtweb-platform/**/*.js',
                included: false
            },
            'public/modules/xjtweb-platform/**/*.html',
            'test/modules/xjtweb-platform/mocks/**/*.html',
            'test/modules/xjtweb-platform/test-main.js', {
                pattern: 'test/modules/xjtweb-platform/**/*.js',
                included: false
            }, {
                pattern: 'test/modules/viewer/mocks/*.js',
                included: false
            }, {
                pattern: 'public/modules/viewer/**/*.js',
                included: false
            },
        ],

        // list of files to exclude
        exclude: [
            'test/modules/xjtweb-platform/report/**/*'
        ],

        // preprocess matching files before serving them to the browser
        // available preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor
        preprocessors: {
            'public/modules/xjtweb-platform/**/!(three).js': 'coverage',
            'public/modules/xjtweb-platform/directives/**/*.html': ['ng-html2js'],
            'test/modules/xjtweb-platform/mocks/**/*.html': ['ng-html2js']
                // 'public/modules/viewer/modules/mousemanagement/widgets/**/*.html' : [ 'ng-html2js' ]
        },

        junitReporter: {
            outputFile: 'test/modules/xjtweb-platform/report/junit/TESTS-xunit.xml',
            suite: ''
        },

        // test results reporter to use
        // possible values: 'dots', 'progress'
        // available reporters: https://npmjs.org/browse/keyword/karma-reporter
        reporters: ['progress', 'coverage', 'junit'],

        /**
         * ng-html2js options
         */
        ngHtml2JsPreprocessor: {
            // strip this from the file path
            stripPrefix: 'public/',

            // setting this option will create only a single module that contains templates
            // from all the files, so you can load them all with module('foo')
            moduleName: 'templates'
        },

        // web server port
        port: 9876,

        // enable / disable colors in the output (reporters and logs)
        colors: true,

        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO ||
        // config.LOG_DEBUG

        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: true,

        // start these browsers
        // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
        browsers: ['PhantomJS'],
        captureTimeout: 90000,

        coverageReporter: {
            dir: 'test/modules/xjtweb-platform/report/coverage',
            reporters: [{
                type: 'lcovonly',
                subdir: 'lcovonly'
            }, {
                type: 'html',
                subdir: 'html'
            }]
        },

        client: {
            captureConsole: true
        },

        // Continuous Integration mode
        // if true, Karma captures browsers, runs the tests and exits
        singleRun: true,
        plugins: [
            'karma-chrome-launcher',
            'karma-phantomjs-launcher',
            'karma-requirejs',
            'karma-mocha',
            'karma-chai',
            'karma-chai-as-promised',
            'karma-sinon-chai',
            'karma-coverage',
            'karma-ng-html2js-preprocessor',
            'karma-junit-reporter'
        ]
    });
};
