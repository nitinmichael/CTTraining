/*
 * mdt-session-details-controller-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular', 'angular-mocks', 'ng-sortable', 'mdt/modules/mdt-session-management/controllers/mdt-session-details-controller'], function () {
    'use strict';

    describe('MDT Session Details controller test cases', function () {
        var scope, stateParams, state, controller, MdtSessionService, MdtSessionDataService, NotificationService,
            fullScreenSuccessHandler, fullScreenErrorHandler, detailsSuccessHandler, detailsErrorHandler;

        beforeEach(function () {
            angular.module('Platform.Directive.Notification', []);
            angular.module('Platform.Directive.GeLoadingSpinner', []);
            angular.module('Platform.Services.NotificationService', []);

            module('Mdt.Module.MdtSessionDetailsController', function ($provide) {});
            module('Mdt.Module.MdtSessionDataService');

            inject(function ($rootScope, $controller, _MdtSessionDataService_) {
                scope = $rootScope.$new();
                stateParams = {sessionId: '6677'};
                state = {
                    transitionTo: sinon.spy()
                };
                MdtSessionService = {
                    then: function(fn){
                        fn({
                            fullscreenPresentation: function (id, success, error) {
                                fullScreenSuccessHandler = success;
                                fullScreenErrorHandler   = error;
                                return {caseList : []};
                            },
                            getProgressiveSessionDetails: function (id, success, error) {
                                detailsSuccessHandler = success;
                                detailsErrorHandler   = error;
                                return {caseList : []};
                            },
                            reorderCases:  sinon.spy(),
                            getSessionHeaders:  sinon.spy(),
                            getCaseHeader:  sinon.spy()
                        });
                    }
                };
                NotificationService = {
                    addErrorMessage: sinon.spy()
                };
                MdtSessionDataService = _MdtSessionDataService_;
                var session = {
                    meetingId: '6677',
                    cases: [
                        {id: '1122',
                            outcome: 'outcome1122'},
                        {id: '3344',
                            outcome: 'outcome3344'}
                    ]
                };
                MdtSessionDataService.updateItemList([session]);
                MdtSessionDataService.retrieveSelectedItem('6677');
                //Initialize the controller
                controller =
                        $controller('MdtSessionDetailsController', {
                            $scope: scope,
                            $stateParams: stateParams,
                            $state: state,
                            MdtSessionService: MdtSessionService,
                            MdtSessionDataService: MdtSessionDataService,
                            NotificationService: NotificationService
                        });
            });
        });

        it("should have a controller defined", function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it("should handle received session details", function(){
            var result = {
                data: {
                    name: 'Lorem Pista'
                }
            };

            detailsSuccessHandler(result);
            expect(scope.sessionDetails.name).to.be.equal(result.data.name);
            expect(scope.fetchingSessionDetails).to.be.false;
        });

        it("should handle session details error", function(){
            detailsErrorHandler();
            expect(scope.sessionDetails).to.be.empty;
            expect(scope.fetchingSessionDetails).to.be.false;
            expect(NotificationService.addErrorMessage.calledOnce).to.be.true;
        });

        it("should handle fullscreen presentation", function(){
            scope.sessionDetails = {
                cases: ["a case"]
            };

            scope.fullscreenPresentation();

            fullScreenSuccessHandler();
            expect(scope.startingFullscreenPresentation).to.be.false;
            expect(state.transitionTo.calledOnce).to.be.true;
        });

        it("should handle fullscreen presentation error", function(){
            scope.fullscreenPresentation();

            fullScreenErrorHandler();
            expect(scope.startingFullscreenPresentation).to.be.false;
            expect(NotificationService.addErrorMessage.calledOnce).to.be.true;
        });

    });
});
