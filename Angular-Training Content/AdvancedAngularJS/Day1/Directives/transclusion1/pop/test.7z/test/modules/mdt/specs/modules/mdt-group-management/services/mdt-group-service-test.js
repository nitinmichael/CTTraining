/*
 * mdt-group-service-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular', 'angular-mocks', 'mdt/modules/mdt-group-management/services/mdt-group-service'], function () {
    'use strict';

    describe("MdtGroupService", function () {
        var MdtGroupService, MdtUserService, $httpBackend;
        var ROOT_URL = 'http://localhost:8080';
        var USER_MANAGEMENT_URL = ROOT_URL + "/userregistry/v2/user/_search";

        beforeEach(function () {
            module('Mdt.Module.MdtGroupService', 'Mdt.MdtUserService', function ($provide) {
                // add a mock $Endpoint provider - it will return ROOT_URL for any endpoint)
                $provide.value('$Endpoint', {
                    getEndpointAsync: function(){
                        return {
                            then: function(success){
                                var publicAPI = success(ROOT_URL);
                                return {
                                    then: function(fn){
                                        fn(publicAPI);
                                    }
                                };
                            }
                        };
                    }
                });
            });

            inject(function (_MdtGroupService_, _MdtUserService_, _$httpBackend_) {
                MdtGroupService = _MdtGroupService_;
                MdtUserService = _MdtUserService_;
                $httpBackend = _$httpBackend_;
            });
        });

        describe("MdtGroupService", function () {
            describe("searchUser", function () {
                it("should find a user", function () {
                    var text = "user";
                    var actUserSearchResult = {
                        "entry": [
                            {
                                "id": "1234567890"
                            }
                        ]
                    };
                    $httpBackend.whenGET(USER_MANAGEMENT_URL + '?' + 'email=' + text + '~%23OR' + '&' + 'firstname=' + text + '~%23OR' + '&' + 'lastname='  + text  + '~%23OR')
                            .respond(actUserSearchResult);
                    var userSearchResult = null;

                    MdtUserService.then(function(service){
                        service.searchUser(text).then(function (response) {
                            userSearchResult = response;
                        });
                    });

                    $httpBackend.flush();

                    expect(userSearchResult).to.have.length(1);
                    expect(userSearchResult[0].id).to.equal(actUserSearchResult.entry[0].id);
                });
            });

            describe("getGroupHeaders", function () {
                it("should call group headers list webservice", function () {
                    $httpBackend.expectGET(ROOT_URL + '/views/manage-groups/list-groups').respond({});

                    MdtGroupService.then(function(service) {
                        service.getGroupHeaders();
                    });

                    $httpBackend.flush();
                });
            });

            describe("getGroupDetails", function () {
                it("should call group details list webservice with proper group id", function () {
                    var groupId = '1';
                    $httpBackend.expectGET(ROOT_URL + '/views/manage-groups/group-settings?groupId=' + groupId).respond({});
                    MdtGroupService.then(function(service) {
                        service.getGroupDetails(groupId);
                    });
                    $httpBackend.flush();
                });
            });

            describe("update", function () {
                it("should update group settings", function () {
                    var groupId = {id: '1'};
                    $httpBackend.expectPOST(ROOT_URL + '/views/manage-groups/group-settings', groupId).respond({});
                    MdtGroupService.then(function(service) {
                        service.update(groupId);
                    });
                    $httpBackend.flush();
                });

                it("should update user settings", function () {
                    var userId = {id: 1};
                    $httpBackend.expectGET(ROOT_URL + '/userregistry/v1/user/' + userId.id + '?fieldset=all&level.value=2').respond({});
                    MdtUserService.then(function(service) {
                        service.updateUser(userId);
                    });
                    $httpBackend.flush();
                });

                it("should update user name", function () {
                    var userId = {id: 1};
                    $httpBackend.expectGET(ROOT_URL + '/userregistry/v1/user/' + userId.id + '?fieldset=all&level.value=2').respond({});

                    MdtUserService.then(function(service) {
                        service.updateUser(userId);
                    });
                    $httpBackend.flush();
                });
            });
        });

    });
});
