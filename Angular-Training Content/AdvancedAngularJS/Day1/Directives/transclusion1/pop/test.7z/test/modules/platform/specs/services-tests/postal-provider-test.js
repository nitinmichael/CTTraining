define(['angular-mocks', 'modules/platform/services/postal-provider'], function(ngMocks) {
    describe('Test  $bus service', function() {

        beforeEach(module('platform.service.postal-provider'));

        it(' defines $bus ', function() {
            var $rootScope, $scope;
            inject(function(_$rootScope_) {
                $rootScope = _$rootScope_;
                $scope = _$rootScope_.$new(); //inherited scope
                expect($scope.$bus).to.exist;
            })
        })
    });
});
