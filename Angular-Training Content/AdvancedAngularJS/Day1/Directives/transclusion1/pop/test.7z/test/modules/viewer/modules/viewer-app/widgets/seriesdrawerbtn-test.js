/*
 *  seriesdrawerbtn-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Sylvain Rouquette <sylvain.rouquette@ge.com>
 */

/**
 * Spec file for Viewer > modules > viewer-app > widgets > series-drawer directive
 */
//

define(['angular', 'angular-mocks', 'viewerModule/widgets/series-drawer/directives/series-drawer-btn', 'viewportParameterStorageMock'], function() {
    'use strict';

    describe('Series Selector Button Directive Test :', function() {
        var element, scope;


        describe('defined directive', function() {
            var  toolFactory;
            var viewportParameterStorage;
          
            beforeEach(module('viewportParameterStorage'));
          
            beforeEach(module('cloudav.viewerApp.widgets', function($provide, viewportParameterStorageMock) {
                toolFactory = {
                    toolPanelObj: sinon.spy(),
                    toolBtnObj: sinon.spy()
                };
                viewportParameterStorage = viewportParameterStorageMock.$get();
                $provide.provider('$viewportParameterStorage', viewportParameterStorageMock);
                $provide.value('$toolFactory', toolFactory);
            }));
            beforeEach(module('templates'));
            beforeEach(
                inject(function($compile, $rootScope) {
                    scope = $rootScope.$new();
                    scope.seriesDrawerBtnContent= {};
                    element = $compile('<series-drawer-btn series-drawer-btn-content="seriesDrawerBtnContent" />')(scope);
                    scope.$digest();
                })
            );
            it('should have a directive', function() {
                assert.isDefined(element, 'series-drawer-btn Directive is not defined');
            });

            it('should update html Content of the inner toolBtnObj', function() { 
                var isolatedScope = element.isolateScope();
                assert.isDefined(isolatedScope, 'series-drawer-btn Directive isolated scope is not defined');
                expect(function(){
                    return ((isolatedScope.seriesDrawerBtn.content.indexOf('2015') !== -1) && (isolatedScope.seriesDrawerBtn.content.indexOf('desc')!==-1));
                }()).to.equal(true);
            });
        });
    });
});
