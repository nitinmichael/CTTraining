/**
 * @ngdoc service
 * @name cloudav.viewerApp.test:TEST_viewer-scrollbar
 *
 * @description This property is a unit test file located at: test > modules > viewer > modules > viewer-app > widgets >
 *              viewer-scrollbar-test.js This file contains unit tests for the
 *              {@link cloudav.viewerApp.directive:viewerScrollbar viewer-scrollbar} directive.
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 *
 * @author: Josselin BUILS <josselin.buils@ge.com>
 */
define(['angular', 'angular-mocks', 'platformMock', 'viewerModule/widgets/viewer-scrollbar/viewer-scrollbar'], function() {
    'use strict';

    describe('Viewer scrollbar :', function() {
        var scope, element, isolatedScope, measureManager, xjtweb, deviceManagerService, container, cssValue, handleSize, mousedownEventMock, moveEventMock;

        beforeEach(module('cloudav.viewerApp.widgets', function($provide) {
            measureManager = {
                publish: sinon.spy()
            };
            xjtweb = {
                XJTWEB: XJTWEB
            };
            deviceManagerService = {
                getSupportedDeviceName: function() {
                    return 'desktop';
                }
            };
            $provide.value('MeasureManager', measureManager);
            $provide.value('$xjtweb', xjtweb);
            $provide.value('$deviceManagerService', deviceManagerService);
        }));

        beforeEach(module('templates'));
        beforeEach(module('platform'));


        beforeEach(inject(function($compile, $rootScope) {
            var html = angular.element('<viewer-scrollbar></viewer-scrollbar>');
            scope = $rootScope.$new();
            element = $compile(html)(scope);
            scope.$digest();
            isolatedScope = element.isolateScope();

            isolatedScope.getContainer = function() {
                var container = {
                    outerHeight: function() {
                        return 100;
                    },
                    offset: function() {
                        return {
                            top: 92
                        }
                    }
                };
                return {
                    top: container.offset().top,
                    height: container.outerHeight(),
                    bottom: (container.offset().top + container.outerHeight()),
                    children: []
                }
            };


            handleSize = {
                outerHeight: function() {
                    return 5;
                },
                css: function(value) {
                    return value;
                }
            };
            isolatedScope.handles = {
                "thickSlabTopHandle": {
                    outerHeight: function() {
                        return 5;
                    },
                    offset: function() {
                        return {
                            top: 115
                        }
                    },
                    css: function(value) {
                        cssValue = value;
                    },
                    heightInPercent: 10,
                    topInPercent: 0
                },
                "pagingHandle": {
                    outerHeight: function() {
                        return 10;
                    },
                    offset: function() {
                        return {
                            top: 130
                        }
                    },
                    css: function(value) {
                        cssValue = value;
                    },
                    heightInPercent: 20,
                    topInPercent: 20
                },
                "thickSlabBottomHandle": {
                    outerHeight: function() {
                        return 5;
                    },
                    offset: function() {
                        return {
                            top: 160
                        }
                    },
                    css: function(value) {
                        cssValue = value;
                    },
                    heightInPercent: 10,
                    topInPercent: 60
                }
            };
            isolatedScope.clickingDistanceToHandleTop = 10;
        }));

        /**
         * @ngdoc property
         * @name UNIT_TEST_viewer-scrollbar-initialization
         * @propertyOf cloudav.viewerApp.test:TEST_viewer-scrollbar
         *
         * @description This property is a unit test located in the viewer-scrollbar-TEST file. It is designed to
         *              test the initial creation of the viewerScrollbar directive.
         *
         */
        it('should have a directive', function() {
            assert.isDefined(element, 'viewer-scrollbar Directive is not defined');
        });

        it('should have a scrollbarBtns property in scope', function() {
            assert.isDefined(isolatedScope.scrollbarBtns, 'viewer-scrollbar Directive should have a scrollbarBtns property in scope');
        });

        it('should have scrollbarBtns of type simple-bar', function() {
            expect(isolatedScope.scrollbarBtns.type).to.equal('simple-bar', 'The scrollbarBtns property should be of type simple-bar');
        });

        it('should have two buttons in the scrollbarBtns.buttons array', function() {
            expect(isolatedScope.scrollbarBtns.buttons.length).to.equal(2, 'scrollbarBtns was not created with a buttons array with two buttons.');
        });

        it('should have two buttons of type toolBtn in the scrollbarBtns.buttons array', function() {
            expect(isolatedScope.scrollbarBtns.buttons[0].type).to.equal('toolBtn', 'The first button in scrollbarBtns is not of type toolBtn');
            expect(isolatedScope.scrollbarBtns.buttons[1].type).to.equal('toolBtn', 'The second button in scrollbarBtns is not of type toolBtn');
        });

        it('should have an icon for each buttons in the scrollbarBtns.buttons array', function() {
            expect(typeof isolatedScope.scrollbarBtns.buttons[0].icon).to.equal('object', 'The first button in scrollbarBtns do not have an icon');
            expect(typeof isolatedScope.scrollbarBtns.buttons[1].icon).to.equal('object', 'The second button in scrollbarBtns do not have an icon');
        });

        it('should have a onclick function for each buttons in the scrollbarBtns.buttons array', function() {
            expect(typeof isolatedScope.scrollbarBtns.buttons[0].onclick).to.equal('function', 'The first button in scrollbarBtns do not have an onclick function');
            isolatedScope.scrollbarBtns.buttons[0].onclick();
            expect(measureManager.publish.calledWith(xjtweb.XJTWEB.MEASURE_MANAGER.TOPIC.SELECT_PREV)).to.equal(true);

            expect(typeof isolatedScope.scrollbarBtns.buttons[1].onclick).to.equal('function', 'The second button in scrollbarBtns do not have an onclick function');
            isolatedScope.scrollbarBtns.buttons[1].onclick();
            expect(measureManager.publish.calledWith(xjtweb.XJTWEB.MEASURE_MANAGER.TOPIC.SELECT_NEXT)).to.equal(true);
        });

        it('should have an id "previous-btn" for the first button in the scrollbarBtns.buttons array', function() {
            expect(isolatedScope.scrollbarBtns.buttons[0].id).to.equal('previous-btn', 'The first button in scrollbarBtns do not have an id "previous-btn"');
        });

        it('should have an id "next-btn" for the first button in the scrollbarBtns.buttons array', function() {
            expect(isolatedScope.scrollbarBtns.buttons[1].id).to.equal('next-btn', 'The second button in scrollbarBtns do not have an id "next-btn"');
        });

        it('should have a content "Previous" for the first button in the scrollbarBtns.buttons array', function() {
            expect(isolatedScope.scrollbarBtns.buttons[0].content).to.equal('Previous', 'The first button in scrollbarBtns do not have a content "Previous"');
        });

        it('should have a content "Next" for the second button in the scrollbarBtns.buttons array', function() {
            expect(isolatedScope.scrollbarBtns.buttons[1].content).to.equal('Next', 'The second button in scrollbarBtns do not have a content "Next"');
        });
        it('should not drag the handle position because the mouse position is not between the top and the bottom of the container', function() {
            var syncStub = sinon.stub(isolatedScope, 'synchronize');

            mousedownEventMock = {
                target: {
                    id: "pagingHandle"
                }
            };
            isolatedScope.setCurrentHandle(mousedownEventMock);
            moveEventMock = {
                clientY: 10,
                originalEvent: {
                    touches: [{
                        clientY: 10
                    }]
                }
            };
            isolatedScope.mouseMove(moveEventMock);
            expect(cssValue).to.equal(undefined);
            syncStub.should.not.have.been.called;
            cssValue = undefined;
        });
        it('should change the handle position on dragg to 0% because the y position is inferior than 0', function() {
            var syncStub = sinon.stub(isolatedScope, 'synchronize');

            mousedownEventMock = {
                target: {
                    id: "thickSlabTopHandle"
                }
            };
            isolatedScope.setCurrentHandle(mousedownEventMock);
            moveEventMock = {
                clientY: 102,
                originalEvent: {
                    touches: [{
                        clientY: 102
                    }]
                }
            };
            isolatedScope.mouseMove(moveEventMock);
            expect(cssValue.top).to.equal('0%', 'the handle did not move with 0% top');
            syncStub.should.have.been.calledOnce;
            cssValue = undefined;
        });
        it('should change the handle position on dragg (mousedown + mosemove)', function() {

            var syncStub = sinon.stub(isolatedScope, 'synchronize');
            mousedownEventMock = {
                target: {
                    id: "thickSlabBottomHandle"
                }
            };
            isolatedScope.setCurrentHandle(mousedownEventMock);
            moveEventMock = {
                clientY: 150,
                originalEvent: {
                    touches: [{
                        clientY: 150
                    }]
                }
            };
            isolatedScope.mouseMove(moveEventMock);
            expect(cssValue.top).to.equal('48%', 'the handle did not move with the correct top %');
            syncStub.should.have.been.calledOnce;
            cssValue = undefined;
        });

        it('should retrieve the distance between the bottom thickslab handle and the top paging handle', function() {
            var delta = isolatedScope.calculateDistanceBetweenHandles();
            expect(delta).to.equal(20);
        });

        it('should move top handle and bottom handle when paging handle moves', function() {
            var moveHandleSpy = sinon.spy(isolatedScope, 'moveHandle');

            isolatedScope.synchronize('pagingHandle');

            moveHandleSpy.should.have.been.calledWith('thickSlabTopHandle');
            moveHandleSpy.should.have.been.calledWith('thickSlabBottomHandle');

        });

        it('should move bottom handle when top handle moves', function() {
            var moveHandleSpy = sinon.spy(isolatedScope, 'moveHandle');
            isolatedScope.synchronize('thickSlabTopHandle');

            moveHandleSpy.should.have.been.calledWith('thickSlabBottomHandle');

        });

        it('should move top handle when bottom handle moves', function() {
            var moveHandleSpy = sinon.spy(isolatedScope, 'moveHandle');
            isolatedScope.synchronize('thickSlabBottomHandle');

            moveHandleSpy.should.have.been.calledWith('thickSlabTopHandle');
        });

    });
});
