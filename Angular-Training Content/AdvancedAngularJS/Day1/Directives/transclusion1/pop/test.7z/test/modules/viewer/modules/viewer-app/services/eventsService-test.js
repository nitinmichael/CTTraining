define(['angular', 'postal', 'GraphicalObjectMock', 'linkingMocks', 'viewerModule/services/eventsService'], function(ng, postal) {
  'use strict';

  describe('Event service test', function() {

    beforeEach(module('xjtweb-platform'));
    beforeEach(module('cloudav.viewerApp.linkingviewport'));
    beforeEach(module('cloudav.viewerApp.services'));
    var eventsService, sceneManager, measureManager, cursorManager, linkingManager, $xjtweb, $timeout;
    var viewportParameterStorage = function() {
      this.$get = function() {
        return {
          'getCurrentConfiguration': function() {
            return {
              ports: [{
                index: 0,
                menu: false,
                cssLayout: 'twoByTwo',
                usePredefinedLayout: true,
                getId: function() {
                  return '0';
                }
              }]
            };
          }
        };
      };
    };
    var portContentFactory = function() {
      this.$get = function() {
        return {
          'getActivePortIndex': function() {}
        };
      };
    };

    beforeEach(module(function($provide, GraphicalObjectMock, linkingMocks) {
      sceneManager = GraphicalObjectMock.SceneManagerMock(false, postal);
      measureManager = GraphicalObjectMock.MeasureManagerMock(postal);
      cursorManager = GraphicalObjectMock.CursorManagerMock(postal);
      linkingManager = linkingMocks.linkingManagerMock();
      $provide.value('SceneManager', sceneManager);
      $provide.value('MeasureManager', measureManager);
      $provide.value('CursorManager', cursorManager);
      $provide.value('linkingManager', linkingManager);
      $provide.provider('$viewportParameterStorage', viewportParameterStorage);
      $provide.provider('portContentFactory', portContentFactory);
      $provide.value('$xjtweb', $xjtweb);
    }));

    beforeEach(inject(function(_eventsService_,_$timeout_) {
      eventsService = _eventsService_;
      $timeout = _$timeout_;
      eventsService.subscribeViewerEvents();
    }));

    it('ADD_GROUP event should be published when a group is added, and create a cursor for that group', function() {

      var group_id = 'group_id';
      var subscribe_addgroup = sceneManager.subscribe.args[1];
      var callback = subscribe_addgroup[1];
      callback(group_id);
      expect(sceneManager.addCursor3D.calledOnce).to.equal(true);
      var cursor = cursorManager.getSelectedCursor();
      expect(cursor).not.to.equal(null);
      expect(cursor.parent_id).to.equal(group_id);

      var subscribe_cursorupdate = cursor.subscribe.args[0];
      callback = subscribe_cursorupdate[1];
      callback();
      expect(linkingManager.publish.calledOnce).to.equal(true);
      expect(cursorManager.setPosition.calledOnce).to.equal(true);
    });


    it('Add Measure callback should be called ', function() {
      var subscribe_addmeasure = measureManager.subscribe.args[0];
      var callback = subscribe_addmeasure[1];
      callback({
        data: null
      });
      expect(sceneManager.addMeasure.calledOnce).to.equal(true);
    });

    it('Render function should be called when a render message is posted on topic', function() {
      var subscribe_render = sceneManager.subscribe.args[0];
      var callback = subscribe_render[1];
      callback();
       $timeout.flush();
      expect(sceneManager.render.calledOnce).to.equal(true);
    });
  });
});
