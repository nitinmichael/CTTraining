    define(['angular',
            'angular-mocks',
            'orgMgmnt/services/userService',
            'orgMgmnt/utilities/masterDataUtil'],
        function () {
            'use strict';
            describe('Test user Service', function () {
                beforeEach(function () {
                    module(function($provide){
                        $provide.service('masterDataModel', function(){
                            this.getGatewayUrl= sinon.spy();
                        });
                    });
                    module('Orgmanagement.Services.UserService');
                });
                var userMgmtService;
                var $httpBackend, uomServiceUrl, _masterDataModel;
                var q, defer,userDeferred,loggedInUserDeferred,activeUserDeferred,listOfSiteForUserDeferred;
                var listOfSitesForLoggedInUserDeferred,listOfApplicationServiceForUserDeferred,
                        listOfApplicationServiceForlistofSitesDeferred, listOfOrgsForLoggedInUserDeferred;

                beforeEach(inject(function(_userMgmtService_, _$httpBackend_,_$q_, masterDataModel) {
                    userMgmtService = _userMgmtService_;
                    $httpBackend = _$httpBackend_;
                    _masterDataModel = masterDataModel;
                    q = _$q_;
                    defer = q.defer();
                    userDeferred = q.defer();
                    activeUserDeferred = q.defer();
                    loggedInUserDeferred= q.defer();
                    listOfSiteForUserDeferred = q.defer();
                    listOfSitesForLoggedInUserDeferred = q.defer();
                    listOfOrgsForLoggedInUserDeferred = q.defer();
                    listOfApplicationServiceForUserDeferred = q.defer();
                    listOfApplicationServiceForlistofSitesDeferred = q.defer();
                    uomServiceUrl = _masterDataModel.getGatewayUrl();
                }));
                    describe('Create user service', function(){
                        it('should test createUser is called successfully ', function () {
                            var user = {"value":"username"};
                            var url=uomServiceUrl+'/v2/user';
                            $httpBackend.expectPOST(url,user).respond(200);
                            defer.resolve();
                            userMgmtService.createUser(user);
                            $httpBackend.flush();
                            $httpBackend.verifyNoOutstandingExpectation();
                            $httpBackend.verifyNoOutstandingRequest();

                    });
                });

                describe('list of users service', function(){
                    it('created new user and list of users is displayed successfully ', function () {
                        var orgId="a8fe5239-d42c-4e77-8809-7fed5db2fd46";
                        var url = uomServiceUrl + "/v2/user/_search?orgId="+orgId;
                        $httpBackend.expectGET(url).respond(200);
                        defer.resolve();
                        userMgmtService.listOfPendingUsers(orgId);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                    it('created new user and list of users is nopt displayed-failure ', function () {
                        var orgId="a8fe5239-d42c-4e77-8809-7fed5db2fd46";
                        var url = uomServiceUrl + "/v2/user/_search?orgId="+orgId;
                        $httpBackend.expectGET(url).respond(400);
                        defer.reject();
                        userMgmtService.listOfPendingUsers(orgId);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });
                });

                describe('getLoggedInUserDetails', function(){
                    it('gets the logged in user details ', function () {
                        var url=uomServiceUrl+'/v1/user/me';
                        $httpBackend.expectGET(url).respond(200);
                        loggedInUserDeferred.resolve();
                        userMgmtService.getLoggedInUserDetails();
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                    it(' gets the logged in user details success, if loggedInUserDetails is already set/defined ', function () {
                        var url=uomServiceUrl+'/v1/user/me';
                        $httpBackend.expectGET(url).respond(200);
                        loggedInUserDeferred.resolve();
                        var loggedInUser = userMgmtService.getLoggedInUserDetails();
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                        chai.expect(loggedInUser).to.be.equal(userMgmtService.getLoggedInUserDetails());
                    });

                    it(' gets the logged in user details failed ', function () {
                        var url=uomServiceUrl+'/v1/user/me';
                        $httpBackend.expectGET(url).respond(400);
                        loggedInUserDeferred.reject();
                        userMgmtService.getLoggedInUserDetails();
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                });

                describe('get list of sites for the user', function(){
                    it('get list of sites for user successfully ', function () {

                        var userId = '11f3c259-b0ac-4eac-93ef-44573735010a';
                        var param = {'level.value':2};
                        var url = uomServiceUrl+"/v1/user/"+userId+"/site?level.value=2";

                        $httpBackend.expectGET(url).respond(200);
                        listOfSiteForUserDeferred.resolve();
                        userMgmtService.listOfSiteForUser(userId,param);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });
                    it('get list of sites for user failure', function () {
                        var userId = '11f3c259-b0ac-4eac-93ef-44573735010a';
                        var param = {"level.value":2};
                        var url = uomServiceUrl+"/v1/user/"+userId+"/site?level.value=2";
                        $httpBackend.expectGET(url).respond(400);
                        listOfSiteForUserDeferred.resolve();
                        userMgmtService.listOfSiteForUser(userId,param);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });
                });

                describe('Save sitelist for the user', function(){
                    it('save sites for the user successfully ', function () {
                        var userId = '11f3c259-b0ac-4eac-93ef-44573735010a';

                        var scopeRoleObj = {
                            "resourceType" : "ResourcesUser",
                            "role" : ""
                        };
                        var saveSitesForUser = {
                            "id":userId,
                            "scopeRoleObj":scopeRoleObj
                        };
                        var url = uomServiceUrl+"/v1/user/"+saveSitesForUser.id+"/scopedrole";
                        $httpBackend.expectPUT(url).respond(200);
                        listOfSiteForUserDeferred.resolve();
                        userMgmtService.saveManageUsersSiteList(saveSitesForUser);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });
                    it('save sites for the user  failure', function () {
                        var userId = '11f3c259-b0ac-4eac-93ef-44573735010a';
                        var scopeRoleObj = {
                            "resourceType" : "ResourcesUser",
                            "role" : ""
                        };
                        var saveSitesForUser = {
                            "id":userId,
                            "scopeRoleObj":scopeRoleObj
                        };
                        var url = uomServiceUrl+"/v1/user/"+saveSitesForUser.id+"/scopedrole";
                        $httpBackend.expectPUT(url).respond(400);
                        listOfSiteForUserDeferred.resolve();
                        userMgmtService.saveManageUsersSiteList(saveSitesForUser);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });
                });

                describe('get list of sites for the list of sites for Logged In User', function(){
                    it('get list of sites for Logged In User successfully ', function () {
                        var param = {
                            role : 'administrator'
                        };
                        var url = uomServiceUrl + "/v1/user/me/site?role=administrator";
                        $httpBackend.expectGET(url).respond(200);
                        listOfSitesForLoggedInUserDeferred.resolve();
                        userMgmtService.listOfSiteForLoggedInUser(param);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });
                    it('get list of sites for Logged In User failure', function () {
                        var param = {
                            role : 'administrator'
                        };
                        var url = uomServiceUrl + "/v1/user/me/site?role=administrator";
                        $httpBackend.expectGET(url).respond(400);
                        listOfSitesForLoggedInUserDeferred.resolve();
                        userMgmtService.listOfSiteForLoggedInUser(param);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                });

                describe('get list of organizations for the Logged In User', function(){
                    it('get list of organizations for Logged In User successfully ', function () {
                        var param = {
                            role : 'administrator',
                            'level.value': '2'
                        };
                        var url = uomServiceUrl + "/v1/user/me/organization?level.value=2&role=administrator";
                        $httpBackend.expectGET(url).respond(200);
                        listOfOrgsForLoggedInUserDeferred.resolve();
                        userMgmtService.listOfOrganizationForLoggedInUser(param);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });
                    it('get list of organizations for Logged In User failure', function () {
                        var param = {
                            role : 'administrator',
                            'level.value': '2'
                        };
                        var url = uomServiceUrl + "/v1/user/me/organization?level.value=2&role=administrator";
                        $httpBackend.expectGET(url).respond(400);
                        listOfOrgsForLoggedInUserDeferred.resolve();
                        userMgmtService.listOfOrganizationForLoggedInUser(param);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                });

                describe('get list of sites for the list of sites for Logged In User', function(){
                    it('get list of sites for Logged In User successfully ', function () {
                        var url = './modules/orgmanagement/services/bulkAppservice.json';
                        $httpBackend.expectGET(url).respond(200);
                        listOfApplicationServiceForlistofSitesDeferred.resolve();
                        userMgmtService.listOfApplicationServiceForlistofSites();
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });
                    it('get list of sites for Logged In User failure', function () {
                        var url = './modules/orgmanagement/services/bulkAppservice.json';
                        $httpBackend.expectGET(url).respond(400);
                        listOfApplicationServiceForlistofSitesDeferred.resolve();
                        userMgmtService.listOfApplicationServiceForlistofSites();
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                });


                describe('get list of application services for the user', function(){
                    it('get list of application services for the user successfully ', function () {
                        var userId = '11f3c259-b0ac-4eac-93ef-44573735010a';
                        var param = {'level.value':2};
                        var url = uomServiceUrl+"/v1/user/"+userId+"/applicationservice?level.value=2";

                        $httpBackend.expectGET(url).respond(200);
                        listOfApplicationServiceForUserDeferred.resolve();
                        userMgmtService.listOfApplicationServiceForUser(userId,param);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });
                    it('get list of application services for the user failure', function () {
                        var userId = '11f3c259-b0ac-4eac-93ef-44573735010a';
                        var param = {'level.value':2};
                        var url = uomServiceUrl+"/v1/user/"+userId+"/applicationservice?level.value=2";
                        $httpBackend.expectGET(url).respond(400);
                        listOfApplicationServiceForUserDeferred.resolve();
                        userMgmtService.listOfApplicationServiceForUser(userId,param);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                });
                describe('list of active users service', function(){
                    it('created new user and list of users is displayed successfully ', function () {
                        var orgId="a8fe5239-d42c-4e77-8809-7fed5db2fd46";
                        var url = uomServiceUrl + "/v2/user/_search?orgId="+orgId;
                        $httpBackend.expectGET(url).respond(200);
                        activeUserDeferred.resolve();
                        userMgmtService.listOfActiveUsers(orgId);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                    it('created new user and list of users is nopt displayed-failure ', function () {
                        var orgId="a8fe5239-d42c-4e77-8809-7fed5db2fd46";
                        var url = uomServiceUrl + "/v2/user/_search?orgId="+orgId;

                        $httpBackend.expectGET(url).respond(400);
                        activeUserDeferred.reject();
                        userMgmtService.listOfActiveUsers(orgId);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });
                });

                describe('searchUserByEmailId ', function(){
                    it('searchUserByEmailId successfully ', function () {
                        var emailId="test123456@ge.com";
                        var url = uomServiceUrl + "/v2/user/_search?email="+emailId;
                        $httpBackend.expectGET(url).respond(200);
                        listOfSitesForLoggedInUserDeferred.resolve();
                        userMgmtService.searchUserByEmailId(emailId);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });
                    it('searchUserByEmailId failure ', function () {
                        var emailId="test123456@ge.com";
                        var url = uomServiceUrl + "/v2/user/_search?email="+emailId;
                        $httpBackend.expectGET(url).respond(400);
                        listOfSitesForLoggedInUserDeferred.resolve();
                        userMgmtService.searchUserByEmailId(emailId);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                });
                describe('Find User Service', function(){
                    var searchUserResult = [ {
                        "title": "ResourcesUser",
                        "id": "3cc1f86d-4c81-46a4-a7f2-76c60a2c84b1",
                        "content": {
                            "resourceType": "ResourcesUser",
                            "name": {
                                "use": "official",
                                "family": [
                                    "Chalmers"
                                ],
                                "given": [
                                    "Bradley",
                                    "Casper"
                                ]
                            },
                            "telecom": [
                                {
                                    "system": "phone",
                                    "value": "(+1) 734-677-7777"
                                },
                                {
                                    "system": "email",
                                    "value": "bradley@ge.com"
                                }
                            ],
                            "status": "active"
                        }
                    }], url = './modules/orgmanagement/services/getAllUser.json';
                    it("checks find user service is called successfully, records found", function(){
                        var user = "a";
                        url = uomServiceUrl+'/v2/user/_search?name='+user;
                        $httpBackend.expectGET(url).respond(200);
                        defer.resolve(searchUserResult);
                        userMgmtService.findUser(user);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                    it("checks find user service is called successfully, no records found", function(){
                        var user = "a";
                        url = uomServiceUrl+'/v2/user/_search?name='+user;
                        $httpBackend.expectGET(url).respond(200);
                        defer.resolve({});
                        userMgmtService.findUser(user);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                    it("checks find user service is not called successfully", function(){
                        var user = "a";
                        url = uomServiceUrl+'/v2/user/_search?name='+user;
                        $httpBackend.expectGET(url).respond(400);
                        defer.reject();
                        userMgmtService.findUser(user);
                        $httpBackend.flush();
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });
                });
            });

        });
