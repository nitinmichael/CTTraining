/*
 *  ge-patient-list-directive-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Raoul Nair<raoul.nair@ge.com>
 */
define([ 'angular', 'angular-mocks', 'widgets/ge-patient-list/ge-patient-list-directive', 'mocks/case-exchange-mock-service' ], function() {
    var expect = chai.expect;
    var scope, element, spy, compile, rootScope, isolateScope, filter, $q, translateFilter, pacsSearchData, patientInfiniteSearchResponse, existingPatientRecord;
    var html = '<ge-patient-list list="patientsList" ' + 
                                'total-patient-count="patientCount" ' + 
                                'click-action="callbackFn"> ' + 
                '</ge-patient-list>';

    function fakeInfiniteSearchResolved(value) {
        return {
            promise : {
                then : function(callback) {
                    callback(patientInfiniteSearchResponse);
                }
            }
        }
    }

    var alertTypes = {
            success: 'success',
            error: 'error'
        };

    function fakeInfiniteSearchNull(value) {
        return {
            promise : {
                then : function(callback) {
                    callback("");
                }
            }
        }
    }

    function configureDirectiveComponents($injector, $templateCache, _$q_, CaseExchangeMocks) {
        $q = _$q_;
        compile = $injector.get('$compile');
        rootScope = $injector.get('$rootScope');

        pacsSearchData = CaseExchangeMocks.getPatientSearchData();
        patientInfiniteSearchResponse = CaseExchangeMocks.getPatientInfiniteSearchData();
        existingPatientRecord = CaseExchangeMocks.getExistingPatients();

        scope = rootScope.$new();
        scope.$digest();

        element = compile(html)(scope);
        scope.$digest();
        isolateScope = element.isolateScope();

        // Mocking the method from parent controller as we don't have inheritance in place in unit testing.
        isolateScope.showAlertMessage = function () {
        };
    }


    function configureDirectiveProviders($provide) {
        var dateFormatFilter = sinon.spy();
        $provide.value('dateFormatFilter', dateFormatFilter);

        $provide.value('PacsSearchMarshaller', {
            getpacsSearchData : function() {
                return pacsSearchData;
            }
        });
    }

    describe('GE patient list with valid data', function() {

        beforeEach(function() {
            // Load the module for the mock data first
            module('cloudav.caseExchange.mocks');
            module('Directive.gePatientList')
        });

        beforeEach(module(function($provide) {
            configureDirectiveProviders($provide);

            // Load the module for the mock data first
            module('cloudav.caseExchange.mocks');

            $provide.value('PacsSearchService', {
                pacsSearch : function() {
                    return fakeInfiniteSearchResolved("value")
                }
            });
        }));

        beforeEach(inject(function($injector, $templateCache, _$q_, CaseExchangeMocks) {
            configureDirectiveComponents($injector, $templateCache, _$q_, CaseExchangeMocks);
        }));

        it('should call updatedPatientName with all defined parameter', function() {
            var patient = {
                name : {
                    firstName : "firstName",
                    lastName : "lastName",
                    middleName : "middleName"
                }
            };
            assert.isDefined(isolateScope.updatedPatientName(patient), 'Ge Patient List directive scope doesn\'t have "updatedPatientName" function defined');
        });

        it('should call updatedPatientName with patient name components as null', function() {
            var patient = {
                name : {
                    firstName : null,
                    lastName : null,
                    middleName : null
                }
            };
            assert.isDefined(isolateScope.updatedPatientName(patient), 'Ge Patient List directive scope doesn\'t have "updatedPatientName" function defined');
        });

        it('should call updatedPatientName with patient components as null', function() {
            var patient = null;
            assert.isDefined(isolateScope.updatedPatientName(patient), 'Ge Patient List directive scope doesn\'t have "updatedPatientName" function defined');
        });

        it('should call showPatient() and it will append incoming patient from ajax call to existing patient list', function() {
            isolateScope.lastPatientFetched = false;
            isolateScope.patients = existingPatientRecord;
            isolateScope.totalPatientCount = 11;
            expect(isolateScope.patients).to.have.length(10);
            isolateScope.showPatients();
            expect(isolateScope.patients).to.have.length(11);
        });

        it('should lastPatientFetched be true for same patients length and patient count in showPatient()', function() {
            isolateScope.patients = [];
            isolateScope.patients.length = 11;
            isolateScope.totalPatientCount = 11;
            isolateScope.showPatients();
            expect(isolateScope.lastPatientFetched ).to.be.true;
        });

    });

    describe('GE patient list with invalid data', function() {

        beforeEach(function() {
            // Load the module for the mock data first
            module('cloudav.caseExchange.mocks');
            module('Directive.gePatientList')
        });

        beforeEach(module(function($provide) {
            configureDirectiveProviders($provide);

            $provide.value('PacsSearchService', {
                pacsSearch : function() {
                    return fakeInfiniteSearchNull("value")
                }
            });
        }));

        beforeEach(inject(function($injector, $templateCache, _$q_, CaseExchangeMocks) {
            configureDirectiveComponents($injector, $templateCache, _$q_, CaseExchangeMocks);
        }));

        it('should call showPatient() and ajax call will return blank data', function() {
            isolateScope.lastPatientFetched = false;
            isolateScope.patients = existingPatientRecord;
            isolateScope.alertTypes = alertTypes;
            var showAlertMessageSpy = sinon.spy(isolateScope, 'showAlertMessage');
            isolateScope.showPatients();
            expect(isolateScope.patients).to.have.length(10);
            expect(isolateScope.numPatientsFound).to.equal(0);
        });
    });
});
