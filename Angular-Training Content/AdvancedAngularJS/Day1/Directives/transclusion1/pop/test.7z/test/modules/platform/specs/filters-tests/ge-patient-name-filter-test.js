/*
 * ge-patient-name-filter-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define([ 'angular-mocks',  'modules/platform/filters/ge-patient-name-filter' ], function() {
    describe('Patient name filter tests', function() {
        var $filter;

        beforeEach(module('platform.filter.ge-patient-name-filter'));
        beforeEach(inject(function(_$filter_) {
            $filter = _$filter_('gePatientName');
        }));

        it("should have a filter defined", function () {
            assert.isDefined($filter, 'filter is not defined');
        });

        it("should return (No information) if name is undefined", function () {
            var name = undefined;
            var result = $filter(name);
            expect(result).to.equal('(No information)');
        });

        it("should return empty string when name is empty", function () {
            var name = {
                prefix: [],
                suffix: [],
                family: [],
                given:  []
            };
            var result = $filter(name);
            expect(result).to.equal('');

            name = {
                prefix: '',
                suffix: '',
                family: '',
                given:  ''
            };
            result = $filter(name);
            expect(result).to.equal('');
        });

        it("should return Family, Given when those are set", function () {
            var name = {
                prefix: [],
                suffix: [],
                family: 'Doe',
                given:  'John'
            };
            var result = $filter(name);
            expect(result).to.equal('Doe, John');

            name = {
                prefix: [],
                suffix: [],
                family: ['Doe'],
                given:  ['John']
            };
            result = $filter(name);
            expect(result).to.equal('Doe, John');
        });

        it("should return Family, Given Given when multiple given name is set", function () {
            var name = {
                prefix: [],
                suffix: [],
                family: ['Doe'],
                given:  ['John', 'Jack']
            };
            var result = $filter(name);
            expect(result).to.equal('Doe, John Jack');
        });

        it("should return Prefix, Family, Given", function () {
            var name = {
                prefix: ['Dr'],
                suffix: [],
                family: ['Doe'],
                given:  ['John']
            };
            var result = $filter(name);
            expect(result).to.equal('Dr, Doe, John');
        });

        it("should return Prefix, Family, Given, Suffix", function () {
            var name = {
                prefix: ['Dr'],
                suffix: ['Sr'],
                family: ['Doe'],
                given:  ['John']
            };
            var result = $filter(name);
            expect(result).to.equal('Dr, Doe, John, Sr');
        });
    });
});