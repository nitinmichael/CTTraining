define(['angular','postal','angular-mocks','orgMgmnt/widgets/ge-exception-handler/geExceptionHandler'],
    function () {
        'use strict';
        describe('Tests ge-exception-handler singleton factory obj methods', function() {
            var rootScope, filter, msgObj,broadcast;
            beforeEach(function () {
                module('geExceptionHandlerModule');
            });
            beforeEach(inject(function ($rootScope, $filter, messageObj) {
                rootScope = $rootScope;
                filter = $filter;
                msgObj = messageObj;
                broadcast=sinon.spy(rootScope, "$broadcast");
            }));
            describe('check global error scenarios', function () {
                it('check for 400 error', function(){
                    msgObj.setErrorCode({},400);
                    chai.expect(broadcast.calledOnce).to.be.true;
                });
                it('check for 404 error', function(){
                    msgObj.setErrorCode({},404);
                    chai.expect(broadcast.calledOnce).to.be.true;
                });
                it('check for 503 error', function(){
                    msgObj.setErrorCode({},503);
                    chai.expect(broadcast.calledOnce).to.be.true;
                });
                it('check for other error', function(){
                    msgObj.setErrorCode({},405);
                    chai.expect(broadcast.calledOnce).to.be.true;
                });
                it('check for operationOutcome obj', function(){
                    var operationOutcomeObj={
                        "resourceType": "OperationOutcome",
                        "issue": [
                            {
                                "severity": "error",
                                "type": "exception",
                                "details": "NO_MATCHING_EXTENSION_FOUND"
                            }
                        ]
                    };
                    msgObj.setErrorCode(operationOutcomeObj,200);
                    chai.expect(broadcast.calledOnce).to.be.true;
                });

                it('checks success code with global context', function(){
                    msgObj.setSuccessCode("Success message received",200);
                    chai.expect(broadcast.calledOnce).to.be.true;
                });

                it('switchOff exception framework and check global error case', function(){
                    msgObj.setEnable(false);
                    msgObj.setErrorCode({},405);
                    chai.expect(broadcast.calledOnce).to.be.false;
                });
                it('checks success code with a context name', function(){
                    msgObj.setSuccessCode("Success message received",200,"mdtGroupCreation");
                    chai.expect(broadcast.calledOnce).to.be.true;
                });
                it('switchOff exception framework and check global success case', function(){
                    msgObj.setEnable(false);
                    msgObj.setSuccessCode("Success message received",200);
                    chai.expect(broadcast.calledOnce).to.be.false;
                });
            });




        });

    }
);

