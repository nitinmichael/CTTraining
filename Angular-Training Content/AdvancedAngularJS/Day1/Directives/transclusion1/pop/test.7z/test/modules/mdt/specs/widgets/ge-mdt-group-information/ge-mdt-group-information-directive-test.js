/*
 * ge-mdt-group-information-directive-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
 /***************************************************************************************************
 *
 * @description
 * Provides tests for the mdt-group information directive
 *
 ***************************************************************************************************/
define(['angular', 'jquery',
        'angular-mocks',
        'mdt/widgets/ge-mdt-group-information/ge-mdt-group-information-directive'
        ],
    function () {
        'use strict';
        var $rootScope, scope, isolatedScope, $compile;

        describe('GE Mdt Group Information Directive Test Suite::', function () {
            beforeEach(function () {
                //Load actual module
                module('Directive.geMdtGroupInformation', function ($provide, $translateProvider) {
                    // This will provide the mock translation to $translate provider
                    $translateProvider.translations('en', {});
                });

                //Load Templates
                module('templates');

                //Create new scope
                inject(function (_$compile_, _$rootScope_) {
                    $rootScope = _$rootScope_;
                    $compile = _$compile_;
                    scope = $rootScope.$new();
                });
            });


            beforeEach(function () {

                scope.group="group";

                scope.groupDetails = {
                    "groupName": "Test group",
                    "scheduling": [
                        {
                            "type": "Weekly",
                            "day": "FRIDAY",
                            "time": [
                                15,
                                0
                            ]
                        }
                    ],
                    "members": [
                        {
                            "reference": null,
                            "display": null,
                            "id": "891a1d75-79cf-49d6-902f-3ccab357e22f",
                            "firstName": "891a1d75-79cf-49d6-902f-3ccab357e22f",
                            "lastName": "",
                            "name": null
                        }
                    ],
                    "admins": [
                        {
                            "reference": null,
                            "display": null,
                            "id": "707e4aa8-ef8a-4608-8baf-2b7bddcfdee4",
                            "firstName": "707e4aa8-ef8a-4608-8baf-2b7bddcfdee4",
                            "lastName": "",
                            "name": null
                        }
                    ]
                };

                var html = '<ge-mdt-group-information group="groupDetails[0]" remove="removeGroup"></ge-mdt-group-information>';

                var element = $compile(html)(scope);

                scope.$digest();
                isolatedScope = element.isolateScope();
             });

            it('check user visible in the directive', function () {
                expect(isolatedScope.group).to.be.eql(scope.groupDetails[0]);
            });
        });
    });
