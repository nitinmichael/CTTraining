/*
 * ge-mdt-group-information-popover-directive-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
/***************************************************************************************************
 *
 * @description
 * Provides tests for the mdt-group information popover directive
 *
 ***************************************************************************************************/
define(['jquery', 'angular',
        'angular-mocks','rich-popover',
        'mdt/widgets/ge-contact-information/ge-contact-information-popover-directive'
        ],
    function () {
        'use strict';
        var $rootScope, scope, isolatedScope, $compile;

        describe('GE Mdt Group Information Directive Test Suite::', function () {
            beforeEach(function () {
                if (!$.fn.richPopover) throw new Error('geMdtGroupInformationPopover requires rich-popover.js');
                module('Directive.geMdtGroupInformationPopover', function ($provide, $translateProvider) {
                    // This will provide the mock translation to $translate provider
                    $translateProvider.translations('en', {});
                });

                //Load Templates
                module('templates');

                //Create new scope
                inject(function (_$compile_, _$rootScope_) {
                    $rootScope = _$rootScope_;
                    $compile = _$compile_;
                    scope = $rootScope.$new();
                });
            });

            it('check group visible in the directive, with weekly scheduling', function () {
                scope.group="group";

                scope.groupDetails = [{
                    "groupName": "Test group",
                    "scheduling": [
                        {
                            "type": "Weekly",
                            "day": "FRIDAY",
                            "time": [
                                15,
                                0
                            ]
                        },
                        {
                            "type": "Weekly",
                            "day": "MONDAY",
                            "time": [
                                23,
                                0
                            ]
                        },
                        {
                            "type": "Weekly",
                            "day": "WEDNESDAY",
                            "time": [
                                23,
                                0
                            ]
                        }
                    ],
                    "members": [
                        {
                            "reference": null,
                            "display": null,
                            "id": "891a1d75-79cf-49d6-902f-3ccab357e22f",
                            "firstName": "891a1d75-79cf-49d6-902f-3ccab357e22f",
                            "lastName": "",
                            "name": null
                        }
                    ],
                    "admins": [
                        {
                            "reference": null,
                            "display": null,
                            "id": "707e4aa8-ef8a-4608-8baf-2b7bddcfdee4",
                            "firstName": "707e4aa8-ef8a-4608-8baf-2b7bddcfdee4",
                            "lastName": "",
                            "name": null
                        }
                    ]
                }];

                var html = '<span ge-mdt-group-information-popover group="groupDetails[0]" position="right"></span>';

                var element = $compile(html)(scope);
                scope.$digest();
                isolatedScope = element.isolateScope();

                var group = isolatedScope.group;
                expect(group).to.be.eql(scope.groupDetails[0]);
            });

            it('check group visible in the directive, with daily scheduling', function () {
                scope.group="group";

                scope.groupDetails = [{
                    "groupName": "Test Group 2",
                    "scheduling": [
                        {
                            "type": "Daily",
                            "time": [
                                15,
                                15
                            ]
                        },
                        {
                            "type": "Daily",
                            "time": [
                                11,
                                15
                            ]
                        },
                        {
                            "type": "Daily",
                            "time": [
                                15,
                                16
                            ]
                        }
                    ],
                    "members": [
                        {
                            "reference": null,
                            "display": null,
                            "id": "77f-3a94-4db5-8a7a-42a190349e39",
                            "firstName": "77f-3a94-4db5-8a7a-42a190349e39",
                            "lastName": "",
                            "name": null
                        }
                    ],
                    "admins": [
                        {
                            "reference": null,
                            "display": null,
                            "id": "444-174c-4077-90f1-2d14b841570d",
                            "firstName": "444-174c-4077-90f1-2d14b841570d",
                            "lastName": "",
                            "name": null
                        }
                    ]
                }];

                var html = '<span ge-mdt-group-information-popover group="groupDetails[0]" position="right"></span>';

                var element = $compile(html)(scope);
                scope.$digest();
                isolatedScope = element.isolateScope();

                var group = isolatedScope.group;
                expect(group).to.be.eql(scope.groupDetails[0]);
            });

            it('check group visible in the directive, with monthly scheduling', function () {
                scope.group="group";

                scope.groupDetails = [{
                    "groupName": "Test Group n",
                    "scheduling": [
                        {
                            "type": "Monthly",
                            "ordinalInMonth": 2,
                            "day": "SUNDAY",
                            "time": [
                                16,
                                45
                            ]
                        },
                        {
                            "type": "Monthly",
                            "ordinalInMonth": 1,
                            "day": "SUNDAY",
                            "time": [
                                16,
                                45
                            ]
                        },
                        {
                            "type": "Monthly",
                            "ordinalInMonth": 3,
                            "day": "SUNDAY",
                            "time": [
                                16,
                                45
                            ]
                        },
                        {
                            "type": "Monthly",
                            "ordinalInMonth": 5,
                            "day": "SUNDAY",
                            "time": [
                                16,
                                45
                            ]
                        },
                        {
                            "type": "Monthly",
                            "ordinalInMonth": 4,
                            "day": "SUNDAY",
                            "time": [
                                16,
                                45
                            ]
                        }
                    ],
                    "members": [
                        {
                            "reference": null,
                            "display": null,
                            "id": "891a1d75-79cf-49d6-902f-3ccab357e22f",
                            "firstName": "891a1d75-79cf-49d6-902f-3ccab357e22f",
                            "lastName": "",
                            "name": null
                        },
                        {
                            "reference": null,
                            "display": null,
                            "id": "891a1d75-79cf-49d6-902f-3ccab357e22f",
                            "firstName": "891a1d75-79cf-49d6-902f-3ccab357e22f",
                            "lastName": "",
                            "name": null
                        }
                    ],
                    "admins": [
                        {
                            "reference": null,
                            "display": null,
                            "id": "707e4aa8-ef8a-4608-8baf-2b7bddcfdee4",
                            "firstName": "707e4aa8-ef8a-4608-8baf-2b7bddcfdee4",
                            "lastName": "",
                            "name": null
                        }
                    ]
                }];

                var html = '<span ge-mdt-group-information-popover group="groupDetails[0]" position="right"></span>';

                var element = $compile(html)(scope);
                scope.$digest();
                isolatedScope = element.isolateScope();

                var group = isolatedScope.group;
                expect(group).to.be.eql(scope.groupDetails[0]);
            });

        });
    });
