/*
 *  uom-service-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * @author: Felipe de Andrade <andrade@ge.com>
 *
 * Spec file for UOM service module
 */

define([
    'angular',
    'angular-mocks',
    'patient-view/services/uomService'
],
function () {
    'use strict';

    describe('UOM Service Test Suite::', function () {

        var UOMService;
        var $httpBackend;
        var $q;
        var $rootScope;
        var $Endpoint;
        var $EndpointMock;
        var deferred;

        var setMocks = function () {
            deferred = $q.defer();
            $EndpointMock.expects('getEndpointAsync').returns(deferred.promise);
        };

        var restoreMocks = function () {
            $EndpointMock.restore();
        };

        beforeEach(module('cloudav.patient-view.uomService', function ($provide) {

            $provide.service('$Endpoint', function() {
                this.getEndpoint = function (key) {
                    return 'http://ge.test.fake.nonexistentdomain';
                };
                this.getEndpointAsync = function () { };
             });

        }));
        
        // Initialize the scope and controller variables
        beforeEach(inject(function (_UOMService_, _$Endpoint_, _$httpBackend_, _$q_, _$rootScope_) {
            UOMService = _UOMService_;
            $Endpoint = _$Endpoint_;
            $httpBackend = _$httpBackend_;
            $q = _$q_;
            $rootScope = _$rootScope_;
            $EndpointMock = sinon.mock($Endpoint);
            setMocks();
        }));

        afterEach(function () {
            restoreMocks();
        });

        it('should define a service', function () {
            assert.isDefined(UOMService, 'UOMService is not defined');
        });

        describe('UOMService', function () {

            var mockedMyUserId = '22222222-3333-4444-5555-666666666666';

            var mockedMyUserInfo = {
              "resourceType": "ResourcesUser",
              "name": {
                "use": "official",
                "family": [],
                "given": [ "mocked user" ]
              },
              "externalId": [
                {
                  "system": "IDM",
                  "value": null,
                },
                {
                  "system": "UOM",
                  "value": mockedMyUserId
                },
                {
                  "_id": "fake.email@fake.domain",
                  "system": "urn:hc.ge.com/pfh/platform/useremail"
                }
              ],
              "role": [],
              "managingOrganization": {},
              "telecom": [],
              "principalName": "fake.email@fake.domain"
            };

            var mockedMyAppSvcs = {
              "resourceType": "Bundle",
              "title": "ApplicationServices information for User " + mockedMyUserId,
              "id": null,
              "entry": [
                {
                  "title": null,
                  "id": "b9ac0b4c-dac4-402c-8311-6d355061be21",
                  "content": {
                    "resourceType": "ResourcesApplicationService",
                    "type": "dicom-send",
                    "name": "CPACS",
                    "endpoint": "b9ac0b4c-dac4-402c-8311-6d355061be21",
                    "gateway": {
                      "reference": "device/0fef67ad-bdf5-4181-87e2-e512631381fd"
                    }
                  }
                }
              ]
            };

            beforeEach(function () {

            });

            it('should define a .getMyInfo method', function () {
                assert.isDefined(UOMService.getMyInfo, '.getMyInfo method not defined');
                assert.isFunction(UOMService.getMyInfo, '.getMyInfo is not a function');
            });

            it('should send to /userregistry/v1/user/me [GET] request (getMyInfo) once and no more than once (cache)', function () {
                $httpBackend.expect(
                    'GET',
                    $Endpoint.getEndpoint('apiGatewayUrl')
                        + '/userregistry/v1/user/me'
                ).respond(200, mockedMyUserInfo);

                var successCallbackSpy = function (data) {
                    expect(data).to.eql(mockedMyUserInfo);
                };
                var errorCallbackSpy = sinon.spy();

                UOMService.getMyInfo().then(successCallbackSpy, errorCallbackSpy);

                $EndpointMock.verify();
                deferred.resolve($Endpoint.getEndpoint('apiGatewayUrl'));
                $rootScope.$apply();

                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
                $httpBackend.resetExpectations();
                assert(!errorCallbackSpy.called, 'getMyInfo calling the errorCallbackSpy inappropriately');

                // cached call
                UOMService.getMyInfo().then(successCallbackSpy, errorCallbackSpy);
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();

                assert(!errorCallbackSpy.called, 'getMyInfo calling the errorCallbackSpy inappropriately');
            });

            it('should call the "then" exception callback when the getMyInfo fail'
                + 'and pass the status code as argument', function () {

                $httpBackend.expect(
                    'GET',
                    $Endpoint.getEndpoint('apiGatewayUrl')
                        + '/userregistry/v1/user/me'
                ).respond(400);

                var successCallbackSpy = sinon.spy();
                var errorCallbackSpy = sinon.spy();
                
                UOMService.getMyInfo().then(successCallbackSpy, errorCallbackSpy);

                $EndpointMock.verify();
                deferred.resolve($Endpoint.getEndpoint('apiGatewayUrl'));
                $rootScope.$apply();

                $httpBackend.flush();

                assert(errorCallbackSpy.calledWith(400), 'getMyInfo not calling the errorCallbackSpy or not passing the right response');
                assert(!successCallbackSpy.called, 'getMyInfo calling the successCallbackSpy inappropriately');
            });

            it('should call the "then" exception callback when the getEndpointAsync fails', function () {
                var successCallbackSpy = sinon.spy();
                var errorCallbackSpy = sinon.spy();
                
                UOMService.getMyInfo().then(successCallbackSpy, errorCallbackSpy);

                $EndpointMock.verify();
                deferred.reject();
                $rootScope.$apply();

                expect(successCallbackSpy.called).to.be.false;
                expect(errorCallbackSpy.called).to.be.true;
            });

            it('should define a .getUOMIdFromInfo method', function () {
                assert.isDefined(UOMService.getUOMIdFromInfo, '.getUOMIdFromInfo method not defined');
                assert.isFunction(UOMService.getUOMIdFromInfo, '.getUOMIdFromInfo is not a function');
            });

            it('should return the UOM Id from Info', function () {
                var expectedUserId = '22222222-3333-4444-5555-666666666666';
                var result = UOMService.getUOMIdFromInfo(mockedMyUserInfo);
                expect(result).to.equal(expectedUserId);
            });

            it('should throw an exception when .getApplicationServices does not receive arguments', function () {
                assert.throws(function () {
                    UOMService.getUOMIdFromInfo();
                },
                'userInfo argument is required');
            });

            it('should throw an exception when .getUOMIdFromInfo receive an userInfo without externalId key', function () {
                var malformedJson = {};
                assert.throws(function() {
                    UOMService.getUOMIdFromInfo(malformedJson);
                },
                'userInfo.externalId do not exist');
            });

            it('should throw an exception when .getUOMIdFromInfo receive an userInfo without externalId[system = "UOM"]', function () {
                var malformedJson = { "externalId": [] };
                assert.throws(function() {
                    UOMService.getUOMIdFromInfo(malformedJson);
                },
                'userInfo.externalId[system = "UOM"] do not exist');
            });



            it('should define a .getMyApplicationServices method', function () {
                assert.isDefined(UOMService.getMyApplicationServices, '.getMyApplicationServices method not defined');
                assert.isFunction(UOMService.getMyApplicationServices, '.getMyApplicationServices is not a function');
            });

            it('should send to /userregistry/v1/user/me/applicationservice [GET] request (getMyApplicationServices) once and no more than once (cache)', function () {

                $httpBackend.expect(
                    'GET',
                    $Endpoint.getEndpoint('apiGatewayUrl')
                        + '/userregistry/v1/user/me/applicationservice'
                ).respond(200, mockedMyAppSvcs);
                               

                UOMService.getMyApplicationServices().then(function (data) {
                    expect(data).to.eql(mockedMyAppSvcs);
                });

                $EndpointMock.verify();
                deferred.resolve($Endpoint.getEndpoint('apiGatewayUrl'));
                $rootScope.$apply();

                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
                $httpBackend.resetExpectations();

                UOMService.getMyApplicationServices().then(function (data) {
                    expect(data).to.eql(mockedMyAppSvcs);
                });

                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should call the "then" exception callback when the getMyApplicationServices fail'
                + 'and pass the status code as argument', function () {

                $httpBackend.expect(
                    'GET',
                    $Endpoint.getEndpoint('apiGatewayUrl')
                        + '/userregistry/v1/user/me/applicationservice'
                ).respond(400);

                var successCallbackSpy = function (data) {
                    expect(data).to.eql(mockedMyAppSvcs);
                };
                var errorCallbackSpy = sinon.spy();
                
                UOMService.getMyApplicationServices().then(successCallbackSpy, errorCallbackSpy);

                $EndpointMock.verify();
                deferred.resolve($Endpoint.getEndpoint('apiGatewayUrl'));
                $rootScope.$apply();

                $httpBackend.flush();

                assert(errorCallbackSpy.calledWith(400), 'getMyApplicationServices not calling the errorCallbackSpy or not passing the right response');
                assert(!successCallbackSpy.called, 'getMyApplicationServices calling the successCallbackSpy inappropriately');
            });

            it('should call the "then" exception callback when the getEndpointAsync fail', function () {
                var successCallbackSpy = sinon.spy();
                var errorCallbackSpy = sinon.spy();

                UOMService.getMyApplicationServices().then(successCallbackSpy, errorCallbackSpy);

                $EndpointMock.verify();
                deferred.reject();
                $rootScope.$apply();

                expect(successCallbackSpy.called).to.be.false;
                expect(errorCallbackSpy.called).to.be.true;
            });

            it('should return the same promise if already there is one runing', function () {

                $httpBackend.expect(
                    'GET',
                    $Endpoint.getEndpoint('apiGatewayUrl')
                        + '/userregistry/v1/user/me/applicationservice'
                ).respond(200, mockedMyAppSvcs);

                var promise = UOMService.getMyApplicationServices();
                assert.isDefined(promise, 'promise should be defined');

                expect(UOMService.getMyApplicationServices()).to.equal(promise);

                $EndpointMock.verify();
                deferred.resolve($Endpoint.getEndpoint('apiGatewayUrl'));
                $rootScope.$apply();

                $httpBackend.flush();
                $httpBackend.resetExpectations();

                var newpromise = UOMService.getMyApplicationServices();
                assert.isDefined(newpromise, 'newpromise should be defined');
                expect(newpromise).to.not.equal(promise);

                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should define a getMyApplicationServiceInfo method', function () {
                assert.isDefined(UOMService.getMyApplicationServiceInfo, 'getMyApplicationServiceInfo is not defined');
                assert.isFunction(UOMService.getMyApplicationServiceInfo, 'getMyApplicationServiceInfo is not a function');
            });

            it('should return an empty object', function () {
                var info = UOMService.getMyApplicationServiceInfo("12345");
                expect(info).to.eql({});
            });

            it('should return the application Service info', function () {
                var uomServiceMock = sinon.mock(UOMService);
                var deferred = $q.defer();
                uomServiceMock.expects('getMyApplicationServices').twice().returns(deferred.promise);
                var info = UOMService.getMyApplicationServiceInfo('12345');
                expect(info).to.eql({});

                deferred.resolve({});
                $rootScope.$apply();
                expect(info).to.eql({});

                info = UOMService.getMyApplicationServiceInfo('12345');
                deferred.resolve({ entry:[] });
                $rootScope.$apply();
                expect(info).to.eql({});

                uomServiceMock.verify();
                uomServiceMock.restore();
            });

            it('should check when application services dont have the appSvcsId in the collection - getMyApplicationServiceInfo(id)',   function () {
                var uomServiceMock = sinon.mock(UOMService);
                var deferred = $q.defer();
                uomServiceMock.expects('getMyApplicationServices').returns(deferred.promise);
                var info = UOMService.getMyApplicationServiceInfo("54321");
                expect(info).to.eql({});

                deferred.resolve({ entry: [ { id: '12345', content: { 'name' : 'theName', 'type': 'theType' } } ] });
                $rootScope.$apply();

                expect(info).to.eql({});

                uomServiceMock.verify();
                uomServiceMock.restore();
            });

            it('should retrive application services info by id - getMyApplicationServiceInfo(id)',   function () {
                var uomServiceMock = sinon.mock(UOMService);
                var deferred = $q.defer();
                uomServiceMock.expects('getMyApplicationServices').returns(deferred.promise);
                var info = UOMService.getMyApplicationServiceInfo("12345");
                expect(info).to.eql({});

                deferred.resolve({ entry: [ { id: '12345', content: { 'name' : 'theName', 'type': 'theType' } } ] });
                $rootScope.$apply();

                expect(info).to.eql({
                    id: '12345',
                    name: 'theName',
                    type: 'UNKNOWN'
                });
            });

            it('should define the presentableApplicationServiceType', function () {
                assert.isDefined(UOMService.presentableApplicationServiceType, 'presentableApplicationServiceType is not defined');
                assert.isFunction(UOMService.presentableApplicationServiceType, 'presentableApplicationServiceType is not a function');
            });

            it('should return the presentable application service type', function () {
                expect(UOMService.presentableApplicationServiceType('dicom-send')).to.equal("DICOM");
                expect(UOMService.presentableApplicationServiceType('hl7-query-retrieve')).to.equal("XDS");
                expect(UOMService.presentableApplicationServiceType('unknown_type')).to.equal("UNKNOWN");
            });
        });
    });
});
