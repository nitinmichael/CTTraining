﻿/*
 *  Gruntfile.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Saravana Velusamy<saravana.velusamy@ge.com>
 */

/**
 * Spec file for Case Exchange > typeahead input directive module
 */

define(['angular', 'angular-mocks', 'morpheus/directives/dashboard/dashboard-directive', 'mocks/morpheus-mock-service',
        'mocks/fake-server'], function () {
    'use strict';

    var expect = chai.expect;
    var $q;

    describe('directive: dashboard', function() {
        var scope;
        var element;
        var compile;
        var rootScope;
        var mockServerLoader;
        var isolateScope;
        var sampleResponse = {status : 200, responseText : 'https://3.39.73.170:8943/app/main?jwt='};
        var getSisenseURLService;
        var mockServer;
        var element, rootScope, scope, isolatedScope, template;

        beforeEach(function () {
            // Load actual module
            module('morpheus');
            module('cloudav.caseExchange.mocks');
            // Load the Sinon fake server.
            module('cloudav.caseExchange.fakeServer');
            module('Services.GetSisenseURL');
            // Load Templates
            module('templates');
        });
        
        beforeEach(
                inject(function ($MockServerLoader, GetSisenseURLService, $rootScope, $compile) {
                	getSisenseURLService = GetSisenseURLService;
                	mockServerLoader = $MockServerLoader;
                    element = angular.element(
                        '<dashboard width-spacing="605" height-spacing="300"></dashboard>');


                    rootScope = $rootScope;
                    rootScope.ssoURL = 'https://3.39.73.170:8943/app/main?jwt=';
                    scope = $rootScope.$new();

                    $compile(element)(rootScope);
                    // fire all the watches, so the scope expressions will be evaluated
                    rootScope.$digest();
                    isolatedScope = element.isolateScope();
                    expect(true).to.equal(true);
                    
                    mockServer = mockServerLoader.init();
                })
            );
        
        describe('defined directive', function() {
            it('should have a directive', function () {
            	console.log("***************"+element.html());
                assert.isDefined(element, 'Directive is not defined');
            });

            it('should have "scope" object', function () {
                assert.isDefined(isolatedScope, 'directive scope doesn\'t exist');
            });
            
	        it('Get URL shold return the sisense URL', function () {
	            var user = $.extend({}, sisenseUrl);
	            
	            var isolated = element.isolateScope();
	            
	           // expect(isolated.id).to.equal("mdtGroupOccurrenceSelector");
	           // expect(isolated.title).to.equal("A title");
	            
	            //expect(element.length).to.equal("https://3.39.73.170:8943/app/main?jwt=");
	        });
	        
            it('should return response on valid input', function(){
                mockServerLoader.fakeGetUrlCall(200, sampleResponse);
        /*        getSisenseURLService.getUrl().then(function(data){
                	console.log("***************"+data);
                	console.log("***************"+sampleResponse);
                    expect(data).to.equal(JSON.stringify(sampleResponse));
                }, function(){
                    assert(false, "Error should not have been thrown");
                });
          */      
                $(window).trigger('resize');
                mockServer.respond();
                rootScope.$apply();
            });
        });

        // Restore jQuery's ajax method to its original state
        afterEach(function () {
           // $.ajax.restore();
        });
    });

    var sisenseUrl = "https://3.39.73.170:8943/app/main?jwt=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJnZW5lcmljX21pbUBnZS5jb20iLCJpYXQiOjE0NDE4Mjc2NDB9.ghPx67zWEdhkDFNfMJAg1ib-mT8NANHyJjt-sVpQHno#/dashboards/5568f7c908f3786020000006?embed=true&r=true&l=true&t=true&h=false";


});
