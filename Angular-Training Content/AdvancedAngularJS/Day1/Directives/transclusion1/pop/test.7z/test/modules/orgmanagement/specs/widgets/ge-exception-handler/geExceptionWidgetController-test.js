define(['angular','postal','angular-mocks','orgMgmnt/widgets/ge-exception-handler/geExceptionHandler'],
    function () {
        'use strict';
        describe('Tests ge-exception-handler controller', function(){
            var scope, geExcCtrl,rootScope;
            var createControllerScopeUsingIsolatedScope=function(str){
                var ele=angular.element('<ge-exception-handler context-name="'+str+'"></ge-exception-handler>');
                inject(function($rootScope,$compile,$templateCache,$controller){
                    var templateHtml = $templateCache.get('./modules/orgmanagement/widgets/ge-exception-handler/geExceptionHandler.html');
                    if(!templateHtml) {
                        templateHtml = '<div data-ng-controller="geExcepCtrl" id="geExceptionHandlerWrapper" data-ng-keydown="closeOnEsc($event)" tabindex="1" class="messageWidget" data-ng-class="{\'widget-wrapperg\':!moduleSpecific,\'widget-wrapperm\':moduleSpecific}"><div id="serverErrorWidget" data-ng-if="hasError" class="serverMsgWidget"  data-ng-class="{\'global\':!moduleSpecific,\'moduleSpecific\':moduleSpecific}"><alert id="alertError" type="alert alert-block alert-error" close="hideErrorWidget()"><h4 id="errorHeading" class="alert-heading">{{\'message.errorHeading\'|translate}}</h4><ul><li id="errorMessage{{$index}}" data-ng-repeat="errs in errArr" data-ng-bind="errs.msg"></li></ul></alert></div><div id="serverSuccessWidget" data-ng-if="hasSuccess"  class="serverMsgWidget" data-ng-class="{\'moduleSpecific\':moduleSpecific,\'global\':!moduleSpecific}"><alert id="alertSuccess" type="alert alert-block alert-success" close="hideSuccessWidget()"><strong class="ng-binding">Success!</strong><span id="successMessage{{$index}}" class="alert-heading" data-ng-repeat="succ in successArr" data-ng-bind="succ.msg"></span></alert></div></div>';
                        $templateCache.put('./modules/orgmanagement/widgets/ge-exception-handler/geExceptionHandler.html', templateHtml);
                    }
                    rootScope=$rootScope;
                    scope = $rootScope.$new();
                    scope.contextName=str;
                    $compile(ele)(scope);
                    scope.$digest();
                    geExcCtrl = $controller('geExcepCtrl', {$scope:scope});
                });
            };
            beforeEach( function(){
                module('geExceptionHandlerModule');
            });
            describe('Test global error scenarios', function () {
                it('checks contextName to be global if no context is specified', function(){
                    createControllerScopeUsingIsolatedScope();
                    chai.expect(scope.contextName).to.equal('global');
                });
                it('checks moduleSpecific to be false if no context is specified', function(){
                    createControllerScopeUsingIsolatedScope();
                    chai.expect(scope.moduleSpecific).to.equal(false);
                });
                it('emit global error and check controller states', function(){
                    createControllerScopeUsingIsolatedScope();
                    rootScope.$broadcast('serverErrMessage'+'global',{msg:"Error occurred due to unknown reasons"});
                    rootScope.$broadcast('serverErrMessage'+'global',{msg:"Another Error occurred due to unknown reasons"});
                    chai.expect(scope.errArr).to.have.length.above(1);
                });
                it('checks error array to be empty after dismissing errorMsg', function(){
                    createControllerScopeUsingIsolatedScope();
                    rootScope.$broadcast('serverErrMessage'+'global',{msg:"Error occurred due to unknown reasons"});
                    rootScope.$broadcast('serverErrMessage'+'global',{msg:"Another Error occurred due to unknown reasons"});
                    scope.hideErrorWidget();
                    chai.expect(scope.errArr.length).to.equal(0);
                });
                it('checks esc Key functionality if esc key is pressed', function(){
                    createControllerScopeUsingIsolatedScope();
                    rootScope.$broadcast('serverErrMessage'+'global',{msg:"Error occurred due to unknown reasons"});
                    rootScope.$broadcast('serverErrMessage'+'global',{msg:"Another Error occurred due to unknown reasons"});
                    scope.closeOnEsc({keyCode:27});
                    chai.expect(scope.errArr.length).to.equal(0);
                });
                it('checks esc Key functionality if other key is pressed', function(){
                    createControllerScopeUsingIsolatedScope();
                    rootScope.$broadcast('serverErrMessage'+'global',{msg:"Error occurred due to unknown reasons"});
                    rootScope.$broadcast('serverErrMessage'+'global',{msg:"Another Error occurred due to unknown reasons"});
                    scope.closeOnEsc({keyCode:28});
                    chai.expect(scope.hasError).to.equal(true);
                });
            });

            describe('Test contextSpecific error scenarios', function () {
                it('checks contextName variable if context is specified', function(){
                    createControllerScopeUsingIsolatedScope('createMdtGroup');
                    chai.expect(scope.contextName).to.equal('createMdtGroup');
                });
                it('checks moduleSpecific to be true if context is specified', function(){
                    createControllerScopeUsingIsolatedScope('createMdtGroup');
                    chai.expect(scope.moduleSpecific).to.equal(true);
                });
            });

            describe('Test success scenarios', function () {

                it('emit global success and check controller states', function(){
                    createControllerScopeUsingIsolatedScope();
                    rootScope.$broadcast('serverSuccessMessage'+'global',{msg:"Success message received"});
                    chai.expect(scope.successArr.length).to.equal(1);
                });
                it('checks success array to be empty after dismissing successMsg', function(){
                    createControllerScopeUsingIsolatedScope('createMdtGroup');
                    rootScope.$broadcast('serverSuccessMessage'+'createMdtGroup',{msg:"Success message received"});
                    scope.hideSuccessWidget();
                    chai.expect(scope.successArr.length).to.equal(0);
                });
            });
        });
    }
);