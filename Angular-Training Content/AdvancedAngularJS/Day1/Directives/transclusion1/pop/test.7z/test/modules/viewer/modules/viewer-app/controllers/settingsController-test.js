define([ 'angular', 'angular-mocks', 'viewerModule/controllers/settingsController', 'viewerModule/services/annotStateService', 'deviceManagerServiceMock', 'viewerServiceMock'], function(ng, mocks) {
    'use strict';

    describe('Test Settings Controller', function() {
        var annotStateService;
        var settingsCtrl;
        var scope;

        var httpBackend;
        var rootScope;

        var defaultAnnotState = 'full';

        var annotationUIService = {
        };

        beforeEach(function() {
            annotationUIService.setAnnotationVisibility = sinon.spy();
        });

        var configManagementServiceMock = {
            getAnnotationStateForCurrentUser : sinon.spy(),
            saveAnnotationStateForCurrentUser : sinon.spy()
        };

        beforeEach(module('deviceManagerServiceMock'));
        beforeEach(module('viewerServiceMock'));
        beforeEach(module('cloudav.viewerApp.annotation.annotStateService'));
        beforeEach(module('cloudav.viewerApp.annotation.settingsController'));

        beforeEach(module(function($provide) {
            $provide.constant('annotationUIService', annotationUIService);
            $provide.constant('configManagementService', configManagementServiceMock);
        }));

        beforeEach(inject(function($httpBackend, $q) {
            httpBackend = $httpBackend;
        }));

        beforeEach(inject(function($rootScope, $controller, _annotStateService_) {
            annotStateService = _annotStateService_;
            scope = $rootScope.$new();
            rootScope = $rootScope;

            settingsCtrl = $controller('settingsController', {
                $scope : scope,
                annotStateService : annotStateService
            });

        }));

        var verifyAnnotStateHandlerCall = function(expectedArgument, expectedArgumentDescription) {

            assert.isTrue(annotationUIService.setAnnotationVisibility.calledOnce, 'annotationUIService.setAnnotationVisibility invoked');

            var annotStateHandlerArg = annotationUIService.setAnnotationVisibility.args[0][0];
            assert.equal(expectedArgument, annotStateHandlerArg, 'annotationUIService.setAnnotationVisibility argument is ' + expectedArgumentDescription);
        };

        it('should have a controller', function() {
            assert.isDefined(settingsCtrl, 'settings Controller is not defined');
        });

        //TODO: this unit test is broken because of httpBackend.flush, it seems to be called multiple times.
        it('controller.saveAnnotationState', function() {
            var selectedAnnotState = 'partial';
            annotStateService.selectedAnnotState = selectedAnnotState;

            scope.saveAnnotationState();

            verifyAnnotStateHandlerCall(selectedAnnotState, 'the selected annotation state');

            // rootScope.$digest();
            // we would only like to resolve the promise, but they seem to be coupled with the httpBackend
            httpBackend.when('GET', /.*\/warnings.json$/).respond({});
            httpBackend.flush();

            var annotationHelperSaveFunction = configManagementServiceMock.saveAnnotationStateForCurrentUser;
            assert.isTrue(annotationHelperSaveFunction.calledOnce, 'configManagementServiceMock.saveAnnotationStateForCurrentUser called');
            var savedAnnotState = annotationHelperSaveFunction.args[0][0];
            var successCallback = annotationHelperSaveFunction.args[0][1];
            var errorCallback = annotationHelperSaveFunction.args[0][2];

            assert.equal(selectedAnnotState, savedAnnotState, 'selected state propagated to the config endpoint');

            successCallback();
            assert.isFalse(annotStateService.lastNotificationError, 'No error flag');
            assert.equal('', annotStateService.lastNotificationMessage, 'No notification message');

            var notificationMessage = 'some message about saving';
            annotStateService.warningMessages.SAVE_ERROR_MESSAGE = notificationMessage;
            errorCallback();
            assert.isTrue(annotStateService.lastNotificationError, 'Error flag set');
            assert.equal(notificationMessage, annotStateService.lastNotificationMessage, 'Error notification displayed');
        });

        it('controller.applyAnnotStateLocally should delegate to annotStateHandler ', function() {
            var selectedAnnotState = 'partial';
            annotStateService.selectedAnnotState = selectedAnnotState;

            scope.applyAnnotStateLocaly();

            verifyAnnotStateHandlerCall(selectedAnnotState, 'the selected annotation state');

        });

        it('controller.applyAnnotStateLocally displays a warning when hiding the annotations ', function() {
            var selectedAnnotState = 'hidden';
            var warningMessage = 'A warning about hiding';
            annotStateService.selectedAnnotState = selectedAnnotState;

            annotStateService.warningMessages = {
                ANNOT_HIDING_WARNING_MESSAGE : warningMessage
            };

            scope.applyAnnotStateLocaly();

            assert.equal(warningMessage, annotStateService.lastNotificationMessage, 'notification message set');
            assert.isTrue(annotStateService.lastNotificationError, 'error flag set');
        });

        it('controller.applyAnnotStateLocally displays a warning about saving when NOT hiding the annotations ', function() {
            var selectedAnnotState = 'someWeirdState';
            var warningMessage = 'A warning about saving';
            annotStateService.selectedAnnotState = selectedAnnotState;

            annotStateService.warningMessages = {
                NOT_SAVED_WARNING_MESSAGE : warningMessage
            };

            scope.applyAnnotStateLocaly();

            assert.equal(warningMessage, annotStateService.lastNotificationMessage, 'notification message set');
            assert.isTrue(annotStateService.lastNotificationError, 'error flag set');
        });

        it('controller.cancelSetting should restore the temp values', function() {

            assert.equal(defaultAnnotState, annotStateService.selectedAnnotState);
            assert.isFalse(annotStateService.lastNotificationError);
            assert.equal('', annotStateService.lastNotificationMessage);

            var annotStateTemp = 'partial';
            var lastErrorTemp = true;
            var lastMsg = 'Some message';

            annotStateService.selectedAnnotStateTemp = annotStateTemp;
            annotStateService.lastNotificationErrorTemp = lastErrorTemp;
            annotStateService.lastNotificationMessageTemp = lastMsg;

            scope.cancelSettings('a');

            assert.equal(annotStateTemp, annotStateService.selectedAnnotState, 'Temp annotState restored');
            assert.equal(lastErrorTemp, annotStateService.lastNotificationError, 'Temp notification error restored');
            assert.equal(lastMsg, annotStateService.lastNotificationMessage, 'Temp notification message restored');

            verifyAnnotStateHandlerCall(annotStateTemp, 'the temp annotation state');
        });

        it('controller.saveSettings should call saveAnnotationSettings', function() {
            scope.saveAnnotationState = sinon.spy();
            scope.saveSettings('a');
            assert.isTrue(scope.saveAnnotationState.calledOnce, 'saveAnnotationState called');
        });

    });
});
