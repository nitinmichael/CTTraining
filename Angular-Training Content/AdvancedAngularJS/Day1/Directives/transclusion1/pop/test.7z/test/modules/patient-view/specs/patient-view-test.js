
define([
    'angular',
    'angular-mocks',
    'patient-view/main'
], function () {
    "use strict";

    describe('Patient-View Module bootstrap Test Suite', function () {

        var $translatePartialLoader = function () {
            this.addPart = function () { return this; };
            this.$get = function () { return this; };
        };

        var $AppConfig = function () {
            this.addAppDescriptor = function () { };
            this.$get = function () { return this; };
        };

        var $state = function () {
            this.state = function () { return this; };
            this.$get = function () { return this; };
        };

        var translateSpy;
        var appConfigSpy;
        var stateSpy;

        beforeEach(function () {
            angular.module('uaf.appshell', []);
            angular.module('ui.router', []);
            module(function ($provide) {
                $provide.provider('$translatePartialLoader', $translatePartialLoader);
                $provide.provider('uaf.appshell.AppConfig', $AppConfig);
                $provide.provider('$state', $state);
            });
        });

        beforeEach(module([
            '$translatePartialLoaderProvider', 'uaf.appshell.AppConfigProvider', '$stateProvider',
            function($translatePartialLoaderProvider, $AppConfigProvider, $stateProvider) {
            translateSpy = sinon.spy($translatePartialLoaderProvider, 'addPart');
            appConfigSpy = sinon.spy($AppConfigProvider, 'addAppDescriptor');
            stateSpy = sinon.spy($stateProvider, 'state');
        }]));

        beforeEach(module('cloudav.patient-view'));

        beforeEach(inject(function () { }));

        it('should call $translatePartialLoaderProvider.addPart', function () {
            expect(translateSpy.calledTwice).to.be.true;
        });

        it('should call $AppConfigProvider.addAppDescriptor', function () {
            expect(appConfigSpy.calledOnce).to.be.true;
        });

        it('should call $stateProvider.state', function () {
            expect(stateSpy.calledThrice).to.be.true;
        });
    });
});