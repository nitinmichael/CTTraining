define([ 'angular-mocks', 'modules/platform/directives/opsisSlider/opsisSlider' ], function(ngMocks) {
    describe('Test  opsisSlider', function() {
        var $compile;
        var $rootScope;

        beforeEach(module('platform.directive.opsisSlider'));
        beforeEach(module('templates'));

        beforeEach(module(function($provide) {
            $provide.factory('$cssService', function() {
                return {
                    'addlightsOnOffCB' : function() {
                    }
                }
            });
            $provide.factory('$logger', function() {
                return {}
            });
        }));

        beforeEach(inject(function(_$compile_, _$rootScope_) {
            $compile = _$compile_;
            $rootScope = _$rootScope_;
        }));

        it(' defines $sliderService ', function() {
            inject(function($sliderService) {
                expect($sliderService).to.exist;
            })
        });

        it('Replaces the element with the appropriate content', function() {
            var scope = $rootScope.$new();
            var element = $compile("<opsis-slider></opsis-slider>")(scope);
            $rootScope.$digest();
            var html = element.html();
            expect(html).to.contain('opsisSlider');
        });
    });
});