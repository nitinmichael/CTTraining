define(['angular',
        'angular-mocks',
        'orgMgmnt/features/site/viewSite/controllers/viewSiteController',
        'orgMgmnt/dataModels/siteDataModel',
        'orgMgmnt/services/siteService',
        'orgMgmnt/services/organizationService',
        'orgMgmnt/widgets/ge-exception-handler/geExceptionHandler'
    ],
    function(ng) {
        'use strict';

        describe('Test the View Site Controller', function () {
            var ViewSiteCtrl, scope, _log, _q, deferred,_siteMgmtService, getAllSite, _rootScope, _state,_messageObj,
                    _$timeout,_orgMgmtService, siteList, findSiteDeferred;

            beforeEach(function () {
                module('Orgmanagement.Features.Site.ViewSite.ViewSiteController');
                module('Orgmanagement.DataModel.SiteDataModel');
                module('Orgmanagement.Services.SiteService');
                module('Orgmanagement.Services.OrganizationService');
                module('ui.router');
                module('geExceptionHandlerModule');
                module('Orgmanagement.Utilities.MasterData');
            });


            beforeEach(function(){
                getAllSite = {"resourceType": "Bundle","title": "Title ","id": null,"entry": [{"title": null,"id": "93c562aa-c560-46b9-98ee-17417dedb738","content": {"resourceType": "Organization","text": {"status": "generated","div": "<div>502538594</div>"},"name": "site","type": {"coding": [{"system": "urn:hc.ge.com/pfh/platform/orgtype","code": "SITE","display": "site"}]},"partOf": {"reference": "organization/15848068-aa11-4548-a23c-48a2a0568e06"}}}, {"title": null,"id": "3c2955cb-87de-489b-8adc-dfc40e850009","content": {"resourceType": "Organization","text": {"status": "generated","div": "<div>Rdesc</div>"},"name": "Rname","type": {"coding": [{"system": "urn:hc.ge.com/pfh/platform/orgtype","code": "SITE","display": "site"}]},"partOf": {"reference": "organization/58416417-bc7c-4b90-9419-7ef1c68c539e"}}},{"title": null,"id": "3c2955cb-87de-489b-8adc-dfc40e850009","content": {"resourceType": "Organization","text": {"status": "generated","div": "<div>Rdesc</div>"},"name": "Rname","type": {"coding": [{"system": "urn:hc.ge.com/pfh/platform/orgtype","code": "SITE","display": "site"}]},"partOf": {"reference": "organization/f9e2dfa7-e6e0-485a-947b-7110a6acba96"}}}]};
                siteList = JSON.parse(JSON.stringify({"data":{"entry":[{"content":{"name":"test"}},{"content":{"name":"test1"}}]}, "status": 200}));
            });


            beforeEach(inject(function($controller, $rootScope,siteMgmtService ,$q, $log, $state,messageObj,$timeout, orgMgmtService){
                scope = $rootScope.$new();
                _rootScope = $rootScope;
                _siteMgmtService=siteMgmtService;
                _orgMgmtService=orgMgmtService;
                _rootScope.selectedOrg = {id:'1234'};
                _q = $q;
                _log = $log;
                _state = $state;
                deferred = _q.defer();
                _$timeout=$timeout;


                sinon.stub(_siteMgmtService, 'getAllSite').returns(deferred.promise);
                findSiteDeferred = _q.defer();
                sinon.stub(_siteMgmtService, 'findSite').returns(findSiteDeferred.promise);
                sinon.stub(_log, 'info');
                _state.transitionTo = sinon.stub();
                _state.params= {errList:null, successList:null};
                _messageObj= messageObj;
                ViewSiteCtrl = $controller('ViewSiteCtrl', {$scope: scope,$log:_log,siteMgmtService:_siteMgmtService,$rootScope:_rootScope,$state:_state,messageObj:_messageObj,$timeout:_$timeout})
            }));
            it('should test the controller is defined', function(){
                chai.assert.isDefined(ViewSiteCtrl, 'Controller not defined');
            });

            it('should test when site is selected from the list', function(){
                var siteObject = {
                    content: {
                        resourceType: "Organization",
                        _id: "c528ab77-7ab3-42f4-b96e-5a2e8a11840a",
                        name: "GE Healthcare",
                        address: [
                            {
                                line: [
                                    "3300 Washtenaw Avenue, Suite 227",
                                    "second line"
                                ],
                                city: "Ann Arbor",
                                state: "MI",
                                zip: "48104",
                                country: "USA"
                            }
                        ]
                    }
                };
                scope.selectSite(siteObject);
                chai.expect(_state.transitionTo).to
                    .have.been.calledOnce
                    .and.calledWith('orgmanagement.site.details');
            });

            it('should test transition to Create Site Page when Create Site is Clicked', function(){
                scope.createSiteButton();
                chai.expect(_state.transitionTo).to
                    .have.been.calledOnce
                    .and.calledWith('orgmanagement.createSite');
            });

            describe('When page is loaded ', function(){
                it('should test that the getAllSite service is called successfully, if logged in user is org admin', function(done){
                    sinon.stub(_orgMgmtService, 'getLoggedInUserOrgIds').returns(['1234']);
                    scope.init();
                    deferred.resolve({data:getAllSite,status:200});
                    scope.$root.$digest();
                    chai.expect(scope.siteList).to.have.length(3);
                    done();
                });

                it('should test that the getAllSite service is called successfully, if logged in user is site admin', function(done){
                    sinon.stub(_orgMgmtService, 'getLoggedInUserOrgIds').returns([]);
                    sinon.stub(_siteMgmtService, 'getLoggedInUserSiteIds').returns(['93c562aa-c560-46b9-98ee-17417dedb738']);
                    deferred.resolve({data:getAllSite,status:200});
                    scope.$root.$digest();
                    chai.expect(scope.siteList).to.have.length(1);
                    done();
                });

                it('should test that the getAllSite service is not called successfully', function(done){

                    scope.init();
                    deferred.reject({data:getAllSite,status:404});
                    scope.$root.$digest();

                    chai.expect(scope.siteList).to.have.length(0);
                    done();
                });
                it('checks for state change listening function', function () {
                    var spyNewCreateSiteId = sinon.stub(_siteMgmtService, 'setNewCreatedSiteId');
                    _state.transitionTo('Organization');
                    scope.$emit('$stateChangeStart');
                    chai.expect(spyNewCreateSiteId.called).to.be.true;
                });
                it('should test that if page has no error from createSite screen', function(done){
                    var sp = sinon.spy(_messageObj,"setSuccessCode");
                    _state.params= {errList:null, successList:{data:"",status:200}};
                    scope.init();
                    deferred.resolve({data:getAllSite,status:200});
                    _$timeout.flush();
                    scope.$root.$digest();
                    chai.assert(sp.called);
                    done();
                });
                it('should test that if page has error from createSite screen', function(done){
                    var sp = sinon.spy(_messageObj,"setErrorCode");
                    _state.params= {errList:{data:"",status:404}, successList:null};
                    scope.init();
                    deferred.resolve({data:getAllSite,status:200});
                    _$timeout.flush();
                    scope.$root.$digest();
                    chai.assert(sp.called);
                    done();
                });
            });
            it('should filter site list from server after 3 characters typed', function(done){
                var text = 'test';
                scope.textToBeSearched = '';
                scope.searchedSuperSetData = [];

                scope.searchSite(text);
                findSiteDeferred.resolve(siteList);
                scope.$root.$digest();

                chai.expect(scope.siteList).to.have.length(2);
                done();
            });

            it('should not open site list after 3 characters typed not found', function(done){
                var text = 'test2';
                scope.textToBeSearched = '';
                scope.searchedSuperSetData = siteList.data.entry;

                scope.searchSite(text);
                findSiteDeferred.reject();
                scope.$root.$digest();

                chai.expect(scope.siteList).to.have.length(0);
                done();
            });

            it('should filter site list at clientside if 3 characters match superSetData', function(done){
                var text = 'test1';
                scope.textToBeSearched = 'tes';
                scope.searchedSuperSetData = siteList.data.entry;

                scope.searchSite(text);
                findSiteDeferred.resolve(siteList);
                scope.$root.$digest();

                chai.expect(scope.siteList).to.have.length(1);
                done();
            });

            it('should not open site list at clientside if 3 characters not found', function(done){
                var text = 'test2';
                scope.textToBeSearched = 'tes';
                scope.searchedSuperSetData = siteList.data.entry;

                scope.searchSite(text);
                findSiteDeferred.reject();
                scope.$root.$digest();

                chai.expect(scope.siteList).to.have.length(0);
                done();
            });
            it('passing the telecom object return the phone number', function(){
                chai.expect(scope.getTelecomPhoneNumber([{system:"phone", value:"126646546"}])).to.equal('126646546');
            });
            it('passing the telecom object return the phone number', function(){
                chai.expect(scope.getTelecomPhoneNumber([{system:"extension", value:"126646546"}])).to.equal('');
            });
            it('passing no telecom data return blank data', function(){
                chai.expect(scope.getTelecomPhoneNumber()).to.equal('');
            });
            describe('Test typeAhead Search for negative paths', function() {
                beforeEach(function() {
                    scope.searcTriggered=true;
                });
                it('should test that the getAllSite service is called successfully, if logged in user is org admin', function(done){
                    sinon.stub(_orgMgmtService, 'getLoggedInUserOrgIds').returns(['1234']);
                    scope.init();
                    deferred.resolve({data:getAllSite,status:200});
                    scope.$root.$digest();
                    chai.expect(scope.fullSiteList.length>0).to.be.true;
                    done();
                });
                it('should test that the getAllSite service is called successfully, if logged in user is site admin', function(done){
                    sinon.stub(_orgMgmtService, 'getLoggedInUserOrgIds').returns([]);
                    sinon.stub(_siteMgmtService, 'getLoggedInUserSiteIds').returns(['93c562aa-c560-46b9-98ee-17417dedb738']);
                    deferred.resolve({data:getAllSite,status:200});
                    scope.$root.$digest();
                    chai.expect(scope.fullSiteList.length>0).to.be.true;
                    done();
                });
                it('checks searchSite for less than 3 characters', function (done) {
                    scope.searchSite('ab');
                    chai.expect(scope.fullSiteList.length===scope.siteList.length).to.be.true;
                    done();
                });
            });
        });

    });