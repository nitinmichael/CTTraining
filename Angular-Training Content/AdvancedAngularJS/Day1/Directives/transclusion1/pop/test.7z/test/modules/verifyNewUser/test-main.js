var tests = [];
for (var file in window.__karma__.files) {
    if (window.__karma__.files.hasOwnProperty(file)) {
        if (/-test\.js$/.test(file)) {
            tests.push(file);
        }
    }
}

require.config({
    // Karma serves files under /base, which is the basePath from your config file
    baseUrl: '/base/public',

    paths: {
        'angular': './uaf/3rdparty/angular/angular',
        'angular-mocks'   : './uaf/3rdparty/angular/angular-mocks',
        'angularRoute': './uaf/3rdparty/angular-route/angular-route',
        'uiRouter': './uaf/3rdparty/angular-ui-router/build/angular-ui-router',
        'angularTranslate': './uaf/3rdparty/angular-translate/dist/angular-translate',
        'angularTranslatePartialLoader': './uaf/3rdparty/angular-translate/dist/angular-translate-loader-partial/angular-translate-loader-partial',
        'lodash': './uaf/3rdparty/lodash',
        'postal': './uaf/3rdparty/postal/lib/postal',
        'hdx': './uaf/hdx/js/hdx',
        'hdx-bootstrap': './uaf/hdx/components/hdx-bootstrap/js/hdx-bootstrap',
        'jquery': './uaf/hdx/components/3rdparty/jquery/jquery',
        'bootstrap': './uaf/hdx/components/3rdparty/bootstrap/js',
        'prettify': './uaf/hdx/components/3rdparty/prettify/prettify',
        'typeahead': './uaf/hdx/components/3rdparty/typeahead.js/dist/typeahead.jquery', // this is added only for unit test execution
        'bloodhound': './uaf/hdx/components/3rdparty/typeahead.js/dist/bloodhound', //Added only for unit test creation
        'angular-ui': './uaf/hdx/components/3rdparty/angular-ui/ui-bootstrap-tpls-0.12.1',
        'hdx-header-directive' : './uaf/widgets/header/js/directive/hdx-header-directive',
        'patientInfo-directive' : './uaf/widgets/header/lib/patientInfo/src/js/directive/patientInfo-directive',
        'navbar' : './uaf/widgets/navbar/js/navbar',
        'modules': './uaf/widgets/js/modules',
        'modal-service': './uaf/widgets/modals/js/services/modal-service',
        'popover': './uaf/hdx/components/3rdparty/bootstrap/js/popover',
        'tooltip': './uaf/hdx/components/3rdparty/bootstrap/js/tooltip',
        'modal-jquery': './uaf/hdx/components/3rdparty/bootstrap/js/modal',
        'respond' : './uaf/hdx/components/3rdparty/respond/respond.min',
        'responsive-emitter' : './uaf/hdx/components/3rdparty/responsive-emitter/js/responsive-emitter',
        'multi-step-navigation': './uaf/widgets/multi-step-navigation/js/multi-step-navigation',
        'twitter-bootstrap-wizard': './uaf/hdx/components/3rdparty/twitter-bootstrap-wizard/jquery.bootstrap.wizard',
        'verifyNewUser'		: './modules/verifyNewUser'
    },
    shim: {
        'hdx': {deps:['jquery']},
        'angular': {deps:['jquery'], 'exports' : 'angular'},
        'angular-mocks'   : {
            deps:['angular'],
            'exports':'angular.mock'
        },
        'angularRoute': ['angular'],
        'angularTranslate': {deps: ['angular']},
        'angularTranslatePartialLoader': {deps: ['angularTranslate']},
        'uiRouter':{deps:['angular']},
        'postal': {deps: ['lodash']},
        'hdx-header-directive': { deps:['hdx','angular', 'jquery', 'patient-banner-directive']},
        'patientInfo-directive' : {deps: ['jquery','angular']},
        'modal-jquery': ['jquery', 'angular-ui'],
        'tooltip': ['jquery'],
        'popover': ['tooltip'],
        'modal-service': ['angular', 'modal-jquery', 'popover', 'jquery', 'prettify'],
        'angular-ui': ['angular', 'jquery']
    },

    // dynamically load all test files
    deps: tests,

    // start running the tests, once Require.js is done
    callback: window.__karma__.start
});

