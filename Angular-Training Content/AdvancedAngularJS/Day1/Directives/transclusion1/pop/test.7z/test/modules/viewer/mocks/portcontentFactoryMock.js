
define(['angular'],function(ng) {
    return ng.module('portContent', []).constant('portContentFactoryMock', {
        setGroup: function(){},
        getActivePort: function() {},
        getActivePortIndex: function() {}
    });
});



