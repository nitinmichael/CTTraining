/**
 * @ngdoc service
 * @name xjtweb-platform.provider:port-unit-test
 * @author Benjamin Beeman <benjamin.beeman@ge.com>; Aamir Omar<omar.aamir@ge.com>
 *
 * @description This is the test suite for the {@link xjtweb-platform.directive:viewPort viewPort}.
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */
define(['angular', 'angular-mocks', 'jquery', 'modules/xjtweb-platform/directives/port/port', 'viewerMockModule', 'serviceDiscoveryMock'], function(angular) {
    'use strict';

    describe('Port Directive Test :', function() {
        var $compile, $rootScope, $scope, $timeout, $viewportParameterStorage, portContentFactory;
        var element, parentScope, linkingManagerLinkMockMsg, activePort2D = false;

        var viewerUrls = {
            servicesName: {
                groupBuilder: 'pfh_hcimg_av_group_builder',
                saveState: 'pfh_hcimg_av_presentationstate_provider',
                imageController: 'pfh_hcimg_av_image_controller',
                mprRendering: 'pfh_hcimg_av_mpr_rendering',
                vrRendering: 'pfh_hcimg_av_vr_rendering',
                annotationService: 'pfh-hcimg-av-annotation',
                configManagment: 'pfh-config-configuration-store'
            }
        };

        beforeEach(function() {
            module('port');
            module('templates');
            module('cloudav.viewerMockModule');

            module(function($provide) {
                $provide.factory('$xjtweb', function() {
                    return {
                        XJTWEB: {
                            VIEWPORT_UPDATE: {
                                CHANNEL: 'VIEWPORT_UPDATE_CHANNEL',
                                TOPIC: {
                                    SWITCH_TYPE: 'VIEWPORT_UPDATE.SWITCH_TYPE'
                                }
                            },
                            ServiceLocator: {
                                resolve: function() {
                                    return {
                                        publish: sinon.spy()
                                    };
                                }
                            },
                            SERVICE: {
                                GMC: 'GMC'
                            },
                            GMC: {
                                CHANNEL: 'GMC_CHANNEL',
                                TOPIC: {
                                    ALL: 'GMC.*.*',
                                    VIEWPORT: {
                                        SWITCH: 'GMC.VIEWPORT.SWITCH',
                                        UPDATE: 'GMC.VIEWPORT.UPDATE',
                                        IMAGE_UPDATED: 'GMC.VIEWPORT.IMAGE_UPDATED'
                                    }
                                }
                            }
                        }
                    };
                });

                $provide.factory('linkingManager', function() {
                    return {
                        link: function(msg) {
                            linkingManagerLinkMockMsg = msg;
                        }
                    };
                });

                $provide.factory('$viewportParameterStorage', function() {
                    return {
                        getCurrentConfiguration: function() {
                            return {
                                ports: [{
                                    volumeInfo: {
                                        modality: ''
                                    },
                                    viewPortObject: {
                                        copyFromViewport: sinon.spy(),
                                        get3DCursorPosition: function() {
                                            return [0, 0, 0];
                                        },
                                        updateCamera: sinon.spy(),
                                        getZoomViewHeightMin: sinon.spy(),
                                        setView: sinon.spy(),
                                        setViewHeight: sinon.spy(),
                                        renderEngine: {
                                            getWindowLevel: sinon.spy(),
                                            getWindowWidth: sinon.spy(),
                                            setRendererType: sinon.spy(),
                                            setRendererBaseUrl: sinon.spy()
                                        }
                                    },
                                    updateViewportImage: sinon.spy(),
                                    rendererType: 'MPR',
                                    vrRenderType: 'VR'
                                }]
                            };
                        }
                    };
                });

                $provide.factory('EventBroker', function() {
                    return sinon.spy();
                });

                $provide.factory('$windowResizeService', function() {
                    return {
                        addCBforOnResize: function(cb) {
                            cb();
                        }
                    };
                });

                $provide.factory('portContentFactory', function() {
                    return {
                        getEventModes: function() {
                            return [{
                                event: 'panup pandown',
                                metadata: 'paging'
                            }, {
                                event: 'pinch',
                                metadata: 'zoom'
                            }];
                        },
                        getActivePort: sinon.spy(),
                        setActivePort: sinon.spy()
                    };
                });

                $provide.value('viewerUrls', viewerUrls);
                $provide.value('BddEventAccumulator', {
                    BDD_Events_Modes: {
                        CHANNEL: 'GMC_CHANNEL',
                        TOPIC: {
                            ALL: 'GMC.*.*',
                            INTERACTION: {
                                REQUEST_SENT: "GMC.INTERACTION.REQUEST_SENT"
                            },
                            VIEWPORT: {
                                UPDATE: 'GMC.VIEWPORT.UPDATE',
                                IMAGE_UPDATED: 'GMC.VIEWPORT.IMAGE_UPDATED',
                                SWITCH: 'GMC.VIEWPORT.SWITCH'
                            }
                        }
                    },
                    appendNewEvent: function(data, event) {}
                });
            });

            inject(function(_$compile_, _$rootScope_, _$timeout_, _$viewportParameterStorage_, _portContentFactory_) {
                $rootScope = _$rootScope_;
                parentScope = $rootScope.$new();
                $compile = _$compile_;
                $timeout = _$timeout_;
                $viewportParameterStorage = _$viewportParameterStorage_;
                portContentFactory = _portContentFactory_;
            });
        });

        var createPort = function(visible) {
            element = angular.element('<port port="port" selectedViewPort="selectedViewport"></port>');

            parentScope.port = {
                index: 0,
                rendererType: 'MPR',
                vrRenderType: 'Max',
                viewType: 'LEFT',
                getId: function() {
                    return 'MockID';
                },
                active2D: activePort2D,
                visible: visible,
                viewPortObject: {
                    setWindowing: sinon.spy(),
                    get3DCursorPosition: function() {
                        return [0, 0, 0];
                    },
                    destroy: sinon.spy(),
                    updateCamera: sinon.spy(),
                    setView: sinon.spy(),
                    setViewHeight: sinon.spy(),
                    getZoomViewHeightMin: sinon.spy(),
                    renderEngine: {
                        setRendererType: sinon.spy(),
                        setRendererBaseUrl: sinon.spy()
                    }
                },
                volumeInfo: {
                    modality: ''
                },
                refresh: sinon.spy(),
                updateViewportImage: sinon.spy(),
            };

            parentScope.selectedViewPort = {
                index: 0,
                getId: sinon.spy()
            };

            $compile(element)(parentScope);
            parentScope.$digest();
            $scope = element.isolateScope();
            $timeout.flush();
        };

        describe('port directive', function() {

            /**
             * @ngdoc property
             * @name switchViewType TEST,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This tests the switchViewType function.
             */
            it('switchViewType test', function() {
                createPort();
                expect(typeof $scope.switchViewType).to.equal('function');

                var broadcastSpy = sinon.spy($rootScope, '$broadcast'),
                    updatePortDataSpy = sinon.spy($scope, 'updatePortData');

                $scope.switchViewType('MPR', '3D', 'VR');
                viewerUrls.servicesName.mprRendering = 'url';
                $scope.$apply();

                expect(broadcastSpy.calledOnce).to.equal(true);
                expect(updatePortDataSpy.calledOnce).to.equal(true);

                $scope.switchViewType('MPR', '3D', 'VR');
                expect(broadcastSpy.calledOnce).to.equal(true);
                expect(updatePortDataSpy.calledOnce).to.equal(true);

                $scope.switchViewType('VR', '2D', 'Max', '3D');
                $scope.switchViewType('VR', '3D', 'Max', '2D');

            });

            /**
             * @ngdoc property
             * @name switchViewType test update Camera TEST,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This tests the switchViewType function to ensure update Camera is called when changing Rendering Type.
             */
            it('switchViewType test update Camera', function() {
                createPort();
                expect(typeof $scope.switchViewType).to.equal('function');

                var broadcastSpy = sinon.spy($rootScope, '$broadcast'),
                    updatePortDataSpy = sinon.spy($scope, 'updatePortData');

                $scope.switchViewType('MPR', '3D', 'VR');
                viewerUrls.servicesName.mprRendering = 'url';
                $scope.$apply();

                expect(broadcastSpy.calledOnce).to.equal(true);
                expect(updatePortDataSpy.calledOnce).to.equal(true);
                expect($scope.port.viewPortObject.updateCamera.calledOnce).to.equal(true);
            });



            /**
             * @ngdoc property
             * @name updatePortData TEST,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This tests the updatePortData function.
             */
            it('updatePortData test', function() {
                createPort();
                expect(typeof $scope.updatePortData).to.equal('function');

                var data = {
                    viewTypeTarget: '',
                    rendererType: 'cat',
                    vrRenderType: ''
                };

                var vpTarget = $viewportParameterStorage.getCurrentConfiguration().ports[0];

                try {
                    $scope.updatePortData(data, true, vpTarget);
                } catch (error) {
                    expect(error.message).to.equal('renderer type unknown: cat');
                }
                expect(vpTarget.viewPortObject.copyFromViewport.calledOnce).to.equal(true);

                data.rendererType = 'MPR';
                $scope.updatePortData(data, false, vpTarget);

                expect(vpTarget.viewPortObject.setView.calledOnce).to.equal(true);
                expect(vpTarget.viewPortObject.setViewHeight.calledOnce).to.equal(true);
                expect(vpTarget.viewPortObject.renderEngine.setRendererType.calledOnce).to.equal(true);

                $scope.$apply();

                expect(vpTarget.viewPortObject.renderEngine.setRendererBaseUrl.calledOnce).to.equal(true);
                expect(vpTarget.updateViewportImage.calledOnce).to.equal(true);
            });

            /**
             * @ngdoc property
             * @name Port Define TEST,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This test determines that the port directive was initiated when complied.
             */
            it('should have a directive', function() {
                createPort();
                assert.isDefined(element, 'directive is not defined');
            });

            /**
             * @ngdoc property
             * @name vp3Dcanvas Define TEST,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This test determines that the "vp3Dcanvas" is attached to the port object after
             *              initialization of the port.
             */
            it('"vp3Dcanvas" should be attached to the port object after initialization of the port.', function() {
                activePort2D = false;
                createPort();
                assert.isDefined($scope.port.vp3Dcanvas, 'vp3Dcanvas is not defined');
            });

            /**
             * @ngdoc property
             * @name vp3Dsvg Define TEST,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This test determines that the "vp3Dsvg" is attached to the port object after initialization
             *              of the port.
             */
            it('"vp3Dsvg" should be attached to the port object after 2D initialization of the port.', function() {
                activePort2D = true;
                createPort();
                assert.isDefined($scope.port.vp3Dsvg, 'vp3Dsvg is not defined');
            });

            /**
             * @ngdoc property
             * @name vp3DOverlay Define TEST,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This test determines that the "vp3DOverlay" is attached to the port object after
             *              initialization of the port.
             */
            it('"vp3DOverlay" should be attached to the port object after initialization of the port.', function() {
                activePort2D = false;
                createPort();
                assert.isDefined($scope.port.vp3DOverlay, 'vp3DOverlay is not defined');
            });

            /**
             * @ngdoc property
             * @name vp2Dcanvas Define TEST,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This test determines that the "vp2Dcanvas" is attached to the port object after
             *              initialization of the port.
             */
            it('"vp2Dcanvas" should be attached to the port object after initialization of the port.', function() {
                activePort2D = true;
                createPort();
                assert.isDefined($scope.port.vp2Dcanvas, 'vp2Dcanvas is not defined');
            });

            /**
             * @ngdoc property
             * @name vp2Dsvg Define TEST,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This test determines that the "vp2Dsvg" is attached to the port object after initialization
             *              of the port.
             */
            it('"vp2Dsvg" should be attached to the port object after initialization of the port.', function() {
                activePort2D = true;
                createPort();
                assert.isDefined($scope.port.vp2Dsvg, 'vp2Dsvg is not defined');
            });

            /**
             * @ngdoc property
             * @name vp2DOverlay Define TEST,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This test determines that the "vp2DOverlay" is attached to the port object after
             *              initialization of the port.
             */
            it('"vp2DOverlay" should be attached to the port object after initialization of the port.', function() {
                createPort();
                assert.isDefined($scope.port.vp2DOverlay, 'vp2DOverlay is not defined');
            });

            /**
             * @ngdoc property
             * @name linkingManagerLink,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This test determines that the port calls the link function on the linkingManager and passes
             *              in the getID from the port.
             */
            it('linkingManagerLinkMockMsg should equal scope.port.getId()', function() {
                createPort(true);
                expect(linkingManagerLinkMockMsg).to.equal($scope.port.getId());
            });

            /**
             * @ngdoc property
             * @name port 3D mode TEST,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This test determines that when the port is in 3D mode the 2D port div is hidden and the 3D
             *              port div is shown.
             */
            it('"vp2Dcanvas" hidden.', function() {
                activePort2D = true;
                createPort();

                $scope.port.active2D = false;
                $scope.port.port2DSetup = true;
                $scope.$digest();

                var port2Ddiv = element[0].querySelector('#port2DDiv' + $scope.port.index);
                var port3Ddiv = element[0].querySelector('#port3DDiv' + $scope.port.index);

                assert.isDefined(port2Ddiv, 'port2Ddiv' + $scope.port.index + ' is not defined');
                expect(port2Ddiv.classList.contains("ng-hide")).to.equal(true);

                assert.isDefined(port3Ddiv, 'port3Ddiv' + $scope.port.index + ' must be defined');
            });

            /**
             * @ngdoc property
             * @name port 2D mode TEST,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This test determines that when the port is in 2D mode the 3D port div is hidden and the 2D
             *              port div is shown.
             */
            it('"vp2Dcanvas" hidden.', function() {
                activePort2D = true;
                createPort();

                var port2Ddiv = element[0].querySelector('#port2DDiv' + $scope.port.index);
                var port3Ddiv = element[0].querySelector('#port3DDiv' + $scope.port.index);

                assert.isDefined(port2Ddiv, 'port2Ddiv' + $scope.port.index + ' is not defined');
                expect(port2Ddiv.classList.contains("ng-hide")).to.equal(false);

                assert.isDefined(port3Ddiv, 'port3Ddiv' + $scope.port.index + ' must be defined');
            });

            /**
             * @ngdoc property
             * @name $destroy event TEST,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This test determines that the port directive was initiated when complied.
             */
            it('catch $destroy event should call the viewport object destroy method', function() {
                createPort();
                $rootScope.$broadcast('$destroy');
                expect($scope.port.viewPortObject.destroy.calledOnce).to.equal(true);

                $scope.port.viewPortObject = null;
                $rootScope.$broadcast('$destroy');
            });

            /**
             * @ngdoc property
             * @name port ready TEST,
             * @propertyOf xjtweb-platform.provider:port-unit-test
             *
             * @description This test determines if the port calls the callbacks when it's ready.
             */
            it('portReady test', function() {
                activePort2D = true;
                createPort();

                $scope.port.cbForOnReady = [function() {
                    $scope.kikou = true;
                }];
                $scope.port.active2D = false;
                $scope.$apply();
                expect($scope.kikou).to.equal(true);

                $scope.port.cbForOnReady = [];
                $scope.port.active2D = true;
                $scope.$apply();

                $scope.port.cbForOnReady = ['test'];
                $scope.port.active2D = false;
                $scope.$apply();
            });
        });
    });
});
