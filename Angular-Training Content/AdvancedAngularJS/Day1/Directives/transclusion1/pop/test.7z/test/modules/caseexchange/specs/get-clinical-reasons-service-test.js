/*
 *  get-get-clinical-reasons-service-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 */

/**
 * Spec file for Get Clinical Reasons Service Test module
 */

define([
  'angular',
  'angular-mocks',
  'modules/caseexchange/services/get-clinical-reasons-service',
  'mocks/case-exchange-mock-service',
  'mocks/fake-server'
], function() {
  'use strict';

  describe('Get Clinical Reasons Details', function() {
    var clinicalReasonsService, rootScope, originalAjax, $mockServerLoader, mockServer;

    beforeEach(function() {
      // Load the module for the mock data first
      module('cloudav.caseExchange.mocks');
      // Load the Sinon fake server.
      module('cloudav.caseExchange.fakeServer');

      // store original $.ajax
      originalAjax = $.ajax;
      // provide mock services for clinicalReasonsService
      module('Services.clinicalReasonsService', function($provide) {
        $provide.factory('configurationService', ['$q',
          function($q) {
            return {
              getProperty: function() {
                return $q.when({});
              }
            }
          }
        ]);
      });
      // inject dependencies for clinicalReasonsService
      inject(function(_ClinicalReasonsService_, _CaseExchangeDataService_, $rootScope, $MockServerLoader) {
        clinicalReasonsService = _ClinicalReasonsService_;
        rootScope = $rootScope;
        $mockServerLoader = $MockServerLoader;
        mockServer = $mockServerLoader.init();
      });
    });

    // restore $.ajax for use by other test suites
    afterEach(function() {
      $.ajax = originalAjax;
    });

    it('should define a service', function() {
      assert.isDefined(clinicalReasonsService, 'ClinicalReasonsService is defined');
    });

    describe('Testing successful getClinicalReasons() method', function() {
      it('should indicate success when set up to run normally', function(done) {
        var isSuccessful = false;
        $mockServerLoader.fakeClinicalReasonsCall(200, {data:{}});
        clinicalReasonsService.getClinicalReasons().then(
          function onResolve(data) {
            isSuccessful = true;
            done();
          },

          function onError(errorMessage) {
          }
        );

        // respond will trigger the success of getConditionKeyList call.
        mockServer.respond();
        rootScope.$apply();

        assert(isSuccessful, 'normal run should have succeeded');
      });
    });
  });
});