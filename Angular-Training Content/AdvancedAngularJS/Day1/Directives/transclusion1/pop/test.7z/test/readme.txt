Test Framework
--------------

The test framework for the application seed project is using the following tools:

    Protractor: For access and control of the Angular application.
    Webdriver: Used by protractor to drive the browser
    Cucumber: BDD framework.
    Karma: Test runner for unit tests.
    Mocha: Unit test framework for JavaScript.
    Chai and Chai-as-Promised: Assertion libraries

BDD Test Environment Setup
--------------------------

1. Set HTTP and HTTPS proxies for npm (command below) and as environment variables (HTTP_PROXY, HTTPS_PROXY)

    npm config set proxy http://proxy.company.com:8080

    npm config set https-proxy http://proxy.company.com:8080

2. Install protractor and its dependencies

    npm install -g protractor

    webdriver-manager update

3. Install cucumber

    npm install -g cucumber

4. Install chai

    npm install chai

    npm install chai-as-promised

Running BDD Tests
-----------------

1. Setup the runtime environment by running (in the proxy directory)

    node server.js
    webdriver-manager start

2. In the application-seed folder run the tests using protractor, e.g.

    protractor test/bdd/cucumber.conf.js

   Or run the entire build and test using maven, e.g.

    mvn install
    
Unit Test Environment Setup
---------------------------

1. Install the test related tools by running in the top level directory of the project

    npm install

This will load the dependencies mentioned in the package.json file.

Running Unit Tests
------------------

1. In the test directory run

    karma start