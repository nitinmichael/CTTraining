define([ 'angular', 'angular-mocks', 'deviceManagerServiceMock', 'viewerServiceMock', 'viewerModule/services/annotStateService'], function(ng, mocks) {
    'use strict';

    describe('Test annotStateService', function() {
        var annotStateService;

        var httpBackend;
        var viewerService, theNavigator, theWindow, iPadUserAgent, iPhoneUserAgent, androidDeviceUserAgent, desktopUserAgent;

        var warningMessages = {
            LOAD_ERROR_MESSAGE : 'errorMessageToDisplayWhenTheConfigurationServiceCanNotBeAccessed',
        };

        var defaultAnnotState = 'full';

        var annotationUIService = {
        };

        var configManagementServiceMock = {
        };

        beforeEach(function() {
            annotationUIService.setAnnotationVisibility = sinon.spy();
            configManagementServiceMock.getAnnotationStateForCurrentUser = sinon.spy();
        });

        beforeEach(module('deviceManagerServiceMock'));
        beforeEach(module('viewerServiceMock'));

        beforeEach(module('cloudav.viewerApp.annotation.annotStateService'));

        beforeEach(module(function($provide) {
            $provide.constant('annotationUIService', annotationUIService);
            $provide.constant('configManagementService', configManagementServiceMock);
        }));

        beforeEach(inject(function($httpBackend, $q) {
            httpBackend = $httpBackend;
        }));

        beforeEach(inject(function(_annotStateService_) {
            annotStateService = _annotStateService_;
        }));

        beforeEach(inject(function (_$window_, _viewerService_) {
            theWindow = _$window_;
            theNavigator = theWindow.navigator;
            viewerService = _viewerService_;

            iPadUserAgent = 'Mozilla/5.0 (iPad; CPU OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53';
            iPhoneUserAgent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 8_0 like Mac OS X) AppleWebKit/600.1.3 (KHTML, like Gecko) Version/8.0 Mobile/12A4345d Safari/600.1.4';
            androidDeviceUserAgent = 'Mozilla/5.0 (Linux; Android 4.3; Nexus 10 Build/JSS15Q) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2307.2 Safari/537.36';
            desktopUserAgent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36';
        }));

        afterEach(function () {
            theWindow.navigator = theNavigator;
        });

        it('annotStateService is defined', function() {
            assert.isDefined(annotStateService, 'annotStateService is not defined');
        });

        it('annotStateService default annotation state', function() {
            assert.equal(defaultAnnotState, annotStateService.selectedAnnotState, 'Default annotation state is returned');
        });

        var verifyAnnotStateHandlerCall = function(expectedArgument, expectedArgumentDescription) {

            assert.isTrue(annotationUIService.setAnnotationVisibility.calledOnce, 'annotationUIService.setAnnotationVisibility invoked');

            var setAnnotationVisibilityArg = annotationUIService.setAnnotationVisibility.args[0][0];
            assert.equal(expectedArgument, setAnnotationVisibilityArg, 'annotationUIService.setAnnotationVisibility argument is ' + expectedArgumentDescription);
        };

        var simulateSuccessfulWarningsAndServiceUrlRetrieval = function() {

            httpBackend.when('GET', /.*\/warnings.json$/).respond(warningMessages);
            httpBackend.flush();
        }

        var checkAnnotStateLoading = function() {
            var loadAnnotationStateFunc = configManagementServiceMock.getAnnotationStateForCurrentUser;
            assert.isTrue(loadAnnotationStateFunc.calledOnce, 'configManagementServiceMock.getAnnotationStateForCurrentUser called exactly once');

            var successCallback = loadAnnotationStateFunc.args[0][0];
            var errorCallback = loadAnnotationStateFunc.args[0][1];

            var callbacks = [ successCallback, errorCallback ];
            return callbacks;
        }

        it('annotStateService when config service can not be reached', function() {
            simulateSuccessfulWarningsAndServiceUrlRetrieval();

            var loadingCallbacks = checkAnnotStateLoading();
            var successCb = loadingCallbacks[0];
            var errorCb = loadingCallbacks[1];

            errorCb();

            assert.isTrue(annotStateService.lastNotificationError, 'Error notification was recorded');
            assert.equal(warningMessages.LOAD_ERROR_MESSAGE, annotStateService.lastNotificationMessage, 'Last notification message recorded');

            assert.equal(defaultAnnotState, annotStateService.selectedAnnotState, 'annotState is the default');

        });

        it('annotStateService incomplete config state loading', function() {
            simulateSuccessfulWarningsAndServiceUrlRetrieval();

            var loadingCallbacks = checkAnnotStateLoading();
            var successCb = loadingCallbacks[0];
            var errorCb = loadingCallbacks[1];

            /* no data received */
            var retrievedAnnotationState = {};

            successCb(retrievedAnnotationState);

            assert.isTrue(annotStateService.lastNotificationError, 'Error notification was recorded');
            assert.equal(warningMessages.LOAD_ERROR_MESSAGE, annotStateService.lastNotificationMessage, 'Last notification message recorded');

            assert.equal(defaultAnnotState, annotStateService.selectedAnnotState, 'annotState is the default');

            verifyAnnotStateHandlerCall(defaultAnnotState, 'the default annotation state');

        });

        it('annotStateService successful loading', function() {

            simulateSuccessfulWarningsAndServiceUrlRetrieval();

            var loadingCallbacks = checkAnnotStateLoading();
            var successCb = loadingCallbacks[0];
            var errorCb = loadingCallbacks[1];

            var expectedResult = "partial";

            var retrievedAnnotationState = { annotState : "partial" };

            successCb(retrievedAnnotationState);

            assert.isFalse(annotStateService.lastNotificationError, 'No error notification was recorded');
            assert.equal(expectedResult, annotStateService.selectedAnnotState, 'Selected annotState stored');

            verifyAnnotStateHandlerCall(expectedResult, 'the value retrieved from the configuration');

        });

        it('annotStateService display partial annotations if the device is an iPad', function() {
            theWindow.navigator = {
                userAgent: iPadUserAgent
            };

            var annotState = viewerService.getDefaultLayoutConfiguration().annotState;
            simulateSuccessfulWarningsAndServiceUrlRetrieval();

            var loadingCallbacks = checkAnnotStateLoading();
            var successCb = loadingCallbacks[0];
            var errorCb = loadingCallbacks[1];

            var expectedResult = 'partial';

            var retrievedAnnotationState = { annotState : annotState };
            successCb(retrievedAnnotationState);

            assert.isFalse(annotStateService.lastNotificationError, 'No error notification was recorded');
            assert.equal(expectedResult, annotStateService.selectedAnnotState, 'Selected annotState stored');

            verifyAnnotStateHandlerCall(expectedResult, 'the value retrieved from the configuration');
        });

        it('annotStateService display partial annotations if the device is an iPhone', function() {
            theWindow.navigator = {
                userAgent: iPhoneUserAgent
            };

            var annotState = viewerService.getDefaultLayoutConfiguration().annotState;
            simulateSuccessfulWarningsAndServiceUrlRetrieval();

            var loadingCallbacks = checkAnnotStateLoading();
            var successCb = loadingCallbacks[0];
            var errorCb = loadingCallbacks[1];

            var expectedResult = 'partial';

            var retrievedAnnotationState = { annotState : annotState };
            successCb(retrievedAnnotationState);

            assert.isFalse(annotStateService.lastNotificationError, 'No error notification was recorded');
            assert.equal(expectedResult, annotStateService.selectedAnnotState, 'Selected annotState stored');

            verifyAnnotStateHandlerCall(expectedResult, 'the value retrieved from the configuration');
        });

        it('annotStateService display full annotations if the device is a desktop', function() {
            theWindow.navigator = {
                userAgent: desktopUserAgent
            };

            var annotState = viewerService.getDefaultLayoutConfiguration().annotState;
            simulateSuccessfulWarningsAndServiceUrlRetrieval();

            var loadingCallbacks = checkAnnotStateLoading();
            var successCb = loadingCallbacks[0];
            var errorCb = loadingCallbacks[1];

            var expectedResult = 'full';

            var retrievedAnnotationState = { annotState : annotState };
            successCb(retrievedAnnotationState);

            assert.isFalse(annotStateService.lastNotificationError, 'No error notification was recorded');
            assert.equal(expectedResult, annotStateService.selectedAnnotState, 'Selected annotState stored');

            verifyAnnotStateHandlerCall(expectedResult, 'the value retrieved from the configuration');
        });
    });
});
