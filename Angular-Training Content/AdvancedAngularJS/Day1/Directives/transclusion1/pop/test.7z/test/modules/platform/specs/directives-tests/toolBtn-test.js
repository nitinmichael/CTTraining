define(['angular-mocks', 'modules/platform/directives/toolBtn/toolBtn'], function() {
    describe('Test toolBtn', function() {
        var $compile, $httpBackend, $rootScope, $sce, $scope, element, parentScope;

        var cssService = {
            lightsOn: true
        };

        beforeEach(function() {
            module('platform.directive.toolBtn');
            module('templates');

            module(function($provide) {
                $provide.value('$cssService', {
                    isLightsOn: function() {
                        return cssService.lightsOn;
                    }
                });
            });

            inject(function(_$compile_, _$httpBackend_, _$rootScope_, _$sce_) {
                $compile = _$compile_;
                $httpBackend = _$httpBackend_;
                $rootScope = _$rootScope_;
                $sce = _$sce_;

                $httpBackend.whenGET(/.*/).respond('');

                parentScope = $rootScope.$new();
                parentScope.mybutton = {
                    isValidType: function() {
                        return false;
                    }
                };

                element = $compile("<tool-btn btn='mybutton'></tool-btn>")(parentScope);
                parentScope.$digest();
                $scope = element.isolateScope();
            });
        });

        it('should replace the element with the appropriate content', function() {
            expect(element.html()).to.contain('getContentUrl');
        });

        it('btnIsSelected should return whether the button is selected', function() {
            $scope.btn.selected = false;
            $scope.isSelected = true;
            expect($scope.btnIsSelected()).to.equal(true);

            $scope.btn.selected = true;
            $scope.isSelected = false;
            expect($scope.btnIsSelected()).to.equal(true);

            $scope.btn.selected = false;
            $scope.isSelected = false;
            expect($scope.btnIsSelected()).to.equal(false);
        });

        it('click on mobileMenuItem should toggle panel, disable watches and call onclick', function() {
            parentScope.mybutton.type = 'mobileMenuItem';

            var elem = $compile("<tool-btn btn='mybutton'></tool-btn>")(parentScope);
            parentScope.$digest();
            $scope = elem.isolateScope();

            $scope.tbClick();

            $scope.btn.panel = {
                type: 'popover',
                toggle: sinon.spy()
            };

            $scope.btn.onclick = sinon.spy();

            $scope.tbClick();
            expect($scope.btn.panel.toggle.calledOnce).to.equal(true);
            expect($scope.btn.onclick.calledOnce).to.equal(true);
        });

        it('click on userPrefToolBtn should inverse btn.quicktool', function() {
            parentScope.mybutton.type = 'userPrefToolBtn';

            var elem = $compile("<tool-btn btn='mybutton'></tool-btn>")(parentScope);
            parentScope.$digest();
            $scope = elem.isolateScope();

            $scope.btn.quicktool = false;
            $scope.tbClick();
            expect($scope.btn.quicktool).to.equal(true);
        });

        it('click on a button should toggle panel by default', function() {
            $scope.tbClick();

            $scope.btn.panel = {
                type: 'popover',
                toggle: sinon.spy()
            };

            $scope.tbClick();
            expect($scope.btn.panel.toggle.calledOnce).to.equal(true);
        });

        it('click on a button should call an onclick function if available', function() {
            $scope.btnClick = sinon.spy();
            $scope.btn.onclick = sinon.spy();

            $scope.tbClick();
            expect($scope.btnClick.calledWith($scope.btn)).to.equal(true);
            expect($scope.btn.onclick.called).to.equal(false);

            $scope.btnClick = null;
            $scope.tbClick();
            expect($scope.btn.onclick.calledOnce).to.equal(true);
        });

        it('groupIconClick should toggle group panel', function() {
            $scope.btn.groupPanel = {
                toggle: sinon.spy()
            };
            $scope.groupIconClick();
            expect($scope.btn.groupPanel.toggle.calledOnce).to.equal(true);
        });

        it('getContentUrl should return the template urls', function() {
            parentScope.mybutton.type = 'test';

            var elem = $compile("<tool-btn btn='mybutton'></tool-btn>")(parentScope);
            parentScope.$digest();
            $scope = elem.isolateScope();
            expect($scope.getContentUrl()).to.contain('test.html');

            parentScope.mybutton.icon = {
                type: 'svg'
            };
            elem = $compile("<tool-btn btn='mybutton'></tool-btn>")(parentScope);
            parentScope.$digest();
            $scope = elem.isolateScope();
            expect($scope.getContentUrl()).to.contain('testSvg.html');

            parentScope.mybutton.icon = {
                type: 'css'
            };
            elem = $compile("<tool-btn btn='mybutton'></tool-btn>")(parentScope);
            parentScope.$digest();
            $scope = elem.isolateScope();
            expect($scope.getContentUrl()).to.contain('testCss.html');

            parentScope.mybutton.icon = {
                type: 'snorlax'
            };
            elem = $compile("<tool-btn btn='mybutton'></tool-btn>")(parentScope);
            parentScope.$digest();
            $scope = elem.isolateScope();
            expect($scope.getContentUrl()).to.contain('test.html');
        });

        it('getIcon should return the button icon url', function() {
            $scope.btn.icon = {
                url: 'url',
                urlLightsOff: 'urlLightsOff'
            };

            expect($scope.getIcon()).to.equal('url');

            cssService.lightsOn = false;
            expect($scope.getIcon()).to.equal('urlLightsOff');
        });

        it('renderHtml should send trusted version of the html in parameter', function() {
            var spy = sinon.spy($sce, 'trustAsHtml');
            $scope.renderHtml();
            expect(spy.calledOnce).to.equal(true);
        });
    });
});
