/*
 *  get-morpheus-service-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jyothi Jayaraman<Jyothi.Jayaraman@ge.com>
 */

/**
 * Test specs for get-morpheus-service.js
 */
 define([
    'angular',
    'angular-mocks',
    'modules/caseexchange/modules/morpheus/services/get-morpheus-service'],
    function () {

    'use strict';
    var service, rootScope, scope, _caseExchangeDataService, serviceUrl, q, defer, $httpBackend;

    describe('Morpheus Get Morpheus Service Test Suite::', function() {

        beforeEach(function () {
            module('Services.morpheusServices', function ($provide) {
                 $provide.service('caseExchangeDataService', function(){
                    this.getServiceURL= sinon.spy();
                });
            });

             // inject dependencies for GetMorpheusService
            inject(function (_MorpheusServices_, $rootScope, _CaseExchangeDataService_, _$q_, _$httpBackend_) {
                service  = _MorpheusServices_;
                rootScope = $rootScope;
                $httpBackend = _$httpBackend_;
                _caseExchangeDataService = _CaseExchangeDataService_;
                serviceUrl = _caseExchangeDataService.getServiceURL();
                q = _$q_;
                defer = q.defer();
            });
        });

        //Tests for logged in user details.
        describe('Testing LoggedInUserDetails function:', function() {

            it('should define a service', function () {
                assert.isDefined(service, 'MorpheusService is defined');
            });

            //it('should test the success path:' , function() {
            //    var url= serviceUrl +'/userregistry/v1/user/me?level.value=2';
            //    $httpBackend.expectGET(url).respond(200);
            //    defer.resolve();
            //    service.getLoggedInUserDetails();
            //    //$httpBackend.flush();
            //    $httpBackend.verifyNoOutstandingExpectation();
            //    $httpBackend.verifyNoOutstandingRequest();
            //});

            //it('should test the error path:' , function() {
            //    var url= serviceUrl +'/userregistry/v1/user/me?level.value=2';
            //    $httpBackend.expectGET(url).respond(500);
            //    defer.resolve();
            //    service.getLoggedInUserDetails();
            //    //$httpBackend.flush();
            //    $httpBackend.verifyNoOutstandingExpectation();
            //    $httpBackend.verifyNoOutstandingRequest();
            //});

        });

        //Tests for get clinical data.
        describe('Testing getClinicalData function:', function() {

            it('should test the success path:' , function() {
                var url= serviceUrl +'/analyticdata/v1/analyticdata?uomUserId=1&days=30';
                $httpBackend.expectGET(url).respond(200);
                defer.resolve();
                service.getClinicianData(1, 30);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test the error path:' , function() {
                var url= serviceUrl +'/analyticdata/v1/analyticdata?uomUserId=1&days=30';
                $httpBackend.expectGET(url).respond(500);
                defer.resolve();
                service.getClinicianData(1, 30);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

        });

    });
});
