define(['angular',
        'angular-mocks',
        'orgMgmnt/features/site/siteDetail/controllers/siteDetailsController',
        'orgMgmnt/dataModels/appServiceDataModel',
        'orgMgmnt/dataModels/siteDataModel',
        'orgMgmnt/dataModels/deviceDataModel',
        'orgMgmnt/services/siteService',
        'orgMgmnt/widgets/ge-exception-handler/geExceptionHandler',
        'orgMgmnt/services/userService'

    ],
    function() {
        'use strict';

        describe('Test the Site Detail Controller', function () {
            var SiteDetailsCtrl, scope, _siteDataModel, _siteMgmtService, _q, deferred, _log,
                _deviceDataModel,rootScope,deviceDefer,deferredAppServices, _state,_messageObj,
                findUserDeferred, loggedInUserContextServiceResponse, searchUserResult, filter,
                updateSiteAdminsDeferred, getLoggedInUserDetailsDeferred,
                getSiteAdminsDeferred,_userService, otherAdmin,_appServiceDataModel;

            var  extensionForSiteDetails = [
                {
                    "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                    "valueString": "GE Healthcare STO-I"
                },
                {
                    "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                    "valueCoding": {
                        "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                        "code": "_case_reshare_inside_new_site",
                        "display": "Allow re-share"
                    }
                },
                {
                    "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                    "valueCoding": {
                        "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                        "code": "_case_reshare_outside_new_site",
                        "display": "Allow Clinician/Staff re-share outside this network"
                    }
                },
                {
                    "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                    "valueCoding": {
                        "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                        "code": "_site_visible_public_directory",
                        "display": "site is visible in the public directory"
                    }
                },
                {
                    "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                    "valueCoding": {
                        "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                        "code": "_case_download_inside_new_site",
                        "display": "Allow download of case files"
                    }
                },
                {
                    "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                    "valueCoding": {
                        "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                        "code": "_case_download_outside_new_site",
                        "display": "Allow Clinician/Staff to download outside this network"
                    }
                }
            ];
            beforeEach(function () {
                module('Orgmanagement.Features.Site.SiteDetail.SiteDetailsController');
                module('Orgmanagement.DataModel.AppServiceModel');
                module('Orgmanagement.DataModel.SiteDataModel');
                module('Orgmanagement.DataModel.DeviceDataModel');
                module('Orgmanagement.Services.SiteService');
                module('ui.router');
                module('geExceptionHandlerModule');
                module('Orgmanagement.Services.UserService');
            });
            beforeEach(inject(function ($controller, $rootScope, siteDataModel,deviceDataModel,appServiceDataModel, siteMgmtService ,$q, $log, $state,messageObj, userMgmtService) {
                scope = $rootScope.$new();
                rootScope = $rootScope;
                $rootScope.selectedOrg={'siteId':'12345'};
                $rootScope.siteDetails = {
                    name: 'GEHCOrg',
                    nickName: 'GE Healthcare Organization',
                    description: 'John Doe',
                    addressOne: '1st Street',
                    email: 'john.doe@ge.com',
                    address2: '2nd Street',
                    resource: '1324536',
                    city: 'BLR',
                    ext: '23456',
                    state: {name: 'KAR'},
                    zip: '560066',
                    country: {name: 'INDIA'},
                    extension: extensionForSiteDetails
                };
                scope.stateArrayValue = [{name:"Washington"},
                    {name:"Alabama"}];

                scope.countryArrayValue = [{name:"US"}];
                _siteDataModel = siteDataModel;
                _deviceDataModel= deviceDataModel;
                _appServiceDataModel=appServiceDataModel;
                _siteMgmtService = siteMgmtService;
                _userService=userMgmtService;
                _q = $q;
                deferred = _q.defer();
                deviceDefer = _q.defer();
                deferredAppServices = _q.defer();
                findUserDeferred = $q.defer();
                updateSiteAdminsDeferred = $q.defer();
                getLoggedInUserDetailsDeferred = $q.defer();
                getSiteAdminsDeferred = $q.defer();
                _log = $log;
                _state = $state;
                _messageObj=messageObj;
                sinon.stub(_siteMgmtService, 'getSiteDetail').returns(deferred.promise);
                sinon.stub(_siteMgmtService, 'updateSiteSettings').returns(deferred.promise);
                sinon.stub(_siteMgmtService, 'updateSiteDetail').returns(deferred.promise);
                sinon.stub(_siteMgmtService, 'createDevice').returns(deviceDefer.promise);
                sinon.stub(_siteMgmtService, 'updateDevice').returns(deviceDefer.promise);
                sinon.stub(_siteMgmtService, 'getListOfDevices').returns(deviceDefer.promise);
                sinon.stub(_siteMgmtService, 'createUpdateApplicationServices').returns(deferredAppServices.promise);
                sinon.stub(_siteMgmtService, 'getApplicationServices').returns(deferredAppServices.promise);
                sinon.stub(_siteMgmtService, 'deleteApplicationService').returns(deferredAppServices.promise);
                sinon.stub(_userService, 'findUser').returns(findUserDeferred.promise);
                sinon.stub(_siteMgmtService, 'updateSiteAdmins').returns(updateSiteAdminsDeferred.promise);
                sinon.stub(_siteMgmtService, 'getSiteAdmins').returns(getSiteAdminsDeferred.promise);
                sinon.stub(_userService, 'getLoggedInUserDetails').returns(getLoggedInUserDetailsDeferred.promise);
                sinon.stub(_log, 'info');
                $rootScope.selectedSite = {
                    id:"12345678",
                    content: {name:"Site1"}
                };
                $rootScope.countryStatesData = [
                    {
                        "name": "United States of America",
                        "code": "US",
                        "states": [
                            {
                                "name": "Alabama",
                                "code": "AL"
                            },
                            {
                                "name": "Alaska",
                                "code": "AK"
                            },
                            {
                                "name": "American Samoa",
                                "code": "AS"
                            },
                            {
                                "name": "Arizona",
                                "code": "AZ"
                            },
                            {
                                "name": "Arkansas",
                                "code": "AR"
                            },
                            {
                                "name": "California",
                                "code": "CA"
                            },
                            {
                                "name": "Colorado",
                                "code": "CO"
                            },
                            {
                                "name": "Connecticut",
                                "code": "CT"
                            },
                            {
                                "name": "Delaware",
                                "code": "DE"
                            },
                            {
                                "name": "District Of Columbia",
                                "code": "DC"
                            },
                            {
                                "name": "Federated States Of Micronesia",
                                "code": "FM"
                            },
                            {
                                "name": "Florida",
                                "code": "FL"
                            },
                            {
                                "name": "Georgia",
                                "code": "GA"
                            },
                            {
                                "name": "Guam",
                                "code": "GU"
                            },
                            {
                                "name": "Hawaii",
                                "code": "HI"
                            },
                            {
                                "name": "Idaho",
                                "code": "ID"
                            },
                            {
                                "name": "Illinois",
                                "code": "IL"
                            },
                            {
                                "name": "Indiana",
                                "code": "IN"
                            },
                            {
                                "name": "Iowa",
                                "code": "IA"
                            },
                            {
                                "name": "Kansas",
                                "code": "KS"
                            },
                            {
                                "name": "Kentucky",
                                "code": "KY"
                            },
                            {
                                "name": "Louisiana",
                                "code": "LA"
                            },
                            {
                                "name": "Maine",
                                "code": "ME"
                            },
                            {
                                "name": "Marshall Islands",
                                "code": "MH"
                            },
                            {
                                "name": "Maryland",
                                "code": "MD"
                            },
                            {
                                "name": "Massachusetts",
                                "code": "MA"
                            },
                            {
                                "name": "Michigan",
                                "code": "MI"
                            },
                            {
                                "name": "Minnesota",
                                "code": "MN"
                            },
                            {
                                "name": "Mississippi",
                                "code": "MS"
                            },
                            {
                                "name": "Missouri",
                                "code": "MO"
                            },
                            {
                                "name": "Montana",
                                "code": "MT"
                            },
                            {
                                "name": "Nebraska",
                                "code": "NE"
                            },
                            {
                                "name": "Nevada",
                                "code": "NV"
                            },
                            {
                                "name": "New Hampshire",
                                "code": "NH"
                            },
                            {
                                "name": "New Jersey",
                                "code": "NJ"
                            },
                            {
                                "name": "New Mexico",
                                "code": "NM"
                            },
                            {
                                "name": "New York",
                                "code": "NY"
                            },
                            {
                                "name": "North Carolina",
                                "code": "NC"
                            },
                            {
                                "name": "North Dakota",
                                "code": "ND"
                            },
                            {
                                "name": "Northern Mariana Islands",
                                "code": "MP"
                            },
                            {
                                "name": "Ohio",
                                "code": "OH"
                            },
                            {
                                "name": "Oklahoma",
                                "code": "OK"
                            },
                            {
                                "name": "Oregon",
                                "code": "OR"
                            },
                            {
                                "name": "Palau",
                                "code": "PW"
                            },
                            {
                                "name": "Pennsylvania",
                                "code": "PA"
                            },
                            {
                                "name": "Puerto Rico",
                                "code": "PR"
                            },
                            {
                                "name": "Rhode Island",
                                "code": "RI"
                            },
                            {
                                "name": "South Carolina",
                                "code": "SC"
                            },
                            {
                                "name": "South Dakota",
                                "code": "SD"
                            },
                            {
                                "name": "Tennessee",
                                "code": "TN"
                            },
                            {
                                "name": "Texas",
                                "code": "TX"
                            },
                            {
                                "name": "Utah",
                                "code": "UT"
                            },
                            {
                                "name": "Vermont",
                                "code": "VT"
                            },
                            {
                                "name": "Virgin Islands",
                                "code": "VI"
                            },
                            {
                                "name": "Virginia",
                                "code": "VA"
                            },
                            {
                                "name": "Washington",
                                "code": "WA"
                            },
                            {
                                "name": "West Virginia",
                                "code": "WV"
                            },
                            {
                                "name": "Wisconsin",
                                "code": "WI"
                            },
                            {
                                "name": "Wyoming",
                                "code": "WY"
                            }
                        ]
                    }
                ];
                searchUserResult = {
                    "resourceType": "Bundle",
                    "title": "List of all groups for user",
                    "id": null,
                    "data": {
                        "entry": [
                            {
                                "title": null,
                                "id": "034e2e9b-60b0-4856-85a7-c43779a11746",
                                "content": {
                                    "resourceType": "ResourcesUser",
                                    "name": {
                                        "use": "official",
                                        "family": [
                                            "Tari"
                                        ],
                                        "given": [
                                            "Tushar",
                                            "K"
                                        ]
                                    },
                                    "externalId": [
                                        {
                                            "system": "IDM",
                                            "value": "b9f2b0f9-03ab-4d94-bd33-f40b495fc4d5"
                                        },
                                        {
                                            "system": "UOM",
                                            "value": "034e2e9b-60b0-4856-85a7-c43779a11746"
                                        },
                                        {
                                            "_id": "tushar.tari@ge.com",
                                            "system": "urn:hc.ge.com/pfh/platform/useremail"
                                        }
                                    ],
                                    "role": [
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "practitioner",
                                                    "display": "practitioner"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "organization/5"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "practitioner",
                                                    "display": "practitioner"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "organization/6"
                                            },
                                            "status": "active"
                                        }
                                    ],
                                    "managingOrganization": {
                                        "organization": {
                                            "reference": "organization/74553d9a-7d1b-4f93-929c-72b6318a6178"
                                        },
                                        "jobTitle": {
                                            "coding": [
                                                {
                                                    "system": "http://hl7.org/fhir/v3/AdministrativeUser",
                                                    "version": "1",
                                                    "code": "Manager",
                                                    "primary": true
                                                }
                                            ],
                                            "text": "Manager"
                                        },
                                        "employeeNumber": "ID_123445"
                                    },
                                    "telecom": [
                                        {
                                            "system": "phone",
                                            "value": "(+1) 734-677-7777"
                                        },
                                        {
                                            "system": "email",
                                            "value": "tushar.tari@ge.com"
                                        }
                                    ],
                                    "principalName": "tushar.tari@ge.com",
                                    "display": "Tushar K"
                                }
                            }
                        ]
                    }
                };
                otherAdmin = {
                    name: "yash23",
                    display: "yash23",
                    principalName: "yash23.yash23@ge.com",
                    id: "034e2e9b-60b0-4856-85a7-c43779a89678"
                };
                loggedInUserContextServiceResponse={
                    "resourceType": "ResourcesUser",
                    "name": {
                        "use": "official",
                        "family": [
                            "Tari"
                        ],
                        "given": [
                            "Tushar",
                            "K"
                        ]
                    },
                    "externalId": [
                        {
                            "system": "IDM",
                            "value": "b9f2b0f9-03ab-4d94-bd33-f40b495fc4d5"
                        },
                        {
                            "system": "UOM",
                            "value": "034e2e9b-60b0-4856-85a7-c43779a11746"
                        },
                        {
                            "_id": "tushar.tari@ge.com",
                            "system": "urn:hc.ge.com/pfh/platform/useremail"
                        }
                    ],
                    "role": [
                        {
                            "code": [
                                {
                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                    "code": "practitioner",
                                    "display": "practitioner"
                                }
                            ],
                            "scopingOrganization": {
                                "reference": "organization/5"
                            },
                            "status": "active"
                        },
                        {
                            "code": [
                                {
                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                    "code": "practitioner",
                                    "display": "practitioner"
                                }
                            ],
                            "scopingOrganization": {
                                "reference": "organization/6"
                            },
                            "status": "active"
                        }
                    ],
                    "managingOrganization": {
                        "organization": {
                            "reference": "organization/74553d9a-7d1b-4f93-929c-72b6318a6178"
                        },
                        "jobTitle": {
                            "coding": [
                                {
                                    "system": "http://hl7.org/fhir/v3/AdministrativeUser",
                                    "version": "1",
                                    "code": "Manager",
                                    "primary": true
                                }
                            ],
                            "text": "Manager"
                        },
                        "employeeNumber": "ID_123445"
                    },
                    "telecom": [
                        {
                            "system": "phone",
                            "value": "(+1) 734-677-7777"
                        },
                        {
                            "system": "email",
                            "value": "tushar.tari@ge.com"
                        }
                    ],
                    "principalName": "tushar.tari@ge.com",
                    "display": "Tushar K"
                };
                scope.applicationServicesObj = {
                    resourceType: "Bundle",
                    title: "List of all Application Servcies",
                    id: null,
                    entry: [
                        {
                            $$hashKey: "object:412",
                            title: null,
                            id: "01cdab3b-1454-4033-bee3-8db5cab7336e",
                            content: {
                                resourceType: "ResourcesApplicationService",
                                type: "DICOM",
                                name: "bbb",
                                endpoint: "http://blob-set-view.foundation-int.grc-apps.svc.ice.ge.com/v1/bucket/com.ge.pfh.ig.fe8ecc18-f9a4-4867-9bab-22c2de965596/set/configuration/content/fe8ecc18-f9a4-4867-9bab-22c2de965596-AppConf/",
                                gateway: {
                                    reference: "device/"
                                },
                                owner: {
                                    reference: "site/bc5f9675-ad70-47d4-9213-739e09a551ff"
                                },
                                networkAddress: {
                                    ip: "bbb",
                                    entityName: "bbb",
                                    port: 8080
                                }
                            }
                        },
                        {
                            $$hashKey: "object:413",
                            title: null,
                            id: "ce5d1787-0ba0-44da-8c03-2dcf8f4f0653",
                            content: {
                                resourceType: "ResourcesApplicationService",
                                type: "DICOM",
                                name: "aaa",
                                endpoint: "http://blob-set-view.foundation-int.grc-apps.svc.ice.ge.com/v1/bucket/com.ge.pfh.ig.fe8ecc18-f9a4-4867-9bab-22c2de965596/set/configuration/content/fe8ecc18-f9a4-4867-9bab-22c2de965596-AppConf/",
                                gateway: {
                                    reference: "device/"
                                },
                                owner: {
                                    reference: "site/bc5f9675-ad70-47d4-9213-739e09a551ff"
                                },
                                networkAddress: {
                                    ip: "aaa",
                                    entityName: "aaa",
                                    port: 8080
                                }
                            }
                        }
                    ]
                };

                SiteDetailsCtrl = $controller('SiteDetailsCtrl', {
                    $scope: scope,
                    $log: _log,
                    $rootScope: rootScope,
                    siteMgmtService: _siteMgmtService,
                    messageObj: _messageObj
                });
            }));

            describe('Edit and update the site Setting',function(){
                it('should test the value coding array length when all true', function(){
                    scope.siteDetailsObj.reShare = true;
                    scope.siteDetailsObj.reShareOutSide = true;
                    scope.siteDetailsObj.siteVisibleInPublicDirectory = true;
                    scope.siteDetailsObj.siteDownloads = true;
                    scope.siteDetailsObj.siteDownloadsOutside = true;
                    scope.updateSiteSettings();
                    chai.expect(scope.valueCodingArr).to.have.length(5);
                });

                it('should test the value coding array length when all false', function(){
                    scope.siteDetailsObj.reShare = false;
                    scope.siteDetailsObj.reShareOutSide = false;
                    scope.siteDetailsObj.siteVisibleInPublicDirectory = false;
                    scope.siteDetailsObj.siteDownloads = false;
                    scope.siteDetailsObj.siteDownloadsOutside = false;
                    scope.updateSiteSettings();
                    chai.expect(scope.valueCodingArr).to.have.length(0);
                });
                it('should test when save site setting success', function(done){
                    var address = [];
                    address.push({city:'Bangalore',country:'india',line:['some addr','some addr1'],state:{id:8},zip:123456});
                    var extension = [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "GE Healthcare STO-I"
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_inside_new_site",
                                "display": "Allow re-share"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_new_site",
                                "display": "Allow Clinician/Staff re-share outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_new_site",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_outside_new_site",
                                "display": "Allow Clinician/Staff to download outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_site_visible_public_directory",
                                "display": "site is visible in the public directory"
                            }
                        }
                    ];
                    var responseData ={data:{
                        siteName :'Manipal Whitefield',
                        address :address,
                        extension:extension,
                        telecom:[{"system":"dummy", "value":"124354"}]
                    },status:200};
                    scope.updateSiteSettings();
                    deferred.resolve(responseData);
                    scope.$root.$digest();
                    done();
                    chai.expect(_log.info.calledWith(responseData));
                    chai.expect(scope.editSiteSettingsMode).to.be.true;
                });

                it('should test when save site setting error', function(done){
                    var address = [];
                    address.push({city:'',country:'',line:['some addr','some addr1'],state:{id:5},zip:2343});
                    var extension = [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "GE Healthcare STO-I"
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_inside_new_site",
                                "display": "Allow re-share"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_new_site",
                                "display": "Allow Clinician/Staff re-share outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_new_site",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_outside_new_site",
                                "display": "Allow Clinician/Staff to download outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_route_site_admin",
                                "display": "Cases sent to site routed to Admin?"
                            }
                        }
                    ];
                    var responseData ={data:{
                        siteName :'Manipal Whitefield',
                        address :address,
                        extension:extension
                    },status:402};
                    scope.updateSiteSettings();
                    deferred.reject(responseData);
                    scope.$root.$digest();
                    done();
                    chai.expect(_log.info.calledWith(responseData));
                    chai.expect(scope.editSiteSettingsMode).to.be.true;
                });


                it('should test when cancelling the edit mode', function () {
                    scope.siteDetailsObject = {};
                    scope.siteDetailsObject.extension = [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "GE Healthcare STO-I"
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_inside_new_site",
                                "display": "Allow re-share"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_new_site",
                                "display": "Allow Clinician/Staff re-share outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_new_site",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_outside_new_site",
                                "display": "Allow Clinician/Staff to download outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_site_visible_public_directory",
                                "display": "site is visible in public directory"
                            }
                        }
                    ];
                    scope.cancelSiteNetworkSetting();
                    chai.expect(scope.editSiteSettingsMode).to.be.false;
                });


                it('should test when edit the site setting ', function () {
                    scope.editSiteSettings();
                    chai.expect(scope.editSiteSettingsMode).to.be.false;
                });
            });

            describe('updateSiteDetail Service', function(){
                it('should test the success response on updating site details', function(done) {
                    var address = [];
                    address.push({city:'',country:'',line:['test addr','test addr1'],stateArrayValue:{name:'Washington'},zip:2315});
                    var extension = [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "GE Healthcare STO-I"
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_inside_new_site",
                                "display": "Allow re-share"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_new_site",
                                "display": "Allow Clinician/Staff re-share outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_new_site",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_outside_new_site",
                                "display": "Allow Clinician/Staff to download outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_route_site_admin",
                                "display": "Cases sent to site routed to Admin?"
                            }
                        }
                    ];

                    var responseData ={data:{
                        siteName :'Manipal',
                        address :address,
                        extension:extension,
                        telecom:[{"system":"phone", "value":"124354"}]
                    },status:200};
                    scope.detailForm ={};
                    scope.detailForm.$error = true;

                    scope.updateSiteDetail();
                    deferred.resolve(responseData);
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.getSiteDetails.calledOnce);
                });

                it('should test the error response on updating organization details', function(done) {
                    var address = [];
                    address.push({city:'',country:'',line:['whitefield','Main Street1'],stateArrayValue:{name:'Washington'},zip:78945});
                    var extension = [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "GE Healthcare STO-I"
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_inside_new_site",
                                "display": "Allow re-share"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_new_site",
                                "display": "Allow Clinician/Staff re-share outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_new_site",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_outside_new_site",
                                "display": "Allow Clinician/Staff to download outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_route_site_admin",
                                "display": "Cases sent to site routed to Admin?"
                            }
                        }
                    ];

                    var responseData ={data:{
                        siteName :'Manipal',
                        address :address,
                        extension:extension
                    },status:402};
                    scope.detailForm ={};
                    scope.detailForm.$error = true;
                    scope.updateSiteDetail();
                    deferred.reject(responseData);
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.getSiteDetails.notCalled);
                });

                it('should test the cancelling of edit mode', function () {
                    scope.editModeOrgDetails=true;
                    var address = [];
                    address.push({city:'Bangalore',country:'india',line:['some addr','some addr1'],state:{id:8},zip:123456});
                    scope.siteDetailsObject ={
                        siteName :'Manipal Whitefield',
                        address :address
                    };
                    scope.cancelSiteDetails();
                    chai.expect(scope.editModeSiteDetails).to.be.false;
                });
                it('should test the address array if address line 2 is not present in cancel', function(){
                    var address = [];
                    address.push({city:'Bangalore',country:'india',line:['some addr'],state:{id:8},zip:123456});
                    scope.siteDetailsObject ={
                        siteName :'Manipal Whitefield',
                        address :address
                    };
                    scope.cancelSiteDetails();

                });
                it('should test the address array if address line 2 is not present', function(){
                    scope.Address = "Line1 Address";
                    scope.Address2 = undefined;
                    scope.detailForm ={};
                    scope.detailForm.$error = true;
                    scope.updateSiteDetail();
                    chai.expect(scope.addressArray).to.have.length(1);
                });

                it('should test the address array if address line 2 is present', function(){
                    scope.Address = "Line1 Address";
                    scope.Address2 = "Line 2 Address";
                    scope.detailForm ={};
                    scope.detailForm.$error = true;
                    scope.updateSiteDetail();
                    chai.expect(scope.addressArray).to.have.length(2);
                });

                it('should test Mandatory fields Presents before save', function(){
                    scope.detailForm ={};
                    scope.detailForm.$error={required:"Yes"};
                    scope.updateSiteDetail();
                    chai.expect(scope.loadingSiteUpdateDetail).to.be.false;
                });

            });

            describe('getSiteDetails Service', function(){
                it('should be called successfully',function(done){

                    var address = [];
                    address.push({city:'',country:'',line:['MG ROAD','Seattle'],state:{id:99},zip:584128});
                    var extension = [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "GE Healthcare STO-I"
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_inside_new_site",
                                "display": "Allow re-share"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_new_site",
                                "display": "Allow Clinician/Staff re-share outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_new_site",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_outside_new_site",
                                "display": "Allow Clinician/Staff to download outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_route_site_admin",
                                "display": "Cases sent to site routed to Admin?"
                            }
                        }
                    ];

                    var responseData ={data:{
                        siteName :'Manipal East Coast',
                        address :address,
                        extension:extension,
                        telecom:[{system:'phone', value:'1234678'}]
                    },status:200};

                    scope.getSiteDetails();
                    deferred.resolve(responseData);
                    scope.$digest();
                    done();

                    chai.expect(scope.siteName).to.be.equal(responseData.siteName);
                });

                it('should not be called successfully',function(done){
                    var address = [];
                    address.push({city:'',country:'',line:['Mys','Usa'],state:{id:43},zip:122343});
                    var extension = [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "GE Healthcare STO-I"
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_inside_new_site",
                                "display": "Allow re-share"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_new_site",
                                "display": "Allow Clinician/Staff re-share outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_new_site",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_outside_new_site",
                                "display": "Allow Clinician/Staff to download outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_route_site_admin",
                                "display": "Cases sent to site routed to Admin?"
                            }
                        }
                    ];

                    var responseData ={data:{
                        siteName :'Manipal Delhhi',
                        address :address,
                        extension:extension,
                        telecom:[{system:'phone', value:'1234678'}]
                    },status:404};

                    scope.getSiteDetails();
                    deferred.reject(responseData);
                    scope.$root.$digest();
                    done();

                    chai.expect(scope.siteName).to.be.equal('');
                });

                it('should test when data.text value is empty',function(done){
                    var address = [];
                    address.push({city:'',country:'',line:['Mys','Usa'],state:{id:43},zip:122343});
                    var extension = [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "GE Healthcare STO-I"
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_inside_new_site",
                                "display": "Allow re-share"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_new_site",
                                "display": "Allow Clinician/Staff re-share outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_new_site",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_outside_new_site",
                                "display": "Allow Clinician/Staff to download outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_route_site_admin",
                                "display": "Cases sent to site routed to Admin?"
                            }
                        }
                    ];

                    var responseData ={data:{
                        siteName :'Manipal Delhhi',
                        address :address,
                        extension:extension,
                        text:'',
                        telecom:[{system:'phone', value:'1234678'}]
                    },status:200};

                    scope.getSiteDetails();
                    deferred.resolve(responseData);
                    scope.$digest();
                    done();

                    chai.expect(scope.description).to.be.equal('');
                });

                it('should test when data.text value is present',function(done){
                    var address = [];
                    address.push({city:'',country:'',line:['Mys','Usa'],state:{id:43},zip:122343});
                    var extension = [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "GE Healthcare STO-I"
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_inside_new_site",
                                "display": "Allow re-share"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_new_site",
                                "display": "Allow Clinician/Staff re-share outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_new_site",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_outside_new_site",
                                "display": "Allow Clinician/Staff to download outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_route_site_admin",
                                "display": "Cases sent to site routed to Admin?"
                            }
                        }
                    ];

                    var responseData ={data:{
                        siteName :'Manipal Delhhi',
                        address :address,
                        extension:extension,
                        text:{div:"<div>testDescription</div>"},
                        telecom:[{system:'phone', value:'1234678'}]
                    },status:200};

                    scope.getSiteDetails();
                    deferred.resolve(responseData);
                    scope.$digest();
                    done();
                    chai.expect(scope.description).to.be.equal('textDescription');
                });
            });

            describe('get device details test cases', function(){

                it('saveAddDevice , when user clicks on saves when adding a device ', function(done){
                    scope.editModeDevice = false;
                    scope.showSaveCancelBtn =false;
                    var identifier = [
                        {
                            system: "http://goodcare.org/devices/id",
                            value: "345675"
                        },
                        {
                            label: "Serial Number",
                            value: "AMID-342135-8464"
                        }
                    ];

                    var  owner = {
                        "reference": "organization/1"
                    };

                    var responseData = {
                        "resourceType":"Bundle",
                        identifier:identifier,
                        owner:owner,
                        url:"test",
                        "title":"List of all organizations",
                        "id":null,
                        "entry":[{"title":null,
                            "id":null,
                            "content":{
                                "resourceType":"Device",
                                "extension":[
                                    {"url":"urn:hc.ge.com/pfh/platform/extension/entitystatus:V1","valueCoding":{"system":"urn:hc.ge.com/pfh/platform/policy:V1","code":"create"}},{"url":"urn:hc.ge.com/pfh/platform/extension/entityname:V1","valueString":"sdsd1232"}],"identifier":[{"_id":"590029bc-f2af-4456-8981-65278edef361","system":"urn:hc.ge.com/pfh/platform/devicetype"}],
                                "owner":{"reference":"organization/9b54d055-98fe-4223-9515-83556c37a96a"},
                                "url":"sdds1212"}}]
                    };
                    scope.saveAddDevice();
                    deviceDefer.resolve({data:responseData,status:200});
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.loadingDevice).to.be.false;

                });

                it('saveAddDevice reject , when user clicks on saves when adding a device is unsuccessfull', function(done){
                    scope.editModeDevice = false;
                    scope.showSaveCancelBtn =false;
                    var identifier = [
                        {
                            system: "http://goodcare.org/devices/id",
                            value: "345675"
                        },
                        {
                            label: "Serial Number",
                            value: "AMID-342135-8464"
                        }
                    ];

                    var  owner = {
                        "reference": "organization/1"
                    };

                    var responseData = {
                        "resourceType":"Bundle",
                        identifier:identifier,
                        owner:owner,
                        url:"test",
                        "title":"List of all organizations",
                        "id":null,
                        "entry":[{"title":null,
                            "id":null,
                            "content":{
                                "resourceType":"Device",
                                "extension":[
                                    {"url":"urn:hc.ge.com/pfh/platform/extension/entitystatus:V1","valueCoding":{"system":"urn:hc.ge.com/pfh/platform/policy:V1","code":"create"}},{"url":"urn:hc.ge.com/pfh/platform/extension/entityname:V1","valueString":"sdsd1232"}],"identifier":[{"_id":"590029bc-f2af-4456-8981-65278edef361","system":"urn:hc.ge.com/pfh/platform/devicetype"}],
                                "owner":{"reference":"organization/9b54d055-98fe-4223-9515-83556c37a96a"},
                                "url":"sdds1212"}}]
                    };
                    scope.saveAddDevice();
                    deviceDefer.reject({data:responseData,status:402});
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.loadingDevice).to.be.false;

                });

                it('saveAddDeviceOnEdit , when user clicks on saves when device is added ', function(done){
                    scope.editModeDevice = false;
                    scope.showSaveCancelBtn =false;
                    var identifier = [
                        {
                            system: "http://goodcare.org/devices/id",
                            value: "345675"
                        },
                        {
                            label: "Serial Number",
                            value: "AMID-342135-8464"
                        }
                    ];
                    var  owner = {
                        "reference": "organization/1"
                    };
                    var responseData = {
                        "resourceType":"Bundle",
                        identifier:identifier,
                        owner:owner,
                        url:"test",
                        "title":"List of all organizations",
                        "id":null,
                        "entry":[{"title":null,
                            "id":null,
                            "content":{
                                "resourceType":"Device",
                                "extension":[
                                    {"url":"urn:hc.ge.com/pfh/platform/extension/entitystatus:V1","valueCoding":{"system":"urn:hc.ge.com/pfh/platform/policy:V1","code":"create"}},{"url":"urn:hc.ge.com/pfh/platform/extension/entityname:V1","valueString":"sdsd1232"}],"identifier":[{"_id":"590029bc-f2af-4456-8981-65278edef361","system":"urn:hc.ge.com/pfh/platform/devicetype"}],
                                "owner":{"reference":"organization/9b54d055-98fe-4223-9515-83556c37a96a"},
                                "url":"sdds1212"}}]
                    };
                    scope.saveAddDeviceOnEdit();
                    deviceDefer.resolve({data:responseData,status:200});
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.getListOfDevices.calledOnce);
                });

                it('saveAddDeviceOnEdit reject , when user clicks on saves when device is added is unsuccessfull ', function(done){
                    scope.editModeDevice = false;
                    scope.showSaveCancelBtn =false;
                    var identifier = [
                        {
                            system: "http://goodcare.org/devices/id",
                            value: "345675"
                        },
                        {
                            label: "Serial Number",
                            value: "AMID-342135-8464"
                        }
                    ];
                    var  owner = {
                        "reference": "organization/1"
                    };
                    var responseData = {
                        "resourceType":"Bundle",
                        identifier:identifier,
                        owner:owner,
                        url:"test",
                        "title":"List of all organizations",
                        "id":null,
                        "entry":[{"title":null,
                            "id":null,
                            "content":{
                                "resourceType":"Device",
                                "extension":[
                                    {"url":"urn:hc.ge.com/pfh/platform/extension/entitystatus:V1","valueCoding":{"system":"urn:hc.ge.com/pfh/platform/policy:V1","code":"create"}},{"url":"urn:hc.ge.com/pfh/platform/extension/entityname:V1","valueString":"sdsd1232"}],"identifier":[{"_id":"590029bc-f2af-4456-8981-65278edef361","system":"urn:hc.ge.com/pfh/platform/devicetype"}],
                                "owner":{"reference":"organization/9b54d055-98fe-4223-9515-83556c37a96a"},
                                "url":"sdds1212"}}]
                    };
                    scope.saveAddDeviceOnEdit();
                    deviceDefer.reject({data:responseData,status:402});
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.loadingDevice).to.be.false;
                });

                it('createDeviceObject , create site controller object', function () {
                    scope.resourceTypeDevice = 'Device';
                    scope.siteId = '1234';
                    scope.formDeviceInfo = {
                        DeviceEndpoint:'1.1.1.1',
                        DeviceName:'HCIG'
                    };
                    scope.createDeviceObject();
                    chai.expect(scope.deviceObj.resourceType).to.be.equal('Device');
                });
                it('editIndustrialGatewayClick , when user edit for a  device', function(){
                    var extension = [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entityname:V1",
                            "valueString": "Sparx"
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitystatus:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "create"
                            }
                        }
                    ];

                    var  owner = {
                        "reference": "organization/1"
                    };
                    scope.deviceObj = {
                        resourceType: 'Device',
                        owner:owner,
                        url:"test",
                        extension : extension
                    };

                    scope.editModeDevice = true;
                    scope.showSaveCancelBtn=true;
                    scope.editIndustrialGatewayClick();
                    chai.expect(scope.editModeDevice).to.be.false;
                    chai.expect(scope.showSaveCancelBtn).to.be.true;
                });


                it('cancelAddDeviceOnEdit , when user clicks on cancel during adding a  device', function(){
                    scope.addIndustrialGateway = false;
                    scope.showSaveCancelBtn =false;
                    scope.cancelAddDeviceOnEdit();
                    chai.expect(scope.addIndustrialGateway).to.be.false;
                    chai.expect(scope.showSaveCancelBtn).to.be.false;
                });

                it('cancelAddDevice , when user clicks on cancel before adding device ', function(){
                    scope.addIndustrialGateway=false;
                    scope.cancelAddDevice();
                    chai.expect(scope.addIndustrialGateway).to.be.true;
                });

                it('getListOfDeviceBySiteId , this method is called to retrive list of devices for the site ', function(done){
                    var responseData = {
                        "resourceType":"Bundle",
                        "title":"List of all organizations",
                        "id":null,
                        "entry":[{"title":null,
                            "id":null,
                            "content":{
                                "resourceType":"Device",
                                "extension":[
                                    {"url":"urn:hc.ge.com/pfh/platform/extension/entitystatus:V1","valueCoding":{"system":"urn:hc.ge.com/pfh/platform/policy:V1","code":"create"}},{"url":"urn:hc.ge.com/pfh/platform/extension/entityname:V1","valueString":"sdsd1232"}],"identifier":[{"_id":"590029bc-f2af-4456-8981-65278edef361","system":"urn:hc.ge.com/pfh/platform/devicetype"}],
                                "owner":{"reference":"organization/9b54d055-98fe-4223-9515-83556c37a96a"},
                                "url":"sdds1212"}}]
                    };
                    scope.getListOfDeviceBySiteId();
                    deviceDefer.resolve({data:responseData,status:200});
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.loadingDevice).to.be.false;
                });

                it('getListOfDeviceBySiteId , called with no data as response ', function(done){
                    var responseData = {
                        "resourceType":"Bundle",
                        "title":"List of all organizations",
                        "id":null,
                        "entry":[]
                    };
                    scope.getListOfDeviceBySiteId();
                    deviceDefer.resolve({data:responseData,status:200});
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.loadingDevice).to.be.true;
                });

                it('getListOfDeviceBySiteId , to test the deviceId value ', function(done){
                    scope.DeviceIdValue = '123';
                    var responseData = {
                        "resourceType":"Bundle",
                        "title":"List of all organizations",
                        "id":null,
                        "entry":[{"title":null,
                            "id":null,
                            "content":{
                                "resourceType":"Device",
                                "extension":[
                                    {"url":"urn:hc.ge.com/pfh/platform/extension/entitystatus:V1","valueCoding":{"system":"urn:hc.ge.com/pfh/platform/policy:V1","code":"create"}},{"url":"urn:hc.ge.com/pfh/platform/extension/entityname:V1","valueString":"sdsd1232"}],
                                "identifier":[{value:"testID"}],
                                "owner":{"reference":"organization/9b54d055-98fe-4223-9515-83556c37a96a"},
                                "url":"sdds1212"}}]
                    };
                    scope.getListOfDeviceBySiteId();
                    deviceDefer.resolve({data:responseData,status:200});
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.DeviceIdValue).to.be.equal('123');
                });


                it('addIndustrialGatewayClick , when user clicks on Add Button  ', function(){
                    scope.formDeviceInfo = {
                        DeviceOwner:"Owner",
                        DeviceEndpoint:'End point'
                    };
                    scope.addIndustrialGateway =false;
                    scope.addIndustrialGatewayClick();
                    chai.expect(scope.addIndustrialGateway).to.be.true;
                });
            });

            describe('When there is a XSS event', function(){
                it('and the user closes the alert box, it should test setting of the variable to hide alert', function(){
                    scope.closeAlert();
                    chai.expect(scope.closeAlertPressed).to.be.equal(1);
                });

                it('and there is a rootScope emit of the event, it should test the event is consumed', function(){
                    var object = {message: "There is an attempt to insert scrpit"};
                    scope.$emit("SHOW_FAILURE_MESSAGE_NO_TIMEOUT",object.message);
                    chai.expect(scope.xssMessage).to.be.equal(object.message);
                    chai.expect(scope.closeAlertPressed).to.be.equal(0);
                });
            });

            describe('When file is loaded ', function(){
                it('should test if site is selected in init method', function(){
                    rootScope.selectedSite = "";
                    scope.init();
                    chai.expect(rootScope.siteId).to.be.equal('12345678');
                });
                it('should test that user data is getting loaded', function(done){
                    getLoggedInUserDetailsDeferred.resolve(loggedInUserContextServiceResponse);
                    scope.$digest();
                    done();
                    chai.expect(scope.LoggedInUser).to.be.defined;
                });
                it('should test that user data is getting loaded and site details loaded successfully', function(done){
                    scope.part1 = true;
                    getLoggedInUserDetailsDeferred.resolve(loggedInUserContextServiceResponse);
                    getSiteAdminsDeferred.resolve(searchUserResult);
                    scope.$digest();
                    done();
                    chai.expect(scope.siteDetail.administrators).to.be.get(0);
                });
                it('should test that user data is getting loaded but site details loading failed', function(done){
                    scope.part1 = true;
                    getLoggedInUserDetailsDeferred.resolve(loggedInUserContextServiceResponse);
                    getSiteAdminsDeferred.reject(searchUserResult);
                    scope.$digest();
                    done();
                    chai.expect(scope.siteDetail.administrators).to.equal(0);
                });
                it('should test that user data loading failed', function(done){
                    getLoggedInUserDetailsDeferred.reject(loggedInUserContextServiceResponse);
                    scope.$digest();
                    done();
                    chai.expect(scope.LoggedInUser).to.be.undefined;
                });
            });

            describe('When country dropdown value is selected', function(){
                it('should test that method working in case country not selected', function(){
                    scope.getStatesForCountry();
                    chai.expect(scope.StateArray).to.be.empty;
                });
                it('should test that method working in case the selected country not found in list', function(){
                    rootScope.countryStatesData = undefined;
                    scope.getStatesForCountry("AB");
                    chai.expect(scope.StateArray).to.be.empty;
                });
                it('should test the states data for US country selected', function(){
                    scope.getStatesForCountry("US");
                    chai.expect(scope.StateArray).to.have.length.above(10);
                });
                it('should test the states data for not matching the selected country code', function(){
                    scope.getStatesForCountry({code:"AB",name:"United States of America"});
                    chai.expect(scope.StateArray.length).to.have.length.equal(0);
                });
                it('when selected country code is blank', function(){
                    scope.getStatesForCountry("");
                    chai.expect(scope.StateArray.length).to.have.length.equal(0);
                });
                it('should test the Empty states data for blank country', function(){
                    scope.getStatesForCountry("");
                    chai.expect(scope.StateArray).to.be.empty;
                });
            });

            describe('Search user for making admin and select admin', function(){
                it('Search user for admin success', function(done){
                    scope.searchUserForAdmin("a");
                    findUserDeferred.resolve(searchUserResult);
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.searchingUsersForAdmin).to.be.false;
                });
                it('Check searchUserForAdmin function, reject', function (done) {
                    scope.searchUserForAdmin("abc");
                    findUserDeferred.reject();
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.noResultsForAdmin).to.be.true;
                });

                it('select administrator', function(){
                    var user ={
                        "data": {
                            "resourceType": "Bundle",
                            "title": null,
                            "id": '12-45gf-435',
                            "entry": [
                                {
                                    "title": null,
                                    "id": "034e2e9b-60b0-4856-85a7-c43779a11746",
                                    "content": {
                                        "resourceType": "ResourcesUser",
                                        "name": {
                                            "use": "official",
                                            "family": [
                                                "Tari"
                                            ],
                                            "given": [
                                                "Tushar",
                                                "K"
                                            ]
                                        },
                                        "externalId": [
                                            {
                                                "system": "IDM",
                                                "value": "b9f2b0f9-03ab-4d94-bd33-f40b495fc4d5"
                                            },
                                            {
                                                "system": "UOM",
                                                "value": "034e2e9b-60b0-4856-85a7-c43779a11746"
                                            },
                                            {
                                                "_id": "tushar.tari@ge.com",
                                                "system": "urn:hc.ge.com/pfh/platform/useremail"
                                            }
                                        ],
                                        "role": [
                                            {
                                                "code": [
                                                    {
                                                        "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                        "code": "practitioner",
                                                        "display": "practitioner"
                                                    }
                                                ],
                                                "scopingOrganization": {
                                                    "reference": "organization/5"
                                                },
                                                "status": "active"
                                            },
                                            {
                                                "code": [
                                                    {
                                                        "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                        "code": "practitioner",
                                                        "display": "practitioner"
                                                    }
                                                ],
                                                "scopingOrganization": {
                                                    "reference": "organization/6"
                                                },
                                                "status": "active"
                                            }
                                        ],
                                        "managingOrganization": {
                                            "organization": {
                                                "reference": "organization/74553d9a-7d1b-4f93-929c-72b6318a6178"
                                            },
                                            "jobTitle": {
                                                "coding": [
                                                    {
                                                        "system": "http://hl7.org/fhir/v3/AdministrativeUser",
                                                        "version": "1",
                                                        "code": "Manager",
                                                        "primary": true
                                                    }
                                                ],
                                                "text": "Manager"
                                            },
                                            "employeeNumber": "ID_123445"
                                        },
                                        "telecom": [
                                            {
                                                "system": "phone",
                                                "value": "(+1) 734-677-7777"
                                            },
                                            {
                                                "system": "email",
                                                "value": "tushar.tari@ge.com"
                                            }
                                        ],
                                        "principalName": "tushar.tari@ge.com",
                                        "display": "Tushar K"
                                    }
                                }
                            ]
                        },
                        "status": 200,
                        "config": {},
                        "statusText": "OK"
                    };
                    scope.loggedInUser = loggedInUserContextServiceResponse;
                    scope.selectAdministrator(user.data.entry[0]);
                    chai.expect(scope.siteDetail.administrators.length).to.be.gt(0);
                });
                it('checks if select administrator works with no user data', function(){
                    var user ={
                        "data": {
                            "resourceType": "Bundle",
                            "title": null,
                            "id": '12-45gf-435',
                            "entry": [
                                {
                                    "title": null,
                                    "id": "034e2e9b-60b0-4856-85a7-c43779a11746",
                                    "content": {}
                                }
                            ]
                        },
                        "status": 200,
                        "config": {},
                        "statusText": "OK"
                    };
                    scope.siteDetail.administrators = [];
                    scope.loggedInUser = loggedInUserContextServiceResponse;
                    scope.selectAdministrator(user.data.entry[0]);
                    chai.expect(scope.siteDetail.administrators.length).to.be.gt(0);
                });
                it('Checks nonLogged/OtherAdmin display values', function(done){
                    scope.LoggedInUser=loggedInUserContextServiceResponse;
                    chai.expect(scope.getUserForDisplay(searchUserResult.data.entry[0].content)).to.be.equal('Tushar K (orgmanagement.you)');
                    done();
                });
                it('Checks nonLogged/OtherAdmin display values if no email is present', function(done){
                    scope.LoggedInUser={principalName: "tushar.tari@ge.com"};
                    var youAdmin={name: "Tushar K", "display":"Tushar K", principalName: "tushar.tari@ge.com", id: "034e2e9b-60b0-4856-85a7-c43779a11746"};
                    chai.expect(scope.getUserForDisplay(youAdmin)).to.be.equal('Tushar K (orgmanagement.you)');
                    done();
                });
                it('Checks nonLogged/OtherAdmin display values if no email is present', function(done){
                    scope.LoggedInUser={principalName: "tushar.tari@ge.com"};
                    var youAdmin={name: "Tushar K", "display":"Tushar K", principalName: "tushar.tari@ge.com", id: "034e2e9b-60b0-4856-85a7-c43779a11746"};
                    youAdmin.principalName=undefined;
                    chai.expect(scope.getUserForDisplay(youAdmin)).to.be.equal('Tushar K');
                    done();
                });
                it('Checks removeAdministrator button functionality', function(done){
                    var youAdmin={name: "Tushar K", "display":"Tushar K", principalName: "tushar.tari@ge.com", id: "034e2e9b-60b0-4856-85a7-c43779a11746"};
                    scope.removeAdministrator(youAdmin);
                    chai.expect(scope.siteDetail.administrators.length).to.be.equal(0);
                    done();
                });
                it('Edit site admins', function(){
                    scope.editSiteAdminDiv = true;
                    scope.editAdmin();
                    chai.expect(scope.editSiteAdminDiv).to.be.false;
                });
                it('Cancel site admin editing', function(){
                    scope.administratorsTemp = [{"display":"Tushar Tari"}];
                    scope.cancelSiteAdminDiv();
                    chai.expect(scope.siteDetail.administrators).to.be.length(1);
                });
            });

            describe('Update added or removed admin data', function(){
                it('update site admin, admin to add', function(){
                    scope.adminBeforeId = ['1'];
                    scope.siteDetail.administrators = [{'id':'1'}, {'id':'2'}];
                    scope.updateSiteAdmin();
                    updateSiteAdminsDeferred.resolve({"data":"response"});
                    scope.$digest();
                    chai.expect(_siteMgmtService.getSiteAdmins).called;
                });
                it('update site admin, admin to remove successful', function(){
                    scope.adminBeforeId = ['1', '2'];
                    scope.siteDetail.administrators = [{'id':'1'}];
                    scope.updateSiteAdmin();
                    updateSiteAdminsDeferred.resolve({"data":"response"});
                    scope.$digest();
                    chai.expect(_siteMgmtService.getSiteAdmins).called;
                });
                it('update site admin, admin to add failed', function(){
                    scope.adminBeforeId = ['1'];
                    scope.siteDetail.administrators = [{'id':'1'}, {'id':'2'}];
                    scope.updateSiteAdmin();
                    updateSiteAdminsDeferred.reject({"data":"response"});
                    scope.$digest();
                    chai.expect(_siteMgmtService.getSiteAdmins).called;
                });
                it('when no admins is selected', function(){
                    scope.siteDetail.administrators = [];
                    scope.updateSiteAdmin();
                    scope.$digest();
                    chai.expect(_siteMgmtService.updateSiteAdmins).not.called;
                });
            });


            describe('Checks scope.setNickNameDescriptionAndPhoneNumber method which is called internally on clicking cancel of edit site details', function(){
                it('checks site nick name for defined values', function(){
                    scope.siteDetailsObject=JSON.parse(JSON.stringify({"resourceType":"Organization","extension":[{"url":"urn:hc.ge.com/pfh/platform/extension/entitynickname:V1","valueString":"AutomationTestSite"},{"url":"urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1","valueCoding":{"system":"urn:hc.ge.com/pfh/platform/policy:V1","code":"_case_reshare_outside_new_site","display":"Allow Clinician/Staff re-share outside this network"}}],"text":{"status":"generated","div":"<div>SampleText</div>"},"name":"AutomationSite11_Dec_03-08-30_PM(IST)","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"site"}]},"telecom":[{"system":"phone","value":"89765844017","use":"mobile"}],"address":[{"line":["Burlington","Hambourgh"],"city":"Boston","state":"AK","zip":"32432","country":"US"}],"partOf":{"reference":"organization/02d5ec60-1f05-4aa1-a60f-520d64bee539"}}));
                    scope.setNickNameDescriptionAndPhoneNumber();
                    chai.expect(scope.nickName).to.be.equal('AutomationTestSite');
                });
                it('checks site nick name for undefined values', function(){
                    scope.siteDetailsObject=JSON.parse(JSON.stringify({"resourceType":"Organization","extension":[{"url":"urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1","valueCoding":{"system":"urn:hc.ge.com/pfh/platform/policy:V1","code":"_case_reshare_outside_new_site","display":"Allow Clinician/Staff re-share outside this network"}}],"text":{"status":"generated","div":"<div>SampleText</div>"},"name":"AutomationSite11_Dec_03-08-30_PM(IST)","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"site"}]},"telecom":[{"system":"phone","value":"89765844017","use":"mobile"}],"address":[{"line":["Burlington","Hambourgh"],"city":"Boston","state":"AK","zip":"32432","country":"US"}],"partOf":{"reference":"organization/02d5ec60-1f05-4aa1-a60f-520d64bee539"}}));
                    scope.setNickNameDescriptionAndPhoneNumber();
                    chai.expect(scope.nickName).to.be.falsy;
                });

                it('checks decodeHtml method for HTML character entities', function(){
                    chai.expect(scope.decodeHtml("&#60")).to.be.equal('<');
                });
            });

            describe('Select administrator for site and displaying the admin name', function(){
                it('do not add existing admin', function(){
                    var selectedAdmin = otherAdmin;
                    scope.siteDetail.administrators = [selectedAdmin];
                    scope.selectAdministrator(selectedAdmin);
                    chai.expect(scope.siteDetail.administrators).to.have.length(1);
                });
                it('return blank data if there is no content in user object', function(){
                    chai.expect(scope.getUserNameForDisplay({})).to.equal("");
                });
                it('return first name only as there is no last name present', function(){
                    var userObj = {"name":{"given":["Patrice", null]}};
                    chai.expect(scope.getUserNameForDisplay(userObj)).to.equal("Patrice ");
                });
            });

            describe('Custom object for Application services', function() {
                it('It should test calling the custom app method ', function () {
                    scope.entryList = [];
                    var entryObject = {
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "dicom",
                            "capability": [
                                "query-retrieve",
                                "send"
                            ],
                            "name": "test",
                            "endpoint": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                            "gateway": {
                                "reference": "device/c8fd7700-4d55-4e9f-a17d-49819f498592",
                                "display": "hello device"
                            },
                            "owner": {
                                "reference": "site/1d4b7835-639d-4414-b3ef-b159de3f1de9",
                                "display": "Namrata Org Site"
                            },
                            networkAddress: {
                                ip: "1.2.3.4",
                                entityName: "1",
                                port: 1
                            }
                        }
                    };
                    scope.entryList.push(entryObject);
                    scope.customAppServiceObject();
                    chai.expect(scope._query).to.be.true;
                    chai.expect(scope._send).to.be.true;

                });


                it('It should test calling the custom app method when send ', function () {
                    scope.entryList = [];
                    var entryObject = {
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "dicom",
                            "capability": [],
                            "name": "test1",
                            "endpoint": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                            "gateway": {
                                "reference": "device/c8fd7700-4d55-4e9f-a17d-49819f498592",
                                "display": "hello device"
                            },
                            "owner": {
                                "reference": "site/1d4b7835-639d-4414-b3ef-b159de3f1de9",
                                "display": "Namrata Org Site"
                            },
                            networkAddress: {
                                ip: "1.2.3.4",
                                entityName: "1",
                                port: 1
                            }
                        }
                    };
                    scope.entryList.push(entryObject);
                    scope.customAppServiceObject();
                    chai.expect(scope._send).to.be.false;
                    chai.expect(scope._query).to.be.false;
                });
            });

            describe('Edit app Service',function() {
                it('Edit app service , when edit mode is true', function () {
                    var appService = {
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "dicom",
                            "capability": [
                                "query-retrieve",
                                "send"
                            ],
                            "name": "test",
                            "endpoint": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                            "gateway": {
                                "reference": "device/c8fd7700-4d55-4e9f-a17d-49819f498592",
                                "display": "hello device"
                            },
                            "owner": {
                                "reference": "site/1d4b7835-639d-4414-b3ef-b159de3f1de9",
                                "display": "Namrata Org Site"
                            },
                            networkAddress: {
                                ip: "1.2.3.4",
                                entityName: "1",
                                port: 1
                            },
                            tempObj: {
                                editMode: false,
                                header: "New Application Service",
                                showMessage: false,
                                appName: ''
                            },
                            headerObject: {
                                appName: '',
                                headerIPAddress: '',
                                headerType: '',
                                headerTitle: ''
                            },

                        }
                    };
                    scope.editAppService(appService);
                    chai.expect(appService.content.tempObj.editMode).to.be.true;
                });

                it('Edit app service , when its already editable', function () {
                    var appService = {
                        title: '',
                        id: '1234',
                        content: {
                            gateway: {
                                displayName: 'test'
                            },
                            name: '',
                            networkAddress: {
                                entityName: 'ae',
                                ip: '1.1.1.1',
                                port: '45'
                            },
                            owner: 'test',
                            tempObj: {
                                editMode: true,
                                header: "New Application Service",
                                showMessage: false,
                                appName: ''
                            },
                            headerObject: {
                                appName: '',
                                headerIPAddress: '',
                                headerType: '',
                                headerTitle: ''
                            },
                            type: 'dicom',
                            capabilityObject: {query: true, send: true},
                            collapseIn: true
                        }
                    };
                    scope.editAppService(appService);
                    chai.expect(scope.disableAll).to.be.false;
                });
            });

            describe('change Type drop down HL7/DICOM',function() {
                it('change type drop when when it is HL7', function () {
                    var appService = {
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "hl7",
                            "capability": [
                                "query-retrieve",
                                "send"
                            ],
                            "name": "test",
                            "endpoint": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                            "gateway": {
                                "reference": "device/c8fd7700-4d55-4e9f-a17d-49819f498592",
                                "display": "hello device"
                            },
                            "owner": {
                                "reference": "site/1d4b7835-639d-4414-b3ef-b159de3f1de9",
                                "display": "Namrata Org Site"
                            },
                            networkAddress: {
                                ip: "1.2.3.4",
                                entityName: "1",
                                port: 1
                            },
                            tempObj: {
                                editMode: false,
                                header: "New Application Service",
                                showMessage: false,
                                appName: ''
                            },
                            headerObject: {
                                appName: '',
                                headerIPAddress: '',
                                headerType: '',
                                headerTitle: ''
                            }
                        }
                    };
                    scope.changeTypeDropDown(appService);
                    chai.expect(scope.readOnlyEntityTextBox).to.be.true;
                    chai.expect(scope.required).to.be.false;
                });

                it('change type drop when when it is DICOM', function () {
                    var appService = {
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "dicom",
                            "capability": [
                                "query-retrieve",
                                "send"
                            ],
                            "name": "test1",
                            "endpoint": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                            "gateway": {
                                "reference": "device/c8fd7700-4d55-4e9f-a17d-49819f498592",
                                "display": "hello device"
                            },
                            "owner": {
                                "reference": "site/1d4b7835-639d-4414-b3ef-b159de3f1de9",
                                "display": "Namrata Org Site"
                            },
                            networkAddress: {
                                ip: "1.2.3.4",
                                entityName: "1",
                                port: 1
                            },
                            tempObj: {
                                editMode: false,
                                header: "New Application Service",
                                showMessage: false,
                                appName: ''
                            },
                            headerObject: {
                                appName: '',
                                headerIPAddress: '',
                                headerType: '',
                                headerTitle: ''
                            }
                        }
                    };
                    scope.changeTypeDropDown(appService);
                    chai.expect(scope.readOnlyEntityTextBox).to.be.false;
                    chai.expect(scope.required).to.be.true;
                });

            });

            describe('Cancel while editing the app service',function() {
                it('Cancel from the edit mode , when id is null should remove the app service from list', function () {
                    var appService = {
                        title: '',
                        id: '',
                        content: {
                            gateway: {
                                displayName: ''
                            },
                            name: '',
                            networkAddress: {
                                entityName: '',
                                ip: '',
                                port: ''
                            },
                            owner: '',
                            tempObj: {
                                editMode: false,
                                header: "New Application Service",
                                showMessage: false,
                                appName: ''
                            },
                            headerObject: {
                                appName: '',
                                headerIPAddress: '',
                                headerType: '',
                                headerTitle: ''
                            },
                            type: 'dicom',
                            capabilityObject: {query: true, send: true},
                            collapseIn: true
                        }
                    };
                    scope.entryList = [];
                    scope.entryList.push(appService);
                    scope.cancelEdit(appService);
                    chai.expect(scope.showDeviceListEditMode).to.be.false;
                    chai.expect(scope.entryList.length).to.equal(0);
                });

                /*it('Test list when id is not null', function () {
                 var appService1 = [
                 {
                 "title": null,
                 "id": "3e159c4e-f2bd-4441-aff6-0bdcd1783e38",
                 "content": {
                 "resourceType": "ResourcesApplicationService",
                 "type": "hl7",
                 "capability": [
                 "send",
                 "query-retrieve"
                 ],
                 "name": "Application Service 1",
                 "endpoint": "3e159c4e-f2bd-4441-aff6-0bdcd1783e38",
                 "gateway": {
                 "reference": "device/c1251679-1f4b-4a6e-9f5a-8c8366f8520f",
                 "display": "test device"
                 },
                 "owner": {
                 "reference": "site/c6265710-b1cc-4e9c-ae28-5e53097ec206",
                 "display": "ge hc"
                 },
                 tempObj: {
                 editMode: true,
                 header: "New Application Service",
                 showMessage: false,
                 appName: ''
                 },
                 "networkAddress": {
                 "ip": "123.44.55.66",
                 "entityName": "test1",
                 "port": 89
                 }
                 }
                 },
                 {
                 "title": null,
                 "id": "932ebfa9-f20f-4399-aa54-85f56e6c630f",
                 "content": {
                 "resourceType": "ResourcesApplicationService",
                 "type": "dicom",
                 "capability": [
                 "send",
                 "query-retrieve"
                 ],
                 "name": "Application Service 2",
                 "endpoint": "932ebfa9-f20f-4399-aa54-85f56e6c630f",
                 "gateway": {
                 "reference": "device/c1251679-1f4b-4a6e-9f5a-8c8366f8520f",
                 "display": "test device"
                 },
                 "owner": {
                 "reference": "site/c6265710-b1cc-4e9c-ae28-5e53097ec206",
                 "display": "ge hc"
                 },
                 tempObj: {
                 editMode: false,
                 header: "New Application Service",
                 showMessage: false,
                 appName: ''
                 },
                 "networkAddress": {
                 "ip": "122.34.55.65",
                 "entityName": "Test Service",
                 "port": 99
                 }
                 }
                 }
                 ];

                 var appService = {
                 "title": null,
                 "id": "3e159c4e-f2bd-4441-aff6-0bdcd1783e38",
                 "content": {
                 "resourceType": "ResourcesApplicationService",
                 "type": "hl7",
                 "capability": [
                 "send",
                 "query-retrieve"
                 ],
                 "name": "Application Service 1",
                 "endpoint": "3e159c4e-f2bd-4441-aff6-0bdcd1783e38",
                 "gateway": {
                 "reference": "device/c1251679-1f4b-4a6e-9f5a-8c8366f8520f",
                 "display": "test device"
                 },
                 "owner": {
                 "reference": "site/c6265710-b1cc-4e9c-ae28-5e53097ec206",
                 "display": "ge hc"
                 },
                 tempObj: {
                 editMode: true,
                 header: "New Application Service",
                 showMessage: false,
                 appName: ''
                 },
                 "networkAddress": {
                 "ip": "123.44.55.66",
                 "entityName": "test1",
                 "port": 89
                 }
                 }
                 };
                 scope.entryList.push(appService1);
                 scope.cancelEdit(appService);
                 chai.expect(scope.showDeviceListEditMode).to.be.true;
                 });*/
            });

            describe('When changing the capabilities oo Application Service',function() {
                it('should show the error message when no capability is selected', function () {
                    var index = 0;
                    var appService = {
                        title: '',
                        id: '',
                        content: {
                            gateway: {
                                displayName: ''
                            },
                            name: '',
                            networkAddress: {
                                entityName: '',
                                ip: '',
                                port: ''
                            },
                            owner: '',
                            tempObj: {
                                editMode: false,
                                header: "New Application Service",
                                showMessage: false,
                                appName: ''
                            },
                            headerObject: {
                                appName: '',
                                headerIPAddress: '',
                                headerType: '',
                                headerTitle: ''
                            },
                            type: 'dicom',
                            capabilityObject: {query: false, send: false},
                            collapseIn: true
                        }
                    };

                    scope.change(appService);
                    chai.expect(scope.showCapabilityError).to.be.true;

                });


                it('should show the error message when capability is undefined', function () {
                    var index = 0;
                    var appService = {
                        title: '',
                        id: '',
                        content: {
                            gateway: {
                                displayName: ''
                            },
                            name: '',
                            networkAddress: {
                                entityName: '',
                                ip: '',
                                port: ''
                            },
                            owner: '',
                            tempObj: {
                                editMode: false,
                                header: "New Application Service",
                                showMessage: false,
                                appName: ''
                            },
                            headerObject: {
                                appName: '',
                                headerIPAddress: '',
                                headerType: '',
                                headerTitle: ''
                            },
                            type: 'dicom',
                            capabilityObject: {query: undefined, send: false},
                            collapseIn: true
                        }
                    };
                    scope.change(appService);
                    chai.expect(scope.showCapabilityError).to.be.false;
                });


                it('should hide the error message when capability is selected', function () {
                    var index = 0;
                    var appService = {
                        title: '',
                        id: '',
                        content: {
                            gateway: {
                                displayName: ''
                            },
                            name: '',
                            networkAddress: {
                                entityName: '',
                                ip: '',
                                port: ''
                            },
                            owner: '',
                            tempObj: {
                                editMode: false,
                                header: "New Application Service",
                                showMessage: false,
                                appName: ''
                            },
                            headerObject: {
                                appName: '',
                                headerIPAddress: '',
                                headerType: '',
                                headerTitle: ''
                            },
                            type: 'dicom',
                            capabilityObject: {query: true, send: false},
                            collapseIn: true
                        }
                    };

                    scope.change(appService);
                    chai.expect(scope.showCapabilityError).to.be.false;

                });
            });

            describe('Get and Remove the Application Service',function() {

                it('Delete app service', function(){
                    var index=0;
                    var appService = {
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "dicom",
                            "capability": [
                                "query-retrieve",
                                "send"
                            ],
                            "name": "test1",
                            "endpoint": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                            "gateway": {
                                "reference": "device/c8fd7700-4d55-4e9f-a17d-49819f498592",
                                "display": "hello device"
                            },
                            "owner": {
                                "reference": "site/1d4b7835-639d-4414-b3ef-b159de3f1de9",
                                "display": "Namrata Org Site"
                            },
                            networkAddress: {
                                ip: "1.2.3.4",
                                entityName: "1",
                                port: 1
                            }
                        }
                    };
                    scope.deleteAppService (appService);
                    chai.expect(scope.updateAppServiceObj.calledOnce);
                });


                it('should test that the deletion from db was successful', function(done){
                    var removeObj = {
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "dicom",
                            "capability": [
                                "query-retrieve",
                                "send"
                            ],
                            "name": "test1",
                            "endpoint": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                            "gateway": {
                                "reference": "device/c8fd7700-4d55-4e9f-a17d-49819f498592",
                                "display": "hello device"
                            },
                            "owner": {
                                "reference": "site/1d4b7835-639d-4414-b3ef-b159de3f1de9",
                                "display": "Namrata Org Site"
                            },
                            networkAddress: {
                                ip: "1.2.3.4",
                                entityName: "1",
                                port: 1
                            }
                        }
                    };
                    var responseData = {data:"Sucess",status:200};
                    scope.removeAppService(removeObj);
                    deferredAppServices.resolve(responseData);
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.updateAppServiceObj.calledOnce);
                });


                it('should test that the deletion pf app service is unsuccessfull', function (done) {
                    var removeObj = {
                        title: '',
                        id: '546444',
                        content: {
                            gateway: {
                                displayName: ''
                            },
                            name: '',
                            networkAddress: {
                                entityName: '',
                                ip: '',
                                port: ''
                            },
                            owner: '',
                            tempObj: {
                                editMode: false,
                                header: "New Application Service",
                                showMessage: false,
                                appName: ''
                            },
                            headerObject: {
                                appName: '',
                                headerIPAddress: '',
                                headerType: '',
                                headerTitle: ''
                            },
                            type: 'dicom',
                            capabilityObject: {query: true, send: undefined},
                            collapseIn: true
                        }
                    };

                    var responseData = {data: "Error", status: 405};
                    scope.removeAppService(removeObj);
                    deferredAppServices.reject(responseData);
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.showDeviceListEditMode).to.be.false;
                });

                it('should test the application is deleted from list', function () {
                    var removeObj = {
                        title: '',
                        id: '546444',
                        content: {
                            gateway: {
                                displayName: ''
                            },
                            name: '',
                            networkAddress: {
                                entityName: '',
                                ip: '',
                                port: ''
                            },
                            owner: '',
                            tempObj: {
                                editMode: false,
                                header: "New Application Service",
                                showMessage: false,
                                appName: ''
                            },
                            headerObject: {
                                appName: '',
                                headerIPAddress: '',
                                headerType: '',
                                headerTitle: ''
                            },
                            type: 'dicom',
                            capabilityObject: {query: true, send: undefined},
                            collapseIn: true
                        }
                    };
                    scope.entryList=[];
                    scope.entryList.push(removeObj);
                    scope.updateAppServiceObj(removeObj);
                    chai.expect(scope.entryList.length).to.be.equal(0);
                });


                it('should remove the app service if id is null', function (done) {
                    var removeObj = {
                        title: '',
                        id: '',
                        content: {
                            gateway: {
                                displayName: ''
                            },
                            name: '',
                            networkAddress: {
                                entityName: '',
                                ip: '',
                                port: ''
                            },
                            owner: '',
                            tempObj: {
                                editMode: false,
                                header: "New Application Service",
                                showMessage: false,
                                appName: ''
                            },
                            headerObject: {
                                appName: '',
                                headerIPAddress: '',
                                headerType: '',
                                headerTitle: ''
                            },
                            type: 'dicom',
                            capabilityObject: {query: true, send: undefined},
                            collapseIn: true
                        }
                    };
                    scope.removeAppService(removeObj);
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.updateAppServiceObj.calledOnce);
                });


                it('$scope.addDeviceEndPoints which hides and shows the main add pannel', function () {
                    scope.addDeviceEndPoints();
                    chai.expect(scope.showDeviceListEditMode).to.be.true;
                });


                it('$scope.getDeviceEndPoints', function (done) {
                    var responseData = {
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": null,
                        "entry": [
                            {
                                "title": null,
                                "id": "123",
                                "content": {
                                    "resourceType": "ResourcesApplicationService",
                                    "type": "DICOM",
                                    "name": "test",
                                    "endpoint": "",
                                    "gateway": {
                                        "reference": "device/1234"
                                    },
                                    "owner": {
                                        "reference": "site/12345"
                                    },
                                    "networkAddress": {
                                        "ip": "111.11.11.1111",
                                        "entityName": "AE_PACS",
                                        "port": 8080
                                    },
                                    capability: ['query', 'send-retrieve']
                                }
                            }
                        ]
                    };

                    scope.getDeviceEndPoints();
                    var responseData = {data: responseData, status: 200};
                    deferredAppServices.resolve(responseData);
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.entryList).length.to.be(1);
                });


            });

            describe('Save of Application Service',function(){
                it('save the application service', function(done){
                    var responseData ={
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": null,
                        "entry": [{
                            "title": null,
                            "id": "123",
                            "content": {
                                "resourceType": "ResourcesApplicationService",
                                "type": "DICOM",
                                "name": "test",
                                "endpoint": "",
                                "gateway": {
                                    "reference": "device/1234"
                                },
                                "owner": {
                                    "reference": "site/12345"
                                },
                                "networkAddress": {
                                    "ip": "111.11.11.1111",
                                    "entityName": "AE_PACS",
                                    "port": 8080
                                },
                                capability :['query','send-retrieve']
                            }
                        }]
                    };

                    scope.saveValidApplication();
                    var responseData = {data:responseData,status:200};
                    deferredAppServices.resolve(responseData);
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.getDeviceEndPoint()).to.be.calledOnce;
                });


                it('save of application service throws an error or is rejected', function(done){
                    var responseData ={
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": null,
                        "entry": [{
                            "title": null,
                            "id": "123",
                            "content": {
                                "resourceType": "ResourcesApplicationService",
                                "type": "DICOM",
                                "name": "test",
                                "endpoint": "",
                                "gateway": {
                                    "reference": "device/1234"
                                },
                                "owner": {
                                    "reference": "site/12345"
                                },
                                "networkAddress": {
                                    "ip": "111.11.11.1111",
                                    "entityName": "AE_PACS",
                                    "port": 8080
                                },
                                capability :['query','send-retrieve']
                            }
                        }]
                    };

                    scope.saveValidApplication ();
                    var responseData = {data:"Error",status:405};
                    deferredAppServices.reject(responseData);
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.disableDropdown).to.be.false;

                });


                it('Method to check duplicate IP+Port combination , so that it shows error message if duplicate', function(){
                    var appService ={
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": '12345',
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "DICOM",
                            "name": "test",
                            "endpoint": "",
                            "gateway": {
                                "reference": "device/1234"
                            },
                            "owner": {
                                "reference": "site/12345"
                            },
                            "networkAddress": {
                                "ip": "1.1.1.1",
                                "entityName": "AE_PACS",
                                "port": 8080
                            },
                            tempObj:
                            {
                                editMode:true,
                                header:"New Application Service",
                                showMessage :false,
                                appName:''
                            } ,
                            headerObject :{
                                appName:'',
                                headerIPAddress:'',
                                headerType:'',
                                headerTitle:''
                            },
                            capability :['query','send-retrieve']
                        }

                    };

                    scope.appServiceListCopy =[];

                    var appServiceCopy ={
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": '',
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "DICOM",
                            "name": "test",
                            "endpoint": "",
                            "gateway": {
                                "reference": "device/1234"
                            },
                            "owner": {
                                "reference": "site/12345"
                            },
                            "networkAddress": {
                                "ip": "1.1.1.1",
                                "entityName": "AE_PACS",
                                "port": 8080
                            },
                            capability :['query','send-retrieve']
                        }
                    };
                    scope.appServiceListCopy.push(appServiceCopy);
                    scope.checkIPPortDuplication(appService);
                    chai.expect(appService.content.tempObj.editMode).to.be.true;
                    chai.expect(appService.content.showMessage).to.be.true;
                });


                it('When there is no port and ip duplication should not show error emssage', function(){
                    var appService ={
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": '12345',
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "DICOM",
                            "name": "test",
                            "endpoint": "",
                            "gateway": {
                                "reference": "device/1234"
                            },
                            "owner": {
                                "reference": "site/12345"
                            },
                            "networkAddress": {
                                "ip": "1.1.1.2",
                                "entityName": "AE_PACS",
                                "port": 8080
                            },
                            tempObj:
                            {
                                editMode:true,
                                header:"New Application Service",
                                showMessage :false,
                                appName:''
                            } ,
                            headerObject :{
                                appName:'',
                                headerIPAddress:'',
                                headerType:'',
                                headerTitle:''
                            },
                            capability :['query','send-retrieve']
                        }

                    };
                    scope.appServiceListCopy =[];
                    var appServiceCopy ={
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": '',
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "DICOM",
                            "name": "test",
                            "endpoint": "",
                            "gateway": {
                                "reference": "device/1234"
                            },
                            "owner": {
                                "reference": "site/12345"
                            },
                            "networkAddress": {
                                "ip": "1.1.1.1",
                                "entityName": "AE_PACS",
                                "port": 8080
                            },

                            capability :['query','send-retrieve']
                        }
                    };
                    scope.appServiceListCopy.push(appServiceCopy);
                    scope.checkIPPortDuplication(appService);
                    chai.expect(appService.content.showMessage).to.be.false;
                });


                it('Save app Service', function(){
                    var appService = {
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": "",
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "dicom",
                            "capability": [
                                "query-retrieve",
                                "send"
                            ],
                            "name": "test1",
                            "endpoint": "ce95397e-59b5-4fac-ad82-f0f910dea852",
                            "gateway": {
                                "reference": "device/c8fd7700-4d55-4e9f-a17d-49819f498592",
                                "display": "hello device"
                            },
                            "owner": {
                                "reference": "site/1d4b7835-639d-4414-b3ef-b159de3f1de9",
                                "display": "Namrata Org Site"
                            },
                            networkAddress: {
                                ip: "1.2.3.4",
                                entityName: "1",
                                port: 1
                            },
                            tempObj: {
                                editMode: true,
                                header: "New Application Service",
                                showMessage: false,
                                appName: ''
                            },
                            capabilityObject : {query: true, send: true}
                        }
                    };
                    scope.appDataForm.appForm = {$valid:true};
                    scope.showCapabilityError=false;
                    scope.saveAppService(appService,1);
                    chai.expect(scope.saveValidApplication.calledOnce);
                });



                it('When app service cannot be saved , if form is invalid', function(){
                    var appService ={
                        "resourceType": "Bundle",
                        "title": "List of all Application Servcies",
                        "id": '12345',
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "DICOM",
                            "name": "test",
                            "endpoint": "",
                            "gateway": {
                                "reference": "device/1234"
                            },
                            "owner": {
                                "reference": "site/12345"
                            },
                            "networkAddress": {
                                "ip": "1.1.1.2",
                                "entityName": "AE_PACS",
                                "port": 8080
                            },
                            tempObj: {
                                editMode: true,
                                header: "New Application Service",
                                showMessage: false,
                                appName: ''
                            },
                            headerObject: {
                                appName: '',
                                headerIPAddress: '',
                                headerType: '',
                                headerTitle: ''
                            },
                            capability: ['query', 'send-retrieve'],
                            capabilityObject : {query: true, send: true}
                        }
                    };
                    scope.appDataForm.appForm = {$valid:false};
                    scope.showCapabilityError=true;
                    scope.saveAppService(appService,1);
                    chai.expect(scope.appDataForm.appForm.$submitted).to.be.true;
                });
            });

        });
    });
