define([ 'angular', 'angular-mocks', 'viewerModule/services/configManagementService'], function() {
    'use strict';

    describe('Test configManagementService', function() {
        var configManagementService;
        var httpBackend;

        var successCB;
        var errorCB;

        var endpointMock = {
            getEndpoint : function() {
                return "configManagementURL";
            }
        };

        var viewerUrlsMock = {
            servicesName : {
                configManagement : 'configManagement'
            }
        };

        var mouseModes = [1, 2, 3, 4, 5];

        var xjtwebMock = {
            XJTWEB : {
                MouseModeStore: {
                    DEFAULT_MOUSE_MODES: mouseModes
                }
            }
        };

        var caseExchangeDataServiceMock = {
            getCurrentUserID: function() {
                return "defaultUser";
            }
        };

        beforeEach(module('cloudav.viewerApp.services'));

        beforeEach(module(function($provide) {
            $provide.constant('$xjtweb', xjtwebMock);
            $provide.constant('$Endpoint', endpointMock);
            $provide.constant('viewerUrls', viewerUrlsMock);
            $provide.constant('CaseExchangeDataService', caseExchangeDataServiceMock);
        }));

        beforeEach(inject(function(_configManagementService_, $httpBackend) {
            configManagementService = _configManagementService_;
            httpBackend = $httpBackend;
        }));

        beforeEach(function() {
            successCB = sinon.spy();
            errorCB = sinon.spy();
        });

        afterEach(function() {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        var mouseModeSaveURL  = "configManagementURL/oauth/v1/application/app1/configitem/mouseModes_defaultUser";
        var mouseModeGetURL   = "configManagementURL/oauth/v1/application/app1/configitem/mouseModes_defaultUser/latest";
        var annotStateSaveURL = "configManagementURL/oauth/v1/application/app1/configitem/annotationState_defaultUser";
        var annotStateGetURL  = "configManagementURL/oauth/v1/application/app1/configitem/annotationState_defaultUser/latest";

        var annotState = "full";
        var annotStateObject = {
            annotState: annotState
        };

        var mouseModesObject = {
            mouseModes2D : mouseModes,
            mouseModes3D : mouseModes
        };

        it('configManagementService is defined', function() {
            assert.isDefined(configManagementService, 'configManagementService is not defined');
        });

        it('saveAnnotationStateForCurrentUser successfully sends request and calls successCB', function() {
            configManagementService.saveAnnotationStateForCurrentUser(annotState, successCB, errorCB);

            httpBackend.expectPUT(annotStateSaveURL, annotStateObject).respond(200);
            httpBackend.flush();

            assert.isTrue(successCB.calledOnce);
            assert.isTrue(errorCB.notCalled);
        });

        it('saveAnnotationStateForCurrentUser calls errorCB on failure', function() {
            configManagementService.saveAnnotationStateForCurrentUser(annotState, successCB, errorCB);

            httpBackend.expectPUT(annotStateSaveURL, annotStateObject).respond(404);
            httpBackend.flush();

            assert.isTrue(successCB.notCalled);
            assert.isTrue(errorCB.calledOnce);
        });

        it('saveMouseModesForCurrentUser successful sends request and calls successCB', function() {
            configManagementService.saveMouseModesForCurrentUser(mouseModes, mouseModes, successCB, errorCB);

            httpBackend.expectPUT(mouseModeSaveURL, mouseModesObject).respond(200);
            httpBackend.flush();

            assert.isTrue(successCB.calledOnce);
            assert.isTrue(errorCB.notCalled);
        });

        it('saveMouseModesForCurrentUser calls errorCB on failure', function() {
            configManagementService.saveMouseModesForCurrentUser(mouseModes, mouseModes, successCB, errorCB);

            httpBackend.expectPUT(mouseModeSaveURL, mouseModesObject).respond(404);
            httpBackend.flush();

            assert.isTrue(successCB.notCalled);
            assert.isTrue(errorCB.calledOnce);
        });

        it ('getMouseModesForCurrentUser GET is successful', function() {
            configManagementService.getMouseModesForCurrentUser(successCB, errorCB);

            httpBackend.expectGET(mouseModeGetURL).respond(200, mouseModesObject);
            httpBackend.flush();

            assert.isTrue(successCB.calledOnce);
            assert.deepEqual(successCB.args[0][0], mouseModesObject);

            assert.isTrue(errorCB.notCalled);
        });

        it ('getMouseModesForCurrentUser GET is unsuccessful with no default', function() {
            configManagementService.getMouseModesForCurrentUser(successCB, errorCB, false);

            httpBackend.expectGET(mouseModeGetURL).respond(400);
            httpBackend.flush();

            assert.isTrue(errorCB.calledOnce);
            assert.isTrue(successCB.notCalled);
        });

        it ('getMouseModesForCurrentUser both GET and POST are unsuccessful', function() {
            configManagementService.getMouseModesForCurrentUser(successCB, errorCB);

            httpBackend.expectGET(mouseModeGetURL).respond(404);
            httpBackend.expectPOST(mouseModeSaveURL, mouseModesObject).respond(404);
            httpBackend.flush();

            assert.isTrue(errorCB.calledOnce);
            assert.isTrue(successCB.notCalled);
        });

        it ('getMouseModesForCurrentUser GET returns 404, but POST works', function() {
            configManagementService.getMouseModesForCurrentUser(successCB, errorCB);

            httpBackend.expectGET(mouseModeGetURL).respond(400);
            httpBackend.expectPOST(mouseModeSaveURL, mouseModesObject).respond(201);
            httpBackend.flush();

            assert.isTrue(successCB.calledOnce);
            assert.deepEqual(successCB.args[0][0], mouseModesObject);

            assert.isTrue(errorCB.notCalled);
        });

        it ('getAnnotationStateForCurrentUser GET is successful', function() {
            configManagementService.getAnnotationStateForCurrentUser(successCB, errorCB);

            httpBackend.expectGET(annotStateGetURL).respond(200, annotStateObject);
            httpBackend.flush();

            assert.isTrue(successCB.calledOnce);
            assert.deepEqual(successCB.args[0][0], annotStateObject);

            assert.isTrue(errorCB.notCalled);
        });

        it ('getAnnotationStateForCurrentUser GET is unsuccessful with no default', function() {
            configManagementService.getAnnotationStateForCurrentUser(successCB, errorCB, false);

            httpBackend.expectGET(annotStateGetURL).respond(404);
            httpBackend.flush();

            assert.isTrue(successCB.notCalled);
            assert.isTrue(errorCB.calledOnce);
        });

        it ('getAnnotationStateForCurrentUser both GET and POST unsuccessful', function() {
            configManagementService.getAnnotationStateForCurrentUser(successCB, errorCB);

            httpBackend.expectGET(annotStateGetURL).respond(404);
            httpBackend.expectPOST(annotStateSaveURL, annotStateObject).respond(404);
            httpBackend.flush();

            assert.isTrue(successCB.notCalled);
            assert.isTrue(errorCB.calledOnce);
        });

        it ('getAnnotationStateForCurrentUser GET returns 404 but POST works', function() {
            configManagementService.getAnnotationStateForCurrentUser(successCB, errorCB);

            httpBackend.expectGET(annotStateGetURL).respond(400);
            httpBackend.expectPOST(annotStateSaveURL, annotStateObject).respond(201);
            httpBackend.flush();

            assert.isTrue(successCB.calledOnce);
            assert.deepEqual(successCB.args[0][0], annotStateObject);

            assert.isTrue(errorCB.notCalled);
        });
    });
});
