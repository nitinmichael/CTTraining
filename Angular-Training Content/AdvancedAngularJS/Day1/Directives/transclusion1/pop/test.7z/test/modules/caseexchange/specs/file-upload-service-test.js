/*
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular', 'angular-mocks','uaf/appshell/services/endpointConfig',
    'create-case/services/file-upload-service'], function () {
    'use strict';

    var DEFAULT_FILE_LIMIT = 1024*1024*100;
    var DEFAULT_FILE_LIST_LIMIT = 1024*1024*200;
    var DEFAULT_ALLOWED_EXTENSIONS = [
        "pdf", "doc", "docx", "xls", "xlsx", "csv", "rtf", "tiff", "tif", "txt", "bmp", "jpeg", "jpg", "ppt", "pptx", "dcm", "xml", "mov", "mp4"
    ];

    describe('File Upload Service Test Suite::', function () {
        var FileUploadService, $filter;

        beforeEach(module('Services.fileUploadService'));
        beforeEach(module('uaf.appshell.endpoint'));

        var FileUploadService;

        beforeEach(inject(function($injector) {
            FileUploadService = $injector.get('FileUploadService');
        }));

        describe('isFileSizeUnderLimit() function', function(){
            it('should return false - file size is above limit', function(){
                var file = {};
                file.size = 5;
                var limit = 4;
                expect( FileUploadService.isFileSizeUnderLimit(file, limit)).to.be.false;
            });
            it('should return true - file size is under limit', function(){
                var file = {};
                file.size = 5;
                var limit = 6;
                expect( FileUploadService.isFileSizeUnderLimit(file, limit)).to.be.true;
            });
            it('should return false - file size is above default limit', function(){
                var file = {};
                file.size = DEFAULT_FILE_LIMIT+1;
                expect( FileUploadService.isFileSizeUnderLimit(file)).to.be.false;
            });
            it('should return true - file size is under default limit', function() {
                var file = {};
                file.size = DEFAULT_FILE_LIMIT - 1;
                expect(FileUploadService.isFileSizeUnderLimit(file, "")).to.be.true;
            });
        });

        describe('isFileListSizeUnderLimit() function', function(){
            it('should return false - file list size is above limit', function(){
                var alreadySelectedFileList = [{}, {}];
                alreadySelectedFileList[0].size = 2;
                alreadySelectedFileList[1].size = 1;
                var freshlySelectedFileList = [{}, {}];
                freshlySelectedFileList[0].size = 1;
                freshlySelectedFileList[1].size = 2;
                var sumSizeLimitToCheck = 4;
                var sizeLimitToCheck = 3;
                expect( FileUploadService.isFileListSizeUnderLimit(alreadySelectedFileList, freshlySelectedFileList, sizeLimitToCheck, sumSizeLimitToCheck)).to.be.false;
            });
            it('should return true - file list size is under limit', function(){
                var alreadySelectedFileList = [{}, {}];
                alreadySelectedFileList[0].size = 1;
                alreadySelectedFileList[1].size = 1;
                var freshlySelectedFileList = [{}, {}];
                freshlySelectedFileList[0].size = 1;
                freshlySelectedFileList[1].size = 1;
                var sumSizeLimitToCheck = 4;
                var sizeLimitToCheck = 2;
                expect( FileUploadService.isFileListSizeUnderLimit(alreadySelectedFileList, freshlySelectedFileList, sizeLimitToCheck, sumSizeLimitToCheck)).to.be.true;
            });
            it('should return false - file list size is above default limit', function(){
                var alreadySelectedFileList = [{}, {}];
                alreadySelectedFileList[0].size = DEFAULT_FILE_LIMIT-1;
                alreadySelectedFileList[1].size = 1;
                var freshlySelectedFileList = [{}, {}];
                freshlySelectedFileList[0].size = DEFAULT_FILE_LIMIT+1;
                freshlySelectedFileList[1].size = 1;
                expect( FileUploadService.isFileListSizeUnderLimit(alreadySelectedFileList, freshlySelectedFileList)).to.be.false;
            });
            it('should return true - file list size is under default limit', function(){
                var alreadySelectedFileList = [{}, {}];
                alreadySelectedFileList[0].size = 1;
                alreadySelectedFileList[1].size = 1;
                var freshlySelectedFileList = [{}, {}];
                freshlySelectedFileList[0].size = 1;
                freshlySelectedFileList[1].size = 1;
                expect( FileUploadService.isFileListSizeUnderLimit(alreadySelectedFileList, freshlySelectedFileList)).to.be.true;
            });
        });

        describe('isFileExtensionValid() function', function(){
            it('should return true - check all valid default extension', function(){
                var file = {};
                var fileName = "dummy.zomby.";
                _.forEach(DEFAULT_ALLOWED_EXTENSIONS, function(ext){
                    file.name = fileName + ext;
                    expect( FileUploadService.isFileExtensionValid(file)).to.be.true;
                });
            });
            it('should return false - check some not valid default extension', function(){
                var file = {};
                var fileName = "dummy.zomby.";
                var INVALID_EXTENSIONS = ["inv", "xyz", ".", ""];
                _.forEach(INVALID_EXTENSIONS, function(ext){
                    file.name = fileName + ext;
                    expect( FileUploadService.isFileExtensionValid(file)).to.be.false;
                });
            });
            it('should return true - check all defined extension', function(){
                var file = {};
                var fileName = "dummy.zomby.";
                var MY_EXTENSIONS = ["alma", "korte"];
                _.forEach(MY_EXTENSIONS, function(ext){
                    file.name = fileName + ext;
                    expect( FileUploadService.isFileExtensionValid(file, MY_EXTENSIONS)).to.be.true;
                });
            });
            it('should return false - check some not valid extension', function(){
                var file = {};
                var fileName = "dummy.zomby.";
                var MY_EXTENSIONS = ["alma", "korte"];
                var INVALID_EXTENSIONS = ["inv", "xyz", ".", ""];
                _.forEach(INVALID_EXTENSIONS, function(ext){
                    file.name = fileName + ext;
                    expect( FileUploadService.isFileExtensionValid(file, MY_EXTENSIONS)).to.be.false;
                });
            });
        });

        describe('isFileNameAlreadyExistInList() function', function(){
            it('should return true - file with the same name in the list', function(){
                var file = {};
                file.name = "apple.txt";
                var fileList = [{},{},{}];
                fileList[0].name = "apple.txt";
                fileList[1].name = "pear.ppt";
                expect( FileUploadService.isFileNameAlreadyExistInList(file, fileList)).to.be.true;
            });
            it('should return false - no file with the same name in the list', function(){
                var file = {};
                file.name = "apple.ppt";
                var fileList = [{},{},{}];
                fileList[0].name = "apple.txt";
                fileList[1].name = "pear.ppt";
                expect( FileUploadService.isFileNameAlreadyExistInList(file, fileList)).to.be.false;
            });
        });

        describe('convertFileValidationErrorsToErrorMessages() function', function(){
            var fileListSizeErrorMsg, duplicateNameErrorMsg, fileExtensionErrorMsg;
            var $filter;
            beforeEach(inject(function(_$filter_) {
                $filter = _$filter_;
                fileListSizeErrorMsg = $filter("translate")(
                    "createcase.sumFilesSizeValidationError",
                    {
                        //we need the limit in MB
                        sizeLimit: parseInt(DEFAULT_FILE_LIST_LIMIT / (1024 * 1024))
                    }
                );
                duplicateNameErrorMsg = $filter("translate")("createcase.duplicatedFileName");
                fileExtensionErrorMsg = $filter("translate")("createcase.supportedExtensions");
            }));

            it('should return fileListSizeErrorMsg', function(){
                expect( FileUploadService.convertFileValidationErrorsToErrorMessages([], true, DEFAULT_FILE_LIMIT, DEFAULT_FILE_LIST_LIMIT).indexOf(fileListSizeErrorMsg)).to.be.equal(0);
            });
            it('should return fileListSizeErrorMsg', function(){
                var errors = [{}];
                errors[0].file = {};
                errors[0].file.name = "barack.jpg";
                errors[0].invalidSize = true;
                expect( FileUploadService.convertFileValidationErrorsToErrorMessages(errors, true, DEFAULT_FILE_LIMIT, DEFAULT_FILE_LIST_LIMIT).indexOf(fileListSizeErrorMsg)).to.be.equal(0);
            });
            it('should return fileListSizeErrorMsg', function(){
                var errors = [{}];
                errors[0].file = {};
                errors[0].file.name = "barack.jpg";
                errors[0].invalidSize = true;
                var fileSizeErrorMsg = $filter("translate")(
                    "createcase.fileSizeValidationError",
                    {
                        fileName: errors[0].file.name,
                        //we need the limit in MB
                        sizeLimit: parseInt(DEFAULT_FILE_LIMIT / (1024 * 1024))
                    }
                );
                expect( FileUploadService.convertFileValidationErrorsToErrorMessages(errors, false, DEFAULT_FILE_LIMIT, DEFAULT_FILE_LIST_LIMIT).indexOf(fileSizeErrorMsg)).to.be.equal(0);
            });
            it('should return duplicateNameErrorMsg', function(){
                var errors = [{}];
                errors[0].duplicatedName = true;
                expect( FileUploadService.convertFileValidationErrorsToErrorMessages(errors, false, DEFAULT_FILE_LIMIT, DEFAULT_FILE_LIST_LIMIT).indexOf(duplicateNameErrorMsg)).to.be.equal(0);
            });
            it('should return fileExtensionErrorMsg', function(){
                var errors = [{}];
                errors[0].invalidExtension = true;
                expect( FileUploadService.convertFileValidationErrorsToErrorMessages(errors, false, DEFAULT_FILE_LIMIT, DEFAULT_FILE_LIST_LIMIT).indexOf(fileExtensionErrorMsg)).to.be.equal(0);
            });
            it('should return 4 error messages', function(){
                var errors = [{}, {}, {}, {}];
                errors[0].file = {};
                errors[0].file.name = "barack.jpg";
                errors[0].invalidSize = true;
                var fileSizeErrorMsg1 = $filter("translate")(
                    "createcase.fileSizeValidationError",
                    {
                        fileName: errors[0].file.name,
                        //we need the limit in MB
                        sizeLimit: parseInt(DEFAULT_FILE_LIMIT / (1024 * 1024))
                    }
                );
                errors[1].file = {};
                errors[1].file.name = "eper.jpg";
                errors[1].invalidSize = true;
                var fileSizeErrorMsg2 = $filter("translate")(
                    "createcase.fileSizeValidationError",
                    {
                        fileName: errors[1].file.name,
                        //we need the limit in MB
                        sizeLimit: parseInt(DEFAULT_FILE_LIMIT / (1024 * 1024))
                    }
                );
                errors[2].duplicatedName = true;
                errors[3].invalidExtension = true;
                var errMsg = FileUploadService.convertFileValidationErrorsToErrorMessages(errors, false, DEFAULT_FILE_LIMIT, DEFAULT_FILE_LIST_LIMIT);
                var errMsg1Ind = errMsg.indexOf(fileSizeErrorMsg1);
                expect( errMsg1Ind ).to.be.equal(0);
                var errMsg2Ind = errMsg.indexOf(fileSizeErrorMsg2,1);
                expect( errMsg2Ind ).to.be.above(1);
                var errMsg3Ind = errMsg.indexOf(duplicateNameErrorMsg);
                expect( errMsg3Ind ).to.be.above(errMsg2Ind);
                var errMsg4Ind = errMsg.indexOf(fileExtensionErrorMsg);
                expect( errMsg4Ind ).to.be.above(errMsg2Ind);
            });
        });
    });
});
