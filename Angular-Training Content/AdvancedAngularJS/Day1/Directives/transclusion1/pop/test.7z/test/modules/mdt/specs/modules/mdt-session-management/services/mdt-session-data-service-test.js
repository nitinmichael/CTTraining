/*
 * mdt-session-data-service-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular', 'angular-mocks', 'mdt/services/mdt-session-data-service'], function () {
    'use strict';
    describe("MdtSessionDataService ", function () {
        var MdtSessionDataService;

        beforeEach(function () {
            module('Mdt.Module.MdtSessionDataService');

            inject(function (_MdtSessionDataService_) {
                MdtSessionDataService = _MdtSessionDataService_;
            });
        });

        it("should return empty object when retrieveSelectedSession called with sessionId = null", function () {
            var selectedSession = MdtSessionDataService.retrieveSelectedItem(null);
            expect(selectedSession).to.be.empty;
        });

        it("should update session details 1", function () {
            var sessionId = "id";
            var session = {meetingId: sessionId,
                cases: [{caseId: 5}]};
            var sessionList = [session];
            MdtSessionDataService.updateItemList(sessionList);
            var selectedSession = MdtSessionDataService.retrieveSelectedItem(sessionId);
            var result = {id: sessionId,
                cases: [{caseId: "4"}]};
            MdtSessionDataService.updateItemDetails(result);
            expect(selectedSession.cases[0].caseId).to.be.equal("4");
        });

        it("should update session details 2", function () {
            var sessionId = "id";
            var session = {meetingId: sessionId,
                cases: [{caseId: "5",
                         status: "IN_REVIEW"}]};
            var sessionList = [session];
            MdtSessionDataService.updateItemList(sessionList);
            var selectedSession = MdtSessionDataService.retrieveSelectedItem(sessionId);
            var result = {id: sessionId,
                cases: [{caseId: "5",
                         status: "CLOSED"}]};
            MdtSessionDataService.updateItemDetails(result);
            expect(selectedSession.cases[0].status).to.be.equal("CLOSED");
        });
    });
});

