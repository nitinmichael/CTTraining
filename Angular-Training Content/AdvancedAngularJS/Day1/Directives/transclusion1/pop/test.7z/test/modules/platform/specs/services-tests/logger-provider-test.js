define([ 'angular-mocks', 'modules/platform/services/logger-provider' ], function(ngMocks) {
    describe('Test  $logger service', function() {

        beforeEach(module('platform.service.logger-provider'));

        it(' defines $logger ', function() {
            inject(function($logger) {
                expect($logger).to.exist;
            })
        })
    });
});