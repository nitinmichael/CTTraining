define(['angular',
        'angular-mocks',
        'orgMgmnt/features/organization/createOrganization/controllers/createOrganizationController',
        'orgMgmnt/dataModels/organizationDataModel',
        'orgMgmnt/dataModels/networkSettingEnum',
        'orgMgmnt/services/organizationService',
        'orgMgmnt/utilities/masterDataUtil',
        'angularTranslate',
        'angularTranslatePartialLoader',
        'orgMgmnt/services/userService'
    ],
    function(){
        'use strict';

        describe('Test the CreateOrganizationController', function(){
            var CreateOrganizationCtrl, scope, _orgDataModel, _orgMgmtService, q, createResponse, orgObj, rootScope;
            var searchUserResult,deferred,deffered1, _log, _state, _event,_filter,loggedInUserContextServiceResponse,
                otherAdmin,youAdmin,_userService, validateOrgLegalNameStub, validateOrgNameDeferred,
                templateOrgName, formElem, orgForm, findUserDeferred, updateOrgAdminsdeferred,_filterFilter;
            beforeEach(function(){
                createResponse = {data:{"id":"12345"},status:200};
                orgObj = {"resourceType":"Organization", "name":"GEHC"};
                _orgMgmtService = {
                    createOrganization : function(){
                        return;
                    }
                };
            });

            beforeEach( function(){
                module('Orgmanagement.Features.Organization.CreateOrganization.CreateOrganizationController');
                module('Orgmanagement.DataModel.OrgDataModel');
                module('Orgmanagement.DataModel.NetworkSettingEnum');
                module('Orgmanagement.Services.OrganizationService');
                module('Orgmanagement.Utilities.MasterData');
                module('ui.router');
                module('pascalprecht.translate');
                module('Orgmanagement.Services.UserService');
            });
            beforeEach(inject(function($controller,$rootScope ,orgDataModel, orgMgmtService, $q, $log, $state,$filter, $compile, userMgmtService,filterFilter){
                scope = $rootScope.$new();
                rootScope = $rootScope;
                _orgDataModel = orgDataModel;
                _orgMgmtService = orgMgmtService;
                _userService=userMgmtService;
                q = $q;
                _log = $log;
                _state = $state;

                deferred = q.defer();
                deffered1 = q.defer();
                validateOrgNameDeferred = q.defer();
                _event = {
                    stopPropagation: sinon.spy(),
                    preventDefault: sinon.spy()
                };
                findUserDeferred = $q.defer();
                updateOrgAdminsdeferred = q.defer();
                sinon.stub(_orgMgmtService, 'updateOrgAdmins').returns(updateOrgAdminsdeferred.promise);
                sinon.stub(_userService, 'findUser').returns(findUserDeferred.promise);
                sinon.stub(_orgMgmtService, 'createOrganization').returns(deferred.promise);
                validateOrgLegalNameStub = sinon.stub(_orgMgmtService, 'isValidOrgName').returns(validateOrgNameDeferred.promise);
                sinon.stub(_log, 'info');
                sinon.stub(_log, 'error');
                _state.transitionTo = sinon.stub();
                _filter=$filter;
                _filterFilter=filterFilter;
                sinon.stub(_userService, 'getLoggedInUserDetails').returns(deffered1.promise);
                $rootScope.countryStatesData =
                    [
                        {
                            "name": "United States of America",
                            "code": "US",
                            "states": [
                                {
                                    "name": "Alabama",
                                    "code": "AL"
                                },
                                {
                                    "name": "Alaska",
                                    "code": "AK"
                                },
                                {
                                    "name": "American Samoa",
                                    "code": "AS"
                                },
                                {
                                    "name": "Arizona",
                                    "code": "AZ"
                                },
                                {
                                    "name": "Arkansas",
                                    "code": "AR"
                                },
                                {
                                    "name": "California",
                                    "code": "CA"
                                },
                                {
                                    "name": "Colorado",
                                    "code": "CO"
                                },
                                {
                                    "name": "Connecticut",
                                    "code": "CT"
                                },
                                {
                                    "name": "Delaware",
                                    "code": "DE"
                                },
                                {
                                    "name": "District Of Columbia",
                                    "code": "DC"
                                },
                                {
                                    "name": "Federated States Of Micronesia",
                                    "code": "FM"
                                },
                                {
                                    "name": "Florida",
                                    "code": "FL"
                                },
                                {
                                    "name": "Georgia",
                                    "code": "GA"
                                },
                                {
                                    "name": "Guam",
                                    "code": "GU"
                                },
                                {
                                    "name": "Hawaii",
                                    "code": "HI"
                                },
                                {
                                    "name": "Idaho",
                                    "code": "ID"
                                },
                                {
                                    "name": "Illinois",
                                    "code": "IL"
                                },
                                {
                                    "name": "Indiana",
                                    "code": "IN"
                                },
                                {
                                    "name": "Iowa",
                                    "code": "IA"
                                },
                                {
                                    "name": "Kansas",
                                    "code": "KS"
                                },
                                {
                                    "name": "Kentucky",
                                    "code": "KY"
                                },
                                {
                                    "name": "Louisiana",
                                    "code": "LA"
                                },
                                {
                                    "name": "Maine",
                                    "code": "ME"
                                },
                                {
                                    "name": "Marshall Islands",
                                    "code": "MH"
                                },
                                {
                                    "name": "Maryland",
                                    "code": "MD"
                                },
                                {
                                    "name": "Massachusetts",
                                    "code": "MA"
                                },
                                {
                                    "name": "Michigan",
                                    "code": "MI"
                                },
                                {
                                    "name": "Minnesota",
                                    "code": "MN"
                                },
                                {
                                    "name": "Mississippi",
                                    "code": "MS"
                                },
                                {
                                    "name": "Missouri",
                                    "code": "MO"
                                },
                                {
                                    "name": "Montana",
                                    "code": "MT"
                                },
                                {
                                    "name": "Nebraska",
                                    "code": "NE"
                                },
                                {
                                    "name": "Nevada",
                                    "code": "NV"
                                },
                                {
                                    "name": "New Hampshire",
                                    "code": "NH"
                                },
                                {
                                    "name": "New Jersey",
                                    "code": "NJ"
                                },
                                {
                                    "name": "New Mexico",
                                    "code": "NM"
                                },
                                {
                                    "name": "New York",
                                    "code": "NY"
                                },
                                {
                                    "name": "North Carolina",
                                    "code": "NC"
                                },
                                {
                                    "name": "North Dakota",
                                    "code": "ND"
                                },
                                {
                                    "name": "Northern Mariana Islands",
                                    "code": "MP"
                                },
                                {
                                    "name": "Ohio",
                                    "code": "OH"
                                },
                                {
                                    "name": "Oklahoma",
                                    "code": "OK"
                                },
                                {
                                    "name": "Oregon",
                                    "code": "OR"
                                },
                                {
                                    "name": "Palau",
                                    "code": "PW"
                                },
                                {
                                    "name": "Pennsylvania",
                                    "code": "PA"
                                },
                                {
                                    "name": "Puerto Rico",
                                    "code": "PR"
                                },
                                {
                                    "name": "Rhode Island",
                                    "code": "RI"
                                },
                                {
                                    "name": "South Carolina",
                                    "code": "SC"
                                },
                                {
                                    "name": "South Dakota",
                                    "code": "SD"
                                },
                                {
                                    "name": "Tennessee",
                                    "code": "TN"
                                },
                                {
                                    "name": "Texas",
                                    "code": "TX"
                                },
                                {
                                    "name": "Utah",
                                    "code": "UT"
                                },
                                {
                                    "name": "Vermont",
                                    "code": "VT"
                                },
                                {
                                    "name": "Virgin Islands",
                                    "code": "VI"
                                },
                                {
                                    "name": "Virginia",
                                    "code": "VA"
                                },
                                {
                                    "name": "Washington",
                                    "code": "WA"
                                },
                                {
                                    "name": "West Virginia",
                                    "code": "WV"
                                },
                                {
                                    "name": "Wisconsin",
                                    "code": "WI"
                                },
                                {
                                    "name": "Wyoming",
                                    "code": "WY"
                                }
                            ]
                        }
                    ];
                searchUserResult = {
                    "resourceType": "Bundle",
                    "title": "List of all groups for user",
                    "id": null,
                    "data": {
                        "entry": [
                            {
                                "title": null,
                                "id": "034e2e9b-60b0-4856-85a7-c43779a11746",
                                "content": {
                                    "resourceType": "ResourcesUser",
                                    "name": {
                                        "use": "official",
                                        "family": [
                                            "Tari"
                                        ],
                                        "given": [
                                            "Tushar",
                                            "K"
                                        ]
                                    },
                                    "externalId": [
                                        {
                                            "system": "IDM",
                                            "value": "b9f2b0f9-03ab-4d94-bd33-f40b495fc4d5"
                                        },
                                        {
                                            "system": "UOM",
                                            "value": "034e2e9b-60b0-4856-85a7-c43779a11746"
                                        },
                                        {
                                            "_id": "tushar.tari@ge.com",
                                            "system": "urn:hc.ge.com/pfh/platform/useremail"
                                        }
                                    ],
                                    "role": [
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "practitioner",
                                                    "display": "practitioner"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "organization/5"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "practitioner",
                                                    "display": "practitioner"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "organization/6"
                                            },
                                            "status": "active"
                                        }
                                    ],
                                    "managingOrganization": {
                                        "organization": {
                                            "reference": "organization/74553d9a-7d1b-4f93-929c-72b6318a6178"
                                        },
                                        "jobTitle": {
                                            "coding": [
                                                {
                                                    "system": "http://hl7.org/fhir/v3/AdministrativeUser",
                                                    "version": "1",
                                                    "code": "Manager",
                                                    "primary": true
                                                }
                                            ],
                                            "text": "Manager"
                                        },
                                        "employeeNumber": "ID_123445"
                                    },
                                    "telecom": [
                                        {
                                            "system": "phone",
                                            "value": "(+1) 734-677-7777"
                                        },
                                        {
                                            "system": "email",
                                            "value": "tushar.tari@ge.com"
                                        }
                                    ],
                                    "principalName": "tushar.tari@ge.com",
                                    "display": "Tushar K"
                                }
                            }
                        ]
                    }
                };
                loggedInUserContextServiceResponse=
                {
                    "resourceType": "ResourcesUser",
                    "name": {
                        "use": "official",
                        "family": [
                            "Tari"
                        ],
                        "given": [
                            "Tushar",
                            "K"
                        ]
                    },
                    "externalId": [
                        {
                            "system": "IDM",
                            "value": "b9f2b0f9-03ab-4d94-bd33-f40b495fc4d5"
                        },
                        {
                            "system": "UOM",
                            "value": "034e2e9b-60b0-4856-85a7-c43779a11746"
                        }
                    ],
                    "role": [
                        {
                            "code": [
                                {
                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                    "code": "practitioner",
                                    "display": "practitioner"
                                }
                            ],
                            "scopingOrganization": {
                                "reference": "organization/5"
                            },
                            "status": "active"
                        },
                        {
                            "code": [
                                {
                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                    "code": "practitioner",
                                    "display": "practitioner"
                                }
                            ],
                            "scopingOrganization": {
                                "reference": "organization/6"
                            },
                            "status": "active"
                        }
                    ],
                    "managingOrganization": {
                        "organization": {
                            "reference": "organization/74553d9a-7d1b-4f93-929c-72b6318a6178"
                        },
                        "jobTitle": {
                            "coding": [
                                {
                                    "system": "http://hl7.org/fhir/v3/AdministrativeUser",
                                    "version": "1",
                                    "code": "Manager",
                                    "primary": true
                                }
                            ],
                            "text": "Manager"
                        },
                        "employeeNumber": "ID_123445"
                    },
                    "telecom": [
                        {
                            "system": "phone",
                            "value": "(+1) 734-677-7777"
                        },
                        {
                            "system": "email",
                            "value": "tushar.tari@ge.com"
                        }
                    ],
                    "principalName": "tushar.tari@ge.com",
                    "display": "Tushar K"
                };
                otherAdmin={
                    "data": {
                        "resourceType": "ResourcesUser",
                        "name": {
                            "use": "official",
                            "family": [
                                "yash23"
                            ],
                            "given": [
                                "yash23",
                                null
                            ]
                        },
                        "externalId": [
                            {
                                "system": "IDM",
                                "value": "edb49cf6-0ec7-446c-ac15-11104b116449"
                            },
                            {
                                "system": "UOM",
                                "value": "0daf0216-8260-47c8-88f5-d3da742b4304"
                            },
                            {
                                "_id": "yash23.yash23@ge.com",
                                "system": "urn:hc.ge.com/pfh/platform/useremail"
                            }
                        ],
                        "role": [
                            {
                                "code": [
                                    {
                                        "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                        "code": "practitioner",
                                        "display": "HealthcareProvider"
                                    }
                                ],
                                "scopingOrganization": {
                                    "reference": "organization/"
                                },
                                "status": "pending"
                            }
                        ],
                        "address": [
                            {
                                "line": [
                                    null
                                ]
                            }
                        ],
                        "telecom": [
                            {
                                "system": "phone",
                                "use": "mobile"
                            },
                            {
                                "system": "phone",
                                "use": "home"
                            },
                            {
                                "system": "email",
                                "value": "yash23.yash23@ge.com",
                                "use": "work"
                            }
                        ],
                        "preferredLanguage": "English",
                        "type": "Human",
                        "status": "active",
                        "comment": "This is an Hospital Practioner 1",
                        "principalName": "yash23.yash23@ge.com",
                        "gender": {
                            "coding": [
                                {
                                    "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                    "code": "M",
                                    "display": "Male"
                                }
                            ]
                        },
                        "acceptedAgreement": [
                            {
                                "agreementUri": "http://goodcare.org/devices/id",
                                "accepted": false
                            }
                        ]
                    },
                    "status": 200,
                    "config": {},
                    "statusText": "OK"
                };
                youAdmin={
                    "data": {
                        "resourceType": "ResourcesUser",
                        "name": {
                            "use": "official",
                            "family": [
                                "Tari"
                            ],
                            "given": [
                                "Tushar",
                                "K"
                            ]
                        },
                        "externalId": [
                            {
                                "system": "IDM",
                                "value": "b9f2b0f9-03ab-4d94-bd33-f40b495fc4d5"
                            },
                            {
                                "system": "UOM",
                                "value": "034e2e9b-60b0-4856-85a7-c43779a11746"
                            },
                            {
                                "_id": "tushar.tari@ge.com",
                                "system": "urn:hc.ge.com/pfh/platform/useremail"
                            }
                        ],
                        "role": [
                            {
                                "code": [
                                    {
                                        "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                        "code": "practitioner",
                                        "display": "practitioner"
                                    }
                                ],
                                "scopingOrganization": {
                                    "reference": "organization/5"
                                },
                                "status": "active"
                            },
                            {
                                "code": [
                                    {
                                        "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                        "code": "practitioner",
                                        "display": "practitioner"
                                    }
                                ],
                                "scopingOrganization": {
                                    "reference": "organization/6"
                                },
                                "status": "active"
                            }
                        ],
                        "address": [
                            {
                                "line": [
                                    "3300 Washtenaw Avenue, Suite 227"
                                ],
                                "city": "Ann Arbor",
                                "state": "MI",
                                "zip": "48104",
                                "country": "USA"
                            }
                        ],
                        "telecom": [
                            {
                                "system": "phone",
                                "value": "(+1) 734-677-7777"
                            },
                            {
                                "system": "email",
                                "value": "tushar.tari@ge.com"
                            }
                        ],
                        "preferredLanguage": "English",
                        "type": "Human",
                        "status": "active",
                        "comment": "This is an Hospital Practioner 1",
                        "principalName": "tushar.tari@ge.com",
                        "display":"Tushar K",
                        "gender": {
                            "coding": [
                                {
                                    "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                    "code": "M",
                                    "display": "Male"
                                }
                            ]
                        },
                        "acceptedAgreement": [
                            {
                                "agreementUri": "http://goodcare.org/devices/id",
                                "accepted": false
                            }
                        ]
                    }
                };
                otherAdmin=JSON.parse(JSON.stringify(otherAdmin));
                youAdmin=JSON.parse(JSON.stringify(youAdmin));
                CreateOrganizationCtrl = $controller('CreateOrganizationCtrl', {
                    $scope: scope,
                    $rootScope: rootScope,
                    orgMgmtService: _orgMgmtService,
                    $filter: _filter,
                    userMgmtService: _userService,
                    filterFilter:_filterFilter
                });
                templateOrgName = '<form name="parentForm.orgForm"><input name="name" type="text" ng-model="formInfo.name" /></form>';
                formElem = angular.element("<div>" + templateOrgName + "</div>");
                $compile(formElem)(scope);
                orgForm = scope.parentForm.orgForm;
                scope.$apply();
                rootScope.uomServiceUrl = "http://case-api-gateway1.grc-apps.svc.ice.ge.com";
            }));

            describe('When Organization is created', function(){
                it('should check the service "createOrganization" has been called with success', function(done) {
                    scope.createOrganization();
                    deferred.resolve(createResponse);
                    updateOrgAdminsdeferred.resolve();
                    done();
                    scope.$digest();
                    chai.expect(scope.orgId).to.be.equal('12345');
                });
                it('should check the service "updateOrgAdmins" failed', function() {
                    scope.updateOrgAdmins('123', function(){});
                    updateOrgAdminsdeferred.reject({"data":"response"});
                    scope.$root.$digest();
                    chai.expect(_orgMgmtService.updateOrgAdmins).called;
                });
                it('should check the service "createOrganization" has been called with error', function(done) {
                    scope.createOrganization();
                    deferred.reject(createResponse);
                    scope.$root.$digest();
                    chai.expect(_log.info.calledOnce);
                    done();
                });

                it('should check the "valueArr" length when all TRUE', function(){
                    scope.sharingNetwork.value = true;
                    scope.downloadCaseFiles.value = true;
                    scope.sitesVisibleToNetwork.value = true;
                    scope.OrgVisibleToPublic.value = true;

                    scope.reShare.value = true;
                    scope.shareOutsideNetwork.value = true;
                    scope.downloadCaseFilesNewSites.value = true;
                    scope.downloadOutsideNetwork.value = true;

                    scope.saveNetworkSetting();
                    chai.expect(scope.valueCodingArr).to.have.length(8);
                });

                it('should check the "valueArr" length when all FALSE', function(){
                    scope.sharingNetwork.value = false;
                    scope.downloadCaseFiles.value = false;
                    scope.sitesVisibleToNetwork.value = false;
                    scope.OrgVisibleToPublic.value = false;
                    scope.reShare.value = false;
                    scope.shareOutsideNetwork.value = false;
                    scope.downloadCaseFilesNewSites.value = false;
                    scope.downloadOutsideNetwork.value = false;

                    scope.saveNetworkSetting();
                    chai.expect(scope.valueCodingArr).to.have.length(0);
                });
            });

            describe('When Organization Info object is created', function(){
                it('should have a "createAddressObject" function', function () {
                    chai.assert.isDefined(scope.createAddressObject, 'Controller scope doesn\'t have "createAddressObject" function defined');
                });

            });

            describe('When "createAddressObject" is called', function(){
                it('should test address line 2 is present', function(){
                    scope.formInfo = {
                        name: 'GEHCOrg',
                        nickName: 'GE Healthcare Organization',
                        accountOwner:'John Doe',
                        addressOne: '1st Street',
                        email: 'john.doe@ge.com',
                        address2: '2nd Street',
                        phone:'1324536',
                        city:'BLR',
                        ext:'23456',
                        state:{name:'KAR'},
                        zip:'560066',
                        country:{name:'INDIA'}
                    };
                    scope.createAddressObject();
                    chai.expect(scope.lineArr).to.have.length(2);
                });

                it('should test address line 2 is not present', function(){
                    scope.formInfo = {
                        name: 'GEHCOrg',
                        nickName: 'GE Healthcare Organization',
                        accountOwner:'John Doe',
                        addressOne: '1st Street',
                        email: 'john.doe@ge.com',
                        //address2: '2nd Street',
                        phone:'1324536',
                        city:'BLR',
                        ext:'23456',
                        state:{name:'KAR'},
                        zip:'560066',
                        country:{name:'INDIA'}
                    };
                    scope.createAddressObject();
                    chai.expect(scope.lineArr).to.have.length(1);
                });
            });

            describe('When "Next Button"  is pressed', function(){
                it('should test the form is valid', function(){
                    scope.formInfo = {
                        name: 'GEHCOrg',
                        nickName: 'GE Healthcare Organization',
                        accountOwner:'John Doe',
                        addressOne: '1st Street',
                        email: 'john.doe@ge.com',
                        address2: '2nd Street',
                        phone:'1324536',
                        city:'BLR',
                        ext:'343',
                        state:{name:'KAR'},
                        zip:'560066',
                        country:{name:'INDIA'}
                    };
                    scope.parentForm.orgForm = {$valid:true};
                    scope.nextScreen();
                    chai.expect(scope.tab).to.equal('orgSetting');
                });
                it('create contact obj without extension', function(){
                    scope.formInfo = {
                        name: 'GEHCOrg',
                        nickName: 'GE Healthcare Organization',
                        accountOwner:'John Doe',
                        addressOne: '1st Street',
                        email: 'john.doe@ge.com',
                        address2: '2nd Street',
                        phone:'1324536',
                        city:'BLR',
                        ext:'',
                        state:{name:'KAR'},
                        zip:'560066',
                        country:{name:'INDIA'}
                    };
                    scope.parentForm.orgForm = {$valid:true};
                    scope.nextScreen();
                    chai.expect(scope.tab).to.equal('orgSetting');
                });

                it('should test the form is not valid', function(){
                    scope.formInfo = {
                        name: 'GEHCOrg',
                        nickName: 'GE Healthcare Organization',
                        accountOwner:'John Doe',
                        addressOne: '1st Street',
                        email: 'john.doe@ge.com',
                        address2: '2nd Street',
                        phone:'1324536',
                        city:'BLR',
                        ext:'456',
                        state:{name:'KAR'},
                        zip:'560066',
                        country:{name:'INDIA'}
                    };
                    scope.parentForm.orgForm = {$valid:false};
                    scope.nextScreen();
                    chai.expect(scope.tab).to.not.equal('orgSetting');
                });
            });

            describe('When "Cancel Button" is pressed', function(){
                it('should test proper transition happening', function(){
                    scope.cancelClicked();
                    chai.expect(_state.transitionTo).to
                        .have.been.calledOnce
                        .and.calledWith('orgmanagement.organization');
                });
            });

            describe('When new Org is created successfully or not', function(){
                it('should test the transition to OrgList', function(){
                    scope.goBackToOrgList();
                    chai.expect(_state.transitionTo).to
                        .have.been.calledOnce
                        .and.calledWith('orgmanagement.organization');
                });
            });

            describe('Click Next Button ', function(){

                it('When Press Next Button in Org Create Form', function(){
                    scope.currentStep = 2;
                    scope.prevOrgFrom();
                    chai.expect(scope.currentStep).to.be.equal(1);

                });


                it('When Press Previous Button in Org Create Form ', function(){
                    scope.currentStep = 2;
                    scope.formInfo = {
                        name: 'GEHCOrg',
                        nickName: 'GE Healthcare Organization',
                        accountOwner:'John Doe',
                        addressOne: '1st Street',
                        email: 'john.doe@ge.com',
                        address2: '2nd Street',
                        phone:'1324536',
                        city:'BLR',
                        ext:'23456',
                        state:{name:'KAR'},
                        zip:'560066',
                        country:{name:'INDIA'}
                    };

                    scope.parentForm.orgForm = {$invalid:false};
                    scope.nextOrgFrom(_event);
                    chai.expect(scope.currentStep).to.be.equal(2);
                });

                it('and should test the click is stopped if invalid form', function(){
                    scope.parentForm.orgForm = {$invalid:true};
                    scope.currentStep = 2;
                    scope.nextOrgFrom(_event);
                    chai.expect(scope.currentStep).to.be.equal(2);
                });
                it('should go to next page when form is valid', function(){
                    scope.formInfo = {
                        name: 'GEHCOrg',
                        nickName: 'GE Healthcare Organization',
                        accountOwner:'John Doe',
                        addressOne: '1st Street',
                        email: 'john.doe@ge.com',
                        address2: '2nd Street',
                        phone:'1324536',
                        city:'BLR',
                        ext:'23456',
                        state:{name:'KAR'},
                        zip:'560066',
                        country:{name:'INDIA'}
                    };
                    scope.orgDetail.administrators = [youAdmin.data];
                    scope.parentForm.orgForm = {$invalid:false};
                    scope.nextOrgFrom(_event);
                    chai.expect(scope.currentStep).to.be.equal(1);
                });

            });

            describe('When there is a XSS event', function(){
                it('and the user closes the alert box, it should test setting of the variable to hide alert', function(){
                    scope.closeAlert();
                    chai.expect(scope.closeAlertPressed).to.be.equal(1);
                });

                /*    it('and there is a rootScope emit of the event, it should test the event is consumed', function(){
                 var object = {message: "There is an attempt to insert scrpit"};
                 scope.$emit("SHOW_FAILURE_MESSAGE_NO_TIMEOUT",object.message);
                 chai.expect(scope.xssMessage).to.be.equal(object.message);
                 chai.expect(scope.closeAlertPressed).to.be.equal(0);
                 });*/
            });
            describe('Checks default administrators list', function(){
                it('Checks nonLogged/OtherAdmin display values 1', function(done){
                    /*-deffered1.resolve calls the pending promise of
                     loggedInUserContext.getLoggedInUserDetails which is called in init()
                     */
                    deffered1.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    done();
                    scope.LoggedInUser={principalName: "tushar.tari@ge.com"};
                    chai.expect(scope.getUserForDisplay(otherAdmin.data)).to.be.equal('yash23  (yash23.yash23@ge.com)');
                    done();
                });
                it('Checks nonLogged/OtherAdmin display values 2', function(done){
                    /*-deffered1.resolve calls the pending promise of
                     loggedInUserContext.getLoggedInUserDetails which is called in init()
                     */
                    deffered1.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.LoggedInUser=loggedInUserContextServiceResponse;
                    chai.expect(scope.getUserForDisplay(searchUserResult.data.entry[0].content)).to.be.equal('Tushar K (orgmanagement.you)');
                    done();
                });
                it('Checks nonLogged/OtherAdmin display values if no email is present', function(done){
                    /*-deffered1.resolve calls the pending promise of
                     loggedInUserContext.getLoggedInUserDetails which is called in init()
                     */
                    deffered1.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.LoggedInUser=searchUserResult.data;
                    youAdmin.data.principalName=undefined;
                    chai.expect(scope.getUserForDisplay(youAdmin.data)).to.be.equal('Tushar K');
                    done();
                });
                it('Checks removeAdministrator button functionality', function(done){
                    /*-deffered1.resolve calls the pending promise of
                     loggedInUserContext.getLoggedInUserDetails which is called in init()
                     */
                    deffered1.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.removeAdministrator({user:youAdmin});
                    chai.expect(scope.orgDetail.administrators.length).to.be.equal(0);
                    done();
                });
                it('Checks userContextSuccesshandler and getUserDetails success', function(done){
                    var usrDetailDeferred= q.defer();
                    sinon.stub(_orgMgmtService, 'getUserDetails').returns(usrDetailDeferred.promise);
                    usrDetailDeferred.resolve(youAdmin);
                    scope.$digest();
                    scope.LoggedInUser={principalName: "tushar.tari@ge.com"};
                    chai.expect(scope.getUserForDisplay(youAdmin.data)).to.be.equal('Tushar K (orgmanagement.you)');
                    done();
                });
                it('Checks getUserDetails failure', function(done){
                    var usrDetailDeferred= q.defer();
                    sinon.stub(_orgMgmtService, 'getUserDetails').returns(usrDetailDeferred.promise);
                    usrDetailDeferred.reject({});
                    scope.$digest();
                    chai.expect(_log.error.calledOnce);
                    done();
                });
                it('Checks userContextFailurehandler', function(done){
                    deffered1.reject(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.$digest();
                    chai.expect(_log.error.calledOnce);
                    done();
                });
            });

            describe('When country dropdown value is selected', function(){
                it('should test the states data for US country selected', function(){
                    scope.getStatesForCountry({code:"US",name:"United States of America"});
                    chai.expect(scope.states).to.have.length.above(10);
                });
                it('should test the states data for US country selected with country states data undefined', function(){
                    rootScope.countryStatesData = undefined;
                    scope.getStatesForCountry({code:"US",name:"United States of America"});
                    chai.expect(scope.states.length).to.have.length.equal(0);
                });
                it('should test the states data for not matching the selected country code', function(){
                    scope.getStatesForCountry({code:"AB",name:"United States of America"});
                    chai.expect(scope.states.length).to.have.length.equal(0);
                });
                it('when selected country code is blank', function(){
                    scope.getStatesForCountry("");
                    chai.expect(scope.states.length).to.have.length.equal(0);
                });
                it('should test the Empty states data for blank country', function(){
                    scope.getStatesForCountry(undefined);
                    chai.expect(scope.states).to.be.empty;
                });
            });
            describe('Search user for making admin', function(){
                it('Search user for admin success', function(done){
                    deffered1.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    done();
                    scope.searchUserForAdmin("a");
                    findUserDeferred.resolve(searchUserResult);
                    scope.$digest();
                    done();
                    chai.expect(scope.searchingUsersForAdmin).to.be.false;
                });
                it('Check searchUserForAdmin function, reject', function (done) {
                    deffered1.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    done();
                    scope.searchUserForAdmin("abc");
                    findUserDeferred.reject();
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.noResultsForAdmin).to.be.true;
                });
            });
            describe('Validate org legal name uniqueness', function () {
                it('Org legal name is not given', function () {
                    scope.formInfo.name = '';
                    scope.validateOrgName();
                    chai.expect(validateOrgLegalNameStub.called).to.be.false;
                });
                it('Org legal name is unique', function (done) {
                    scope.formInfo.name = 'GE Org';
                    scope.validateOrgName();
                    validateOrgNameDeferred.resolve();
                    done();
                    scope.$digest();
                    chai.expect(orgForm['name'].$valid).to.be.true;
                });
                it('Org legal name is not unique', function (done) {
                    scope.formInfo.name = 'GE Org';
                    scope.validateOrgName();
                    validateOrgNameDeferred.reject();
                    done();
                    scope.$digest();
                    chai.expect(orgForm['name'].$valid).to.be.false;
                });
                it('remove org legal name uniqueness error message', function (done) {
                    scope.formInfo.name = 'GE Org';
                    scope.validateOrgName();
                    validateOrgNameDeferred.reject();
                    done();
                    scope.$digest();
                    scope.removeUniqueOrgNameExistMessage();
                    chai.expect(orgForm['name'].exist).to.be.true;
                });
                it('do not go for removing error message as legal name is unique', function (done) {
                    scope.formInfo.name = 'GE Org';
                    scope.validateOrgName();
                    validateOrgNameDeferred.resolve();
                    done();
                    scope.$digest();
                    scope.removeUniqueOrgNameExistMessage();
                    chai.expect(orgForm['name'].exist).to.be.undefined;
                });
            });
            describe('Checks Typeahead search and other scope methods', function () {
                it('for admins list to be empty', function () {
                    var text="hervin"
                    scope.searchedSuperSetData=JSON.parse(JSON.stringify('[{"title":"User Resource","id":"637f2b1b-26ba-43a0-89c4-87a311557b58","content":{"resourceType":"ResourcesUser","name":{"use":"official","family":["Bansal"],"given":["Hervinder"," "]},"externalId":[{"system":"IDM","value":"a78900da-869d-49a6-b239-90721e476107"},{"system":"UOM","value":"637f2b1b-26ba-43a0-89c4-87a311557b58"}],"role":[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/758ddb07-5042-4be0-ac22-c371b2b9575f","display":"TestBugSprint6"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/b7c32002-3efd-490a-9bb1-38f8ac3307b7","display":"TestBugSite1"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/88be78fc-bbc3-4a25-bf70-16284a5d490c","display":"DE6025"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/729e1347-c455-49f8-b9ae-531d3064b220","display":"DE6775"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/db9f844c-154f-494f-a34a-f570305b74e6","display":"SLNDuplicate"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a1430df1-79f2-4541-9dcb-cddf2eb184a1","display":"SLN"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/e8972bd6-5a11-4957-8aa8-d2af6d6675cd","display":"AutomationSapphire"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/f77ea534-eeeb-4f77-a69a-433ffe757bca","display":"OrgTestName"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/67304e6f-1601-4f9b-9548-c5232dc48c51","display":"abc"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/9b08b7cd-8305-47d5-91df-0b58d9c0a0bf","display":"si"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/2d68d547-ffd3-417e-a64d-e17ed6206335","display":"Duplicate"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/1375ab68-18fb-47e4-8b9e-afa10a5738a7","display":"DuplicateSite"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/93c562aa-c560-46b9-98ee-17417dedb738","display":"site"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a05715c0-b461-48d2-9f3d-2d5f3daf5bdd","display":"siteL"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/58416417-bc7c-4b90-9419-7ef1c68c539e","display":"Rname"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/270255de-0204-4ca7-9a00-c3c982d5aeaa","display":"Test87652579"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/1b2ea56e-f453-4e0d-bf82-f937e7d56238","display":"AutomationSapphire"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a985795c-fae2-40b7-afc6-1f37921d2048","display":"GE Healthcare RSNA VNA"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/09227e3e-1d92-4921-a944-3d22e43ad14c","display":"GE Healthcare RSNA 3"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/480f2c99-8056-4a1f-9202-1bc3c9339cf4","display":"GE Healthcare RSNA 4"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/4fcae497-335e-48b7-a58d-2f2418daa271","display":"GE Healthcare RSNA 2"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/734aef80-acd0-4d57-95ea-fd7337c2aef6","display":"hgh"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/90acd143-d416-4635-8fdd-9b73d2989449","display":"GE Healthcare Waukesha"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/622e80cf-1753-42a3-b673-e95008b4f91e","display":"SLN"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/f6f61b97-759d-4252-b758-7a5807660eb5","display":"AutomationNewOrg10_Dec_03-31-10_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/61a5503b-cf89-4972-9701-1f83ffd25de3","display":"AutomationTestSite10_Dec_03-32-35_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/ed811a2a-a5a0-4ff4-a81f-accfc018e871","display":"AutomationNewOrg10_Dec_03-47-16_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/45083d0b-63f5-43e6-8887-08205ef15d95","display":"AutomationTestSite10_Dec_03-48-58_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/7f583689-a6e3-4153-a681-aaa6719d49b2","display":"AutomationNewOrg10_Dec_03-56-20_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/de925917-e968-4b11-8351-c1f47fe0082d","display":"AutomationTestSite10_Dec_03-57-14_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/cf20a4ee-7968-4ed1-9ae2-86038d580b5a","display":"Rname2"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/2bff999a-84cf-4c21-b482-92a7cf09b7fc","display":"ge"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/c969ae91-4d70-4440-b7cc-7553dac8ebfe","display":"Rname2"},"status":"active"}],"address":[{"line":["3300 Washtenaw Avenue, Suite 227"],"city":"Ann Arbor","state":"MI","zip":"48104","country":"USA"}],"telecom":[{"system":"phone","value":"123454"},{"system":"email","value":"hervinder.bansal@ge.com"},{"system":"notification","value":"68E7D327A297D3E99A8A27C0C248B4AACDB46552DE301C77E5895A949DB64F41"}],"preferredLanguage":"English","type":"Human","status":"active","comment":"User Created by UOM","principalName":"hervinder.bansal@ge.com","gender":{"coding":[{"system":"http://hl7.org/fhir/v3/AdministrativeGender","code":"M","display":"Male"}]},"acceptedAgreement":[{"agreementUri":"http://goodcare.org/devices/id","accepted":false}]}},{"title":"User Resource","id":"9b27f650-79ce-4140-9f7d-ae82e4eac758","content":{"resourceType":"ResourcesUser","name":{"use":"official","family":["Hervo"],"given":["Patrice"," "]},"externalId":[{"system":"IDM","value":"949760fc-7e17-498d-9514-5a511049612a"},{"system":"UOM","value":"9b27f650-79ce-4140-9f7d-ae82e4eac758"}],"role":[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"practitioner"}],"scopingOrganization":{"reference":"site/a985795c-fae2-40b7-afc6-1f37921d2048","display":"GE Healthcare RSNA VNA"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"practitioner"}],"scopingOrganization":{"reference":"site/42c5cb4f-7fcd-46fc-9a58-f87739338444","display":"GE Healthcare San Ramon"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"practitioner"}],"scopingOrganization":{"reference":"site/90acd143-d416-4635-8fdd-9b73d2989449","display":"GE Healthcare Waukesha"},"status":"active"}],"address":[{"line":["3300 Washtenaw Avenue, Suite 227"],"city":"Ann Arbor","state":"MI","zip":"48104","country":"USA"}],"telecom":[{"system":"phone","value":"123454"},{"system":"email","value":"Patrice.Hervo@med.ge.com"}],"preferredLanguage":"English","type":"Human","status":"active","comment":"User Created by UOM","principalName":"Patrice.Hervo@med.ge.com","gender":{"coding":[{"system":"http://hl7.org/fhir/v3/AdministrativeGender","code":"M","display":"Male"}]},"acceptedAgreement":[{"agreementUri":"http://goodcare.org/devices/id","accepted":false}]}}]'));
                    scope.textToBeSearched="her";
                    var obj=scope.searchUserForAdmin(text);
                    chai.expect(obj.length).to.be.equal(0);
                });

                it('hasError for fields', function () {
                    var field="name";
                    scope.parentForm={
                        orgForm:{
                            name:{
                                $invalid:true,
                                $pristine:false
                            }
                        }
                    };
                    chai.expect(scope.hasError(field)).to.be.true;
                });

                it('hasError for fields with submitted form', function () {
                    var field="name";
                    scope.parentForm={
                        orgForm:{
                            name:{
                                $invalid:true,
                                $pristine:true
                            },
                            $submitted:true
                        }
                    };
                    chai.expect(scope.hasError(field)).to.be.true;
                });

            });

            describe('Miscellneous code coverage', function(){
                it('do not add existing admin', function(){
                    var selectedAdmin = searchUserResult.data.entry[0];
                    scope.orgDetail.administrators = [selectedAdmin];
                    scope.selectAdministrator(selectedAdmin);
                    chai.expect(scope.orgDetail.administrators).to.have.length(1);
                });
                it('return blank data if there is no content in user object', function(){
                    chai.expect(scope.getUserNameForDisplay({})).to.equal("");
                });
                it('return first name only as there is no last name present', function(){
                    var userObj = {"name":{"given":["Patrice", null]}};
                    chai.expect(scope.getUserNameForDisplay(userObj)).to.equal("Patrice ");
                });
            });
        });
    });
