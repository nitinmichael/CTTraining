/*
 *  pacs-patient-list-controller-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 */

/**
 * Spec file for Case Exchange > Create case > Pacs search > Patient List controller module
 */

define(['angular', 'angular-mocks', 'create-case/module', 'create-case/controllers/pacs-patient-list-controller', 'filters/name-filter', 'mocks/case-exchange-mock-service'], function () {
    'use strict';

    describe('Pacs Patient List Controller Test Suite::', function () {
        var index = 0, patients, singlePatient, patientList, patientData, selectedStudy, patientStudiesStub, pacsSearchData, studyList,pacsSearchStub,stateParams,selectedPatient,
            scope, controller, rootScope, filter, mock, studyListService, selectedStudyListService, location, state, studyStub, studyListResponse, selectedStudyData,
            caseExchangeDataService, PacsSearchMarshaller, PacsSearchMarshallerStub, patient = null, selectedStudyListStub, dicomDevice, pacsSearchService, applicationServiceId,
            caseExchangeMocks;

        function fakeStudyResolved(value) {
            return {
                promise: {
                    then: function (callback) {
                        callback(studyListResponse);
                    }
                }
            }
        }

        function fakePacsSearchResolved(index){
            return {
                promise: {
                    then: function (callback) {
                        switch(index){
                            case 0: patients.totalCount=30;
                            break;
                            case 1: patients.totalCount=0;
                            break;
                            case 2: patients.errorCodeMap['1c5b5099-967e-4a04-9826-9cfb42195819']='500';
                            break;
                        }
                        
                        callback(patients);
                    }
                }
            }
        }

        var nameFilter = function (value) {
            return value;
        };

        beforeEach(function () {
            // Load the module for the mock data first
            module('cloudav.caseExchange.mocks');

            module('cloudav.caseExchange.createCase.pacsPatientListCtrl', function ($provide) {
                $provide.value('$state', {
                    transitionTo: function (url) {
                    },
                    current: {
                        params: {}
                    }
                });

                $provide.value('$stateParams', {
                  "id": "0",
                  "pacsSearchData": {}
                });

                $provide.value('nameFilter', nameFilter);

                $provide.factory('configurationService', ['$q', function ($q) {
                    return {
                        getProperty: function () {
                            return $q.when({});
                        }
                    }
                }]);
            })
        });

        // Initialize the scope and controller variables
        beforeEach(inject(function ($rootScope, $controller, $filter, $location, $state,$stateParams,PacsSearchService, StudyListService, SelectedStudyListService, CaseExchangeDataService, PacsSearchMarshaller, CaseExchangeMocks) {
            caseExchangeMocks = CaseExchangeMocks;
            patients = CaseExchangeMocks.getPatientsFromPacs();
            singlePatient = CaseExchangeMocks.getSinglePatientFromPacs();
            patientList = CaseExchangeMocks.getPatientsFromPacs().responseList;
            patientData = CaseExchangeMocks.getPatientsFromPacs().responseList[0];
            dicomDevice = CaseExchangeMocks.getPacsDevices()[0];
            selectedStudy = CaseExchangeMocks.getSelectedStudyList();
            pacsSearchData = CaseExchangeMocks.getPatientSearchData();
            studyListResponse = CaseExchangeMocks.getStudiesFromPacs();
            studyList = CaseExchangeMocks.getStudiesFromPacs().responseList;
            selectedPatient = patientData;

            applicationServiceId = "24";

            rootScope = $rootScope;
            scope = $rootScope.$new();
            controller = $controller;
            filter = $filter;
            $stateParams.pacsSearchData = pacsSearchData;
            stateParams = $stateParams;

           
            // Initialize the controller before each specs
            controller('PacsPatientListCtrl', {$scope: scope});

            sinon.stub(PacsSearchService, 'getPacsSearchResultData' , function () {
                return patients;
            });
            sinon.stub(PacsSearchService, 'getPacsSearchParams' , function () {
                return pacsSearchData;
            });
            sinon.stub(PacsSearchService, 'setPacsSearchParams' , function () {
                return'';
            });
            patientStudiesStub = sinon.stub(StudyListService, 'getStudyListData', function (isSingle, isNull) {
                if(isSingle){
                    return singlePatient;
                }
                if(isNull){
                    return false;
                }
                return studyList;
            });
            studyStub = sinon.stub(StudyListService, 'studyList', function () {
                return fakeStudyResolved('value');
            });
            PacsSearchMarshallerStub = sinon.stub(PacsSearchMarshaller, 'getDicomDetail', function (applicationServiceId) {
                return dicomDevice;
            });
            selectedStudyListStub = sinon.stub(SelectedStudyListService, 'getSelectedPatient', function () {
                return patientData;
            });
            selectedStudyData = sinon.stub(SelectedStudyListService, 'getList', function () {
                return selectedStudy[0];
            });
            pacsSearchService = PacsSearchService;
            caseExchangeDataService = CaseExchangeDataService;
            studyListService = StudyListService;
            selectedStudyListService = SelectedStudyListService;
            location = $location;
            state = $state;
            scope.alertTypes = {error:''};
            scope.showAlertMessage = function(){};
        }));

        it('should have a controller', function () {
            assert.isDefined(controller, 'Pacs Patient List Controller is not defined');
        });

        it('Should convert date yyyymmdd to dd MMM YYYY', function () {
            var date = "19880226";
            var filterDate = filter('dateFormat')(date);
            expect(filterDate).to.equal("26 Feb 1988");
        });

        it('should show "not available" message when date is not in required format', function () {
            var date = "198802";
            var filterDate = filter('dateFormat')(date);
            expect(filterDate).to.equal("pacsPatientList.notAvailable");
        });

        it('should show "not available" message when date is not defined', function () {
            var date;
            var filterDate = filter('dateFormat')(date);
            expect(filterDate).to.equal("pacsPatientList.notAvailable");
        });

        it('should have a "clickedOnPatient" function', function () {
            assert.isDefined(scope.clickedOnPatient, 'Pacs Patient List Controller scope doesn\'t have "clickedOnPatient" function defined');
        });

        it('should have a "togglePatients" function', function () {
            assert.isDefined(scope.togglePatients, 'Pacs Patient List Controller scope doesn\'t have "togglePatients" function defined');
        });

        it('should have a "updatedPatientName" function', function () {
            assert.isDefined(scope.updatedPatientName, 'Pacs Patient List Controller scope doesn\'t have "updatedPatientName" function defined');
        });

        it('should have a "getPatientStudies" function', function () {
            assert.isDefined(scope.getPatientStudies, 'Pacs Patient List Controller scope doesn\'t have "getPatientStudies" function defined');
        });

        it('should have a "clickStudy" function', function () {
            assert.isDefined(scope.clickStudy, 'Pacs Patient List Controller scope doesn\'t have "clickStudy" function defined');
        });

        it('should have a "navigateUp" function', function () {
            assert.isDefined(scope.navigateUp, 'Pacs Patient List Controller scope doesn\'t have "navigateUp" function defined');
        });

        it('should have a "deselectAllStudies" function', function () {
            assert.isDefined(scope.deselectAllStudies, 'Pacs Patient List Controller scope doesn\'t have "deselectAllStudies" function defined');
        });

        it('should have a "attachStudies" function', function () {
            assert.isDefined(scope.attachStudies, 'Pacs Patient List Controller scope doesn\'t have "attachStudies" function defined');
        });

        it('should have a "cancelPacsList" function', function () {
            assert.isDefined(scope.cancelPacsList, 'Pacs Patient List Controller scope doesn\'t have "cancelPacsList" function defined');
        });

        it('should make an AJAX call when clickedOnPatient() is called', function () {
            patients=scope.patients = caseExchangeMocks.getPatientsFromPacs().responseList;
            patientData=scope.patientData = patients[0];
            scope.selectedPatient=singlePatient;
            scope.selectedPatient.existingStudies = true;
            patientData.name.given = 'sd';
            patientData.gender = 'M';
            patientData.birthDate = '19021978';            
            scope.clickedOnPatient(patientData, index);
            expect(scope.isStudyFetchingComplete).to.be.true;
        });

        it('should give "isStudyFetchingComplete" false', function () {
            scope.isStudyFetchingComplete = false;
            scope.clickedOnPatient(patientData, index);
            expect(scope.isStudyFetchingComplete).to.be.false;
        });

        it('should not enter if condition in "deselectAllStudies()" function', function () {
            scope.patientStudies = [];
            scope.deselectAllStudies();
            expect(scope.patientStudies[0]).to.be.undefined;
        });

        it('should not set "isAttachedFinally" true when selectedStudiesCount is equal to 0 in "attachStudies()" function', function () {
            scope.selectedStudiesCount = 0;
            scope.attachStudies();
            expect(scope.isAttachedFinally).to.be.false;
        });

        it('should set "isAttachedFinally" true', function () {
            scope.cancelPacsList();
            expect(scope.isAttachedFinally).to.be.false;
        });

        it('should return from method immediately, it will not set setSubmitDisabledFlag to true', function () {
            patientData.active = true;
            patientData.identifier = undefined;
            scope.setSubmitDisabledFlag = false;
            scope.togglePatients(patientData, index);
            expect(scope.setSubmitDisabledFlag).to.be.false;
        });

        it('should call init method for a single patient', function () {
            patientData.active=true;
            scope.togglePatients(patientData, 1000);
            expect(scope.setSubmitDisabledFlag).to.be.true;
        });

        it('should call init method for a single patient', function () {
            scope.patientDataIsActive = true;
            scope.togglePatients(patientData, index);
            expect(scope.setSubmitDisabledFlag).to.be.true;
        });

        it('should toggle patient if patient.active= true', function () {
            scope.togglePatients(patientData, index);
            expect(scope.search).to.equal(filter("translate")("pacsPatientList.search"));
        });

        it('should toggle patient patients css & show/hide when clicked on non-active patient', function () {            
            patientData.active = false;
            scope.togglePatients(patientData, index);
            expect(scope.search).to.equal(filter("translate")("pacsPatientList.patientList"));
        });

        it('should increment selectedStudiesCount with one when "clickStudy" function is called', function () {
            scope.patientStudies = studyListService.getStudyListData();
            selectedStudyListService.setSelectedPatient(patientData);
            var selectedStudiesCount = scope.selectedStudiesCount;
            scope.clickStudy(selectedStudy[0]);
            expect(scope.selectedStudiesCount).to.equal(selectedStudiesCount + 1);
        });

        it('should decrement selectedStudiesCount with one when "clickStudy" function is called', function () {
            scope.selectedStudiesCount = 1;
            scope.patientStudies = studyListService.getStudyListData();
            selectedStudyListService.setSelectedPatient(patientData);
            scope.selectedStudy = [selectedStudy[0]];
            var selectedStudiesCount = scope.selectedStudiesCount;
            scope.clickStudy(selectedStudy[0]);
            expect(scope.selectedStudiesCount).to.equal(selectedStudiesCount + 1);
        });

         it('should set patient data to undefined', function () {
            scope.isAttached = false;
            scope.patientStudies = studyListService.getStudyListData();
            scope.selectedStudy = scope.patientStudies;
            selectedStudy[0].selected = true;
            scope.clickStudy(selectedStudy[0]);
            expect(scope.selectedStudiesCount).to.equal(-1);
        });

        it('should not execute if condition in "clickStudy" function', function () {
            scope.clickStudy(selectedStudy[1]);
            assert.isDefined(scope.clickStudy, 'Controller scope does not have "clickStudy" object defined');
        });

        it('should not execute if condition in "updatedPatientName "', function () {
            scope.updatedPatientName(patient);
            assert.isDefined(scope.updatedPatientName, 'Controller scope does not have "updatedPatientName" object defined');
        });

        it('should not toggle studies in "clickStudy" function', function () {
            scope.patientStudies = studyListService.getStudyListData();
            scope.clickStudy(selectedStudy[2]);
            assert.isDefined(scope.clickStudy, 'Controller scope does not have "clickStudy" object defined');
        });

        it('should call "navigateUp" & return to Patient List Screen function when click on Patient List Button', function () {
            scope.currentPatientIndex = 0;
            scope.patientDataIsActive = true;
            scope.patients = [];

            var patient = {};
            patient.active = true;
            scope.patients.push(patient)

            scope.patientStudies = studyListService.getStudyListData();
            scope.navigateUp();
            expect(scope.selectedStudiesCount).to.equal(0);
        });

        it('should call "attachStudies" function when clicked on "Attach Studies" Button with selected studies and return to Create Case page', function () {
            scope.selectedStudiesCount = 1;
            scope.attachStudies();
            expect(scope.isAttachedFinally).to.be.true;
        });

        it('should have search object', function () {
            scope.search = {
                $valid: false
            }
            assert.isDefined(scope.search, 'Controller scope doesn\'t have "search" object defined');
        });

        it('should have detailsDisplay object', function () {
            scope.detailsDisplay = {
                $valid: false
            }
            assert.isDefined(scope.detailsDisplay, 'Controller scope doesn\'t have "detailsDisplay" object defined');
        });

        it('should have type object', function () {
            scope.type = {
                $valid: false
            }
            assert.isDefined(scope.type, 'Controller scope doesn\'t have "type" object defined');
        });

        it('should have studyListDisplayed object', function () {
            scope.studyListDisplayed = {
                $valid: false
            }
            assert.isDefined(scope.studyListDisplayed, 'Controller scope doesn\'t have "studyListDisplayed" object defined');
        });

        it('should have setSubmitDisabledFlag object', function () {
            scope.setSubmitDisabledFlag = {
                $valid: false
            }
            assert.isDefined(scope.setSubmitDisabledFlag, 'Controller scope doesn\'t have "setSubmitDisabledFlag" object defined');
        });

        it('should have selectedStudiesCount object', function () {
            scope.selectedStudiesCount = {
                $valid: false
            }
            assert.isDefined(scope.selectedStudiesCount, 'Controller scope doesn\'t have "selectedStudiesCount" object defined');
        });

        it('should call "getPatientStudies" function', function () {
            scope.selectedPatient = patientData;
            scope.patients = {};
            scope.patientCount = 1;
            scope.getPatientStudies(patientData);
            expect(scope.isStudyFetchingComplete).to.be.true;
        });

        it('should set false value to "isStudyFetchingComplete"', function () {
            scope.selectedPatient = patientData;
            scope.patients = {};
            scope.patientCount = 1;
            scope.isStudyFetchingComplete = false;
            scope.getPatientStudies(patientData);
            expect(scope.isStudyFetchingComplete).to.be.false;
        });

        it('should call "getPatientStudyDetails" function for multiple patients', function () {
            scope.patientStudies = studyListService.getStudyListData();
            scope.patients = patientList;
            scope.getPatientStudyDetails();
            expect(scope.isLocalPatientStudies).to.be.true;
        });

        it('should call "getPatientStudyDetails" function for single patient', function () {
            scope.patientStudies = studyListService.getStudyListData(true);
            scope.getPatientStudyDetails();
            expect(scope.isLocalPatientStudies).to.be.false;
        });

        it('should navigate to create case page on click of cancel', function () {
            var stateSpy = sinon.spy(state, "transitionTo");
            patientData.studyList= [];
            patientData.studyList.length = 1;
            selectedStudyListService.setSelectedPatient(patientData);
            scope.cancelPacsList();
            assert(stateSpy.calledWith('caseexchange.createcase'));
        });

        it('should navigate to add to case page on click of cancel if there is caseUpdateType present as "ADDCASE"', function () {
            caseExchangeDataService.setCaseUpdateType("ADDCASE");
            var stateSpy = sinon.spy(state, "transitionTo");
            patientData.studyList= [];
            patientData.studyList.length = 1;
            selectedStudyListService.setSelectedPatient(patientData);
            scope.cancelPacsList();
            assert(stateSpy.calledWith('caseexchange.updatecase'));
        });

        it('should navigate to pacs query page on click of search button', function () {
            var stateSpy = sinon.spy(state, "transitionTo");
            scope.patientCount = 1;
            scope.isAttachedFinally = false;
            scope.navigateUp();
            assert(stateSpy.calledWith('caseexchange.pacsquery'));
        });

        it('should navigate to add to case page on click of attach button if there is caseUpdateType present as "ADDCASE"', function () {
            caseExchangeDataService.setCaseUpdateType("ADDCASE");
            var stateSpy = sinon.spy(state, "transitionTo");
            scope.selectedStudiesCount = 1;
            scope.attachStudies();
            assert(stateSpy.calledWith('caseexchange.updatecase'));
        });

        it('should remove one particular item from the studyList', function () {
            selectedStudyListService.setList(studyList);
            selectedStudyListService.removeItem(selectedStudy.identifier);
            assert.isDefined(selectedStudyListService.removeItem, "Selected study List Service have 'removeItem' function defined.");
        });

        it('should call updatedPatientName and empty patient', function () {
            var patient = {};
            scope.updatedPatientName(patientData);
            assert.isDefined(scope.updatedPatientName, "'updatedPatientName' function defined.");
        });

        it('should call init method with dicom devices length < 25 & > 0 & with status code 200', function () {
           pacsSearchService.setPacsSearchParams(pacsSearchData);
           var pacsSearchStub = sinon.stub(pacsSearchService, 'pacsSearch' , function () {
                return fakePacsSearchResolved(null);
            });
            scope.init();
            expect(patients.totalCount).to.be.above(0);
            expect(patients.totalCount).to.be.below(25);
        });

        it('should call init method with dicom devices length > 25 & with status code 200', function () {
           pacsSearchService.setPacsSearchParams(pacsSearchData);
           var pacsSearchStub = sinon.stub(pacsSearchService, 'pacsSearch' , function () {
                return fakePacsSearchResolved(0);
            });
            scope.init();
            expect(patients.totalCount).to.be.above(25);
        });

        it('should set patient visibility to true', function () {     
            patientData.active = true;
            scope.patients = patientList;
            scope.togglePatients(patients, 0);
            expect(scope.patients[0].visible).to.equal(true);
        });

        it('should set patient visibility to false', function () {
            patientData.active = true;
            scope.patients = patientList;     
            scope.togglePatients(patients, 56);
            expect(scope.patients[0].visible).to.equal(false);
        });

        it('should call init method with dicom devices length as zero & with status code 200', function () {     
           var pacsSearchStub = sinon.stub(pacsSearchService, 'pacsSearch' , function () {
                return fakePacsSearchResolved(1);
            });
            scope.init();
            expect(patients.totalCount).to.equal(0);
        });

        it('should call init method with dicom device with status code 500', function () {
           pacsSearchService.setPacsSearchParams(pacsSearchData);
           var pacsSearchStub = sinon.stub(pacsSearchService, 'pacsSearch' , function () {
                return fakePacsSearchResolved(2);
            });
            scope.init();
            expect(patients.errorCodeMap['1c5b5099-967e-4a04-9826-9cfb42195819']).to.equal('500');
        });

        it('should call showAlertMessage method', function () {
           var showAlertMessageSpy = sinon.stub(scope, 'showAlertMessage');
            scope.showMsg('msg','alertType');
            assert(showAlertMessageSpy.calledOnce);
        });

        it('should set patients value', function () {
            scope.getAllPatients(patients,true);
            expect(scope.patients).to.equal(patients);
        });

        it('should not set patients value', function () {
            scope.getAllPatients('', false);
            expect(scope.patients).to.not.equal('');
        }); 

        // Use Sinon to replace jQuery's ajax method with a spy.
        beforeEach(function () {
            sinon.stub($, 'ajax').yieldsTo('success', {});
        });

        // Restore jQuery's ajax method to its original state
        afterEach(function () {
            $.ajax.restore();
        });
    });
});