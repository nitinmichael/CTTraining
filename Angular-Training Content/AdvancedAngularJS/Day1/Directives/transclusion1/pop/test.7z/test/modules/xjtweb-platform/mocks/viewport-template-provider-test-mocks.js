angular.module('viewport-template-provider-test-mocks', []).constant('VpTemplateProvTestMocks', {

    xjtweb : function() {
        return {
            getModuleHome : function() {
                return "modules/xjtweb-platform";
            }
        };
    },

});
