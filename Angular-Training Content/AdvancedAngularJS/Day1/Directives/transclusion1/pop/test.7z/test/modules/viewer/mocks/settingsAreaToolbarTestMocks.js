define(['angular'], function(angular){
/**
 * @ngdoc property
 * @name MockFile_settingsAreaToolbarTestMocks
 * @propertyOf cloudav.viewerApp.test:TEST_settings-area-toolbar
 * 
 * @description This file defines mocked dependencies for the settingAreaToolbar directive in its unit tests.
 * 
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 * 
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 * 
 * @author Beeman, Benjamin <benjamin.beeman@ge.com>
 */
angular.module('settingsAreaToolbarTestMocks', []).directive('toolBox', function() {
    return {
        restrict : 'E',
        scope : {
            toolModel : '='
        },
        template : '<div id="settings-btn-settings" ><span></span></div><div id="settings-btn-help" ><span></span></div>'
    };
})
});