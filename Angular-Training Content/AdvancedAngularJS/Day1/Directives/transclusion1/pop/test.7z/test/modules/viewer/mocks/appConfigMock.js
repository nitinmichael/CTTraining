define(['angular'], function(angular){
angular.module('cloudav.configuration', [])
    .provider('$AppConfig', function () {
        var appDescriptors = [];

        this.getAppDescriptors = function (value) {
            return appDescriptors;
        };

        this.addAppDescriptor = function (appModule) {
            appDescriptors = appDescriptors.concat(appModule);
        };

        this.$get =  function () {
            return function () {
                return appDescriptors;
            };
        };
    });
});