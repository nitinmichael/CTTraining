/*
 * patient-management-controller-test.js
 * 
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 * 
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */

define([
    'postal',
    'angular',
    'angular-mocks',
    'patient-view/modules/patient-management/controllers/patient-management-controller'
], function (postal, ng) {
    'use strict';

    describe('Patient Management Controller Test Suite', function () {
        var $controller;
        var $rootScope;
        var $q;
        var $scope;
        var $state;
        var $timeout;
        var NotificationService;
        var patient;
        var Patient;
        var mock;
        var identifier = [];
        var patientviewIdentifier = {};
        var officialIdentifier = {};
        var UOMService;
        var UOMServiceMock;
        var UOMServiceDeferred;
        var NSerrorSpy;

        var setupMockState = function () {
            $scope = $rootScope.$new();

            UOMServiceMock = sinon.mock(UOMService);
            UOMServiceDeferred = $q.defer();
            UOMServiceMock.expects('getMyApplicationServices').returns(UOMServiceDeferred.promise);

            var deferred = $q.defer();
            mock = sinon.mock(Patient);
            mock.expects('listMyPatients').returns(deferred.promise);

            $controller('PatientManagementCtrl', {$scope:$scope});

            $scope.patientGenericListAPI = {
                resetScroll: sinon.spy(),
                scrollTo: sinon.spy()
            };

            deferred.resolve({ totalRecords: 0, listPatientVO: []});
            $rootScope.$apply();

            mock.restore();
            mock = sinon.mock(Patient);

            NSerrorSpy = sinon.spy(NotificationService, 'addErrorMessage');
        };

        var clearMockState = function () {
            mock.restore();
            UOMServiceMock.restore();
            NSerrorSpy.restore();
        };

        beforeEach(function () {
            ng.module('Platform.Services.NotificationService', []);

            module('cloudav.patient-view.patient-management', function ($provide) {
                $provide.value('translateFilter', function (value) {
                    return value;
                });

                $provide.service('$Endpoint', function() {
                    this.getEndpoint = function (key) {
                        return 'http://ge.test.fake.nonexistentdomain';
                    };

                    this.getEndpointAsync = function () { };
                });

                $provide.service('NotificationService', function () {
                    this.addErrorMessage = function (msg) {
                        console.log("Error msg: ", msg);
                    };

                    this.addSuccessMessage = function (msg) {
                        console.log("Success msg: ", msg);
                    };
                });

                $provide.service('$state', function () {
                    this.go = function (destination, args) {
                        console.log('$state.go()', destination, args);
                    };
                });

                $provide.value('$stateParams', {});
            });
        });

        beforeEach(inject([
        '$controller', '$rootScope', '$q', 'Patient', '$state', '$timeout', 'UOMService', 'NotificationService',
        function (_$controller_, _$rootScope_, _$q_, _Patient_, _$state_, _$timeout_, _UOMService_, _NotificationService_) {
            $controller = _$controller_;
            $rootScope = _$rootScope_;
            $q = _$q_;
            $state = _$state_;
            $timeout = _$timeout_;
            UOMService = _UOMService_;
            Patient = _Patient_;
            NotificationService = _NotificationService_;
            officialIdentifier = {
                system: 'urn:oid:0.1.2.3.4.5.6.7',
                value: '9fd78cd6-3ec9-46db-8925-029cab56d313'
            };
            patientviewIdentifier = {
                system: 'patientview',
                value: '9fd78cd6-3ec9-46db-8925-029cab56d313'
            }

            identifier = [officialIdentifier, patientviewIdentifier];

            patient = {
                rid: '9fd78cd6-3ec9-46db-8925-029cab56d313',
                identifier: identifier,
                getOfficialIdentifier: function () { return officialIdentifier; },
                getPatientViewIdentifier: function () {return patientviewIdentifier; },
                uploadStudy: function () {},
                getStudies: function () {},
                getUpdatedStudies: function () {},
                getFullName: function () { return "FULL NAME"; }
            };

            setupMockState();
        }]));

        afterEach(function () {
            clearMockState();
        });

        it('should call UOMService.getMyApplicationServices in the controller constructor', function () {
            UOMServiceMock.verify();
        });

        it('should define a loadPage method', function () {
            assert.isDefined($scope.loadPage, 'Controller scope doesn\'t have "loadPage" function defined');
            assert.isFunction($scope.loadPage, '"loadPage" is not a function');
        });

		it('should define a loadMorePatients method', function () {
            assert.isDefined($scope.loadMorePatients, 'Controller scope doesn\'t have "loadMorePatients" function defined');
            assert.isFunction($scope.loadMorePatients, '"loadMorePatients" is not a function');
        });
		
		it('should define a searchPatient method', function () {
            assert.isDefined($scope.searchPatient, 'Controller scope doesn\'t have "searchPatient" function defined');
            assert.isFunction($scope.searchPatient, '"searchPatient" is not a function');
        });
		
		it('should have a noResultsFound onScript', function () {
            assert.isFunction($scope.onScript, 'Controller scope doesn\'t have "onScript" function defined');
        });

        it('shoud watch selectedItemObj', function () {
            $scope.selectedItemObj = {
                value: 1,
                selectedItem: patient
            };

            var spy = sinon.spy($state, 'go');

            $scope.$apply();

            expect(spy.called).to.be.true;
        });
		
        it('should call the Patient.listMyPatients method', function () {
            var deferred = $q.defer();
			
            mock.expects('listMyPatients').withArgs(0, 10, null).returns(deferred.promise);

            $scope.loadPage();

            mock.verify();
        });
		
		 it('should call the Patient.listMyPatients method with loadMorePatients', function () {
            var deferred = $q.defer();
			
			mock.expects('listMyPatients').withArgs(0, 10, null).returns(deferred.promise);
            
            $scope.loadPage();
			mock.verify();

            $scope.offset = 10;
            $scope.limit = 10;
            $scope.totalRecords = 50;
            $scope.searchFinished = true;

            mock.restore();
            mock = sinon.mock(Patient);
            mock.expects('listMyPatients').withArgs(20, 10, null).returns(deferred.promise);

            $scope.loadMorePatients();
            mock.verify();
        });

        it('should call the Patient.listMyPatients method with loadMorePatients offset invalid', function () {
            var deferred = $q.defer();
			
			mock.expects('listMyPatients').withArgs(0, 10, null).returns(deferred.promise).once();
            
            $scope.loadPage();
			
			$scope.offset = 11;
            $scope.limit = 10;
            $scope.totalRecords = 10;
            			
			$scope.loadMorePatients();

			mock.verify();
			
        });

		
        it('should call the Patient.listMyPatients method with searchPatient ', function () {
            var deferred = $q.defer();
			
            mock.expects('listMyPatients').withArgs(0, 10, null).returns(deferred.promise);
            
            $scope.loadPage();
			mock.verify();

			$scope.offset = 10;
            $scope.limit = 10;
            $scope.totalRecords = 50;
            $scope.selectedItemObj = { value: 0 };

            mock.restore();
            mock = sinon.mock(Patient);
            mock.expects('listMyPatients').withArgs(0, 10, null).returns(deferred.promise);

            var spy = sinon.spy($state, 'go');
			
			$scope.searchPatient();

            expect($scope.selectedItemObj.value).to.equal(-1);
            expect($scope.patientGenericListAPI.resetScroll.calledOnce).to.be.true;

            expect(spy.called).to.be.true;

			mock.verify();

        });
		
		it('should call the Patient.listMyPatients method with searchPatient and loadMorePatients ', function () {
            var deferred = $q.defer();
			
            mock.expects('listMyPatients').withArgs(0, 10, null).returns(deferred.promise);
            $scope.loadPage();
			mock.verify();

            mock.restore();
            mock = sinon.mock(Patient);
            mock.expects('listMyPatients').withArgs(0, 10, null).returns(deferred.promise);

			$scope.searchPatient();
			
			$scope.offset = 10;
            $scope.limit = 10;
            $scope.totalRecords = 50;
			
			$scope.loadMorePatients();

			mock.verify();

        });

		
        it('should update the totalRecords and patients attributes when listMyPatients returns successfully', function () {
            var deferred = $q.defer();
			
			var offset =  0;
			var limit = 10;
			var search = null;
            mock.expects('listMyPatients').withArgs(offset, limit, search).returns(deferred.promise);

            $scope.totalRecords = 0;
            $scope.patients = [];

            $scope.loadPage();
            deferred.resolve({ totalRecords: 132, listPatientVO: [{identifier: '1'}, {identifier: '2'}]});
            $rootScope.$apply();

            expect($scope.totalRecords).to.equal(132);
            expect($scope.patients).to.eql([{identifier: '1'}, {identifier: '2'}]);
            mock.verify();
        });
		
		
        it('should set $scope.requestError to true when listMyPatients request fails', function () {
            var deferred = $q.defer();
            
			var offset =  0;
			var limit = 10;
			var search = null;
        
			mock.expects('listMyPatients').withArgs(offset, limit, search).returns(deferred.promise);

            $scope.loadPage();
            deferred.reject();
            $rootScope.$apply();

            expect(NSerrorSpy.calledWith('patient-management.requestError')).to.be.true;
        });

        it('should define the selectPatient method', function () {
            expect($scope.selectPatient).to.be.instanceof(Function);
        });

        it('should throw an error if the argument is not a patient', function () {
            var patient = new Patient();

            expect($scope.selectPatient).to.throws('argument should be a Patient instance');
            expect(function () {
                $scope.selectPatient(patient)
            }).to.not.throws('argument should be a Patient instance');
        });

        it('should wait for the last searchPatient get finished', function () {
            var patient = new Patient({rid: 2});
            var deferred = $q.defer();
            $scope.listMyPatientsPromise = deferred.promise;
            $scope.selectedItemObj = { value: -1 };
            $scope.patients = generatePatientArray(0, 10);

            $scope.selectPatient(patient);
            expect($scope.selectedItemObj.value).to.equal(-1);

            deferred.resolve();
            $scope.$apply();

            $timeout.flush();
            expect($scope.selectedItemObj.value).to.equal(1);
            expect($scope.patientGenericListAPI.scrollTo.calledWith(1)).to.be.true;

            $scope.selectPatient(patient);
            expect($scope.selectedItemObj.value).to.equal(1);
            
        });

        it('should select the patient', function () {
            var patient = new Patient({rid: 2});

            $scope.patients = generatePatientArray(0, 10);
            $scope.selectedItemObj = { value: -1 };

            $scope.selectPatient(patient);

            $timeout.flush();
            expect($scope.selectedItemObj.value).to.equal(1);
            expect($scope.patientGenericListAPI.scrollTo.calledWith(1)).to.be.true;
        });

        var generatePatientArray = function (offset, limit) {
            var patients = [];
            for(var i = 0; i < limit; i++) {
                patients.push({ rid: (i + 1 + offset) });
            }
            return patients;
        }

        it('should load more pages until finde out the selected patient', function () {
            var patient = new Patient({rid: 21});
            var d1 = $q.defer();
            var d2 = $q.defer();

            $scope.selectedItemObj = { value: -1 };
            $scope.patients = generatePatientArray(0, 10);
            $scope.totalRecords = 30;
            $scope.offset = 0;
            $scope.limit = 10;

            mock.expects('listMyPatients').withArgs(10, 10, null).returns(d1.promise);
            mock.expects('listMyPatients').withArgs(20, 10, null).returns(d2.promise);

            $scope.selectPatient(patient);

            var data1 = {
                totalRecords: 30,
                listPatientVO: generatePatientArray(10, 10)
            };
            var data2 = {
                totalRecords: 30,
                listPatientVO: generatePatientArray(20, 10)
            };
            d1.resolve(data1);
            d2.resolve(data2);

            $scope.$apply();

            $timeout.flush();
            expect($scope.selectedItemObj.value).to.equal(20);
            expect($scope.patientGenericListAPI.scrollTo.calledWith(20)).to.be.true;
            mock.verify();
        });
		
		it('should the value of field text will be clear', function () {
            var fieldName = "text";
			$scope.search[fieldName] = 'anyvalue';
			
			$scope.onScript(fieldName);
            expect($scope.search[fieldName]).to.equal('');
        });
    });
});