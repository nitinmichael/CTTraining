define(['angular-mocks', 'virtual-viewer/filters/name-filter'], function() {
    'use strict';
    
    describe('name filter', function() {

        var nameFilter;
    
        beforeEach(module('Filters.name'));
        beforeEach(inject(function(_$filter_) {
            nameFilter = _$filter_('name');
        }));
    
    
        it('should empty when given names', function() {
            expect(nameFilter()).to.equal("");
        });
        
        it('should return family name only when no given name', function() {
            var names = {
                family: ['family']
            };
            
            expect(nameFilter(names)).to.equal('family');
        });
        
        it('should return concatenated name', function() {
            var names = {
                family: ['family1', 'family2'],
                given: ['given1', 'given2']
            };
            
            expect(nameFilter(names)).to.equal('family1 family2, given1 given2');
        });
    });
});
