/*
 * ge-drag-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular-mocks', 'jquery', 'modules/platform/directives/ge-drag-clone'], function() {
    describe('Test  unselectable', function() {
        var scope, rootScope, element, $compile, $sce;

        beforeEach(module('platform.directive.ge-drag-clone'));

        beforeEach(function() {
            inject(function($rootScope, _$compile_, _$sce_) {
                rootScope = $rootScope;
                $compile = _$compile_;
                $sce = _$sce_;
                scope = rootScope.$new();
                element = $compile("<div ge-drag-clone=\"true\"></div>")(scope);
            });
        });

        it('must run onDragStart on draggable:start event broadcasted', function() {
            var dragElement = $compile("<div>drag</div>")(scope);
            var _x = 100;
            var _y = 100;
            expect($(element[0]).css('visibility')).to.equal('hidden');
            rootScope.$broadcast('draggable:start', {
                tx: _x,
                ty: _y,
                element: dragElement
            });
            scope.$apply();
            expect($(element[0]).css('visibility')).to.equal('visible');
            expect($(element[0]).css('transform')).to.equal('matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, ' + _x + ', ' + _y + ', 0, 1)');

        });

        it('must run onDragMove on draggable:move event broadcasted', function() {
            var dragElement = $compile("<div>drag</div>")(scope);
            var _x = 200;
            var _y = 100;
            expect($(element[0]).css('visibility')).to.equal('hidden');
            rootScope.$broadcast('draggable:move', {
                tx: _x,
                ty: _y,
                element: dragElement,
                dragOffset: {
                    left: 0,
                    right: 0
                }
            });
            scope.$apply();
            expect($(element[0]).css('visibility')).to.equal('visible');
        });

        it('must run onDragEnd on draggable:end event broadcasted', function() {
            var dragElement = $compile("<div>drag</div>")(scope);
            var _x = 100;
            var _y = 100;
            expect($(element[0]).css('visibility')).to.equal('hidden');
            rootScope.$broadcast('draggable:start', {
                tx: _x,
                ty: _y,
                element: dragElement
            });
            scope.$apply();
            expect($(element[0]).css('visibility')).to.equal('visible');

            rootScope.$broadcast('draggable:end');
            scope.$apply();
            expect($(element[0]).css('visibility')).to.equal('hidden');

        });
    });
});
