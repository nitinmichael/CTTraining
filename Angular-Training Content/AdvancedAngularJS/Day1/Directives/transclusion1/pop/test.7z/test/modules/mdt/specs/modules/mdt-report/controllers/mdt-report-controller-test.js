/*
 * mdt-report-controller.js
 * 
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 * 
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 * 
 *
 */

define([ 'angular', 'angular-mocks', 'mdt/modules/mdt-report/controllers/mdt-report-controller' ], function() {
    'use strict';

    var rootScope, scope, controller, log, stateParams, state;

    describe('Mdt Report Controller Test Suite::', function() {
        beforeEach(function() {
            module('Mdt.Module.MdtReportController', function($provide) {
                $provide.value('$state', {
                    transitionTo : function(url) {
                    },
                    go : function(url) {
                    },
                    current : {
                        params : {}
                    }
                });
            });
        });


        // Initialize the scope and controller variables
        beforeEach(inject(function($rootScope, $controller, $log, $state) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            controller = $controller;
            log = $log;
            stateParams = {
            };
            state = $state;
            state.params = {
                sessionId: 'abc123'
            };

            // Initialize the controller before each specs
            controller('mdtReportController', {
                $scope : scope,
                $stateParams: stateParams,
                $state: state,
                $log: log
            });
        }));

        it('should have a controller', function() {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it('should go back to inbox page', function() {
            var stateSpy = sinon.spy(state, "transitionTo");
            scope.cancelForm();
            assert(stateSpy.calledWith('mdt-session.list.details'));
        });

        it('should redirect to fullsize state from default one', function() {
            var basicState = {
                current: {
                    name: 'mdt-report'
                },
                transitionTo: sinon.spy()
            };

            controller('mdtReportController', {
                $scope: scope,
                $stateParams: stateParams,
                $state: basicState,
                $log: log
            });

            expect(basicState.transitionTo.calledWith('mdt-report.fullsize')).to.be.true;
        });
    });
});