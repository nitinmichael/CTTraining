Cursor3D = (function() {
    function Cursor3D(volumeId) {
        this.parent_id = volumeId;
        this.channel = { subscribe : function() {}, publish : function() {} };
        this.position = undefined;
        this.name = undefined;
        this.id = undefined;
    }
    Cursor3D.prototype.setPosition = function(position) {
        position = position;
    };

    Cursor3D.prototype.getVolumeId = function() {
        return this.parent_id;
    };

    Cursor3D.prototype.getChannel = function() {
        return this.channel;
    };

    return Cursor3D;
})();
