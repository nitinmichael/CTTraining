/*
 *  case-inbox-controller-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Henry Navarro<henry.navarro@ge.com>
 */

/**
 * Spec file for Case Inbox controller module
 */

define(['angular',
        'angular-mocks', 'modules/analytics/controllers/analytics-dashboard-controller'], function () {

    'use strict';
    var scope, controller, rootScope, caseDataService, caseExchangeDataService, getPacsServices, caseTransactions, caseDetailsJSON, caseHeaderJSON, caseReviewedDetailsJSON, caseDicomAttachment,
    $q, caseUpdateType,  mockServer, $mockServerLoader, meServiceResponse, timeout;

    describe('Analytics Controller Test Suite::', function () {

        beforeEach(
            // Load the module for the mock data first
           // module('cloudav.analytics.mocks');
            // Load the Sinon fake server.
            //module('cloudav.analytics.fakeServer');

            module('cloudav.caseExchange.analyticsDashboardCtrl', function () {


            })
        );

        // Initialize the scope and controller variables
        beforeEach(inject(
            function ($rootScope, $controller, _$q_,
                      $timeout) {
                scope = $rootScope.$new();
                rootScope = $rootScope;
                controller = $controller;
                $q = _$q_;

                // Initialize the controller before each spec
                controller('analyticsDashboardCtrl', {
                    $scope: scope
                });

                // Mocking the variable from parent controller as we don't have inheritance in place in unit testing.
                scope.alertTypes = {
                    success: 'success',
                    error: 'error'
                };

                // Mocking the method from parent controller as we don't have inheritance in place in unit testing.
                scope.showAlertMessage = function () {
                };


            }
        ));

        it('should have a controller', function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

    });
});
