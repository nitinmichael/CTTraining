angular.module('cloudav.viewerApp.mousemanagement', [])
    .service('mousemodetoolbarFactory', function ($http) {
        return $http.get('');

    }).factory('imageAreaToolbarFactory', function ($http) {
        var operation = {};
        operation.data = {};
        operation.success = function (data) {};
        return operation;
    });