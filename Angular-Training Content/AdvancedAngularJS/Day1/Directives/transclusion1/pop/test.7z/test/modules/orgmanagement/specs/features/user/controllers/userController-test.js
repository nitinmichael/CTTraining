/**
 *  userController-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */
define(['angular', 'angular-mocks','orgMgmnt/features/user/controllers/userController'],
    function (ng) {
        'use strict';

        describe('Test UserController', function(){

            var scope, _userController, _appConfig, _log, _state, stateProvider;

            beforeEach( function(){
                module('Orgmanagement.Features.User.Controller.UserController');
                module('Orgmanagement.Utilities.MasterData');
                module('ui.router');
            });

            var appDescriptors = [
                {
                    abstract: true,
                    autoStart: "false",
                    href: "/viewer",
                    name: "viewer"
                },
                {
                    abstract: true,
                    autoStart: "true",
                    href: "/orgmanagement",
                    name: "orgmanagement"
                }];
            var endPoint = 'http://case-api-gateway.ge.com';

            beforeEach(function () {
                module('Orgmanagement.Features.User.Controller.UserController', function ($provide) {
                    $provide.provider('uaf.appshell.AppConfig', function () {
                        this.getAppDescriptors = function(){
                            return appDescriptors;
                        }

                        this.$get = function() {
                            return this;
                        };
                    });
                    $provide.provider('$Endpoint', function () {
                        this.getEndpoint = function(){
                            return endPoint;
                        }

                        this.$get = function() {
                            return this;
                        };
                    });
                });
            });

            beforeEach(inject(function($controller, $rootScope, $log, $state){
                scope = $rootScope.$new();
                _log = $log;
                _state = $state;

                sinon.stub(_log, 'log');
                _state.go = sinon.stub();
                _userController = $controller('UserMainCtrl', {$scope:scope});
            }));

            describe('Test User Main Controller', function () {
                it('should test the controller is defined', function(){
                    chai.expect(_userController).to.be.not.undefined;
                });

                it('should test the transition to', function(){
                    chai.expect(_state.go).to
                        .have.been.calledOnce
                        .and.calledWith('userSelfRegister.login');
                });

            });

        });

    });
