/***************************************************************************************************
 * Copyright (c) 2015 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * Test suite for GE Input Patterns Service
 *
 * @author
 * Henry Navarro <henry.navarro@ge.com>
 *
 ***************************************************************************************************/
define([
    'angular',
    'angular-mocks',
    'modules/caseexchange/widgets/ge-xss/input-patterns-service'], function() {
    'use strict';
    describe('TestSuite for GE Input Patterns', function() {
        var inputPatterns;
        beforeEach(function(){
            module('Services.inputPatterns');
        });

        // main suite preparation:
        // inject the $compile and $rootScope services,
        // add the callback functions for scripting and invalid format detection,
        // and add spies on the callback functions

        beforeEach(inject(function(InputPatterns) {
            inputPatterns = InputPatterns;
        }));

        it('Service should match a zip code', function() {
            expect(inputPatterns.matches('94583', inputPatterns['zipCode'])).to.be.true;
        });

        it('Service should match an email address', function() {
            expect(inputPatterns.matches('a.b@c.com', inputPatterns['email'])).to.be.true;
        });

        it('Service should not match an email', function() {
            expect(inputPatterns.matches('a.b@c', inputPatterns['email'])).to.be.false;
        });
    });
});
