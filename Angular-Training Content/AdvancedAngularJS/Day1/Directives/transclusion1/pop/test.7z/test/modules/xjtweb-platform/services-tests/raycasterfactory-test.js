define([ 'angular', 'angular-mocks', 'modules/xjtweb-platform/services/ray-caster-factory' ], function(ng, mocks) {
    'use strict';

    describe('Raycaster factory', function() {
        var raycasterFactory;

        function mockRaycasterFactory() {
        }

        beforeEach(module('raycaster-factory'));

        beforeEach(module(function($provide) {
            $provide.factory('$xjtweb', function() {
                return {
                    XJTWEB : {
                        RaycasterFactory : mockRaycasterFactory
                    }
                };
            });
        }));

        beforeEach(inject(function(RaycasterFactory) {
            raycasterFactory = RaycasterFactory;
        }));

        it('raycasterFactory should have been an instanceof mockRaycasterFactory', function() {
            expect(raycasterFactory instanceof mockRaycasterFactory).to.equal(true);
        });
    });
});