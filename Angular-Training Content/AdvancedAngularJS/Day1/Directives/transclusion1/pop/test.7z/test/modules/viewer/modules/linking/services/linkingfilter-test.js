define(['angular', 'angular-mocks', 'linkingModule/services/linkingfilter'], function(ng, mocks) {
    'use strict';

    describe('linking filter test', function() {

        var linkingFilterFactory;
        var scope;

        beforeEach(module('cloudav.viewerApp.linkingviewport'));

        beforeEach(inject(function(linkingFilter, $rootScope) {
            scope = $rootScope;
            linkingFilterFactory = linkingFilter;
        }));

        it('should add a filter', function() {
            expect(linkingFilterFactory.exists('event', 'filter')).to.equal(false);
            linkingFilterFactory.add('event', 'filter', function(viewId, data) {});
            expect(linkingFilterFactory.exists('event', 'filter')).to.equal(true);
        });


        it('should remove a filter if it exists', function() {
            expect(linkingFilterFactory.exists('event', 'filter')).to.equal(false);
            linkingFilterFactory.add('event', 'filter', function(viewId, data) {});
            expect(linkingFilterFactory.exists('event', 'filter')).to.equal(true);
            linkingFilterFactory.remove('event', 'filter');
            expect(linkingFilterFactory.exists('event', 'filter')).to.equal(false);
        });


        it('"remove" function should not fail if event don\'t have filters', function() {
            expect(linkingFilterFactory.exists('notexisting', 'filter')).to.equal(false);
            linkingFilterFactory.remove('notexisting', 'filter');
        });

        it('"remove" function should not fail if filter not exist', function() {
            linkingFilterFactory.add('event', 'filter', function(viewId, data) {});
            expect(linkingFilterFactory.exists('event', 'filter')).to.equal(true);
            expect(linkingFilterFactory.exists('event', 'filter1')).to.equal(false);
            linkingFilterFactory.remove('event', 'filter1');
        });

        it('"check" function return promise if event does not exist', function() {
            expect(linkingFilterFactory.exists('event', 'filter')).to.equal(false);
            linkingFilterFactory.check('event', 'viewport1', 'data').then(function(res) {
                expect(res).to.be.equal('event');
            }).catch(function(error) {});

            scope.$apply();
        });

        it('"check" function should return resolved promise if filters are checked', function() {
            linkingFilterFactory.add('event', 'filter', function(viewId, data) {
                return true;
            });
            expect(linkingFilterFactory.exists('event', 'filter')).to.equal(true);
            linkingFilterFactory.check('event', 'viewport1', null).then(function(res) {
                expect(res[0]).to.equal(true);
            }).catch(function(error) {
                expect(error).to.equal(undefined);
            });
            scope.$apply();
        });

        it('"check" function should return rejected promise if one of filters is not checked', function() {
            linkingFilterFactory.add('event', 'filter1', function(viewId, data) {
                return true;
            });
            linkingFilterFactory.add('event', 'filter2', function(viewId, data) {
                return false;
            });
            expect(linkingFilterFactory.exists('event', 'filter1')).to.equal(true);
            expect(linkingFilterFactory.exists('event', 'filter2')).to.equal(true);

            linkingFilterFactory.check('event', 'viewport1', null).then(function(res) {
                expect(res).to.equal(undefined);
            }).catch(function(error) {
                expect(error).to.equal(false);
            });
            scope.$apply();
        });

        it('add function should fail if event name or filter name is not given, ', function() {
            var callback = function(viewId, data) {
                return true;
            };
            expect(function() {
                linkingFilterFactory.add(undefined, undefined, callback);
            }).to.throw(Error, 'The event name and filter name must have a value');
            expect(function() {
                linkingFilterFactory.add('', undefined, callback);
            }).to.throw(Error, 'The event name and filter name must have a value');
            expect(function() {
                linkingFilterFactory.add(undefined, '', callback);
            }).to.throw(Error, 'The event name and filter name must have a value');
        });

        it('add function should fail if callback is not a function, ', function() {
            expect(function() {
                linkingFilterFactory.add('event', 'filter', null);
            }).to.throw(Error, 'The callback should be a function');
            expect(function() {
                linkingFilterFactory.add('event', 'filter', 'not_a_function');
            }).to.throw(Error, 'The callback should be a function');
        });

        it('add function should fail if filter exist, ', function() {
            var callback = function(viewId, data) {
                return true;
            };
            linkingFilterFactory.add('event', 'filter', callback);
            expect(function() {
                linkingFilterFactory.add('event', 'filter', callback);
            }).to.throw(Error, 'The callback already exists');
        });

        it('callback should have 2 paramters', function() {
            var callback0 = function() {
                return true;
            };
            var callback1 = function(arg) {
                return true;
            };

            expect(function() {
                linkingFilterFactory.add('event1', 'filter', callback0);
            }).to.throw(Error, 'callback must take 2 parameters.');

            expect(function() {
                linkingFilterFactory.add('event2', 'filter', callback1);
            }).to.throw(Error, 'callback must take 2 parameters.');
        });

    });
});
