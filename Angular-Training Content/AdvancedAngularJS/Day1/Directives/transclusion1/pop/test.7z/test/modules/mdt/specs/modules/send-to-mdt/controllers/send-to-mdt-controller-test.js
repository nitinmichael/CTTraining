/*
 * normalization-controller.js
 * 
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 * 
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 * 
 * @author: Raoul Nair<raoul.nair@ge.com>
 */

define([ 'angular', 'angular-mocks', 'mdt/modules/send-to-mdt/controllers/send-to-mdt-controller' ], function() {
    'use strict';

    var rootScope, scope, controller, http, log, stateParams, endPoint, state, caseId;

    describe('Send to mdt  Controller Test Suite::', function() {
        var MdtGroupService, $httpBackend, NotificationService;
        var ROOT_URL = 'http://localhost:8080';
        var AVAILABLE_GROUPS_URL = ROOT_URL + "/views/send-case-to-mdt/available-groups";
        var TOOLTIP_INFO_URL = ROOT_URL + "/views/send-case-to-mdt/group-tooltip?groupId=";
        var SEND_CASE_URL = ROOT_URL + "/views/send-case-to-mdt/send";

        var group = {name: "Oncology Team 1 group", id: "e7f46cef-b6fa-4cc5-a889-5298b1194321", $$hashKey: "object:750"};
        var tooltipInfo = {
            groupName: "Oncology Team 1 group",
            scheduling: [
                {
                    type: "Daily",
                    time: [
                        18,
                        15
                    ]
                }
            ],
            members: [
            ],
            admins: [
                {
                    reference: null,
                    display: "Dr. Marcus Welby",
                    id: "707e4aa8-ef8a-4608-8baf-2b7bddcfdee4",
                    firstName: "Dr.",
                    lastName: "Marcus"
                }
            ]
        };

        var availableGroups = {
            groups: [
                {
                    name: "Kaiser01 MDT group",
                    id: "486bbb52-e280-4cfd-b672-2f1cd59b927e"
                },
                {
                    name: "Oncology Team 1 group",
                    id: "e7f46cef-b6fa-4cc5-a889-5298b1194321"
                },
                {
                    name: "Kaiser MDT group1",
                    id: "dc68ddba-48cd-4b81-b7b7-53fc0c3e9c12"
                }
            ],
            recentlyUsedGroups: [
                {
                    name: "Oncology Team 1 group",
                    id: "e7f46cef-b6fa-4cc5-a889-5298b1194321"
                }
            ]
        };

        beforeEach(function() {
            module('Mdt.Module.SendToMDTCtrl', function($provide) {
                $provide.value('$state', {
                    transitionTo : function(url) {
                    },
                    go : function(url) {
                    },
                    current : {
                        params : {}
                    }
                });

                $provide.value('$Endpoint', {
                    getEndpointAsync: function(){
                        return {
                            then: function(success){
                                var publicAPI = success(ROOT_URL);
                                return {
                                    then: function(fn){
                                        fn(publicAPI);
                                    }
                                };
                            }
                        };
                    }
                });
            });

            angular.module('Platform.Services.NotificationService',[])
                    .service('NotificationService', [function(){
                        return {
                            addSuccessMessage: sinon.stub(),
                            addErrorMessage: sinon.stub()
                        }
                    }]);
        });


        // Initialize the scope and controller variables
        beforeEach(inject(function($rootScope, $controller, $http, $log, $state, _$httpBackend_, _NotificationService_) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            controller = $controller;
            caseId = {};
            http = $http;
            log = $log;
            stateParams = {
                selectedCaseId: "4356298256986982359382"
            };
            state = $state;

            NotificationService = _NotificationService_;

            // Initialize the controller before each specs
            controller('sendToMDTCtrl', {
                $scope : scope,
                caseId: caseId,
                $stateParams: stateParams,
                $state: state,
                NotificationService: NotificationService,
            });
            $httpBackend = _$httpBackend_;
        }));

        it('should have a controller', function() {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it('should go back to inbox page', function() {
            var stateSpy = sinon.spy(state, "go");
            scope.cancelForm();
            assert(stateSpy.calledWith('caseexchange.caseinbox'));
        });

        it('remove the selected mdt group', function() {
            scope.selectedMember = {name: "Oncology Team 1", id: "e7f46cef-b6fa-4cc5-a889-5298b1194321", $$hashKey: "object:750"};
            scope.searchFieldModel = "onc";
            scope.removeGroup();
            expect(scope.selectedMember).to.be.empty;
            expect(scope.searchFieldModel).to.equal("");
        });

        it("select an mdt group and search for it's tooltip infos", function() {
            $httpBackend.whenGET(AVAILABLE_GROUPS_URL).respond(200,availableGroups);
            $httpBackend.whenGET(TOOLTIP_INFO_URL + group.id).respond(200,tooltipInfo);
            scope.selectMember(group);
            $httpBackend.flush();

            expect(scope.selectedMember).to.deep.equal(group);
            expect(scope.selectedGroupTooltipInfo).to.deep.equal(tooltipInfo);
        });

        it("if get available groups request fails, the group list info remains empty", function() {
            $httpBackend.whenGET(AVAILABLE_GROUPS_URL).respond(404);
            $httpBackend.flush();

            expect(scope.groupDetails).to.deep.equal({
                groups: [],
                recentlyUsedGroups: []
            });
        });

        it("if get tooltip request fails, the tooltip info remains empty", function() {
            $httpBackend.whenGET(AVAILABLE_GROUPS_URL).respond(200,availableGroups);
            $httpBackend.whenGET(TOOLTIP_INFO_URL + group.id).respond(404);
            scope.selectMember(group);
            $httpBackend.flush();

            expect(scope.selectedMember).to.deep.equal(group);
            expect(scope.selectedGroupTooltipInfo).to.deep.equal({});
        });

        it('search for an mdt group by groupname', function() {
            scope.groupDetails = availableGroups;
            //every groupname contains 'gr' chars, so it returns all of them
            var searchResult = scope.searchGroup('gr');
            expect(searchResult).to.deep.equal(availableGroups.groups);
            searchResult = {};
            searchResult = scope.searchGroup('on');
            expect(searchResult).to.deep.equal([availableGroups.groups[1]]);
        });

        it('selects an mdt group and sends the case to mdt', function() {
            var stateSpy = sinon.spy(state, "go");

            var successResponse = {
                meetingId: "TestMeetingId",
                groupId: "TestGroupId",
                meetingDate: 1455196533947
            };

            $httpBackend.whenGET(AVAILABLE_GROUPS_URL).respond(200,availableGroups);
            $httpBackend.whenGET(TOOLTIP_INFO_URL + group.id).respond(200,tooltipInfo);
            $httpBackend.expectPOST(SEND_CASE_URL).respond(200, successResponse);
            //select mdt group
            scope.selectMember(group);
            //insert blank comment
            scope.mdtcomment = "";

            scope.sendToMDT();
            $httpBackend.flush();

            assert(stateSpy.calledWith('caseexchange.caseinbox'));
        });

        it('should show success message when send was success', function() {
            var stateSpy = sinon.spy(state, "go");

            var successResponse = {
                meetingId: "TestMeetingId",
                groupId: "TestGroupId",
                meetingDate: 1455196533947
            };

            $httpBackend.whenGET(AVAILABLE_GROUPS_URL).respond(200,availableGroups);
            $httpBackend.whenGET(TOOLTIP_INFO_URL + group.id).respond(200,tooltipInfo);
            $httpBackend.expectPOST(SEND_CASE_URL).respond(200, successResponse);
            //select mdt group
            scope.selectMember(group);
            //insert blank comment
            scope.mdtcomment = "";

            scope.sendToMDT();
            $httpBackend.flush();

            expect(NotificationService.addSuccessMessage.calledOnce).to.be.true;
            expect(NotificationService.addSuccessMessage).to.have.been.calledWith("Case was successfully scheduled for " +
                scope.formatDate(new Date(successResponse.meetingDate)) + " to " + group.name + ".");
        });

        it('should show success message without date when send was success for on demand session', function() {
            var stateSpy = sinon.spy(state, "go");

            var successResponse = {
                meetingId: "TestMeetingId",
                groupId: "TestGroupId",
                meetingDate: null
            };

            $httpBackend.whenGET(AVAILABLE_GROUPS_URL).respond(200,availableGroups);
            $httpBackend.whenGET(TOOLTIP_INFO_URL + group.id).respond(200,tooltipInfo);
            $httpBackend.expectPOST(SEND_CASE_URL).respond(200, successResponse);
            //select mdt group
            scope.selectMember(group);
            //insert blank comment
            scope.mdtcomment = "";

            scope.sendToMDT();
            $httpBackend.flush();

            expect(NotificationService.addSuccessMessage.calledOnce).to.be.true;
            expect(NotificationService.addSuccessMessage).to.have.been.calledWith("Case was successfully scheduled for " +
                scope.formatDate(null) + " to " + group.name + ".");
        });

        it('selects an mdt group and sends the case to mdt, but the request fails', function() {
            var stateSpy = sinon.spy(state, "go");
            $httpBackend.whenGET(AVAILABLE_GROUPS_URL).respond(200,availableGroups);
            $httpBackend.whenGET(TOOLTIP_INFO_URL + group.id).respond(200,tooltipInfo);
            $httpBackend.expectPOST(SEND_CASE_URL).respond(400);
            //select mdt group
            scope.selectMember(group);
            //insert blank comment
            scope.mdtcomment = "";

            scope.sendToMDT();
            $httpBackend.flush();
            rootScope.$digest();

            assert(stateSpy.calledWith('caseexchange.caseinbox'));
        });

        it('should show error message when send was success', function() {
            var stateSpy = sinon.spy(state, "go");
            $httpBackend.whenGET(AVAILABLE_GROUPS_URL).respond(200,availableGroups);
            $httpBackend.whenGET(TOOLTIP_INFO_URL + group.id).respond(200,tooltipInfo);
            $httpBackend.expectPOST(SEND_CASE_URL).respond(400);
            //select mdt group
            scope.selectMember(group);
            //insert blank comment
            scope.mdtcomment = "";

            scope.sendToMDT();
            $httpBackend.flush();
            rootScope.$digest();

            expect(NotificationService.addErrorMessage.calledOnce).to.be.true;
            expect(NotificationService.addErrorMessage).to.have.been.calledWith("Sending case to " + group.name + " has failed, please try again.");
        });

        it('should format date properly if number of days and months are less than 10', function() {
            var meetingDateToFormat = new Date(1457478000000);      //09.03.2016

            expect(scope.formatDate(meetingDateToFormat)).to.be.equal("09.03.2016.");

        });

        it('should format date properly if number of days and months are more than 10', function() {
            var meetingDateToFormat = new Date(1476309600000);      //13.10.2016

            expect(scope.formatDate(meetingDateToFormat)).to.be.equal("13.10.2016.");

        });

        it('should not format date if there is no date (on demand)', function() {
            var meetingDateToFormat = null;

            expect(scope.formatDate(meetingDateToFormat)).to.be.equal("the next On demand session");

        });
    });
});