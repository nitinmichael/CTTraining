define(['angular', 'angular-mocks','orgMgmnt/dataModels/userDataModel'],
    function(ng){
        'use strict';

        describe('Test User Data Model ', function(){
            var _userDataModel;

            beforeEach( function(){
                module('Orgmanagement.DataModel.UserDataModel');
            });

            beforeEach(inject(function(userDataModel){
                _userDataModel = userDataModel;
            }));

            describe('When userPreferredLanguage  is called', function(){
                it('should test the return value', function(){

                    var preferredLanguage  = _userDataModel.userPreferredLanguage();
                    chai.expect(preferredLanguage).to.be.equal('English');
                });
            });

            describe('When userGender  called ',function(){
                it('should test the return of variable', function(){

                    var userGender =  _userDataModel.userGender();
                    chai.expect(userGender.coding[0].code).to.be.equal('M');
                });
            });

                describe('When acceptedAgreementObject  called ',function(){
                    it('should test the return of variable', function(){

                        var acceptedAgreementObject =  _userDataModel.acceptedAgreementObject();
                        chai.expect(acceptedAgreementObject).to.have.length(1);
                    });
                });


                    describe('When jobTileCoding   called ',function(){
                        it('should test the return of variable', function(){

                            var jobTitleCoding  =  _userDataModel.jobTileCoding ();
                            chai.expect(jobTitleCoding).to.have.length(1);
                        });
                    });

            describe('When divisionRef  called ',function(){
                it('should test the return of variable', function(){

                    var divisionRef = _userDataModel.divisionRef ();
                    chai.expect(divisionRef.reference).to.be.equal('organization/2');
                });
            });

            describe('When departmentRef called ',function(){
                it('should test the return of variable', function(){

                    var departmentRef = _userDataModel.departmentRef ();
                    chai.expect(departmentRef.reference).to.be.equal('organization/3');
                });
            });

                describe('When managerRef called ',function(){
                    it('should test the return of variable', function(){

                        var managerRef = _userDataModel.managerRef ();
                        chai.expect(managerRef.reference).to.be.equal('user/1');
                    });

                });

            describe('When getManagingOrganization  called ',function(){
                it('should test the return of variable', function(){

                    var managingOrganization  = _userDataModel.getManagingOrganization();
                    chai.expect(managingOrganization.jobTitle.text).to.be.equal('Manager');
                });
            });


            describe('When getAffiliatedOrganizationRef   called ',function(){
                it('should test the return of variable', function(){

                    var affiliatedOrganizationRef  = [];
                    affiliatedOrganizationRef= _userDataModel.getAffiliatedOrganizationRef ();
                    chai.expect(affiliatedOrganizationRef).to.have.length(1);
                });
            });

            describe('When getAcceptedAgreement    called ',function(){
                it('should test the return of variable', function(){


                    var acceptedAgreement= _userDataModel.getAcceptedAgreement  ();
                    chai.expect(acceptedAgreement).not.be.undefined;
                });
            });

            describe('When getAffiliatedOrganization    called ',function(){
                it('should test the return of variable', function(){


                    var affiliatedOrganization= _userDataModel.getAffiliatedOrganization();
                    chai.expect(affiliatedOrganization).not.be.undefined;
                });
            });

            describe('When getAssignedResource called ',function(){
                it('should test the return of variable', function(){


                    var assignedResource= _userDataModel.getAssignedResource();
                    chai.expect(assignedResource).not.be.undefined;
                });
            });

            describe('When getName called ',function(){
                it('should test the return of variable', function(){

                    var firstname = "FN";
                    var middleName = "";
                    var lastname ="LN";

                    var name= _userDataModel.getName(firstname,middleName,lastname);


                    chai.expect(name.given).to.have.length(1);
                });
            });



        });
    });
