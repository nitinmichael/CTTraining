/*
 * ge-na-filter-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */

define([ 'angular', 'angular-mocks', 'lodash', 'modules/platform/filters/ge-na-filter' ], function() {
    describe('NA filter tests', function() {
        var naFilter;

        beforeEach(module('platform.filter.ge-na-filter', function($translateProvider) {

            // mock language tables
            $translateProvider.translations('en', {
                "platform.na-filter.na" : "NA"
            });

            $translateProvider.preferredLanguage('en');
        }));

        beforeEach(inject(function(_$filter_) {
            naFilter = _$filter_('geNa');
        }));

        it("should have a filter defined", function() {
            assert.isDefined(naFilter, 'filter is not defined');
        });

        it("should return the original string if it is not missing", function() {
            var string = 'existing string', result = naFilter(string);

            expect(result).to.be.equal(string);
        });

        var falsyStrings = [ '', null, undefined ];

        function structuredTest(tests) {
            _.forEach(tests, function(test) {
                _.forEach(test.strings, function(string) {
                    var args = [ string ];
                    if (test.customNA) {
                        args.push(test.customNA);
                    }
                    expect(naFilter.apply(this, args)).to.be.equal(test.expected);
                });
            })
        }

        it("should return the translated 'platform.na-filter.na' text ('NA'), if the string is missing", function() {
            var expectedString = 'NA';
            structuredTest([ {
                strings : falsyStrings,
                expected : expectedString
            } ]);
        });

        it("should return custom NA if the string is missing", function() {
            var customNAString = 'Custom NA';
            var customNAString2 = 'blabla';
            structuredTest([ {
                strings : falsyStrings,
                customNA : customNAString,
                expected : customNAString
            }, {
                strings : falsyStrings,
                customNA : customNAString2,
                expected : customNAString2
            } ]);
        });

    });
});
