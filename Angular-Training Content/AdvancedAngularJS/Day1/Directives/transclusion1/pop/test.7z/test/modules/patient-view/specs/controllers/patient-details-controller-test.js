/*
 * patient-management-controller-test.js
 * 
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 * 
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */

define([
    'postal',
    'angular',
    'angular-mocks',
    'patient-view/modules/patient-management/controllers/patient-details-controller'
], function (postal, ng) {
    'use strict';

    describe('Patient Details Controller Test Suite::', function () {

        var $rootScope;
        var $controller;
        var $q;
        var $timeout;
        var $filter;
        var $state;
        var $stateParams;
        var Patient;
        var NotificationService;
        var TimeCalcService;

        var $scope;
        var rid;
        var PatientMock;
        var patient;
        var getPatientDeferred;

        beforeEach(function () {
            ng.module('Platform.Services.NotificationService', []);

            module('cloudav.patient-view.patient-management', function ($provide) {
                $provide.value('translateFilter', function (value) {
                    return value;
                });

                $provide.service('$Endpoint', function() {
                    this.getEndpoint = function (key) {
                        return 'http://ge.test.fake.nonexistentdomain';
                    };

                    this.getEndpointAsync = function () { };
                });

                $provide.service('NotificationService', function () {
                    this.addErrorMessage = function (msg) {
                        console.log("Error msg: ", msg);
                    };

                    this.addSuccessMessage = function (msg) {
                        console.log("Success msg: ", msg);
                    };
                });

                $provide.service('$state', function () {
                    this.go = function (destination, args) {
                        console.log('$state.go()', destination, args);
                    };
                });

                $provide.value('$stateParams', {});
            });
        });

        beforeEach(inject([
            '$rootScope',
            '$controller',
            '$q',
            '$timeout',
            '$filter',
            '$state',
            '$stateParams',
            'Patient',
            'NotificationService',
            'TimeCalcService',
        function (
            _$rootScope,
            _$controller,
            _$q,
            _$timeout,
            _$filter,
            _$state,
            _$stateParams,
            _Patient,
            _NotificationService,
            _TimeCalcService
        ) {
            $rootScope = _$rootScope;
            $controller = _$controller;
            $q = _$q;
            $timeout = _$timeout;
            $filter = _$filter;
            $state = _$state;
            $stateParams = _$stateParams;
            Patient = _Patient;
            NotificationService = _NotificationService;
            TimeCalcService = _TimeCalcService;

            PatientMock = sinon.mock(Patient);
            $scope = $rootScope.$new();
            rid = 'de314819-9ed6-3389-bb77-b8c24462215d';
            $stateParams.rid = rid;
            patient = new Patient({ rid: rid });
            getPatientDeferred = $q.defer();
        }]));

        afterEach(function () {
            PatientMock.restore();
        });

        describe('Test constructor', function () {

            var postalMock;

            beforeEach(function () {
                PatientMock.expects('getPatient').withArgs(rid).returns(getPatientDeferred.promise);
                postalMock = sinon.mock(postal);
            });

            afterEach(function () {
                postalMock.restore();
            })
            
            it('should load patient if rid is presented', function () {
                $controller('PatientDetailsCtrl', { $scope:$scope });
                $scope.selectPatient = sinon.spy();
                $scope.$parent.selectPatient = sinon.spy();
                expect(PatientMock.verify());

                getPatientDeferred.resolve(patient);
                $rootScope.$apply();

                expect($scope.selectPatient.calledWith(patient)).to.be.true;
                expect($scope.$parent.selectPatient.calledWith(patient)).to.be.true;
            });

            it('should subscribe in postal to gettingStudies.error, gettingUpdatedStudies.error and gettingUpdatedStudies.success topics ', function () {
                var unsubscribe = sinon.spy();

                postalMock.expects('subscribe').withArgs(sinon.match({
                    channel: Patient.channel,
                    topic: Patient.topics.gettingStudies.error
                })).returns({ unsubscribe: unsubscribe });

                postalMock.expects('subscribe').withArgs(sinon.match({
                    channel: Patient.channel,
                    topic: Patient.topics.gettingUpdatedStudies.error
                })).returns({ unsubscribe: unsubscribe });

                postalMock.expects('subscribe').withArgs(sinon.match({
                    channel: Patient.channel,
                    topic: Patient.topics.gettingUpdatedStudies.success
                })).returns({ unsubscribe: unsubscribe });

                $controller('PatientDetailsCtrl', { $scope:$scope });

                postalMock.verify();

                var timeoutCancelspy = sinon.spy($timeout, 'cancel');

                $scope.$destroy();

                expect(unsubscribe.calledThrice).to.be.true;
                expect(timeoutCancelspy.calledOnce).to.be.true;
                timeoutCancelspy.restore();
            });
        });

        describe('Test $scope', function () {

            var patientMock;
            var NSerrorSpy;
            var NSsuccessSpy;
            var postalStub;

            var subscriptions;

            var getSubscription = function (topic) {
                for(var i = 0; i < subscriptions.length; i++) {
                    if(subscriptions[i].topic === topic) {
                        return subscriptions[i];
                    }
                }
            };

            beforeEach(function () {
                PatientMock.expects('getPatient').withArgs(rid).returns(getPatientDeferred.promise);

                patientMock = sinon.mock(patient);

                NSerrorSpy = sinon.spy(NotificationService, 'addErrorMessage');
                NSsuccessSpy = sinon.spy(NotificationService, 'addSuccessMessage');

                subscriptions = [];

                postalStub = sinon.stub(postal, 'subscribe', function (sub) {
                    subscriptions.push(sub);
                });

                $controller('PatientDetailsCtrl', { $scope:$scope });
            });

            afterEach(function () {
                PatientMock.restore();
                NSerrorSpy.restore();
                NSsuccessSpy.restore();
                postalStub.restore();
                patientMock.restore();
            });

            it('should define a selectPatient  method', function () {
                assert.isDefined($scope.selectPatient , 'Controller scope doesn\'t have "selectPatient " function defined');
                assert.isFunction($scope.selectPatient , '"selectPatient " is not a function');
            });

            it('should define a uploadStudy method', function () {
                assert.isDefined($scope.uploadStudy, 'Controller scope does not have "uploadStudy" function defined');
                assert.isFunction($scope.uploadStudy, '"uploadStudy" is not a function');
            });

            it('should define a viewStudy method', function () {
                assert.isDefined($scope.viewStudy, 'Controller scope does not have "viewStudy" method defined');
                assert.isDefined($scope.viewStudy, '"viewStudy" is not a function');
            });

            it('should define a studiesUpdateTime method', function () {
                assert.isDefined($scope.studiesUpdateTime, 'Controller scope does not have "studiesUpdateTime" method defined');
                assert.isDefined($scope.studiesUpdateTime, '"studiesUpdateTime" is not a function');
            });

            it('should define a studiesUpdateDay method', function () {
                assert.isDefined($scope.studiesUpdateDay, 'Controller scope does not have "studiesUpdateDay" method defined');
                assert.isDefined($scope.studiesUpdateDay, '"studiesUpdateDay" is not a function');
            });

            it('should throw an error when patient argument is undefined in the selectPatient call', function () {
                expect($scope.selectPatient).to.throw('patient should be instance of Patient');
                expect(function () {
                    $scope.selectPatient({});
                }).to.throw('patient should be instance of Patient');
                expect(function () {
                    $scope.selectPatient(new Patient());
                }).to.not.throw('patient should be instance of Patient');
            });

            it('should select patient', function () {
                $scope.cachedStudiesRequestError = true;
                $scope.updatedStudiesRequestError = true;
                $scope.checkUploadStatusPromise = {};

                var timeoutMock = sinon.mock($timeout);
                var patientMock = sinon.mock(patient);
                timeoutMock.expects('cancel').withArgs($scope.checkUploadStatusPromise);
                patientMock.expects('getStudies');
                patientMock.expects('getUpdatedStudies');

                $scope.selectPatient(patient);

                expect($scope.cachedStudiesRequestError).to.be.false;
                expect($scope.updatedStudiesRequestError).to.be.false;
                expect($scope.patient).to.equal(patient);
                timeoutMock.verify();
                patientMock.verify();

                timeoutMock.restore();
                patientMock.restore();
            });

            it('should call patient.uploadStudy', function () {
                var deferred = $q.defer();
                var patientMock = sinon.mock(patient);
                var study = {};
                patientMock.expects('uploadStudy').once().returns(deferred.promise);

                $scope.uploadStudy(study);
                $scope.patient = patient;
                $scope.uploadStudy(study);

                patientMock.verify();
                patientMock.restore();
            });

            it('should show a success message when the upload is initiated', function () {
                var deferred = $q.defer();
                sinon.stub(patient, "uploadStudy").returns(deferred.promise);
                $scope.patient = patient;

                $scope.uploadStudy({ description: "study 1" });
                deferred.resolve();
                $scope.$apply();

                expect(NSsuccessSpy.calledWith('patient-management.uploadStudyRequestSuccess')).to.be.true;

                patient.uploadStudy.restore();
            });

            it('should show an error message when the upload call returns an error', function () {
                var deferred = $q.defer();
                sinon.stub(patient, "uploadStudy").returns(deferred.promise);
                $scope.patient = patient;

                $scope.uploadStudy({});
                deferred.reject();
                $scope.$apply();

                expect(NSerrorSpy.calledWith('patient-management.uploadStudyRequestError')).to.be.true;

                patient.uploadStudy.restore();
            });

            it('should throw an error when study argument is not passed to viewStudy method', function () {
                expect($scope.viewStudy).to.throw('study argument is mandatory');
                expect(function () {
                    $scope.viewStudy({});
                }).to.not.throw('study argument is mandatory');
            });

            it('should redirect to viewer module when the study is uploaded', function () {
                var spy = sinon.spy($state, 'go');
                spy.withArgs('viewer.start');

                $scope.viewStudy({});

                expect(spy.withArgs('viewer.start').called).to.be.false;

                $scope.patient = { caseContainerId: '123.123' };

                $scope.viewStudy({
                    uploadStatus: 'COMPLETED',
                    uid: '456.456'
                });

                expect(spy.withArgs('viewer.start').calledOnce).to.be.true;
            });

            it('should call the TimeCalcService.timeElapsedSince in studiesUpdateTime method', function () {
                $scope.patient = {
                    lastStudiesUpdate: new Date()
                };

                var TimeCalcServiceMock = sinon.mock(TimeCalcService);
                TimeCalcServiceMock.expects('timeElapsedSince').withArgs($scope.patient.lastStudiesUpdate).returns('time text');

                expect($scope.studiesUpdateTime()).to.equal('time text');
                TimeCalcServiceMock.verify();

                TimeCalcServiceMock.restore();
            });

            it('should return the day of the lastStudiesUpdate', function () {
                expect($scope.studiesUpdateDay()).to.be.undefined;
                
                var d1 = new Date();
                var p = {
                    lastStudiesUpdate: d1
                };

                $scope.patient = p;
                expect($scope.studiesUpdateDay()).to.equal('patient-management.today');

                p.lastStudiesUpdate = new Date(d1.getTime() - 2 * 24 * 60 * 60 * 1000);
                
                expect($scope.studiesUpdateDay()).to.equal($filter('date')(p.lastStudiesUpdate, 'yyyy-MM-dd'))
            });

            it('should set studiesRequestError to true if gettingStudies.error and gettingUpdatedStudies.error topic is published', function () {
                var gettingStudiesErrorSub = getSubscription(Patient.topics.gettingStudies.error);
                var gettingUpdatedStudiesErrorSub = getSubscription(Patient.topics.gettingUpdatedStudies.error);
                patientMock.expects('getUpdatedStudies');
                $scope.patient = patient;

                gettingStudiesErrorSub.callback({});
                expect(NSerrorSpy.called).to.be.false;

                gettingStudiesErrorSub.callback(patient);
                expect(NSerrorSpy.called).to.be.false;

                // if a call fron previous patient selected fails, ignore it.
                gettingUpdatedStudiesErrorSub.callback({});
                expect(NSerrorSpy.called).to.be.false;

                gettingUpdatedStudiesErrorSub.callback(patient);

                var message = 'patient-management.studiesRequestError';
                message += " " + patient.getFullName() + ". ";
                message += 'patient-view.tryAgain'

                expect(NSerrorSpy.calledWith(message)).to.be.true;

                $timeout.flush();
                patientMock.verify();
            });

            it('should set the completedStudies array with the studies that changed its stauts do COMPLETED', function () {
                var diff = {
                    previousStudies: [{
                        identifier: '1',
                        description: '1',
                        uploadStatus: 'IN_PROGRESS'
                    },{
                        identifier: '2',
                        description: '2',
                        uploadStatus: 'IN_PROGRESS'
                    },{
                        identifier: '3',
                        description: '3',
                        uploadStatus: 'IN_PROGRESS'
                    }],
                    currentStudies: [{
                        identifier: '1',
                        description: '1',
                        uploadStatus: 'COMPLETED'
                    },{
                        identifier: '2',
                        description: '2',
                        uploadStatus: 'IN_PROGRESS'
                    },{
                        identifier: '3',
                        description: '3',
                        uploadStatus: 'COMPLETED'
                    }]
                };

                var gettingUpdatedStudiesSuccessSub = getSubscription(Patient.topics.gettingUpdatedStudies.success);
                patientMock.expects('getUpdatedStudies');
                $scope.patient = patient;

                gettingUpdatedStudiesSuccessSub.callback({});
                expect(NSsuccessSpy.called).to.be.false;

                gettingUpdatedStudiesSuccessSub.callback({
                    patient: patient,
                    diff: diff
                });

                expect(NSsuccessSpy.calledWith('patient-management.studiesUploadCompleted' + ' 1, 3.')).to.be.true;

                $timeout.flush(); 
                patientMock.verify();
            });

            it('should set the failedStudies array with the studies that changed its stauts do FAILED', function () {
                var diff = {
                    previousStudies: [{
                        identifier: '1',
                        description: '1',
                        uploadStatus: 'IN_PROGRESS'
                    },{
                        identifier: '2',
                        description: '2',
                        uploadStatus: 'IN_PROGRESS'
                    },{
                        identifier: '3',
                        description: '3',
                        uploadStatus: 'IN_PROGRESS'
                    }],
                    currentStudies: [{
                        identifier: '1',
                        description: '1',
                        uploadStatus: 'IN_PROGRESS'
                    },{
                        identifier: '2',
                        description: '2',
                        uploadStatus: 'FAILED'
                    },{
                        identifier: '3',
                        description: '3',
                        uploadStatus: 'FAILED'
                    }]
                };

                var gettingUpdatedStudiesSuccessSub = getSubscription(Patient.topics.gettingUpdatedStudies.success);
                patientMock.expects('getUpdatedStudies');
                $scope.patient = patient;

                gettingUpdatedStudiesSuccessSub.callback({});
                expect(NSsuccessSpy.called).to.be.false;

                gettingUpdatedStudiesSuccessSub.callback({
                    patient: patient,
                    diff: diff
                });

                expect(NSerrorSpy.calledWith('patient-management.studiesUploadFailed' + ' 2, 3.')).to.be.true;

                $timeout.flush(); 
                patientMock.verify();
            });
        });

    });
});