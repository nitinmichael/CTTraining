/*
 *  get-billing-organizations-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * Spec file for Get Billing Organizations Service
 */

define([
    'angular',
    'angular-mocks',
    'modules/caseexchange/modules/create-case/services/get-billing-organizations-service',
    'modules/caseexchange/services/case-exchange-data-service',
    'mocks/case-exchange-mock-service' ], function (ng) {
    'use strict';

    var GetBillingOrganizationsService, q, httpBackend, sampleResponse, serviceUrl;

    describe('Test Get Billing Organizations Service', function () {

        beforeEach(function() {
            // Load the module for the mock data first
            module('cloudav.caseExchange.mocks');

            module('Services.getBillingOrganizationsService', function($provide){
                $provide.factory('configurationService', ['$q', function($q){
                    return {
                        getProperty: function(){
                            return $q.when({});
                        }
                    }
                }]);
            });

            inject(function ($httpBackend, _GetBillingOrganizationsService_, CaseExchangeMocks, CaseExchangeDataService){
                GetBillingOrganizationsService = _GetBillingOrganizationsService_;
                httpBackend = $httpBackend;
                serviceUrl = CaseExchangeDataService.getServiceURL() + '/v1/user/me/organization';
                sampleResponse = CaseExchangeMocks.getBillingOrganizations();
            });
        });

        it('should define a service', function () {
            assert.isDefined(GetBillingOrganizationsService, 'Study List Service is defined');
        });

        describe('Get Billing Organizations Service', function() {

            it('checks Get Billing Organizations service is called successfully', function(){
                httpBackend.expect('GET', serviceUrl).respond(200, sampleResponse);

                GetBillingOrganizationsService.getOrganizationsForLoggedInUser().then(function(response) {
                    expect(response.length).to.equal(sampleResponse.length);
                });

                httpBackend.flush();
            });
            
             it("checks Get Billing Organizations service is not called successfully", function(){
                 httpBackend.expect('GET', serviceUrl).respond(400, 'error');

                GetBillingOrganizationsService.getOrganizationsForLoggedInUser().then(function(){
                    //success callback
                  }, function(response) {
                    //error callback
                    expect(response).to.equal('error');
                });

                httpBackend.flush();
            });
        });
    });
});  