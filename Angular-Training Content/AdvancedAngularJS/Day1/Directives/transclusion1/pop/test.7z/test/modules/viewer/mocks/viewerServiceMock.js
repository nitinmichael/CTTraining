define(['angular'], function(angular) {
    angular.module('viewerServiceMock', []).service('viewerService', function($deviceManagerService) {

        this.viewTypes = {
            '3d': '3D',
            'axial': 'INFERIOR',
            'coronal': 'ANTERIOR',
            'sagittal': 'LEFT',
            'oblique': '3D',
            'threed': '3D'
        };

        this.renderingTypes = {
            'vr': 'VR',
            'mpr': 'MPR',
            'hdmip': 'VR'
        };

        this.vrRenderTypes = {
            'vr': 'VR',
            'mip': 'Max',
            'minip': 'Min'
        };

        this.getDefaultLayoutConfiguration = function() {
            var layouts = {
                'iPad': {
                    'visiblePorts': 3,
                    'cssLayout': 'oneByTwoByTwo',
                    'annotState': 'partial'
                },
                'iPhone': {
                    'visiblePorts': 1,
                    'cssLayout': 'oneByOne',
                    'annotState': 'partial'
                },
                'desktop': {
                    'visiblePorts': 4,
                    'cssLayout': 'twoByTwo',
                    'annotState': 'full'
                }
            };

            var currentConfiguration = $deviceManagerService.getSupportedDeviceName();
            return layouts[currentConfiguration];
        };

        this.getDefaultViewportConfig = function() {
            return [{
                viewType: '3d',
                rendererType: 'vr',
                vrRenderType: 'vr'
            }, {
                viewType: 'axial',
                rendererType: 'mpr'
            }, {
                viewType: 'sagittal',
                rendererType: 'mpr'
            }, {
                viewType: 'coronal',
                rendererType: 'mpr'
            }];
        };

        this.mapGroups = function() {
            return [{
                saveState: true,
                imageType: '3D'
            }];
        };

        this.mapPatient = function() {
            return null;
        };

        this.mapStudy = function() {
            return null;
        };

        this.mapVolumes = function() {
            return [];
        };

        this.mapSaveStates = function() {
            return [];
        };

        this.reformatMeasure = function(measure) {
            return measure;
        };

        this.reformatSaveState = function(saveStateInfo) {
            return saveStateInfo.viewports;
        };

        this.fixPortsConfiguration = function(config) {
            return config;
        };
    });
});
