/*
 * ge-generic-list-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular-mocks', 'modules/platform/directives/ge-patient-header/ge-patient-header-directive'], function () {
    'use strict';


    describe('Patient header controller', function () {
        var scope, controller;

        beforeEach(module('platform.directive.ge-patient-header-directive'));
        beforeEach(function () {
            inject(function ($rootScope, _$controller_) {
                scope = $rootScope.$new();

                scope.caseData = {
                    "id": "851451628906363228426738",
                    "subject": "Automation Test - Case with attachment",
                    "type": "NORMAL",
                    "documentType": "Case",
                    "clinicalReason": "Collaboration",
                    "otherClinicalReason": null,
                    "priority": "HIGH",
                    "status": "IN_PROGRESS",
                    "creator": {
                        "identifier": "2d7c0643-fcb0-4d4f-a921-a1029d9d03f3",
                        "name": {
                            "given": ["Clinician_Given", "Clinician_Middle"],
                            "family": ["Clinician_Family"],
                            "prefix": [],
                            "suffix": []
                        }
                    },
                    "participants": [{
                        "user": {
                            "identifier": "aa36d598-f658-4153-9d2e-54269e5b4288",
                            "name": {"given": ["C360", "First"], "family": ["User13"], "prefix": [], "suffix": []}
                        }, "reviewed": false
                    }, {
                        "user": {
                            "identifier": "2d7c0643-fcb0-4d4f-a921-a1029d9d03f3",
                            "name": {
                                "given": ["Clinician_Given", "Clinician_Middle"],
                                "family": ["Clinician_Family"],
                                "prefix": [],
                                "suffix": []
                            }
                        }, "reviewed": true
                    }],
                    "caseOrganization": {"id": "12", "name": "San Ramon"},
                    "patient": {
                        "identifier": "A16667",
                        "name": {"given": ["Jürgen", "Klaus"], "family": ["Smith"], "prefix": null, "suffix": null},
                        "birthDate": "19651018",
                        "gender": "M"
                    },
                    "createdDate": 1445897233011,
                    "updatedDate": 1445897233011,
                    "transactions": [{
                        "id": "352573359084540147526739",
                        "parentCaseId": "851451628906363228426738",
                        "documentType": "Transaction",
                        "message": "this is another message",
                        "type": "CREATE_CASE",
                        "patient": {
                            "identifier": "A16667",
                            "name": {"given": ["Jürgen", "Klaus"], "family": ["Smith"], "prefix": null, "suffix": null},
                            "birthDate": "19651018",
                            "gender": "M"
                        },
                        "creator": {
                            "identifier": "2d7c0643-fcb0-4d4f-a921-a1029d9d03f3",
                            "name": {
                                "given": ["Clinician_Given", "Clinician_Middle"],
                                "family": ["Clinician_Family"],
                                "prefix": [],
                                "suffix": []
                            }
                        },
                        "addedParticipants": [{
                            "user": {
                                "identifier": "aa36d598-f658-4153-9d2e-54269e5b4288",
                                "name": {"given": ["C360", "First"], "family": ["User13"], "prefix": [], "suffix": []}
                            }, "reviewed": false
                        }],
                        "removedParticipants": null,
                        "createdDate": 1445897236375,
                        "updatedDate": 1445897236375,
                        "hasAttachments": true,
                        "attachments": [{
                            "type": "DocumentReference",
                            "identifier": "511183674015997256526741",
                            "cloudObjectId": "Cloud_id",
                            "parentTransactionId": "352573359084540147526739",
                            "parentCaseId": "851451628906363228426738",
                            "description": "Test File",
                            "uri": "/test",
                            "uploadStatus": "IN_PROGRESS",
                            "createdDate": 1445897236378,
                            "updatedDate": 1445897236378,
                            "documentType": "Attachment",
                            "size": "17MB",
                            "created": "20150118",
                            "linkedStudyId": "777777"
                        }, {
                            "type": "ImagingStudy",
                            "identifier": "861200059614060104526740",
                            "cloudObjectId": "Cloud_id",
                            "parentTransactionId": "352573359084540147526739",
                            "parentCaseId": "851451628906363228426738",
                            "description": "Test",
                            "uri": "/test",
                            "uploadStatus": "IN_PROGRESS",
                            "createdDate": 1445897236377,
                            "updatedDate": 1445897236377,
                            "documentType": "Attachment",
                            "started": "19991017",
                            "accession": "76876123876",
                            "studyId": "5555",
                            "uid": "76878787",
                            "saveStateSuid": "123123",
                            "sourceId": "PACS_SR",
                            "modalityList": ["CT"],
                            "referrer": "Referring physician",
                            "performingPhysician": "Performing physician",
                            "anatomicRegion": "Anatomic Region",
                            "procedure": "Procedure"
                        }],
                        "status": "IN_PROGRESS",
                        "priority": "HIGH"
                    }]
                };

                controller = _$controller_('gePatientHeaderController', {
                    $scope: scope
                });
            });
        });

        it("should have a controller defined", function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

    });

    //describe('Patient header directive', function() {
    //    var $compile;
    //    var $rootScope;
    //
    //    beforeEach(module('templates'));
    //    beforeEach(module('platform.directive.ge-patient-header-directive', function ($provide) {
    //        ['translateFilter'].forEach(function(f){
    //            $provide.value(f, function(val){
    //                return val;
    //            });
    //        });
    //    }));
    //
    //    beforeEach(inject(function(_$compile_, _$rootScope_) {
    //        $compile = _$compile_;
    //        $rootScope = _$rootScope_;
    //    }));
    //
    //    it('should be defined', function() {
    //        var scope = $rootScope.$new();
    //        var element = $compile("<ge-patient-header></ge-patient-header>")(scope);
    //        $rootScope.$digest();
    //        var html = element.html();
    //        expect(html).to.have.length.of.at.least(1);
    //    });
    //});
});