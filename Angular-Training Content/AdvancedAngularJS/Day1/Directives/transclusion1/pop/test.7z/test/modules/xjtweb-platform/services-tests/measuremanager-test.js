/**
 * @ngdoc service
 * @name xjtweb-platform.test.measuremanager-test:measuremanager-test
 *
 * @description This is the test suite for the measuremanager.
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */
define([ 'angular', 'angular-mocks', 'modules/xjtweb-platform/services/measure-manager' ], function(ng, mocks) {
    'use strict';

    describe('Measure manager', function() {
        var mockChannel;
        var measureManager;

        beforeEach(module('measure-manager'));
        beforeEach(module(function($provide) {
            $provide.factory('$xjtweb', function() {
                return {
                    XJTWEB : {
                        MeasureManagerBuilder : function(postMock, cursorMan) {

                            return {
                                'postalMock' : postMock,
                                'CursorManagerMock' : cursorMan
                            };
                        }
                    }
                };
            });
            $provide.factory('CursorManager', function() {
                return {
                    mock : 'mock_CursorManager'
                };
            });
        }));

        beforeEach(inject(function(MeasureManager) {
            measureManager = MeasureManager;
        }));

        /**
         * @ngdoc method
         * @name MeasureManager_Init_Test
         * @methodOf xjtweb-platform.test.measuremanager-test:measuremanager-test
         *
         * @description This test method determines that the MeasureManager is created as a type of object on
         *              initialization.
         */
        it('MeasureManager should be a typeof object', function() {
            expect(typeof measureManager).to.equal('object');
        });

        /**
         * @ngdoc method
         * @name MeasureManager_Logic_Test
         * @methodOf xjtweb-platform.test.measuremanager-test:measuremanager-test
         *
         * @description This test method determines that MeasureManager returns a $xjtweb.XJTWEB.MeasureManagerBuilder
         *              with a $xjtweb.XJTWEB.MEASURE_MANAGER.
         */
        it('MeasureManager should return a $xjtweb.XJTWEB.MeasureManagerBuilder with a $xjtweb.XJTWEB.MEASURE_MANAGER.CHANNEL applied to it.', function() {
            expect(measureManager.postalMock.configuration.SYSTEM_CHANNEL).to.equal('postal');
            expect(measureManager.CursorManagerMock.mock).to.equal('mock_CursorManager');
        });
    });
});
