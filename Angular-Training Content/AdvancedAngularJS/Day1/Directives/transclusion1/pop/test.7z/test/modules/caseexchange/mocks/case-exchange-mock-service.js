/*  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jignesh Parekh<jignesh.parekh@ge.com>
 */

define(['angular'], function (angular) {

    /**
     * Angular Module which contains factory for Case Exchange mock data.
     */
    var mod = angular.module('cloudav.caseExchange.mocks', []);

    /**
     * Factory which contains methods to get mock data for Case Exchange module.
     */
    mod.factory('CaseExchangeMocks', function () {

        /**
         * Function which will return the mock data for case headers
         * @returns:
         *  JSON object with mock case headers
         */
        function getCaseHeaders() {
            return [
                {
                    "id": "279773343203519180018882",
                    "subject": "Test Subject",
                    "type": "NORMAL",
                    "documentType": "Case",
                    "clinicalReason": "Transfer",
                    "priority": "HIGH",
                    "status": "IN_PROGRESS",
                    "creator": {
                        "identifier": "8590f00a-02c7-4e7b-a523-7b2950f24786",
                        "name": {
                            "given": [
                                "Given Name"
                            ],
                            "family": [
                                "Family Name"
                            ],
                            "prefix": null,
                            "suffix": null
                        }
                    },
                    "participants": [
                        {
                            "user": {
                                "identifier": "8590f00a-02c7-4e7b-a523-7b2950f24786",
                                "name": {
                                    "given": [
                                        "Given Name"
                                    ],
                                    "family": [
                                        "Family Name"
                                    ],
                                    "prefix": null,
                                    "suffix": null
                                }
                            },
                            "reviewed": false
                        },
                        {
                            "user": {
                                "identifier": "9d506101-3c84-4928-a381-a462df445893",
                                "name": {
                                    "given": [
                                        "Alen"
                                    ],
                                    "family": [
                                        "Pitt"
                                    ],
                                    "prefix": null,
                                    "suffix": null
                                }
                            },
                            "reviewed": false
                        }
                    ],
                    "caseOrganization": {
                        "id": "12",
                        "name": "San Ramon"
                    },
                    "patient": {
                        "identifier": "A1",
                        "name": {
                            "given": [
                                "Antony"
                            ],
                            "family": [
                                "Mark"
                            ],
                            "prefix": null,
                            "suffix": null
                        },
                        "birthDate": "19651018",
                        "gender": "M"
                    },
                    "createdDate": 1440178982714,
                    "updatedDate": 1440178982714,
                    "transactions": null
                },
                {
                    "id": "3248989545024704301",
                    "subject": "Test Subject",
                    "type": "NORMAL",
                    "documentType": "Case",
                    "clinicalReason": "Transfer",
                    "priority": "HIGH",
                    "status": "COMPLETED",
                    "creator": {
                        "identifier": "8590f00a-02c7-4e7b-a523-7b2950f24786",
                        "name": {
                            "given": [
                                "Given Name"
                            ],
                            "family": [
                                "Family Name"
                            ],
                            "prefix": null,
                            "suffix": null
                        }
                    },
                    "participants": [
                        {
                            "user": {
                                "identifier": "8590f00a-02c7-4e7b-a523-7b2950f24786",
                                "name": {
                                    "given": [
                                        "Given Name"
                                    ],
                                    "family": [
                                        "Family Name"
                                    ],
                                    "prefix": null,
                                    "suffix": null
                                }
                            },
                            "reviewed": false
                        },
                        {
                            "user": {
                                "identifier": "9d506101-3c84-4928-a381-a462df445893",
                                "name": {
                                    "given": [
                                        "Alen"
                                    ],
                                    "family": [
                                        "Pitt"
                                    ],
                                    "prefix": null,
                                    "suffix": null
                                }
                            },
                            "reviewed": false
                        }
                    ],
                    "caseOrganization": {
                        "id": "12",
                        "name": "San Ramon"
                    },
                    "patient": {
                        "identifier": "A16667",
                        "name": {
                            "given": [
                                "John"
                            ],
                            "family": [
                                "Peter"
                            ],
                            "prefix": null,
                            "suffix": null
                        },
                        "birthDate": "19651018",
                        "gender": "M"
                    },
                    "createdDate": 1440178908437,
                    "updatedDate": 1440178908437,
                    "transactions": null
                }
            ];
        }

        /**
         * Function which will return the mock data for case transactions
         * @returns:
         *  JSON object with mock data transactions
         */
        function getCaseTransactions() {
            return [
                {
                    "id": "60052949099804081964",
                    "message": "This is a test Message",
                    "creator": {
                        "identifier": "8590f00a-02c7-4e7b-a523-7b2950f24786",
                        "name": {
                            "given": [
                                "Given Name"
                            ],
                            "family": [
                                "Family Name"
                            ],
                            "prefix": null,
                            "suffix": null
                        }
                    },
                    "addedParticipants": [
                        {
                            "user": {
                                "identifier": "9d506101-3c84-4928-a381-a462df445893",
                                "name": {
                                    "given": [
                                        "Alen"
                                    ],
                                    "family": [
                                        "Pitt"
                                    ],
                                    "prefix": null,
                                    "suffix": null
                                }
                            },
                            "reviewed": false
                        }
                    ],
                    "createdDate": 1440178983509,
                    "hasAttachments": true,
                    "attachments": [
                        {
                            "type": "ImagingStudy",
                            "identifier": "43935615235230264265",
                            "cloudObjectId": "Cloud_id",
                            "parentTransactionId": "60052949099804081964",
                            "parentCaseId": "279773343203519180018882",
                            "description": "Test",
                            "uri": "/test",
                            "uploadStatus": "IN_PROGRESS",
                            "createdDate": 1440178983720,
                            "updatedDate": 1440178983720,
                            "documentType": "Attachment",
                            "started": "19991017",
                            "accession": "76876123876",
                            "studyId": "5555",
                            "uid": "76878787",
                            "saveStateSuid": "123123",
                            "sourceId": "PACS_SR",
                            "modalityList": [
                                "CT"
                            ],
                            "referrer": "Referring physician",
                            "performingPhysician": "Performing physician",
                            "anatomicRegion": "Anatomic Region",
                            "procedure": "Procedure"
                        },
                        {
                            "type": "DocumentReference",
                            "identifier": "61980822690222743026",
                            "cloudObjectId": "Cloud_id",
                            "parentTransactionId": "60052949099804081964",
                            "parentCaseId": "279773343203519180018882",
                            "description": "abc.jpg",
                            "uri": "/test",
                            "uploadStatus": "IN_PROGRESS",
                            "createdDate": 1440178983937,
                            "updatedDate": 1440178983937,
                            "documentType": "Attachment",
                            "size": "17MB",
                            "created": "20150118",
                            "linkedStudyId": "777777"
                        },
                        {
                            "type": "DocumentReference",
                            "identifier": "61980822690222743027",
                            "cloudObjectId": "Cloud_id",
                            "parentTransactionId": "60052949099804081965",
                            "parentCaseId": "279773343203519180018883",
                            "description": "test.xml",
                            "uri": "/test",
                            "uploadStatus": "IN_PROGRESS",
                            "createdDate": 1440178983937,
                            "updatedDate": 1440178983937,
                            "documentType": "Attachment",
                            "size": "17MB",
                            "created": "20150118",
                            "linkedStudyId": "777778"
                        }
                    ],
                    "parentCaseId": "279773343203519180018882",
                    "status": "IN_PROGRESS"
                }
            ];
        }

        /**
         * Function which will return the mock data for case details
         * @returns:
         *  JSON object with mock data
         */
        function getCaseDetails() {
            return {
                "id": "279773343203519180018882",
                "subject": "Test Subject",
                "type": "NORMAL",
                "documentType": "Case",
                "clinicalReason": "Transfer",
                "priority": "HIGH",
                "status": "COMPLETED",
                "creator": {
                    "identifier": "8590f00a-02c7-4e7b-a523-7b2950f24786",
                    "name": {
                        "given": [
                            "Given Name"
                        ],
                        "family": [
                            "Family Name"
                        ],
                        "prefix": null,
                        "suffix": null
                    }
                },
                "participants": [
                    {
                        "user": {
                            "identifier": "8590f00a-02c7-4e7b-a523-7b2950f24786",
                            "name": {
                                "given": [
                                    "Given Name"
                                ],
                                "family": [
                                    "Family Name"
                                ],
                                "prefix": null,
                                "suffix": null
                            }
                        },
                        "reviewed": false
                    },
                    {
                        "user": {
                            "identifier": "9d506101-3c84-4928-a381-a462df445893",
                            "name": {
                                "given": [
                                    "Alen"
                                ],
                                "family": [
                                    "Pitt"
                                ],
                                "prefix": null,
                                "suffix": null
                            }
                        },
                        "reviewed": false
                    }
                ],
                "caseOrganization": {
                    "id": "12",
                    "name": "San Ramon"
                },
                "patient": {
                    "identifier": "A1",
                    "name": {
                        "given": [
                            "Antony"
                        ],
                        "family": [
                            "Mark"
                        ],
                        "prefix": null,
                        "suffix": null
                    },
                    "birthDate": "19651018",
                    "gender": "M"
                },
                "createdDate": 1440178982714,
                "updatedDate": 1440178982714,
                "transactions": getCaseTransactions()
            };
        }

        /**
         * Function to return the mock data for Patient
         * @returns:
         *  JSON object with mock data
         */
        function getPatient() {
            return {
                "identifier": "A1",
                "name": {
                    "given": [
                        "Antony"
                    ],
                    "family": [
                        "Mark"
                    ],
                    "prefix": null,
                    "suffix": null
                },
                "birthDate": "19651018",
                "gender": "M",
                "age": 0,
                "active": true,
                "visible": true,
                "studyList": [
                    {
                        "id": "1.2.840.113619.2.144.37177020.21776.1109368169.819",
                        "description": null,
                        "modalities": ["_CT"],
                        "size": null,
                        "sourceAeTitle": null,
                        "date": "20050201",
                        "instanceUid": "1.2.840.113619.2.144.37177020.21776.1109368169.819",
                        "accessionNumber": null,
                        "$$hashKey": "object:504",
                        "selected": true,
                        "isSelected": true
                    }
                ]
            };
        }

        /**
         * Returns Patients
         * @returns {*[]}
         */
        function getPatients() {
            return [
                {
                    "identifier": "A1",
                    "name": {
                        "given": [
                            "Antony"
                        ],
                        "family": [
                            "Mark"
                        ],
                        "prefix": null,
                        "suffix": null
                    },
                    "birthDate": "19651018",
                    "gender": "M",
                    "age": 0,
                    "active": true,
                    "visible": true,
                    "studyList": [
                        {
                            "id": "1.2.840.113619.2.144.37177020.21776.1109368169.819",
                            "description": null,
                            "modalities": ["_CT"],
                            "size": null,
                            "sourceAeTitle": null,
                            "date": "20050201",
                            "instanceUid": "1.2.840.113619.2.144.37177020.21776.1109368169.819",
                            "accessionNumber": null,
                            "$$hashKey": "object:504",
                            "selected": true,
                            "isSelected": true
                        }
                    ]
                },
                {
                    "identifier": "A2",
                    "name": {
                        "given": [
                            "Antony1"
                        ],
                        "family": [
                            "Mark1"
                        ],
                        "prefix": null,
                        "suffix": null
                    },
                    "birthDate": "19661018",
                    "gender": "F",
                    "age": 30,
                    "active": true,
                    "visible": true,
                    "studyList": [
                        {
                            "id": "1.2.840.113619.2.144.37177020.21776.1109368169.817",
                            "description": null,
                            "modalities": ["_CT"],
                            "size": null,
                            "sourceAeTitle": null,
                            "date": "20050201",
                            "instanceUid": "1.2.840.113619.2.144.37177020.21776.1109368169.817",
                            "accessionNumber": null,
                            "$$hashKey": "object:505",
                            "selected": true,
                            "isSelected": true
                        }
                    ]
                }
            ];
        }

        /**
         * Function to return study list mock data
         * @returns:
         *  JSON object with mock data
         */
        function getStudyList() {
            return [
                {
                    "id": "1.2.840.113619.2.144.37177020.21776.1109368169.819",
                    "description": null,
                    "modalities": [
                        "_CT"
                    ],
                    "size": null,
                    "sourceAeTitle": null,
                    "date": "20050201",
                    "instanceUid": "1.2.840.113619.2.144.37177020.21776.1109368169.819",
                    "accessionNumber": null,
                    "$$hashKey": "object:504",
                    "selected": true,
                    "isSelected": true
                },
                {
                    "id": "1.2.840.113619.2.144.37177020.21776.1109368169.817",
                    "description": null,
                    "modalities": [
                        "_CT"
                    ],
                    "size": null,
                    "sourceAeTitle": null,
                    "date": "20050201",
                    "instanceUid": "1.2.840.113619.2.144.37177020.21776.1109368169.817",
                    "accessionNumber": null,
                    "$$hashKey": "object:555",
                    "selected": true,
                    "isSelected": true
                }
            ];
        }

        /**
         * Function to return study list mock data
         * @returns:
         *  JSON object with mock data
         */
        function getCaseDicomAttachment() {
            return {
                "resourceType": "Bundle",
                "title": "List of all Application Servcies 1",
                "id": null,
                "entry": [
                    {
                        "title": null,
                        "id": "1",
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "dicom-query-retrieve",
                            "name": "LOCAL PACS1-ITG2",
                            "endpoint": "/v1/bucket/com.ge.pfh.ig.{deviceid}/set/configuration/content/{deviceid}-AppConf/",
                            "gateway": {
                                "reference": "LOCAL PACS1-ITG2"
                            },
                            "owner": {
                                "reference": "Concord Medical Center"
                            },
                            "networkAddress": {
                                "ip": "111.11.11.1111",
                                "entityName": "AE_PACS",
                                "port": 8080
                            }
                        }
                    },
                    {
                        "title": null,
                        "id": "1",
                        "content": {
                            "resourceType": "ResourcesApplicationService",
                            "type": "dicom-send",
                            "name": "LOCAL PACS1-ITG2",
                            "endpoint": "/v1/bucket/com.ge.pfh.ig.{deviceid}/set/configuration/content/{deviceid}-AppConf/",
                            "gateway": {
                                "reference": "LOCAL PACS1-ITG2"
                            },
                            "owner": {
                                "reference": "Concord Medical Center"
                            },
                            "networkAddress": {
                                "ip": "111.11.11.1111",
                                "entityName": "AE_PACS",
                                "port": 8080
                            }
                        }
                    }
                ]
            };
        }

        /**
         * Function to return Dicom Application service list mock data
         * @returns:
         *  JSON object with mock data
         */
        function getDicomApplicationService() {
            return {
                "applicationService": {
                    "id": "1",
                    "endpoint": "/v1/bucket/com.ge.pfh.ig.{deviceid}/set/configuration/content/{deviceid}-AppConf/",
                    "attachments": [
                        {
                            "type": "ImagingStudy",
                            "identifier": "5886037742549696642235",
                            "uid": "76878787"
                        }
                    ]
                },
                "operationId": "2845459556961328621285",
                "operationType": "DOWNLOAD"
            }
        }

        /**
         * Function to return non-Dicom mock data
         * @returns:
         *  JSON object with mock data
         */
        function getNonDicomFiles() {
            return [
                {
                    "lastModified": "1440007198827",
                    "name": "abc.pdf",
                    "size": 123456,
                    "type": "application/pdf",
                    "webkitRelativePath": ""
                },
                {
                    "lastModified": "1440007198827",
                    "name": "xyz.pdf",
                    "size": 654321,
                    "type": "application/pdf",
                    "webkitRelativePath": ""
                }
            ];
        };

        /**
         * Function to return Clinical Reasons mock data
         * @returns:
         *  JSON object with mock data
         */
        function getClinicalReasons() {
            return [
                {
                    "id": "1",
                    "value": "Collaboration"
                },
                {
                    "id": "2",
                    "value": "Historical Patient Information"
                },
                {
                    "id": "3",
                    "value": "Multi-Disciplinary Team"
                },
                {
                    "id": "4",
                    "value": "Off-hour Read"
                },
                {
                    "id": "5",
                    "value": "Patient Transfer"
                },
                {
                    "id": "6",
                    "value": "Second Opinion"
                },
                {
                    "id": "7",
                    "value": "Trauma Transfer"
                },
                {
                    "id": "8",
                    "value": "Protocol"
                },
                {
                    "id": "9",
                    "value": "Other"
                }
            ];
        };

        /**
         * Function to return create a case transaction study mock data
         * @returns:
         *  JSON object with mock data
         */
        function getTransactionStudyList() {
            return [
                {
                    "identifier": "20000908-144320",
                    "description": "CHEST 2V",
                    "started": "20100915",
                    "uid": "76878787",
                    "accession": "0000001386",
                    "appid": "b9ac0b4c-dac4-402c-8311-6d355061be21",
                    "$$hashKey": "object:244",
                    "selected": true,
                    "isSelected": true
                },
                {
                    "identifier": "20000908-144320",
                    "description": "CHEST",
                    "started": "20100915",
                    "uid": "76878787",
                    "accession": "0000001386",
                    "appid": "b9ac0b4c-dac4-402c-8311-6d355061be21",
                    "$$hashKey": "object:244",
                    "selected": true,
                    "isSelected": true
                }
            ];
        };

        /**
         * Function to get the moack data for "/me" service response
         * @returns meSuccessResponse: Mock object for "/me" service response.
         */
        function getMeServiceResponse() {
            var meSuccessResponse = {
                "externalId": [
                    {
                        "system": "IDM",
                        "value": "40c5bc1c-11e7-4eff-b5e1-42f474846022"
                    },
                    {
                        "system": "UOM",
                        "value": "f3eb410b-a95f-4b60-9ba2-c99cf8e2f4d3"
                    },
                    {
                        "_id": "username85@ge.com",
                        "system": "urn:hc.ge.com/pfh/platform/useremail"
                    }
                ],
                "role": [
                    {
                        "code": [
                            {
                                "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                "code": "practitioner",
                                "display": "practitioner"
                            }
                        ],
                        "scopingOrganization": {
                            "reference": "site/e23662b2-8c06-43ac-a37f-f2301386e60a"
                        },
                        "status": "active"
                    },
                    {
                        "code": [
                            {
                                "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                "code": "patient",
                                "display": "patient"
                            }
                        ],
                        "scopingOrganization": {
                            "reference": "organization/6"
                        },
                        "status": "active"
                    }
                ]
            };

            return meSuccessResponse;
        }

        /**
         * Function to return user mock data
         * @returns:
         *  JSON object with mock data
         */
        function getToUser() {
            return {
                "resourceType": "Bundle",
                "title": "List of all Users for organization 1",
                "id": null,
                "entry": [
                    {
                        "title": "ResourcesUser",
                        "id": "f4c09dc9-b7e2-4565-9d07-ce31e7ed4b82",
                        "content": {
                            "resourceType": "ResourcesUser",
                            "name": {
                                "use": "official",
                                "family": [
                                    "Chalmers"
                                ],
                                "given": [
                                    "Peter",
                                    "James"
                                ]
                            },
                            "role": [
                                {
                                    "code": [
                                        {
                                            "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                            "code": "practitioner",
                                            "display": "practitioner"
                                        }
                                    ],
                                    "scopingOrganization": {
                                        "reference": "organization/5"
                                    },
                                    "status": "active"
                                },
                                {
                                    "code": [
                                        {
                                            "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                            "code": "practitioner",
                                            "display": "practitioner"
                                        }
                                    ],
                                    "scopingOrganization": {
                                        "reference": "organization/6"
                                    },
                                    "status": "active"
                                }
                            ],
                            "address": [
                                {
                                    "line": [
                                        "3300 Washtenaw Avenue, Suite 227"
                                    ],
                                    "city": "Ann Arbor",
                                    "state": "MI",
                                    "zip": "48104",
                                    "country": "USA"
                                }
                            ],
                            "telecom": [
                                {
                                    "system": "phone",
                                    "value": "(+1) 734-677-7777"
                                },
                                {
                                    "system": "email",
                                    "value": "sreeram@ge.com"
                                }
                            ],
                            "preferredLanguage": "English",
                            "type": "Human",
                            "status": "active",
                            "comment": "This is an Hospital Practioner 1",
                            "principalName": "sreeram@ge.com",
                            "gender": {
                                "coding": [
                                    {
                                        "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                        "code": "M",
                                        "display": "Male"
                                    }
                                ]
                            },
                            "acceptedAgreement": [
                                {
                                    "agreementUri": "http://goodcare.org/devices/id",
                                    "accepted": false
                                }
                            ]
                        }
                    },
                    {
                        "title": "ResourcesUser",
                        "id": "f4c09dc9-b7e2-4565-9d07-ce31e7ed4b82",
                        "content": {
                            "resourceType": "ResourcesUser",
                            "name": {
                                "use": "official",
                                "family": [
                                    "Chalmers"
                                ],
                                "given": [
                                    "Matt",
                                    "James"
                                ]
                            },
                            "role": [
                                {
                                    "code": [
                                        {
                                            "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                            "code": "practitioner",
                                            "display": "practitioner"
                                        }
                                    ],
                                    "scopingOrganization": {
                                        "reference": "organization/5"
                                    },
                                    "status": "active"
                                },
                                {
                                    "code": [
                                        {
                                            "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                            "code": "practitioner",
                                            "display": "practitioner"
                                        }
                                    ],
                                    "scopingOrganization": {
                                        "reference": "organization/6"
                                    },
                                    "status": "active"
                                }
                            ],
                            "address": [
                                {
                                    "line": [
                                        "3300 Washtenaw Avenue, Suite 227"
                                    ],
                                    "city": "Ann Arbor",
                                    "state": "MI",
                                    "zip": "48104",
                                    "country": "USA"
                                }
                            ],
                            "telecom": [
                                {
                                    "system": "phone",
                                    "value": "(+1) 734-677-7777"
                                },
                                {
                                    "system": "email",
                                    "value": "sreeram@ge.com"
                                }
                            ],
                            "preferredLanguage": "English",
                            "type": "Human",
                            "status": "active",
                            "comment": "This is an Hospital Practioner 1",
                            "principalName": "sreeram@ge.com",
                            "gender": {
                                "coding": [
                                    {
                                        "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                        "code": "M",
                                        "display": "Male"
                                    }
                                ]
                            },
                            "acceptedAgreement": [
                                {
                                    "agreementUri": "http://goodcare.org/devices/id",
                                    "accepted": false
                                }
                            ]
                        }
                    }
                ]
            };
        };

        /**
         * Function to return instrution condition generated from form
         * @returns:
         *  JSON object with mock data
         */
        function getFromConditionInstJson() {
            return [
                {
                    "boolean": "",
                    "booleanInvalid": false,
                    "key": {
                        "key": "00080060",
                        "value": "Modality"
                    },
                    "keyInvalid": false,
                    "type": {
                        "key": "CONTAINS",
                        "value": "CONTAINS"
                    },
                    "typeInvalid": false,
                    "value": "CT,MR",
                    "valueInvalid": false,
                    "maxlength": "",
                    "errormsg": ""
                },
                {
                    "boolean": {
                        "key": "AND",
                        "value": "AND"
                    },
                    "booleanInvalid": false,
                    "key": {
                        "key": "00080090",
                        "value": "Referring Physician name"
                    },
                    "keyInvalid": false,
                    "type": {
                        "key": "EQUALS",
                        "value": "EQUALS"
                    },
                    "typeInvalid": false,
                    "value": "Fname, Mname, Lname",
                    "valueInvalid": false,
                    "maxlength": "200",
                    "errormsg": ""
                },
                {
                    "boolean": {
                        "key": "OR",
                        "value": "OR"
                    },
                    "booleanInvalid": false,
                    "key": {
                        "key": "00081050",
                        "value": "Performing Physician name"
                    },
                    "keyInvalid": false,
                    "type": {
                        "key": "CONTAINS",
                        "value": "CONTAINS"
                    },
                    "typeInvalid": false,
                    "value": "Fname, Mname, Lname",
                    "valueInvalid": true,
                    "maxlength": "200",
                    "errormsg": ""
                }
            ];
        };

        /**
         * Function to return instruction condition after marshalling it
         * @returns:
         *  JSON object with mock data
         */
        function getInstructionConditionJson() {
            return [{
                "condition": {
                    "type": "OR",
                    "conditionOne": {
                        "type": "AND",
                        "conditionOne": {
                            "type": "EQUALS",
                            "key": "00080060",
                            "value": "CT,MR"
                        },
                        "conditionTwo": {
                            "type": "CONTAINS",
                            "key": "00080090",
                            "value": "first name, last name, middle name"
                        }
                    },
                    "conditionTwo": {
                        "type": "ISNOT",
                        "key": "00081050",
                        "value": "first name, last name, middle name"
                    }
                }
            }];
        };

        /**
         * Function to return instruction condition key mock data
         * @returns:
         *  JSON object with mock data
         */
        function getConditionKeyList() {
            return [{
                "key": "00080060",
                "value": "Modality"
            }, {
                "key": "00080090",
                "value": "Referring Physician name"
            }, {
                "key": "00081030",
                "value": "Procedure description"
            }, {
                "key": "00081050",
                "value": "Performing Physician name"
            }];
        };

        /**
         * Function to return instruction condition key mock data
         * @returns:
         *  JSON object with mock data
         */
        function getConditionTypeList() {
            return [{
                "key": "EQUALS",
                "value": "EQUALS"
            }, {
                "key": "CONTAINS",
                "value": "CONTAINS"
            }, {
                "key": "ISNOT",
                "value": "IS NOT"
            }];
        };

        /**
         * Function to return instruction condition key mock data
         * @returns:
         *  JSON object with mock data
         */
        function getConditionBooleanList() {
            return [{
                "key": "AND",
                "value": "AND"
            }, {
                "key": "OR",
                "value": "OR"
            }];
        };

        /**
         * Returns respective month's Abbreviation
         * @param month
         * @returns {*}
         */
        var getMonthAbbreviation = function (month) {
            switch (month) {
                case 0:
                    return "JAN";
                case 1:
                    return "FEB";
                case 2:
                    return "MAR";
                case 3:
                    return "APR";
                case 4:
                    return "MAY";
                case 5:
                    return "JUN";
                case 6:
                    return "JUL";
                case 7:
                    return "AUG";
                case 8:
                    return "SEP";
                case 9:
                    return "OCT";
                case 10:
                    return "NOV";
                case 11:
                    return "DEC";
                default:
                    return "JAN";
            }
        };

        /**
         * Returns Pacs devices
         * @returns {*[]}
         */
        var getPacsDevices = function () {
            return [
                {
                    "title":null,
                    "id":"24",
                    "content":{
                        "resourceType":"ResourcesApplicationService",
                        "type":"dicom-send",
                        "name":"CPACS",
                        "endpoint":"ApplicationSeervuiceURi 1",
                        "gateway":{
                            "reference":"device/123456"
                        },
                        "networkAddress":{
                            "ip":"3.204.111.223",
                            "entityName":"AE_ARCH01_M",
                            "port":104
                        }
                    }
                },
                {
                    "title":null,
                    "id":"26",
                    "content":{
                        "resourceType":"ResourcesApplicationService",
                        "type":"dicom-send",
                        "name":"CPACS2",
                        "endpoint":"ApplicationSeervuiceURi 2",
                        "gateway":{
                            "reference":"device/123456"
                        },
                        "networkAddress":{
                            "ip":"3.39.74.34",
                            "entityName":"AE_ARCH02_M",
                            "port":104
                        }
                    }
                }
            ]
        };

        /**
         * Returns selected device data
         * @returns {{title: null, id: string, content: {resourceType: string, type: string, name: string, endpoint: string, gateway: {reference: string}, owner: {reference: string}, networkAddress: {ip: string, entityName: string, port: number}}, selectedForDownload: boolean}}
         */
        var getSelectedDevice = function () {
            return {
                "title": null,
                "id": "1",
                "content": {
                    "resourceType": "ResourcesApplicationService",
                    "type": "dicom-query-retrieve",
                    "name": "LOCAL PACS1-ITG2",
                    "endpoint": "/v1/bucket/com.ge.pfh.ig.{deviceid}/set/configuration/content/{deviceid}-AppConf/",
                    "gateway": {
                        "reference": "LOCAL PACS1-ITG2"
                    },
                    "owner": {
                        "reference": "Concord Medical Center"
                    },
                    "networkAddress": {
                        "ip": "111.11.11.1111",
                        "entityName": "AE_PACS",
                        "port": 8080
                    }
                },
                "selectedForDownload": false
            }
        };

        /**
         * Returns selected case studies
         * @returns {*[]}
         */
        var getCaseStudies = function () {
            return [
                {
                    id: 1
                    , description: 'Study 1'
                    , createdDate: 1439592619952
                    , accession: 76876123876
                    , selectedForDownload: true
                }
                , {
                    id: 2
                    , description: 'Study 2'
                    , createdDate: 1439592664335
                    , accession: 76876123877
                    , selectedForDownload: false
                }
                , {
                    id: 3
                    , description: 'Study 3'
                    , createdDate: 1439592805889
                    , accession: 76876123878
                    , selectedForDownload: false
                }
            ]
        };

        /**
         * Returns Patient search data
         * @returns {{offset: number, limit: number, patientCriteria: {name: {firstName: string, lastName: string, middleName: string}}, studyCriteria: {id: string}, dicomDevices: *[]}}
         */
        var getPatientSearchData = function () {
            return {
                "offset": 0, "limit": 10,
                "patientCriteria": {"name": {"family": ["john"], "given": []}}, "studyCriteria": {"identifier": ""},
                "deviceList": [{
                    "identifier": "b0a0d869-1391-439f-9ee2-bc6c236b6a7d",
                    "uri": "/v1/application/hcig-0b14fa7e-f73b-450e-8e09-9f436885d73b/configitem/AppConfig/revisionid/1",
                    "name": "CPACS11"
                }],
                "patientLastName": "abc",
                "patientFirstName": "an",
                "patientMiddleName": "cde",
                "birthDate": "18031991",
                "gender": "M",
                "studyId": "",
                "identifier": "asd",
                "dicomDevices": [
                  {
                    "title": null,
                    "id": "5e60633a-eb24-49f0-bf48-93b111f7f67b",
                    "content": {
                      "resourceType": "ResourcesApplicationService",
                      "type": "dicom-send",
                      "name": "CCA RSNA",
                      "endpoint": "5e60633a-eb24-49f0-bf48-93b111f7f67b",
                      "gateway": {
                        "reference": "device/0dbc06f6-cbe1-476b-b8f8-cc9032bfb34d"
                      },
                      "owner": {
                        "reference": "site/5d9266c9-2d7c-4542-b4f5-3113924dacce",
                        "display": "GE Healthcare RSNA VNA"
                      }
                    },
                    "selected": true,
                    "expanded": false,
                    "$$hashKey": "object:297"
                  }
                ]
            }
        };

        /**
         * Returns patient search response
         * @returns {{totalCount: number, responseList: *[]}}
         */
        var getPatientInfiniteSearchData = function () {
            return {
                totalCount: 11,
                responseList: [{
                    patientId: "20080128_TOS01",
                    name: {
                        firstName: null,
                        middleName: null,
                        lastName: "TOSHI_CT_1_CARD"
                    },
                    dob: "19671201",
                    sex: "M",
                    age: 47
                }]
            }
        };

        /**
         * Returns existing patients
         * @returns {*[]}
         */
        var getExistingPatients = function () {
            return [
                {
                    patientId: "AW51400339.221.1109368170",
                    name: {
                        firstName: "CARDIAC",
                        middleName: null,
                        lastName: "VCT"
                    },
                    dob: null,
                    sex: "M",
                    age: 0,
                    active: false,
                    visible: true
                }, {
                    patientId: "123Pt30",
                    name: {
                        firstName: "Laszlo",
                        middleName: null,
                        lastName: "Count"
                    },
                    dob: "19260624",
                    sex: "M",
                    age: 88,
                    active: false,
                    visible: true
                }, {
                    patientId: "123Pt31",
                    name: {
                        firstName: "David",
                        middleName: null,
                        lastName: "Caravaggio"
                    },
                    dob: "19260624",
                    sex: "M",
                    age: 88,
                    active: false,
                    visible: true
                }, {
                    patientId: "Cardiac",
                    name: {
                        firstName: null,
                        middleName: null,
                        lastName: "Cardiac"
                    },
                    dob: null,
                    sex: "M",
                    age: 0,
                    active: false,
                    visible: true
                }, {
                    patientId: "123Pt33",
                    name: {
                        firstName: "Katharine",
                        middleName: null,
                        lastName: "Clifton"
                    },
                    dob: "19260624",
                    sex: "M",
                    age: 88,
                    active: false,
                    visible: true
                }, {
                    patientId: "CRIS204229",
                    name: {
                        firstName: "MARTIN",
                        middleName: null,
                        lastName: "DAVIS"
                    },
                    dob: "19680223",
                    sex: "M",
                    age: 46,
                    active: false,
                    visible: true
                }, {
                    patientId: "0020",
                    name: {
                        firstName: "MultiPhase",
                        middleName: null,
                        lastName: "CardiacAngio"
                    },
                    dob: "19500704",
                    sex: "M",
                    age: 64,
                    active: false,
                    visible: true
                }, {
                    patientId: "221-98-1019",
                    name: {
                        firstName: "JACQUELINE",
                        middleName: null,
                        lastName: "ABRAR"
                    },
                    dob: "19381203",
                    sex: "F",
                    age: 76,
                    active: false,
                    visible: true
                }, {
                    patientId: "101GEMS123873751397992",
                    name: {
                        firstName: null,
                        middleName: null,
                        lastName: "Giosuè"
                    },
                    dob: "20090424",
                    sex: "O",
                    age: 5,
                    active: false,
                    visible: true
                }, {
                    patientId: "101GEMS123874028854877",
                    name: {
                        firstName: null,
                        middleName: null,
                        lastName: "Kari"
                    },
                    dob: "20090331",
                    sex: "O",
                    age: 5,
                    active: false,
                    visible: true
                }]
        };

        /**
         * Returns selected study list
         * @returns {*[]}
         */
        var getSelectedStudyList = function () {
            return [
                {
                    "identifier": "3262",
                    "description": "CT:ABD PEL W/O CONT",
                    "modalityList": [
                        "_CT"
                    ],
                    "size": null,
                    "sourceAeTitle": null,
                    "started": "20060629",
                    "uid": "1.3.46.670589.33.1.39137552603945218638.26206065572426287053",
                    "accession": "com.ge.hc.pfh.domain.resources.sdfcore.types.String@79639a2e",
                    "performingPhysician": null,
                    "referrer": null,
                    "anatomicRegion": null,
                    "procedure": null,
                    "selected": false,
                    "isAttached": false
                }, {
                    "identifier": "3262",
                    "description": "CT:ABD PEL W/O CONT",
                    "modalityList": [
                        "_CT"
                    ],
                    "size": null,
                    "sourceAeTitle": null,
                    "started": "20060629",
                    "uid": "1.3.46.670589.33.1.39137552603945218638.26206065572426287053",
                    "accession": "com.ge.hc.pfh.domain.resources.sdfcore.types.String@79639a2e",
                    "performingPhysician": null,
                    "referrer": null,
                    "anatomicRegion": null,
                    "procedure": null,
                    "date": "20061219",
                    "selected": true,
                    "isAttached": true
                },
                {
                    "identifier": "3262",
                    "description": "CT:ABD PEL W/O CONT",
                    "modalityList": [
                        "_CT"
                    ],
                    "size": null,
                    "sourceAeTitle": null,
                    "started": "20060629",
                    "uid": "1.3.46.670589.33.1.39137552603945218638.26206065572426287053",
                    "accession": "com.ge.hc.pfh.domain.resources.sdfcore.types.String@79639a2e",
                    "performingPhysician": null,
                    "referrer": null,
                    "anatomicRegion": null,
                    "procedure": null,
                    "date": "20061219"
                }
            ]
        };

        /**
         * Returns patients from pacs
         * @returns {{totalCount: number, responseList: *[], errorCodeMap: {1c5b5099-967e-4a04-9826-9cfb42195819: string}}}
         */
        var getPatientsFromPacs = function () {
            return {
                "totalCount": 3,
                "responseList": [
                    {
                        "identifier": "AW612437470.888.1276871906",
                        "name": {
                            "family": [
                                "VCT SHUTTLE 4"
                            ],
                            "given": null,
                            "prefix": null,
                            "suffix": null,
                            "empty": false
                        },
                        "birthDate": null,
                        "gender": null,
                        "age": 0,
                        "applicationServiceId": "1c5b5099-967e-4a04-9826-9cfb42195819",
                        "active": true,
                        "errorCodeMap": {
                            "1c5b5099-967e-4a04-9826-9cfb42195819": "200"
                        },
                        "visible": true,
                    },
                    {
                        "identifier": "1",
                        "name": {
                            "family": [
                                "LNCT3"
                            ],
                            "given": [
                                "FNCT3",
                                "MNCT3"
                            ],
                            "prefix": null,
                            "suffix": null,
                            "empty": false
                        },
                        "birthDate": "20020316",
                        "gender": "O",
                        "age": 12,
                        "applicationServiceId": "1c5b5099-967e-4a04-9826-9cfb42195819",
                        "active": true,
                        "errorCodeMap": {
                            "1c5b5099-967e-4a04-9826-9cfb42195819": "500"
                        }
                    },
                    {
                        "identifier": "AW2081708497.751.1438174157",
                        "name": {
                            "family": [
                                "REV_CT"
                            ],
                            "given": [
                                "REV_CT"
                            ],
                            "prefix": null,
                            "suffix": null,
                            "empty": false
                        },
                        "birthDate": "20151101",
                        "gender": "M",
                        "age": 0,
                        "applicationServiceId": "1c5b5099-967e-4a04-9826-9cfb42195819",
                        "active": true
                    }
                ],
                "errorCodeMap": {
                    "1c5b5099-967e-4a04-9826-9cfb42195819": "200"
                }
            }
        };

        /**
         * Returns single patient form pacs
         * @returns {{totalCount: number, responseList: *[], errorCodeMap: {1c5b5099-967e-4a04-9826-9cfb42195819: string}}}
         */
        var getSinglePatientFromPacs = function () {
            return {
                "active": true,
                "totalCount": 1,
                "responseList": [
                    {
                        "identifier": "AW612437470.888.1276871906",
                        "name": {
                            "family": [
                                "VCT SHUTTLE 4"
                            ],
                            "given": null,
                            "prefix": null,
                            "suffix": null,
                            "empty": false
                        },
                        "birthDate": null,
                        "gender": null,
                        "age": 0,
                        "applicationServiceId": "1c5b5099-967e-4a04-9826-9cfb42195819"
                    }
                ],
                "errorCodeMap": {
                    "1c5b5099-967e-4a04-9826-9cfb42195819": "200"
                }
            }
        };

        /**
         * Returns studies from pacs
         * @returns {{totalCount: number, responseList: *[], errorCodeMap: {24: string, 26: string}}}
         */
        var getStudiesFromPacs = function () {
            return {
                "totalCount": 3,
                "responseList": [
                    {
                        "identifier": "3262",
                        "description": "CT:ABD PEL W/O CONT",
                        "modalityList": [
                            "_CT"
                        ],
                        "size": null,
                        "sourceAeTitle": null,
                        "started": "20060629",
                        "uid": "1.3.46.670589.33.1.39137552603945218638.26206065572426287053",
                        "accession": "com.ge.hc.pfh.domain.resources.sdfcore.types.String@79639a2e",
                        "performingPhysician": null,
                        "referrer": null,
                        "anatomicRegion": null,
                        "procedure": null,
                        "active": true
                    },
                    {
                        "identifier": "3261",
                        "description": "CT:ABD PEL W/O CONT",
                        "modalityList": [
                            "_CT"
                        ],
                        "size": null,
                        "sourceAeTitle": null,
                        "started": "20060629",
                        "uid": "1.3.46.670589.33.1.1339745757366423366.2767104374324153402",
                        "accession": "com.ge.hc.pfh.domain.resources.sdfcore.types.String@6eae4441",
                        "performingPhysician": null,
                        "referrer": null,
                        "anatomicRegion": null,
                        "procedure": null
                    },
                    {
                        "identifier": "3263",
                        "description": "CT:ABD PEL W/O CONT",
                        "modalityList": [
                            "_CT"
                        ],
                        "size": null,
                        "sourceAeTitle": null,
                        "started": "20060629",
                        "uid": "1.3.46.670589.33.1.17872257152345180736.26650987383115832436",
                        "accession": "com.ge.hc.pfh.domain.resources.sdfcore.types.String@65ff1490",
                        "performingPhysician": null,
                        "referrer": null,
                        "anatomicRegion": null,
                        "procedure": null
                    }
                ],
                "errorCodeMap": {
                    "24": "200",
                    "26": "200"
                }
            }
        };

        /**
         * Returns json for current user as Admin
         * @returns json object
         */
        function getAdminJson(){
            return {
                "role": [{
                    "code": [{
                        "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                        "code": "administrator",
                        "display": "administrator"
                    }],
                    "scopingOrganization": {
                        "reference": "site/308d7ca2-a53c-4829-9780-ea7d151392d3",
                        "display": "GE Healthcare RSNA 3"
                    },
                    "status": "active"
                }]
            };
        };

        /**
         * Returns json for current user as Patient
         * @returns json object
         */
        function getPatientJson(){
            return {
                "role": [{
                    "code": [{
                        "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                        "code": "patient",
                        "display": "patient"
                    }],
                    "scopingOrganization": {
                        "reference": "site/308d7ca2-a53c-4829-9780-ea7d151392d3",
                        "display": "GE Healthcare RSNA 3"
                    },
                    "status": "active"
                }]
            };
        };
        /**
         * Returns json for current user as practitioner
         * @returns json object
         */
        function getPractitionerJson(){
            return {
                "role": [{
                    "code": [{
                        "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                        "code": "practitioner",
                        "display": "practitioner"
                    }],
                    "scopingOrganization": {
                        "reference": "site/308d7ca2-a53c-4829-9780-ea7d151392d3",
                        "display": "GE Healthcare RSNA 3"
                    },
                    "status": "active"
                }]
            };
        };

        /**
         * Returns case instruction list
         * @returns json object
         */
        function getCaseInstListResponse(){
            return {
              "totalCount":11,
              "responseList":[
                  {"name":"instruction11","description":"The description is instruction11","status":"Active"},
                  {"name":"instruction12","description":"The description is instruction12","status":"Suspended"},
                  {"name":"instruction13","description":"The description is instruction12","status":"Active"},
                  {"name":"instruction14","description":"The description is instruction12","status":"Suspended"},
                  {"name":"instruction15","description":"The description is instruction12","status":"Active"},
                  {"name":"instruction16","description":"The description is instruction12","status":"Active"},
                  {"name":"instruction17","description":"The description is instruction12","status":"Suspended"},
                  {"name":"instruction18","description":"The description is instruction12","status":"Suspended"},
                  {"name":"instruction19","description":"The description is instruction12","status":"Active"},
                  {"name":"instruction10","description":"The description is instruction12","status":"Suspended"}
                ]
            };
        };

        /**
         * Returns post condition json
         * @returns json object
         */
        function getPostCondition() {
            return {
                "algorithm": "Algorithm 1",
                "modality": "MR",
                "description": "description"
            };
        };

        /**
         * Returns marshalled json
         * @returns json object
         */
        function marshalConditionJson(){
            return {
                "algorithm": {
                    "value": "Algorithm 1"
                  },
                  "modality": "MR",
                  "description": "description"
            };
        };

        /**
         * Returns unmarshalled json
         * @returns json object
         */
        function unmarshalConditionJson() {
            return {
                "type": "OR",
                "conditionOne": {
                  "type": "AND",
                  "conditionOne": {
                    "type": "EQUALS",
                    "key": "00080090",
                    "value": "MR"
                  },
                  "conditionTwo": {
                    "type": "CONTAINS",
                    "key": "00081030",
                    "value": "description"
                  }
                },
                "conditionTwo": {
                  "type": "11",
                  "key": "Algorithm",
                  "value": "Algorithm 1"
                }
            };
        };

        /*
        * Returns billing organizations JSON
        * @returns json object
        */
        function getBillingOrganizations(){
            return [{
                "reference": "organization/3f3ac310-d2f0-4570-8bb1-5174d99622cf",
                "display": "qwqww"
              }];
        };

        function getBillingOrganizationsDetails(){
            return {
                role: [{
                "reference": "organization/3f3ac310-d2f0-4570-8bb1-5174d99622cf",
                "display": "qwqww"
              }]
            };
        }

        return {
            getCaseHeaders: getCaseHeaders,
            getCaseTransactions: getCaseTransactions,
            getCaseDetails: getCaseDetails,
            getPatient: getPatient,
            getStudyList: getStudyList,
            getCaseDicomAttachment: getCaseDicomAttachment,
            getDicomApplicationService: getDicomApplicationService,
            getNonDicomFiles: getNonDicomFiles,
            getClinicalReasons: getClinicalReasons,
            getBillingOrganizations: getBillingOrganizations,
            getBillingOrganizationsDetails: getBillingOrganizationsDetails,
            getTransactionStudyList: getTransactionStudyList,
            getMeServiceResponse: getMeServiceResponse,
            getToUser: getToUser,
            getFromConditionInstJson: getFromConditionInstJson,
            getInstructionConditionJson: getInstructionConditionJson,
            getConditionKeyList: getConditionKeyList,
            getConditionTypeList: getConditionTypeList,
            getConditionBooleanList: getConditionBooleanList,
            getMonthAbbreviation: getMonthAbbreviation,
            getPacsDevices: getPacsDevices,
            getSelectedDevice: getSelectedDevice,
            getCaseStudies: getCaseStudies,
            getPatientSearchData: getPatientSearchData,
            getPatientInfiniteSearchData: getPatientInfiniteSearchData,
            getExistingPatients: getExistingPatients,
            getPatients: getPatients,
            getSelectedStudyList: getSelectedStudyList,
            getPatientsFromPacs: getPatientsFromPacs,
            getSinglePatientFromPacs: getSinglePatientFromPacs,
            getStudiesFromPacs: getStudiesFromPacs,
            getAdminJson : getAdminJson,
            getPatientJson : getPatientJson,
            getPractitionerJson : getPractitionerJson,
            getCaseInstListResponse: getCaseInstListResponse,
            getPostCondition:getPostCondition,
            marshalConditionJson:marshalConditionJson,
            unmarshalConditionJson:unmarshalConditionJson
        }
    });
});
