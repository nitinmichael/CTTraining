/*
 * ge-generic-header-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define([ 'angular-mocks',  'modules/platform/directives/ge-generic-header/ge-generic-header-directive' ], function() {
    'use strict';


    describe('Generic header controller', function () {
        var scope, rootScope, $controller, $filter, filterNames, filterArgs, controller;

        beforeEach(module('platform.directive.ge-generic-header-directive'));
        beforeEach(function () {
            rootScope = {
                $broadcast: sinon.spy()
            };
            filterNames = [];
            filterArgs = [];
            $filter = function(fname){
                filterNames.push(fname);
                return function(a1, a2, a3, a4){
                    filterArgs.push([a1, a2, a3, a4]);
                    return a1 + '_' + a2;
                };
            };
            inject(function ($rootScope, _$controller_) {
                scope = $rootScope.$new();
                controller = _$controller_('geGenericHeaderController', {
                    $scope: scope,
                    $rootScope: rootScope,
                    $filter: $filter
                });
            });
        });

        it("should have a controller defined", function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it("should have a toggleDetails method defined", function () {
            assert.isDefined(scope.toggleDetails);
            expect(scope.showDetails).to.be.false;

            scope.toggleDetails();

            expect(scope.showDetails).to.be.true;
            expect(rootScope.$broadcast.calledWith('HeaderDetailIsVisible', true)).to.be.true;
        });

        it("should have a displayData method defined", function () {
            assert.isDefined(scope.displayData);
            scope.data = {
                'ABC123': 'Lorem Pista'
            };

            var config = {
                dataKey: 'ABC123'
            };

            var res = scope.displayData(config);

            expect(res).to.be.equal('Lorem Pista');
        });

        it("should have a displayData method defined which handles filters", function () {
            assert.isDefined(scope.displayData);
            scope.data = {
                'ABC123': 'Lorem Pista'
            };

            var config = {
                dataKey: 'ABC123',
                filters: ['sampleFilter:arg1:arg2:arg3']
            };

            var res = scope.displayData(config);

            expect(filterNames[0]).to.be.equal('sampleFilter');
            expect(filterArgs[0][0]).to.be.equal('Lorem Pista');
            expect(filterArgs[0][1]).to.be.equal('arg1');
            expect(filterArgs[0][3]).to.be.equal('arg3');
            expect(res).to.be.equal('Lorem Pista_arg1');
        });
    });
});