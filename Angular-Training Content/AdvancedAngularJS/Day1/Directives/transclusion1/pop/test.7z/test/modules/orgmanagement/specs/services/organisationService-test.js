define(['angular','angular-mocks', 'orgMgmnt/services/organizationService'], function () {
    'use strict';
    describe('Test Org Service', function () {
        beforeEach(function () {
            module(function($provide){
                $provide.service('masterDataModel', function(){
                    this.getGatewayUrl= sinon.spy();
                });
            });
            module('Orgmanagement.Services.OrganizationService');
        });
        var orgMgmtService, _masterDataModel, uomServiceUrl;
        var $httpBackend;
        var q, defer;
        beforeEach(inject(function(_orgMgmtService_, _$httpBackend_,_$q_, masterDataModel) {
            orgMgmtService = _orgMgmtService_;
            $httpBackend = _$httpBackend_;
            _masterDataModel = masterDataModel;
            q = _$q_;
            defer = q.defer();
            uomServiceUrl = _masterDataModel.getGatewayUrl();
        }));

        describe('UpdateOrganizationSettings service', function(){
            it('should test updateOrganizationSettings is called successfully ', function () {
                var extensions={};
                var url=uomServiceUrl+'/v1/organization';
                $httpBackend.expectPUT(url,extensions).respond(200);
                defer.resolve();
                orgMgmtService.updateOrganizationSettings(extensions);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test updateOrganizationSettings is not called successfully ', function () {
                var extensions={};
                var url=uomServiceUrl+'/v1/organization';
                $httpBackend.expectPUT(url,extensions).respond(400);
                defer.resolve();
                orgMgmtService.updateOrganizationSettings(extensions);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('GetOrganizationDetail service', function(){
            it('should test getOrganisationDetail is called successfully ', function () {
                var url=uomServiceUrl+'/v1/organization/123';
                $httpBackend.expectGET(url).respond(200);
                defer.resolve('1234');
                orgMgmtService.getOrganizationDetail('123');
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test getOrganisationDetail is not called successfully ', function () {
                var url=uomServiceUrl+'/v1/organization/123';
                $httpBackend.expectGET(url).respond(400);
                defer.resolve('1234');
                orgMgmtService.getOrganizationDetail('123');
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('UpdateOrganizationDetail service', function(){
            it('should test updateOrganizationDetail is called successfully ', function () {
                var orgDetail ={organization:"GEHC", orgId:"123"};
                var url= uomServiceUrl+"/v1/organization/"+orgDetail.orgId+"/orgdetails";

                $httpBackend.expectPUT(url).respond(200);
                defer.resolve();
                orgMgmtService.updateOrganizationDetail(orgDetail);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test updateOrganizationDetail is not called successfully ', function () {
                var orgDetail ={organization:"GEHC", orgId:"123"};
                var url= uomServiceUrl+"/v1/organization/"+orgDetail.orgId+"/orgdetails";

                $httpBackend.expectPUT(url).respond(400);
                defer.reject();
                orgMgmtService.updateOrganizationDetail(orgDetail);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test updateOrgAdmins is called successfully ', function () {
                var orgAdminDetail =[{
                    "op": "replace",
                    "path": "scopingOrganization",
                    "value": '232'
                },
                {
                    "op": "replace",
                    "path": "",
                    "value": ['12', '45']
                }];
                var url= uomServiceUrl + "/v1/user/scopedRole";
                $httpBackend.expectPATCH(url).respond(200);
                defer.resolve();
                orgMgmtService.updateOrgAdmins(orgAdminDetail);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test updateOrgAdmins is not called successfully ', function () {
                var orgAdminDetail =[{
                    "op": "replace",
                    "path": "scopingOrganization",
                    "value": '232'
                },
                    {
                        "op": "replace",
                        "path": "",
                        "value": ['12', '45']
                    }];
                var url= uomServiceUrl + "/v1/user/scopedRole";
                $httpBackend.expectPATCH(url).respond(400);
                defer.reject();
                orgMgmtService.updateOrgAdmins(orgAdminDetail);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('CreateOrganization service', function(){
            it('should test createOrganization is called successfully ', function () {
                var org = {"value":"GEHC"};
                var url=uomServiceUrl+'/v1/organization';
                $httpBackend.expectPOST(url,org).respond(200);
                defer.resolve();
                orgMgmtService.createOrganization(org);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test createOrganization is not called successfully ', function () {
                var org = {"value":"GEHC"};
                var url=uomServiceUrl+'/v1/organization';
                $httpBackend.expectPOST(url,org).respond(400);
                defer.resolve();
                orgMgmtService.createOrganization(org);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('UpdateOrganizationNetworkSettings service', function(){
            it('should test UpdateOrganizationNetworkSettings is called successfully', function(){
                var orgNetworkDetail ={extension:"GEHC", orgId:"123"};
                var url= uomServiceUrl+"/v1/organization/"+orgNetworkDetail.orgId+"/networksettings";

                $httpBackend.expectPUT(url).respond(200);
                defer.resolve();
                orgMgmtService.updateOrganizationNetworkSettings(orgNetworkDetail);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test UpdateOrganizationNetworkSettings is not called successfully', function(){
                var orgNetworkDetail ={extension:"GEHC", orgId:"123"};
                var url= uomServiceUrl+"/v1/organization/"+orgNetworkDetail.orgId+"/networksettings";

                $httpBackend.expectPUT(url).respond(400);
                defer.reject();
                orgMgmtService.updateOrganizationNetworkSettings(orgNetworkDetail);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('UpdateOrganizationDefaultNetworkSettings Service', function(){
            it('should test updateOrganizationDefaultNetworkSettings is called successfully', function(){
                var orgDefaultNetworkDetail ={extension:"GEHC", orgId:"123"};
                var url=uomServiceUrl+ "/v1/organization/"+orgDefaultNetworkDetail.orgId+"/defaultsitesettings";

                $httpBackend.expectPUT(url).respond(200);
                defer.resolve();
                orgMgmtService.updateOrganizationDefaultNetworkSettings(orgDefaultNetworkDetail);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
            it('should test updateOrganizationDefaultNetworkSettings is not called successfully', function(){
                var orgDefaultNetworkDetail ={extension:"GEHC", orgId:"123"};
                var url= uomServiceUrl+"/v1/organization/"+orgDefaultNetworkDetail.orgId+"/defaultsitesettings";

                $httpBackend.expectPUT(url).respond(400);
                defer.reject();
                orgMgmtService.updateOrganizationDefaultNetworkSettings(orgDefaultNetworkDetail);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('ViewOrganization service', function(){
            it('should test ViewOrganization is called successfully ', function () {
                var url=uomServiceUrl+'/v1/organization/123';
                $httpBackend.expectGET(url).respond(200);
                defer.resolve('1234');
                orgMgmtService.viewOrganization('123');
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test ViewOrganization is not called successfully ', function () {
                var url=uomServiceUrl+'/v1/organization/123';
                $httpBackend.expectGET(url).respond(400);
                defer.resolve('1234');
                orgMgmtService.viewOrganization('123');
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('GetAllOrganization Service', function(){
            it('should test GetAllOrganization is called successfully ', function () {
                var url=uomServiceUrl+'/v1/organization/user/123';
                $httpBackend.expectGET(url).respond(200);
                defer.resolve('1234');
                orgMgmtService.getAllOrganization();
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test GetAllOrganization is not called successfully ', function () {
                var url=uomServiceUrl+'/v1/organization/user/123';
                $httpBackend.expectGET(url).respond(400);
                defer.reject('1234');
                orgMgmtService.getAllOrganization();
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('GetUserDetails based on userId Service', function(){
            it('should test getUserDetails is called successfully ', function () {
                var id="034e2e9b-60b0-4856-85a7-c43779a11746";
                var url=uomServiceUrl+'/v1/user/'+id;
                var res=JSON.parse(JSON.stringify({"data":{"resourceType":"ResourcesUser","name":{"use":"official","family":["Tari"],"given":["Tushar","K"]},"address":[{"line":["3300 Washtenaw Avenue, Suite 227"],"city":"Ann Arbor","state":"MI","zip":"48104","country":"USA"}],"telecom":[{"system":"phone","value":"(+1) 734-677-7777"},{"system":"email","value":"tushar.tari@ge.com"}],"principalName":"tushar.tari@ge.com"},"status":200}));
                $httpBackend.expectGET(url).respond(200);
                defer.resolve(res);
                orgMgmtService.getUserDetails(id);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test getUserDetails is not called successfully ', function () {
                var id="034e2e9b-60b0-4856-85a7-c43779a11746";
                var url=uomServiceUrl+'/v1/user/'+id;
                var res=JSON.parse(JSON.stringify({data: Object, status: 404, config: Object, statusText: "Not Found"}));
                $httpBackend.expectGET(url).respond(400);
                defer.reject(res);
                orgMgmtService.getUserDetails(id);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('GetOrgAdmins based on orgId', function(){
            it('should test getOrgAdmins is called successfully', function () {
                var id="92d38f96-f122-4465-a4b2-c90c843fda68";
                var url=uomServiceUrl+"/v1/organization/"+id+"/administrator";
                var res=JSON.parse(JSON.stringify({"data":{"resourceType":"Bundle","title":"List of all Users for 92d38f96-f122-4465-a4b2-c90c843fda68","id":null,"entry":[{"title":"ResourcesUser","id":"034e2e9b-60b0-4856-85a7-c43779a11746","content":{"resourceType":"ResourcesUser","name":{"use":"official","family":["Tari"],"given":["Tushar","K"]},"address":[{"line":["3300 Washtenaw Avenue, Suite 227"],"city":"Ann Arbor","state":"MI","zip":"48104","country":"USA"}],"telecom":[{"system":"phone","value":"(+1) 734-677-7777"},{"system":"email","value":"tushar.tari@ge.com"}],"principalName":"tushar.tari@ge.com"}}]},"status":200}));
                $httpBackend.expectGET(url).respond(200);
                defer.resolve(res);
                orgMgmtService.getOrgAdmins(id);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
            it('should test getOrgAdmins is not called successfully', function () {
                var id="92d38f96-f122-4465-a4b2-c90c843fda68";
                var url=uomServiceUrl+"/v1/organization/"+id+"/administrator";
                var res=JSON.parse(JSON.stringify({data: Object, status: 404, config: Object, statusText: "Not Found"}));
                $httpBackend.expectGET(url).respond(400);
                defer.reject(res);
                orgMgmtService.getOrgAdmins(id);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
            it('should test updateOrganizationAccountOwnerDetail is called successfully', function () {
                var id="25a5ce96-c20a-45d0-82e8-fc31c5fe5bea";
                var url=uomServiceUrl+"/v1/organization/"+id+"/contact";
                var res=JSON.parse(JSON.stringify({data: "", status: 200,statusText: "OK"}));
                var orgDetail={"resourceType":"Organization","extension":[{"url":"urn:hc.ge.com/pfh/platform/extension/entitynickname:V1","valueString":"hdf"},{"url":"urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1","valueCoding":{"system":"urn:hc.ge.com/pfh/platform/policy:V1","code":"_case_download_inside_network","display":"Allow download of case files"}},{"url":"urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1","valueCoding":{"system":"urn:hc.ge.com/pfh/platform/policy:V1","code":"_case_download_inside_new_site","display":"Allow download of case files"}}],"identifier":[{"system":"urn:hc.ge.com/pfh/platform/identifier","value":"b6ae9922-21c1-4e89-a3b2-9b056a640047"},{"_id":"25a5ce96-c20a-45d0-82e8-fc31c5fe5bea","system":"urn:hc.ge.com/pfh/platform/orgtype"}],"name":"O31","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"ORG","display":"Organization"}]},"address":[{"line":["hd"],"city":"djf","state":"MI","zip":"785678","country":"US"}],"contact":[{"name":{"text":"abc"},"telecom":[{"system":"phone","value":"22222-9999999999"},{"system":"email","value":"abc@ab.in"}]}]};
                $httpBackend.expectPUT(url,orgDetail).respond(200);
                defer.resolve(res);
                orgMgmtService.updateOrganizationAccountOwnerDetail(orgDetail,id);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
            it('should test updateOrganizationAccountOwnerDetail is not called successfully', function () {
                var id="25a5ce96-c20a-45d0-82e8-fc31c5fe5bea";
                var url=uomServiceUrl+"/v1/organization/"+id+"/contact";
                var res=JSON.parse(JSON.stringify({data: "", status: 405,statusText: "Method Not Allowed"}));
                var orgDetail={"resourceType":"Organization","extension":[{"url":"urn:hc.ge.com/pfh/platform/extension/entitynickname:V1","valueString":"hdf"},{"url":"urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1","valueCoding":{"system":"urn:hc.ge.com/pfh/platform/policy:V1","code":"_case_download_inside_network","display":"Allow download of case files"}},{"url":"urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1","valueCoding":{"system":"urn:hc.ge.com/pfh/platform/policy:V1","code":"_case_download_inside_new_site","display":"Allow download of case files"}}],"identifier":[{"system":"urn:hc.ge.com/pfh/platform/identifier","value":"b6ae9922-21c1-4e89-a3b2-9b056a640047"},{"_id":"25a5ce96-c20a-45d0-82e8-fc31c5fe5bea","system":"urn:hc.ge.com/pfh/platform/orgtype"}],"name":"O31","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"ORG","display":"Organization"}]},"address":[{"line":["hd"],"city":"djf","state":"MI","zip":"785678","country":"US"}],"contact":[{"name":{"text":"abc"},"telecom":[{"system":"phone","value":"22222-9999999999"},{"system":"email","value":"abc@ab.in"}]}]};
                $httpBackend.expectPUT(url,orgDetail).respond(405);
                defer.reject(res);
                orgMgmtService.updateOrganizationAccountOwnerDetail(orgDetail,id);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('Validate Organization Legal Name service', function(){
            it("checks Validate Organization Legal Name service is called successfully", function(){
                var url = uomServiceUrl+"/v1/organization?validateOnly=true";
                var orgObj = {
                    "resourceType": "ResourcesUserGroup",
                    "member": [],
                    "managingOrganization": {},
                    "partOf": {},
                    "name": "org"
                };
                $httpBackend.expectPOST(url,orgObj).respond(200);
                defer.resolve();
                orgMgmtService.isValidOrgName(orgObj);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it("checks Validate Organization Legal Name service is not called successfully", function(){
                var url = uomServiceUrl+"/v1/organization?validateOnly=true";
                var orgObj = {
                    "resourceType": "ResourcesUserGroup",
                    "member": [],
                    "managingOrganization": {},
                    "partOf": {},
                    "name": "org"
                };
                $httpBackend.expectPOST(url,orgObj).respond(400);
                defer.reject();
                orgMgmtService.isValidOrgName(orgObj);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('Get Multi Org Details service', function(){
            var orgIds = ['891a1d75-79cf-49d6-902f-3ccab357e22f'];
            it("checks Multi Org Details service is called successfully", function(){
                var url = uomServiceUrl+ "/v1/organization/"+orgIds[0];
                $httpBackend.expectGET(url).respond(200);
                defer.resolve();
                orgMgmtService.getMultipleOrganizationDetails(orgIds);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it("checks Multi Org Details service is not called successfully", function(){
                var url = uomServiceUrl+ "/v1/organization/"+orgIds[0];
                $httpBackend.expectGET(url).respond(400);
                defer.reject();
                orgMgmtService.getMultipleOrganizationDetails(orgIds);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });
        describe("Organization list depending upon text given", function(){
            it("get organization list from server for typeahead, success", function(){
                var searchParam ='test',
                    ORGANIZATION_SEARCH_URL = uomServiceUrl + '/v1/organization/_search?name=test',
                    res=JSON.parse(JSON.stringify({data: "", status: 200,statusText: "OK"}));
                    
                $httpBackend.expectGET(ORGANIZATION_SEARCH_URL).respond(200);
                defer.resolve(res);
                orgMgmtService.findOrganization(searchParam);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it("get organization list from server for typeahead, failure", function(){
                var searchParam ='test',
                    ORGANIZATION_SEARCH_URL = uomServiceUrl + '/v1/organization/_search?name=test';
                    
                $httpBackend.expectGET(ORGANIZATION_SEARCH_URL).respond(400);
                defer.reject();
                orgMgmtService.findOrganization(searchParam);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });
    });
});




