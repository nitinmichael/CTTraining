/**
 * @ngdoc service
 * @name cloudav.viewerApp.test:TEST_hdx-patient-banner
 *
 * @description This property is a unit test file located at: test > modules > viewer > modules > viewer-app > widgets >
 *              hdx-patient-banner-test.js This file contains unit tests for the
 *              {@link cloudav.viewerApp.mousemanagement.services:mousemodetoolbar} service.
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 *
 * @author: Josselin BUILS <josselin.buils@ge.com>
 */

define(['angular', 'angular-mocks', 'viewerModule/widgets/hdx-patient-banner/hdx-patient-banner-directive','viewportParameterStorageMock'], function() {
    'use strict';

    describe('hdx-patient-banner :', function() {
        var $document,
            element,
            isolatedScope,
            scope,
            viewportParameterStorage,
            viewportParameterStorageMock;

        beforeEach(module('viewportParameterStorage'));
        beforeEach(module('templates'));

        beforeEach(module('cloudav.viewerApp.widgets', function($provide, _viewportParameterStorageMock_) {
            viewportParameterStorage = _viewportParameterStorageMock_.$get();
            viewportParameterStorageMock = _viewportParameterStorageMock_;
            $provide.provider('$viewportParameterStorage', viewportParameterStorageMock);
        }));

        beforeEach(inject(function($compile, $rootScope, _$document_) {
            $document = _$document_;

            var html = '<hdx-patient-banner></hdx-patient-banner>';
            scope = $rootScope.$new();
            element = $compile(html)(scope);
            scope.$digest();
            isolatedScope = element.isolateScope();
        }));

        /**
         * @ngdoc property
         * @name UNIT_TEST_hdx-patient-banner-initialization
         * @propertyOf cloudav.viewerApp.test:TEST_hdx-patient-banner
         *
         * @description This property is a unit test located in the hdx-patient-banner-TEST file. It is designed to
         *              test the initial creation of the hdxPatientBanner directive.
         *
         */

        it('should have a directive', function() {
            assert.isDefined(element, 'hdx-patient-banner Directive is not defined');
        });

        it('should have a patientInfo in scope', function() {
            assert.isDefined(isolatedScope.patientInfo, 'patientInfo is not defined');
        });

        it('should have a patientInfo in scope with an id', function() {
            assert.isDefined(isolatedScope.patientInfo.id, 'patientInfo.id is not defined');
            expect(isolatedScope.patientInfo.id).to.equals('1234', 'patientInfo.id should be equal to 1234');
        });

        it('should have a patientInfo in scope with a title', function() {
            assert.isDefined(isolatedScope.patientInfo.title, 'patientInfo.title is not defined');
            expect(isolatedScope.patientInfo.title).to.equals('Mr.', 'patientInfo.title should be equal to Mr.');
        });

        it('should have a patientInfo in scope with a name', function() {
            assert.isDefined(isolatedScope.patientInfo.name, 'patientInfo.name is not defined');
            expect(isolatedScope.patientInfo.name).to.equals('Jack Travis', 'patientInfo.name should be equal to Jack Travis');
        });

        it('should have a patientInfo in scope with an age', function() {
            assert.isDefined(isolatedScope.patientInfo.age, 'patientInfo.age is not defined');
            expect(isolatedScope.patientInfo.age).to.equals('70', 'patientInfo.age should be equal to 70');
        });

        it('should have a patientInfo in scope with a dob', function() {
            assert.isDefined(isolatedScope.patientInfo.dob, 'patientInfo.dob is not defined');
            expect(isolatedScope.patientInfo.dob).to.equals('16/12/1944', 'patientInfo.dob should be equal to 16/12/1944');
        });

        it('should have a patientInfo in scope with a gender', function() {
            assert.isDefined(isolatedScope.patientInfo.gender, 'patientInfo.gender is not defined');
            expect(isolatedScope.patientInfo.gender).to.equals('male', 'patientInfo.gender should be equal to male');
        });

        it('should not update the patient infos if getPatientInfo returns null', function() {
            viewportParameterStorageMock.patientInfo = null;
            expect(viewportParameterStorage.getPatientInfo()).to.equal(null);
            scope.$apply();
            expect(isolatedScope.patientInfo.gender).to.equals('male', 'patientInfo.gender should be equal to male');
        });
    });
});
