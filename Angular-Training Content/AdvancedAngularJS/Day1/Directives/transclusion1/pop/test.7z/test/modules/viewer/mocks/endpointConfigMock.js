define(['viewerMockModule'], function (viewerMockModule) {
    return viewerMockModule.constant('$Endpoint', {
        getEndpoint: function () {
            return '';
        },
        getEndpointAsync: function () {
            return {
                then: function () {
                    return '';
                }
            };
        }
    });
});
