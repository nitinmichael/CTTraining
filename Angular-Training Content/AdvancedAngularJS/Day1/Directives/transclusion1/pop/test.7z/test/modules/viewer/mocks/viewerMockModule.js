define(['angular'], function(angular) {
    return angular.module('cloudav.viewerMockModule', []);
});
