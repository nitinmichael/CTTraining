/*
 * normalization-controller.js
 * 
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 * 
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 * 
 * @author: Raoul Nair<raoul.nair@ge.com>
 */

define(['angular', 'angular-mocks', 'case-inbox/module', 'case-inbox/controllers/normalization-controller', 'create-case/services/pacs-search-service', 'create-case/services/pacs-search-marshaller-service', 'mocks/case-exchange-mock-service'], function () {
    'use strict';

    var rootScope, scope, controller, state, filter, modal, dismiss, normalizationService, pacsDevices, selectedCasePatient, patientCompareList, selectedStudyList;

    var dismiss = function () {

    };

    function fakePatientResolved(value) {
        return {
            promise: {
                then: function (callback) {
                    callback("");
                }
            }
        }
    }

    var dateFormatFilter = function (value) {
        return value;
    };

    describe('Normalization Controller Test Suite::', function () {

        beforeEach(function () {
            // Load the module for the mock data first
            module('cloudav.caseExchange.mocks');

            module('cloudav.caseExchange.caseInbox.normalizationCtrl', function ($provide) {
                $provide.value('$state', {
                    transitionTo: function (url) {
                    },
                    go: function (url) {
                    },
                    current: {
                        params: {}
                    }
                });

                $provide.value('$stateParams', {
                    id: function () {
                    }
                });

                $provide.value('$modal', {
                    open: function () {
                    }
                });

                $provide.value('NormalizationService', {
                    getSelectedCase: function () {
                        return selectedCasePatient;
                    },
                    getPatient: function () {
                        return fakePatientResolved("value");
                    },
                    getSelectedCaseStudies: function () {
                        return selectedStudyList;
                    },
                    getSelectedDicomDevices: function () {
                        return pacsDevices;
                    },
                    normalizeSave: function () {
                        return fakePatientResolved("value");
                    }
                });

                $provide.value('PacsSearchService', {
                    pacsSearch: function () {
                        return fakePatientResolved("value");
                    }
                });

                $provide.value('dateFormatFilter', dateFormatFilter);

                $provide.factory('configurationService', ['$q', function ($q) {
                    return {
                        getProperty: function () {
                            return $q.when({});
                        }
                    }
                }]);

            })
        });

        // Initialize the scope and controller variables
        beforeEach(inject(function ($rootScope, $controller, $state, $filter, NormalizationService, $modal, CaseExchangeMocks) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            controller = $controller;
            filter = $filter;
            modal = $modal;

            pacsDevices = CaseExchangeMocks.getSelectedDevice();
            selectedCasePatient = CaseExchangeMocks.getPatient();
            patientCompareList = CaseExchangeMocks.getPatients();
            selectedStudyList = CaseExchangeMocks.getSelectedStudyList();


            // Initialize the controller before each specs
            controller('NormalizationCtrl', {
                $scope: scope
            });

            state = $state;

            scope.alertTypes = {
                success: 'success',
                error: 'error'
            };

            // Mocking the method from parent controller as we don't have inheritance in place in unit testing.
            scope.showAlertMessage = function () {
            };
            normalizationService = NormalizationService;
        }));

        it('should have a controller', function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it('should go back to inbox page', function () {
            var stateSpy = sinon.spy(state, "transitionTo");
            scope.backToDownloadPage();
            assert(stateSpy.calledWith('caseexchange.caseinbox.downloadToPremise'));
        });

        it('should select compare patient on click and show compare button', function () {
            scope.patientCompareList = patientCompareList;
            scope.selectPatientForCompare(selectedCasePatient);
            expect(scope.showNomlizCmpreBtn).to.be.true;
        });

        it('it should decrement pagination count by 1', function () {
            scope.paginationCount = 2;
            scope.selectedStudyList = selectedStudyList;
            scope.normalizeStudyList = selectedStudyList;
            scope.getPreviousStudy();
            expect(scope.paginationCount).to.equal(1);
        });

        it('it should increment pagination count by 1', function () {
            scope.paginationCount = 1;
            scope.selectedStudyList = selectedStudyList;
            scope.normalizeStudyList = selectedStudyList;
            scope.getNextStudy();
            expect(scope.paginationCount).to.equal(2);
        });

        it('it go back to selection screen on click of back to selection link', function () {
            scope.backToSelection();
            expect(scope.enableNormalizationForm).to.be.false;
        });

        it('it go back to case summary page on click of cancel normalization flow', function () {
            scope.selectedCaseStudies = selectedStudyList;
            scope.pacsDevices = [{"aeTitle": "AE_EDGEARCHIVE"}];
            var stateSpy = sinon.spy(state, "go");
            scope.cancelNormalizationFlow();
            expect(scope.$parent.downloading).to.be.false;
            assert(stateSpy.calledWith('caseexchange.caseinbox'));
        });

        it('it should add new attributes to normalizePatient object on call of continueNormalizationForm()', function () {
            scope.selectedPatient = {};
            scope.selectedPatient.dob = "20061219";
            scope.selectedPatient.id = "1234";
            scope.selectedPatient.sex = "M";
            scope.continueNormalizationForm();
            expect(scope.normalizePatient.patientId).to.equal("1234");
            expect(scope.normalizePatient.gender).to.equal("M");
        });

        it('it should incremenet editedStudyCount by' +
            ' 1 on call of checkForUpdatedStudy()', function () {
            var selectedStudy = {}, normalizeStudy = {};
            scope.patientData = {'age': '', 'name': {'given': {}}};
            scope.normalizePatient = {'age': '', 'name': {'lastName': {}}};
            scope.patientData.age = '';
            scope.normalizePatient.age = '';
            selectedStudy.accession = "122";
            normalizeStudy.accession = "123";
            scope.editedStudyCount = 0;
            scope.selectedStudyList = [];
            scope.normalizeStudyList = [];
            scope.selectedStudyList.push(selectedStudy);
            scope.normalizeStudyList.push(normalizeStudy);
            scope.checkForUpdatedStudy();
            expect(scope.editedStudyCount).to.equal(1);
        });

        it('it should not incremenet editedStudyCount by 1 on call of checkForUpdatedStudy()', function () {
            var selectedStudy = {}, normalizeStudy = {};
            scope.patientData = {'gender': null}, scope.normalizePatient = {'gender': ''};
            scope.patientData.name = {'family': {}, 'given': {}};
            scope.normalizePatient.name = {'firstName': '', 'lastName': '', 'middleName': ''};
            selectedStudy.accession = null;
            normalizeStudy.accession = "";
            scope.patientData.identifier = null;
            scope.normalizePatient.patientId = "";
            scope.patientData.gender = null;
            scope.normalizePatient.gender = "";
            scope.patientData.age = "";
            scope.normalizePatient.age = "";
            scope.patientData.name.family[0] = "";
            scope.patientData.name.given[0] = "";
            scope.patientData.name.given[1] = "";
            scope.normalizePatient.name.firstName = "";
            scope.normalizePatient.name.lastName = "";
            scope.normalizePatient.name.middleName = "";
            scope.editedStudyCount = 0;
            scope.selectedStudyList = [];
            scope.normalizeStudyList = [];
            scope.selectedStudyList.push(selectedStudy);
            scope.normalizeStudyList.push(normalizeStudy);
            scope.checkForUpdatedStudy();
            expect(scope.editedStudyCount).to.equal(0);
        });

        it('it should submit normalization json to microservice and go back to case inbox screen', function () {
            scope.selectedCaseStudies = selectedStudyList;
            scope.pacsDevices = [{"aeTitle": "AE_EDGEARCHIVE"}];
            var stateSpy = sinon.spy(state, "go");
            scope.normalizePatient.name = {};
            scope.selectedCase = {};
            scope.selectedCase.id = "1123";
            scope.modalInstance = {
                dismiss: function () {
                }
            }
            scope.saveNormalization();
            assert(stateSpy.calledWith('caseexchange.caseinbox'));
        });

        it('it should return blank age', function () {
            scope.calculatePatientAge();
            expect(scope.normalizePatient.age).to.equal("");
        });

        it('it should assign null to comparePatient if no patient is selected', function () {
            var comparePatient = selectedCasePatient;
            comparePatient.isSelected = true;
            scope.selectPatientForCompare(comparePatient);
            expect(scope.comparePatient).to.equal(null);
        });

        it('it should submit null normalization json and go back to case inbox screen', function () {
            scope.selectedCaseStudies = selectedStudyList;
            var stateSpy = sinon.spy(state, "go");
            scope.pacsDevices = [{"aeTitle": "AE_EDGEARCHIVE"}];
            scope.normalizePatient = undefined;
            scope.normalizeStudyList = undefined;
            scope.selectedCase = {"id": "1123"};
            scope.modalInstance = {
                dismiss: function () {
                }
            }
            sinon.stub(normalizationService, 'getSelectedDicomDevices', function () {
                return undefined;
            });
            scope.saveNormalization();
            assert(stateSpy.calledWith('caseexchange.caseinbox'));
        });

    });
});