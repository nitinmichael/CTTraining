/*  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jignesh Parekh<jignesh.parekh@ge.com>
 */

/**
 * Spec file for Case Exchange > Create case controller module
 */

define(['angular',
    'angular-mocks',
    'create-case/module',
    'create-case/controllers/create-case-controller',
    'mocks/case-exchange-mock-service',
    'mocks/fake-server'], function () {

    'use strict';
    var scope, controller, rootScope, CaseDataService, CreateCaseDataService, CreateCaseService, $q, caseExchangeDataService, filter,
        selectedStudyListService, createCaseMarshallerService, pacsSearchService, mockServer, $mockServerLoader, billingOrganizationList,
        MODES = {
            create: 'CREATE',
            update: 'UPDATE'
        };

    describe('Create Case Controller Test Suite::', function () {
        var createCaseStub, caseData, patientData, studyList, clinicalReasons, studyTransactionList, meServiceResponse, recipients;

        beforeEach(function () {
            // Load the module for the mock data first
            module('cloudav.caseExchange.mocks');
            // Load the Sinon fake server.
            module('cloudav.caseExchange.fakeServer');

            module('cloudav.caseExchange.createCaseCtrl', function ($provide) {
                $provide.value('$state', {
                    transitionTo: function (url) {
                    },
                    current: {
                        params: {
                            mode: MODES.create
                        }
                    }
                });

                $provide.value('$stateParams', {
                    id: function () {
                    },
                    billingOrganizationList:[{
                        "reference": "organization/3f3ac310-d2f0-4570-8bb1-5174d99622cf",
                        "display": "qwqww"
                      }]
                });

                $provide.value('PacsSearchService', {
                    getPacsSearchParams: function () {return ""},
                    clearPacsSearchParams: function () {
                        return '';
                    }
                });

                $provide.factory('configurationService', ['$q', function ($q) {
                    return {
                        getProperty: function () {
                            return $q.when({});
                        }
                    }
                }]);
            });
        });

        var FileUploadService;

        angular.module('mock.FileUploadService', []).factory('FileUploadService', function () {
            FileUploadService = {
                doUploadFiles: function (caseId, files, fileUploadSuccessCallback, fileUploadErrorCallback) {
                },
                generateGuid: function () {
                },
                isFileListSizeUnderLimit: function (alreadySelectedFileList, fileArray, sumSizeLimit) {

                },
                isFileSizeUnderLimit: function (file, sizeLimit) {

                },
                isFileExtensionValid: function (file, allowedExtensions) {

                },
                isFileNameAlreadyExistInList: function (file, fileList) {

                },
                convertFileValidationErrorsToErrorMessages: function (errors, sumSizeLimitReached, sizeLimit, sumSizeLimit) {

                }

            };
            return FileUploadService;
        });

        beforeEach(module('mock.FileUploadService'));

        // Initialize the scope and controller variables
        beforeEach(inject(function ($rootScope, $controller, FileUploadService, _CaseDataService_, _CreateCaseDataService_, _CreateCaseService_, _$q_, _CaseExchangeDataService_,
                                    _SelectedStudyListService_, _CreateCaseMarshallerService_, CaseExchangeMocks, $MockServerLoader, $filter, _PacsSearchService_) {

            rootScope = $rootScope;
            scope = $rootScope.$new();
            controller = $controller;
            CaseDataService = _CaseDataService_;
            CreateCaseDataService = _CreateCaseDataService_;
            CreateCaseService = _CreateCaseService_;
            $q = _$q_;
            caseExchangeDataService = _CaseExchangeDataService_;
            selectedStudyListService = _SelectedStudyListService_;
            pacsSearchService = _PacsSearchService_;
            createCaseMarshallerService = _CreateCaseMarshallerService_;
            createCaseStub = sinon.spy(CreateCaseService, 'createCase');

            // Initialize the controller before each specs
            controller('CreateCaseCtrl', {$scope: scope});
            filter = $filter;

            // Mocking the variable from parent controller as we don't have inheritance in place in unit testing.
            scope.alertTypes = {
                success: 'success',
                error: 'error'
            };

            // Mocking the method from parent controller as we don't have inheritance in place in unit testing.
            scope.showAlertMessage = function () {
            };

            caseData = CaseExchangeMocks.getCaseDetails();
            patientData = CaseExchangeMocks.getPatient();
            studyList = CaseExchangeMocks.getStudyList();
            clinicalReasons = CaseExchangeMocks.getClinicalReasons();
            studyTransactionList = CaseExchangeMocks.getTransactionStudyList();
            meServiceResponse = CaseExchangeMocks.getMeServiceResponse();
            recipients = CaseExchangeMocks.getToUser().entry;
            $mockServerLoader = $MockServerLoader;
            // Call the init to initialize the Sinon Mock Data Server.
            mockServer = $mockServerLoader.init();
        }));

        describe('Create Case without attachment::', function () {

            it('should have a controller', function () {
                assert.isDefined(controller, 'Controller is not defined');
            });

            it('should query current user info on controller initialization (if it\'s not available) and check patient persona', function(){
                $mockServerLoader.fakeMeServiceCall(200, meServiceResponse);
                // Creating a spy for setCurrentUser function
                var setCurrentUserSpy = sinon.spy(caseExchangeDataService, 'setCurrentUser');

                // Initialize the controller before each specs
                controller('CreateCaseCtrl', {$scope: scope});

                mockServer.respond();
                rootScope.$apply();

                // Assert if setCurrentUser method is called once
                expect(setCurrentUserSpy.calledOnce).to.be.true;
                expect(scope.isCurrentUserPatient).to.be.true;

                var isPatientLogin = scope.isCurrentUserPatient;
                setCurrentUserSpy.reset();

                // Initialize the controller again to check if it tries to query the current user info again
                controller('CreateCaseCtrl', {$scope: scope});

                // Assert if setCurrentUser method is not called this time
                expect(setCurrentUserSpy.calledOnce).to.be.false;
                expect(scope.isCurrentUserPatient).to.equal(isPatientLogin);
            });

            it('should have formData object', function () {
                assert.isDefined(scope.formData, 'Controller scope doesn\'t have "formData" object defined');
            });

            it('should have addedRecipients array object', function () {
                assert.isDefined(scope.addedRecipients, 'Controller scope doesn\'t have "addedRecipients" array object defined');
            });

            it('should have noRecipientsAdded boolean object', function () {
                assert.isDefined(scope.noRecipientsAdded, 'Controller scope doesn\'t have "noRecipientsAdded" boolean object defined');
            });

            it('should have noMessageAdded boolean object', function () {
                assert.isDefined(scope.noMessageAdded, 'Controller scope doesn\'t have "noMessageAdded" boolean object defined');
            });

            it('should have a "cancelCreateCase" function', function () {
                assert.isDefined(scope.cancelCreateCase, 'Controller scope doesn\'t have "cancelCreateCase" function defined');
            });

            it('should have a "submitCase" function', function () {
                assert.isDefined(scope.submitCase, 'Controller scope doesn\'t have "submitCase" function defined');
            });

            it('should have a "clinicalReasons" array object', function () {
                assert.isDefined(scope.clinicalReasons, 'Controller scope doesn\'t have "clinicalReasons" array object defined');
            });

            it('should have createCaseForm object', function () {
                scope.createCaseForm = {
                    $valid: false
                };
                assert.isDefined(scope.createCaseForm, 'Controller scope doesn\'t have "createCaseForm" object defined');
            });

            it('should highlight message field if empty while creating a case', function () {
                scope.createCaseForm = {
                    $valid: false
                };
                scope.submitCase(MODES.create);
                expect(scope.noMessageAdded).to.not.equal(false);
            });

            it('should highlight to field if no recipients selected while creating a case', function () {
                scope.createCaseForm = {
                    $valid: false
                };

                scope.submitCase(MODES.create);

                expect(scope.noRecipientsAdded).to.not.equal(false);
            });

            it('should have atlease 1 recipient added', function () {
                expect(scope.addedRecipients).to.have.length.below(1);

                scope.addedRecipients.push(recipients);

                expect(scope.addedRecipients).to.have.length.above(0);
            });

            it('should call marshaller and create case service while creating a case', function (done) {
                scope.createCaseForm = {
                    $valid: true
                };

                var study=studyTransactionList;

                scope.formData = {
                    subjectInput: 'Subject::: Test',
                    caseMessage: 'Message::: Test',
                    clinicalReason: clinicalReasons[0],
                    priority: {value : 'NORMAL'},
                    selectedBillingOrganization: scope.billingOrganizationList[0]
                };
                scope.patientData = patientData;
                scope.selectedListItems = studyList;

                scope.addedRecipients.push(recipients);

                /**
                 * This will fake the create case POST submit call.
                 * It will only configure the sever with service URL.
                 * Passing 200 status will force the server to return success
                 * Passing caseData will make the server to return the same back in success resolve.
                 */
                $mockServerLoader.fakeCreateCaseCall(200, caseData);
                sinon.stub(selectedStudyListService, "getList", function () { return study; });
                scope.submitCase(MODES.create);

                /**
                 * This will force the server to return the response.
                 * Based on the passed response status, it will return 200-Success OR 500-Failure
                 */
                mockServer.respond();

                rootScope.$apply();

                expect(createCaseStub.calledOnce).to.be.true;
                done();
            });

            it('should show error message in case of error on submit', function () {
                scope.createCaseForm = {
                    $valid: true
                };

                scope.formData = {
                    subjectInput: 'Subject::: Test',
                    caseMessage: 'Message::: Test',
                    clinicalReason: clinicalReasons[3],
                    priority: {value : 'NORMAL'},
                    selectedBillingOrganization: scope.billingOrganizationList[0]
                };
                scope.patientData = patientData;
                scope.selectedListItems = studyList;

                scope.addedRecipients.push(recipients);

                // Creating a spy for alert message function
                var showAlertMessageSpy = sinon.spy(scope, 'showAlertMessage');

                /**
                 * This will fake the create case POST submit call.
                 * It will only configure the sever with service URL.
                 * Passing 500 status will force the server to return error
                 * Passing caseData will make the server to return the same back in success resolve.
                 */
                $mockServerLoader.fakeCreateCaseCall(500, caseData);

                scope.submitCase(MODES.create);

                mockServer.respond();

                rootScope.$apply();

                // Assert if error message is showed up.
                assert(showAlertMessageSpy.calledWith('common.genericError', scope.alertTypes.error), 'Error message didn\'t showed up on failure.');
            });
        });

        describe('Create Case with non-DICOM attachment Test Suite::', function () {
            var ajaxStub;

            it('should have an empty fileList defined', function () {
                assert.isDefined(scope.fileList, 'Controller scope doesn\'t have "fileList" defined');
                expect(scope.fileList).to.have.length(0);
            });

            beforeEach(function () {
                ajaxStub = sinon.stub($, 'ajax');
                ajaxStub.yieldsTo('success', {});
                ajaxStub.onFirstCall().yieldsTo('success',
                    {
                        id: 13,
                        transactions: [{
                            attachments: [{
                                type: "DocumentReference",
                                name: "alma.txt",
                                description: 'alma.txt',
                                identifier: 42
                            }]
                        }]
                    });
            });

            afterEach(function () {
                $.ajax.restore();
            });

            it('should call lobstore service to upload attachments', function () {

                var fileUploadStub = sinon.stub(FileUploadService, 'doUploadFiles');
                fileUploadStub.callsArgWith(2, {
                    storedObjectList: [{}],
                    failedObjectList: []
                });

                scope.createCaseForm = {
                    $valid: true
                };

                scope.formData = {
                    subjectInput: 'Subject::: Test',
                    caseMessage: 'Message::: Test',
                    clinicalReason: clinicalReasons[7],
                    priority: {value : 'NORMAL'},
                    selectedBillingOrganization: scope.billingOrganizationList[0]
                };
                scope.patientData = patientData;

                scope.addedRecipients.push(recipients);

                scope.fileList = [{size: 4, name: "alma.txt", value: "alma", uuid: 42, type: 'txt'}];

                $mockServerLoader.fakeCreateCaseCall(200, caseData);

                scope.submitCase(MODES.create);

                mockServer.respond();

                rootScope.$apply();

                sinon.assert.callOrder(createCaseStub, fileUploadStub);
                expect(fileUploadStub.calledOnce).to.be.true;
            });

            it('should add files to fileList', function () {
                sinon.stub(FileUploadService, 'isFileListSizeUnderLimit').returns(true);
                sinon.stub(FileUploadService, 'isFileSizeUnderLimit').returns(true);
                sinon.stub(FileUploadService, 'isFileExtensionValid').returns(true);
                sinon.stub(FileUploadService, 'isFileNameAlreadyExistInList').returns(false);

                var fileInput = {value: 'Test'};
                sinon.stub(document, 'querySelector').returns([fileInput]);

                scope.fileList = [];
                var newFileList = [{size: 4, name: "alma.txt", value: "alma", uuid: 42, type: 'txt'}];

                scope.addFiles(newFileList);
                expect(scope.fileList.length).to.equal(1);
                expect(fileInput.value).to.equal(null);
            });

            it('should populate Clinical Reasons dropdown by making an API call', function () {
                beforeEach(function(){
                    $mockServerLoader.fakeClinicalReasonsCall(200, clinicalReasons);

                    mockServer.respond();
                    rootScope.$apply();
                });

                scope.clinicalReasons = clinicalReasons;

                expect(scope.clinicalReasons.length).to.equal(9);
            });

            it('should call "updateUploadStatus" for each attachment on file upload failure', function(){
                FileUploadService.doUploadFiles = function(caseId, filesToUpload, successCallbackFn, errorCallbackFn, token){ errorCallbackFn(); };
                var updateUploadStatusStub = sinon.stub(CreateCaseService, 'updateUploadStatus');
                scope.createCaseForm = {
                    $valid: true
                };

                scope.formData = {
                    subjectInput: 'Subject::: Test',
                    caseMessage: 'Message::: Test',
                    clinicalReason: clinicalReasons[7],
                    priority: {value : 'NORMAL'},
                    selectedBillingOrganization: scope.billingOrganizationList[0]
                };
                scope.patientData = patientData;

                scope.addedRecipients.push(recipients);
                scope.fileList = [{size: 4, name: "alma.txt", value: "alma", uuid: 42, type: 'txt'}];

                $mockServerLoader.fakeCreateCaseCall(200, caseData);

                scope.submitCase(MODES.create);

                mockServer.respond();

                rootScope.$apply();

                expect(updateUploadStatusStub.calledOnce).to.be.true;
            });

        });

        describe('Create case with DICOM Studies::', function () {
            it('should call the create case data service "setCreateCaseData" method before navigating', function () {
                var setCreateCaseDataSpy = sinon.spy(CreateCaseDataService, "setCreateCaseData");
                scope.navigateToPacsQuery({
                    preventDefault: function () {
                    }
                });
                expect(setCreateCaseDataSpy.calledOnce).to.be.true;
            });

            it('should assign the data back to formdata on controller reload', function () {
                scope.formData = {
                    subjectInput: 'Subject::: Test',
                    caseMessage: 'Message::: Test'
                };
                scope.navigateToPacsQuery({
                    preventDefault: function () {
                    }
                });
                controller('CreateCaseCtrl', {$scope: scope});
                expect(scope.formData).to.equal(CreateCaseDataService.getCreateCaseData());
            });

            it('should clear the saved data on click of "Cancel" button', function () {
                var clearCreateCaseDataSpy = sinon.spy(CreateCaseDataService, "clearCreateCaseData");
                scope.cancelCreateCase();
                expect(clearCreateCaseDataSpy.calledOnce).to.be.true;
            });

            it('should reset the selected case data on click of "Cancel" button', function () {
                var resetSelectedCaseDataSpy = sinon.spy(caseExchangeDataService, "resetSelectedCaseData");
                scope.cancelCreateCase();
                assert(resetSelectedCaseDataSpy.calledOnce);
            });

            it('should reset the caseUpdateType on click of "Cancel" button', function () {
                var resetCaseUpdateTypeSpy = sinon.spy(caseExchangeDataService, "resetCaseUpdateType");
                scope.cancelCreateCase();
                assert(resetCaseUpdateTypeSpy.calledOnce);
            });

            it('should remove patent banner if all attached studies are removed', function () {
                scope.patientData = patientData;
                scope.selectedListItems = studyList;
                scope.checkStudyLength();
                expect(scope.patientData).to.not.equal(null);
                scope.selectedListItems = [];
                scope.existingListItems = [];
                scope.checkStudyLength();
                expect(scope.patientData).to.equal(null);
            });
        });

        describe('Test suite for Add to case scenario', function () {
            beforeEach(function () {
                // Marking the case with ID=1 as selected
                caseExchangeDataService.setSelectedCaseData(caseData);
                caseExchangeDataService.setCaseUpdateType('ADDCASE');

                $mockServerLoader.fakeCaseDetailsCall(200, caseData);

                // Initialize the controller using mode as "UPDATE"
                controller('CreateCaseCtrl', {
                    $scope: scope,
                    $state: {
                        current: {
                            params: {mode: MODES.update}
                        }
                    }
                });

                scope.caseUpdateType = caseExchangeDataService.getCaseUpdateType();
                mockServer.respond();
                rootScope.$apply();
            });

            it('should set selected patient in scope if patient context is available', function () {
                /**
                 *  Assert if same patient has been selected
                 *  Since, scope.patientData object might have some additional scope properties, matching with Patient ID makes more sense.
                 */

                scope.patientData = patientData;
                expect(scope.patientData.identifier).to.equal(caseData.patient.identifier);
            });

            it('should set the patient in the service "SelectedStudyListService" if patient context is available', function () {
                scope.patientData = patientData;
                selectedStudyListService.setSelectedPatient(caseData.patient);

                var selectedPatient = selectedStudyListService.getSelectedPatient();
                expect(scope.patientData.identifier).to.equal(selectedPatient.identifier);
            });

            it('should set the DICOM attachments to the scope array if present', function () {
                scope.selectedListItems = studyList;
                var DICOMAttachmentCount = _.filter(caseData.transactions[0].attachments, {type: 'ImagingStudy'}).length;
                expect(scope.selectedListItems.length-1).to.equal(DICOMAttachmentCount);
            });

            it('should not attach duplicate DICOM attachment if it\'s already present', function () {
                var totalDICOMStudies = scope.selectedListItems.length;
                // Initializing the controller again will mock the reloading of the controller.
                controller('CreateCaseCtrl', {
                    $scope: scope,
                    $state: {
                        current: {
                            params: {mode: MODES.update}
                        }
                    }
                });
                mockServer.respond();
                rootScope.$apply();
                expect(scope.selectedListItems.length).to.equal(totalDICOMStudies);
            });

            it('should redirect to defined state after successfully finished', function(){
                $mockServerLoader.fakeCaseDetailsCall(200, caseData);
                var deferred = $q.defer();
                var mockCreateCaseService = {
                    createTransaction: function(){
                        return deferred.promise;
                    }
                };

                var state = {
                    current: {
                        params: {
                            mode: MODES.update,
                            redirectTo: 'test.state'
                        }
                    },
                    transitionTo: sinon.spy()
                };

                controller('CreateCaseCtrl', {
                    $scope: scope,
                    $state: state,
                    $stateParams: {
                        id: '123',
                        redirectTo: 'test.case'
                    },
                    CreateCaseService: mockCreateCaseService
                });
                scope.caseUpdateType = caseExchangeDataService.getCaseUpdateType();
                mockServer.respond();
                rootScope.$apply();
                scope.formData.caseMessage = 'Lipsum';
                scope.createCaseForm = {
                    $valid: true
                };

                scope.submitCase(MODES.update);

                deferred.resolve();
                rootScope.$apply();
                expect(state.transitionTo.calledOnce).to.be.true;
                expect(state.transitionTo.calledWith('test.case', {id: '123'})).to.be.true;

            });

        });

        describe('Test suite for controller functions', function () {
            it('should capitalize input', function () {
                expect(filter('capitalize')("test")).to.equal("Test");
            });

            it('should convert bytes to MB', function () {
                expect(filter('byteToMB')(1048576)).to.equal('1.00 MB');
            });

            it('should update patient name', function () {
                var patient = {
                    name: {}
                }

                //'Sample Name' is set in the typeahead directive test file
                expect(scope.updatedPatientName(patient)).to.equal('Sample Name');
            });

        });

        describe('Test suite for Add Users', function () {
            beforeEach(function () {
                // Marking the case with ID=1 as selected
                caseExchangeDataService.setSelectedCaseData({id: 1});
                caseExchangeDataService.setCaseUpdateType('ADDUSERS');
                // Initialize the controller using mode as "UPDATE"
                controller('CreateCaseCtrl', {
                    $scope: scope
                });
                rootScope.$apply();
            });

            it('should validate the "To" field if left empty on submit', function () {
                // Set the empty recipients list to check validation works
                scope.addedRecipients = [];
                scope.submitCase(MODES.update);
                assert.isTrue(scope.noRecipientsAdded);
            });

            it('should validate the "Message" field if left empty on submit', function () {
                scope.addedRecipients.push(recipients);
                // Set the message field empty
                scope.formData.caseMessage = '';
                scope.submitCase(MODES.update);
                assert.isTrue(scope.noMessageAdded);
            });

            describe('Submit scenarios', function () {

                beforeEach(function () {
                    scope.addedRecipients.push(recipients);
                    scope.formData.caseMessage = 'This is a dummay data';
                });

                it('should NOT make an API call if form is NOT valid', function () {
                    // Set the form to Invalid state
                    scope.createCaseForm = {
                        $valid: false
                    };

                    var createTransactionSpy = sinon.spy(CreateCaseService, 'createTransaction');
                    scope.submitCase(MODES.update);

                    // Assert if Create case service method "createTransaction" is NOT called
                    expect(createTransactionSpy.callCount).to.equal(0);
                });

                it('should call to marshaller service on submit', function () {
                    // Set the form to valid state
                    scope.createCaseForm = {
                        $valid: true
                    };
                    var marshalParticipantsSpy = sinon.spy(createCaseMarshallerService, 'marshalParticipants');
                    scope.submitCase(MODES.update);

                    // Assert if Create case service method "createTransaction" is called or not.
                    assert(marshalParticipantsSpy.calledOnce);
                });

                it('should make a call to "createTransaction" once if form is valid', function () {
                    // Set the form to valid state
                    scope.createCaseForm = {
                        $valid: true
                    };

                    var createTransactionSpy = sinon.spy(CreateCaseService, 'createTransaction');
                    scope.submitCase(MODES.update);

                    // Assert if Create case service method "createTransaction" is called or not.
                    assert(createTransactionSpy.calledOnce);
                });

                it('should display the success message on form submit', function () {
                    // Set the form to valid state
                    scope.createCaseForm = {
                        $valid: true
                    };

                    // Creating a spy for alert message function
                    var showAlertMessageSpy = sinon.spy(scope, 'showAlertMessage');

                    $mockServerLoader.fakeCreateTransactionCall(caseExchangeDataService.getSelectedCaseData().id, 200, {id: 1});

                    // Calling submit case will trigger the addition of recipients scenario
                    scope.submitCase(MODES.update);

                    mockServer.respond();

                    // Apply the root scope again to resolve the promise.
                    rootScope.$apply();

                    // Assert if success message is showed up.
                    assert(showAlertMessageSpy.calledWith('addUsers.caseShareSuccessMsg', scope.alertTypes.success), 'Success message didn\'t showed up after recipients added successfully.');
                });

                it('should display the error message in case of error on submit', function () {
                    // Set the form to valid state
                    scope.createCaseForm = {
                        $valid: true
                    };

                    // Creating a spy for alert message function
                    var showAlertMessageSpy = sinon.spy(scope, 'showAlertMessage');

                    // Passing the status as 500 will force the server to respond with error
                    $mockServerLoader.fakeCreateTransactionCall(caseExchangeDataService.getSelectedCaseData().id, 500);

                    // Calling submit case after ajax is setup to throw error will force the execution of failure scenario
                    scope.submitCase(MODES.update);

                    mockServer.respond();

                    // Apply the root scope again to resolve the promise.
                    rootScope.$apply();

                    // Assert if error message is showed up.
                    assert(showAlertMessageSpy.calledWith('common.genericError', scope.alertTypes.error), 'Error message didn\'t showed up on failure.');
                });
            });
        });

        describe('Test suite for Add To Case', function () {
            beforeEach(function () {
                // Marking the case with ID=1 as selected
                caseExchangeDataService.setSelectedCaseData({id: 1});
                caseExchangeDataService.setCaseUpdateType('ADDCASE');
                // Initialize the controller using mode as "UPDATE"
                controller('CreateCaseCtrl', {
                    $scope: scope
                });
                rootScope.$apply();
            });

            it('should validate the "Message" field if left empty on submit', function () {
                scope.addedRecipients = [];
                // Set the message field empty
                scope.formData.caseMessage = '';
                scope.submitCase(MODES.update);
                assert.isTrue(scope.noMessageAdded);
            });

            describe('Submit scenarios', function () {

                beforeEach(function () {
                    scope.addedRecipients.push(recipients);
                    scope.formData.caseMessage = 'This is a test scenario for add to case.';
                });

                it('should NOT make an API call if form is NOT valid', function () {
                    // Set the form to Invalid state
                    scope.createCaseForm = {
                        $valid: false
                    };

                    var createTransactionSpy = sinon.spy(CreateCaseService, 'createTransaction');
                    scope.submitCase(MODES.update);

                    // Assert if Create case service method "createTransaction" is NOT called
                    expect(createTransactionSpy.callCount).to.equal(0);
                });

                it('should call to marshaller service on submit', function () {
                    // Set the form to valid state
                    scope.createCaseForm = {
                        $valid: true
                    };
                    var marshalCaseTransactionSpy = sinon.spy(createCaseMarshallerService, 'marshalCaseTransaction');
                    scope.submitCase(MODES.update);

                    // Assert if Create case service method "createTransaction" is called or not.
                    assert(marshalCaseTransactionSpy.calledOnce);
                });

                it('should make a call to "createTransaction" once if form is valid', function () {
                    // Set the form to valid state
                    scope.createCaseForm = {
                        $valid: true
                    };

                    var createTransactionSpy = sinon.spy(CreateCaseService, 'createTransaction');
                    scope.submitCase(MODES.update);

                    // Assert if Create case service method "createTransaction" is called or not.
                    assert(createTransactionSpy.calledOnce);
                });

                it('should display the success message on form submit', function () {
                    // Set the form to valid state
                    scope.createCaseForm = {
                        $valid: true
                    };

                    // Creating a spy for alert message function
                    var showAlertMessageSpy = sinon.spy(scope, 'showAlertMessage');

                    $mockServerLoader.fakeCreateTransactionCall(caseExchangeDataService.getSelectedCaseData().id, 200, {id: 1});

                    // Calling submit case will trigger the addition of recipients scenario
                    scope.submitCase(MODES.update);

                    mockServer.respond();

                    // Apply the root scope again to resolve the promise.
                    rootScope.$apply();

                    // Assert if success message is showed up.
                    assert(showAlertMessageSpy.calledWith('addToCase.successMessage', scope.alertTypes.success), 'Success message didn\'t showed up after updating the case successfully.');
                });

                it('should display the error message in case of error on submit', function () {
                    // Set the form to valid state
                    scope.createCaseForm = {
                        $valid: true
                    };

                    // Creating a spy for alert message function
                    var showAlertMessageSpy = sinon.spy(scope, 'showAlertMessage');

                    // Passing the status as 500 will force the server to respond with error
                    $mockServerLoader.fakeCreateTransactionCall(caseExchangeDataService.getSelectedCaseData().id, 500);

                    // Calling submit case after ajax is setup to throw error will force the execution of failure scenario
                    scope.submitCase(MODES.update);

                    mockServer.respond();

                    // Apply the root scope again to resolve the promise.
                    rootScope.$apply();

                    // Assert if error message is showed up.
                    assert(showAlertMessageSpy.calledWith('common.genericError', scope.alertTypes.error), 'Error message didn\'t showed up on failure.');
                });
            });

            it('should not attach duplicate DICOM attachment if it\'s already present', function () {
				var billingOrganizationList = [{
                            "reference": "organization/3f3ac310-d2f0-4570-8bb1-5174d99622cf",
                            "display": "qwqww"
                          },{
                            "reference": "organization/3f3ac310-d2f0-4570-8bb1-5174d99622cf",
                            "display": "qwqww"
                          }];
                controller('CreateCaseCtrl', {
                    $scope: scope,
                    $stateParams: {
                        billingOrganizationList: billingOrganizationList
                    }
                });
                mockServer.respond();
                rootScope.$apply();
                expect(scope.billingOrganizationList.length).to.equal(billingOrganizationList.length);
            });
        });
    });
});
