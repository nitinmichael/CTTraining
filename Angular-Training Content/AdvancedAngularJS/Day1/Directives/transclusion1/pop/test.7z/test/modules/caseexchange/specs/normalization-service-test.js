/*
 *  download-case-service-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 * >
 */

/**
 * Spec file for Normalization Service module
 */

define(['angular','angular-mocks', 'modules/caseexchange/modules/case-inbox/services/normalization-service', 'modules/caseexchange/services/case-exchange-data-service', 'mocks/fake-server' ], function (ng) {
    'use strict';

    var NormalizationService, $mockServerLoader, q, httpBackend, defer, rootScope, stub, mockServer, sampleResponse;
    describe('Test Normalization Service', function () {

        beforeEach(function() {
            // Load the Sinon fake server.
            module('cloudav.caseExchange.fakeServer');

            module('Services.normalizationService', function($provide){
                $provide.factory('configurationService', ['$q', function($q){
                    return {
                        getProperty: function(){
                            return $q.when({});
                        }
                    }
                }]);
            });

            inject(function ($rootScope, _$q_, $MockServerLoader, $httpBackend, _NormalizationService_){
                NormalizationService = _NormalizationService_;
                $mockServerLoader = $MockServerLoader;
                httpBackend = $httpBackend;
                rootScope = $rootScope;
                sampleResponse = {id: 0};
                mockServer = $mockServerLoader.init();
            });
        });

        it('should define a service', function () {
            assert.isDefined(NormalizationService, 'NormalizationService is defined');
        });

        describe('Normalization Service', function() {

            it('should reject promise on invalid input', function(){
                NormalizationService.normalizeSave(0, "").then(function(){
                    assert(false, "Error should have been thrown");
                }, function(){
                });
            });

            it('should reject promise on http error', function(){
                $mockServerLoader.fakeNormalizeSaveCall(500, null);
                NormalizationService.normalizeSave(0, {}).promise.then(function(){
                    assert(false, "Error should have been thrown");
                }, function(error){
                    expect(error.status).to.equal(500);
                });
                mockServer.respond();
                rootScope.$apply();
            });

            it('should return response on valid input', function(){
                var studies = [{selectedForDownload:false},{selectedForDownload:true}];
                var devices = [{selectedForDownload:false},{selectedForDownload:true}];
                NormalizationService.setSelectedCaseStudies(studies);
                NormalizationService.getSelectedCaseStudies();
                NormalizationService.setSelectedDicomDevices(devices);
                NormalizationService.getSelectedDicomDevices();
                $mockServerLoader.fakeNormalizeSaveCall(200, sampleResponse);
                NormalizationService.normalizeSave(0, {}).promise.then(function(data){
                    expect(data.id).to.equal(sampleResponse.id);
                }, function(){
                    assert(false, "Error should not have been thrown");
                });
                mockServer.respond();
                rootScope.$apply();
            });

        });

    });
});  