/***************************************************************************************************
 * Copyright (c) 2015 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * Test suite for Directive.geProgressBar directive
 *
 ***************************************************************************************************/
 define(['angular', 'angular-mocks', 'widgets/ge-progress-bar/ge-progress-bar-directive'], function() {
    var expect = chai.expect;

    beforeEach(module('Directive.geProgressBar'));

    describe('Progress Bar Directive :', function() {
      var isolateScope, scope, element = angular.element('<ge-progress-bar percentage="progressPercentage"></ge-progress-bar>');

      describe('GE progress bar', function() {

      beforeEach(function() {
          module('Directive.geProgressBar');
      });

      beforeEach(inject(function($rootScope, $compile) {
        // set up the scope to use with the directive
        scope = $rootScope.$new();
        
        $compile(element)(scope);
        isolateScope = element.isolateScope();
        isolateScope.percentage = 50;
      }));

      it('should set percentage for progress bar', function() {
          element.isolateScope().$apply(element.isolateScope().percentage);
          expect(isolateScope.progress).to.equal(isolateScope.percentage);
      });
    });
  });
});
