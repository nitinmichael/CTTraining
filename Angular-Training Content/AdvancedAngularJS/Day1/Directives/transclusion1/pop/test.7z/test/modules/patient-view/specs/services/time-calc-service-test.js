/*
 *  time-calc-service-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * @author: Felipe de Andrade <andrade@ge.com>
 *
 * Spec file for TimeCalc service module
 */

define([
    'angular',
    'angular-mocks',
    'patient-view/services/timeCalcService'
],
function () {
    'use strict';

    describe('TimeCalc Service Test Suite::', function () {

        var timeCalcService;
        var $rootScope;

        beforeEach(module('cloudav.patient-view.timeCalcService', function ($provide) {
            $provide.value('translateFilter', function (value) {
                return '{{' + value + '}}';
            });
        }));
        
        // Initialize the scope and controller variables
        beforeEach(inject(function (_TimeCalcService_, _$rootScope_) {
            timeCalcService = _TimeCalcService_;
            $rootScope = _$rootScope_;
        }));

        it('should define a service', function () {
            assert.isDefined(timeCalcService, 'TimeCalc is not defined');
        });

        describe('TimeCalcService', function () {

            beforeEach(function () {

            });

            it('should define a .durationAsString method', function () {
                assert.isDefined(timeCalcService.durationAsString, '.durationAsString method not defined');
                assert.isFunction(timeCalcService.durationAsString, '.durationAsString is not a function');
            });

            it('should calc the duration between two dates as now', function () {

                var d1 = new Date();
                var d2 = new Date();

                var result = timeCalcService.durationAsString(d1, d2);

                expect(result).to.eql("{{patient-view.duration.justNow}}");

            });


            it('should calc the duration between two dates - 1 minute', function () {

                var d2 = new Date();
                var d1 = new Date(d2.getTime() - 60 * 1000);

                var result = timeCalcService.durationAsString(d1, d2);

                expect(result).to.eql("{{patient-view.duration.lastMinute}}");

            });

            it('should calc the duration between two dates - 10 minutes', function () {

                var d2 = new Date();
                var d1 = new Date(d2.getTime() - 600 * 1000);

                var result = timeCalcService.durationAsString(d1, d2);

                expect(result).to.eql("10{{patient-view.duration.minutesAgo}}");

            });


            it('should calc the duration between two dates - 1 hour', function () {

                var d2 = new Date();
                var d1 = new Date(d2.getTime() - 60 * 60 * 1000);

                var result = timeCalcService.durationAsString(d1, d2);

                expect(result).to.eql("{{patient-view.duration.lastHour}}");

            });

            it('should calc the duration between two dates - 10 hours', function () {

                var d2 = new Date();
                var d1 = new Date(d2.getTime() - 60 * 630 * 1000);

                var result = timeCalcService.durationAsString(d1, d2);

                expect(result).to.eql("10{{patient-view.duration.hoursAgo}}");

            });


            it('should calc the duration between two dates - 1 day', function () {

                var d2 = new Date();
                var d1 = new Date(d2.getTime() - 24 * 60 * 60 * 1000);

                var result = timeCalcService.durationAsString(d1, d2);

                expect(result).to.eql("{{patient-view.duration.yesterday}}");

            });

            it('should calc the duration between two dates - 4 days', function () {

                var d2 = new Date();
                var d1 = new Date(d2.getTime() - 4 * 24 * 60 * 60 * 1000);

                var result = timeCalcService.durationAsString(d1, d2);

                expect(result).to.eql("4{{patient-view.duration.daysAgo}}");

            });

            it('should calc the duration between two dates - 7 days', function () {

                var d2 = new Date();
                var d1 = new Date(d2.getTime() - 7 * 24 * 60 * 60 * 1000);

                var result = timeCalcService.durationAsString(d1, d2);

                expect(result).to.eql("{{patient-view.duration.lastWeek}}");

            });

            it('should calc the duration between two dates - 40 days', function () {

                var d2 = new Date();
                var d1 = new Date(d2.getTime() - 40 * 24 * 60 * 60 * 1000);

                var result = timeCalcService.durationAsString(d1, d2);

                expect(result).to.eql("5{{patient-view.duration.weeksAgo}}");

            });

            it('should time elapsed between 25 days ago and now (3 weeks)', function () {

                var now = new Date();
                var d = new Date(now.getTime() - 25 * 24 * 60 * 60 * 1000);

                var result = timeCalcService.timeElapsedSince(d);

                expect(result).to.eql("3{{patient-view.duration.weeksAgo}}");

            });


        });
    });
});
