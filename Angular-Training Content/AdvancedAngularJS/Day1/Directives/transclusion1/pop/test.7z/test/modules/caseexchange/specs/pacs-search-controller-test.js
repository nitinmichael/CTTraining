/*
 *  pacs-search-controller-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Raoul Nair<raoul.nair@ge.com>
 */

define([ 'angular', 'angular-mocks', 'create-case/module', 'create-case/controllers/pacs-search-controller', 'mocks/case-exchange-mock-service'], function() {
    'use strict';
    var scope, controller, rootScope, dicomDevices, dicomDevice, dicomDevicesStub, getPacsService, pacsSearchMarshaller, location, patientResponse, patient,
        stateSpy, state, patientsStub, caseExchangeDataService, dicomDeviceStub, pacsSearchService, pacsSearchDeferred, selectedStudyListService, pacsSearchData;

    describe('Pacs Search Controller Test Suite::', function() {

        var alertTypes = {
                success: 'success',
                error: 'error'
            };

        var pacsSearchResponse = [{totalCount : 0},{totalCount : 2}],
            pacsDevice = {
                entry:[{
                    content:{name:'b'}
                },{
                    content:{name:'a'}
                }]
            },
            SEARCH_RESULT_DATA = {dicomDevices:[]};
 
        function fakePatientResolved(value) {
            return {
                promise : {
                    then : function(callback) {
                        callback(patientResponse);
                    },
                    success : function(callback) {
                        callback(patientResponse);
                    },
                    error : function(callback) {
                        callback("No Record");
                    }
                }
            }
        }

        function fakePacsSearch(value) {
            return {
                promise: {
                    then: function (callback) {
                        callback(pacsSearchResponse[0]);
                    },
                    success: function (callback) {
                        callback(pacsSearchResponse[0]);
                    },
                    error: function (callback) {
                        callback("No Record");
                    }
                }
            }
        }

        function fakePacsSearchCount(value) {
            return {
                promise: {
                    then: function (callback) {
                        callback(pacsSearchResponse[1]);
                    },
                    success: function (callback) {
                        callback(pacsSearchResponse[1]);
                    },
                    error: function (callback) {
                        callback("No Record");
                    }
                }
            }
        }

        beforeEach(function () {
            // Load the module for the mock data first
            module('cloudav.caseExchange.mocks');

            module('cloudav.caseExchange.createCase.pacsSearchCtrl', function ($provide) {
                $provide.value('$state', {
                    transitionTo: function (url) { },
                    current: {
                        params: {}
                    }
                });

                $provide.value('$state', {
                    transitionTo: function (url) { },
                    current: {
                        params: {}
                    }
                });

                $provide.value('$stateParams', {
                    id: function () {}
                });

                $provide.value('PacsSearchService', {
                    pacsSearch: function () {
                        return fakePatientResolved("value");
                    },
                    getPacsSearchParams: function () {
                        return SEARCH_RESULT_DATA;
                    },
                    setPacsSearchResultData : function (data) {
                        SEARCH_RESULT_DATA = data;
                    },
                    setPacsSearchParams : function (data) {},
                    clearPacsSearchParams: function () {
                        return '';
                    }
                });

                $provide.value('GetPacsServices', {
                    getPacsDevices: function() {
                        return {
                            then: function(callback) { return callback(pacsDevice);}
                        };
                    }
                });
            })
        });

        // Initialize the scope and controller variables
        beforeEach(inject(function($rootScope, $controller, GetPacsServices, $location, $state, PacsSearchService, CaseExchangeDataService, PacsSearchMarshaller, SelectedStudyListService, CaseExchangeMocks) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            controller = $controller;
            dicomDevices = CaseExchangeMocks.getPacsDevices();
            dicomDevice = CaseExchangeMocks.getPacsDevices()[0];
            pacsSearchData = CaseExchangeMocks.getPatientSearchData();
            patientResponse = CaseExchangeMocks.getPatientsFromPacs();
            patient = CaseExchangeMocks.getPatientsFromPacs().responseList;

            // Initialize the controller before each specs
            controller('PacsSearchCtrl', {
                $scope : scope
            });
            dicomDevicesStub = sinon.stub(GetPacsServices, 'getPacsDevices', function() {
                return dicomDevices;
            });
            getPacsService = GetPacsServices;
            location = $location;
            state = $state;
            caseExchangeDataService = CaseExchangeDataService;
            selectedStudyListService = SelectedStudyListService;
            pacsSearchMarshaller = PacsSearchMarshaller;
            pacsSearchService = PacsSearchService;
	    
            dicomDeviceStub = sinon.stub(pacsSearchMarshaller,'getDicomDetail',function(deviceId){return dicomDevice;});

            // Mocking the method from parent controller as we don't have inheritance in place in unit testing.
            scope.showAlertMessage = function () {
            };
            getPacsService.getPacsDevices.restore();
        }));

        it('should call success of getPacsDevices service', function (){
            SEARCH_RESULT_DATA = {dicomDevices: [1,2]};
            pacsSearchService.setPacsSearchResultData(SEARCH_RESULT_DATA);
            controller('PacsSearchCtrl', {$scope : scope});

            expect(scope.dicomDevices[0].content.name).to.equal('a');
            expect(scope.dicomDevices[1].content.name).to.equal('b');
            expect(scope.selectDeselectChecked).to.equal(true);
            expect(scope.allDevicesSelected).to.equal(true);
        });

        it('should have a controller', function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it('should assign error message that is passed to it', function () {
            var errorMsg = "error"
            scope.setErrorMsg(errorMsg);
            expect(scope.pacsSearchErrorMsg).to.equal("error");
        });

        it('it should select dicom device if its unselected and add it to devices array', function() {
            scope.pacsData = {};
            scope.pacsData.dicomDevices = [];
            scope.toggleDeviceSelected(dicomDevice, event);
            expect(scope.pacsData.dicomDevices).to.have.length(1);
        });

        it('it should unselect dicom device if its selected and remove it from diveces array', function() {
            dicomDevice.selected = true;
            dicomDevice.resourceId = "41";

            scope.pacsData = {};
            scope.pacsData.dicomDevices = []
            scope.pacsData.dicomDevices.push(dicomDevice);

            scope.toggleDeviceSelected(dicomDevice, event);
            expect(scope.pacsData.dicomDevices).to.have.length(0);
        });

        it('it should not allow to submit pacs search form if any of patient name empty', function() {
            scope.pacsData = {};
            scope.pacsData.patientFirstName = "";
            scope.pacsData.patientLastName = "";
            scope.pacsData.patientMiddleName = "";
            scope.pacsData.studyId = "";
            scope.submitPacsSearch();
            expect(scope.showPacsSearchError).to.equal(true);
        });

        it('it should not allow to submit pacs search form if total length of patient first and last name is less than 1', function() {
            scope.pacsData = {};
            scope.pacsData.patientFirstName = "f";
            scope.pacsData.patientLastName = "";
            scope.pacsData.patientMiddleName = "";
            scope.submitPacsSearch();
            expect(scope.showPacsSearchError).to.equal(true);
        });

        it('it should not allow to submit pacs search form if patient name contain *', function() {
            scope.pacsData = {};
            scope.pacsData.patientFirstName = "first name*";
            scope.pacsData.patientLastName = "";
            scope.pacsData.patientMiddleName = "";
            scope.submitPacsSearch();
            expect(scope.showPacsSearchError).to.equal(true);
        });
        
        it('it should not allow to submit pacs search form if length of study id > 16 characters', function() {
            scope.pacsData = {};
            scope.pacsData.studyId = "12345678901234567";
            scope.submitPacsSearch();
            expect(scope.showPacsSearchError).to.equal(true);
        });
        
        it('it should not allow to submit pacs search form if study id contains * ? \ characters', function() {
            scope.pacsData = {};
            scope.pacsData.studyId = "abn*1";
            scope.submitPacsSearch();
            expect(scope.showPacsSearchError).to.equal(true);
        });

        it('it should not allow to submit pacs search form if length of patient id > 64 characters', function() {
            scope.pacsData = {};
            scope.pacsData.patientId = "12345678901234567890123456789012345678901234567890123456789abcDCH";
            scope.submitPacsSearch();
            expect(scope.showPacsSearchError).to.equal(true);
        });

        it('it should allow to submit pacs search form if length of patient id < 64 characters', function() {
            scope.pacsData = {};
            scope.pacsData.patientId = "12345678901234567890123456789012345678901234567890123456789ab";
            scope.submitPacsSearch();
            expect(scope.showPacsSearchError).to.equal(false);
        });

        it('it should not allow to submit pacs search form if patient id contains "*" character', function() {
            scope.pacsData = {};
            scope.pacsData.patientId = "abn*1";
            scope.submitPacsSearch();
            expect(scope.showPacsSearchError).to.equal(true);
        });

        it('it should not allow to submit pacs search if pacs device is not selected', function() {
            scope.pacsData = {};
            scope.pacsData.devices = [];
            scope.submitPacsSearch();
            expect(scope.showDeviceError).to.equal(true);
        });

        it('it should allow to submit pacs search on valid condition', function() {
            scope.pacsData = {};

            scope.pacsData.patientFirstName = "first name";
            scope.pacsData.patientLastName = "";
            scope.pacsData.patientMiddleName = "";

            var dicomDevice = {};
            scope.pacsData.dicomDevices = [];
            scope.pacsData.dicomDevices.push(dicomDevice);
            
            scope.dicomDevices = dicomDevices;
            scope.alertTypes = alertTypes;

            var showAlertMessageSpy = sinon.spy(scope, 'showAlertMessage');
            scope.submitPacsSearch();
            expect(scope.showPacsSearchError).to.equal(false);
            expect(scope.showDeviceError).to.equal(false);
        });

        it('it should allow to submit pacs search on valid condition with study id', function() {
            scope.pacsData = {};

            scope.pacsData.studyId = "41";

            var dicomDevice = {};
            scope.pacsData.dicomDevices = [];
            scope.pacsData.dicomDevices.push(dicomDevice);

            scope.dicomDevices = dicomDevices;
            scope.alertTypes = alertTypes;

            var showAlertMessageSpy = sinon.spy(scope, 'showAlertMessage');
            scope.submitPacsSearch();
            expect(scope.showPacsSearchError).to.equal(false);
            expect(scope.showDeviceError).to.equal(false);
        });

        it('should have a "cancelPacsSearch" function', function() {
            var stateSpy = sinon.spy(state, "transitionTo");
            scope.cancelPacsSearch(); 
            assert(stateSpy.calledWith('caseexchange.createcase'));
        });

        it('should navigate back to create case screen if there is no caseUpdateType present', function (){
            caseExchangeDataService.resetCaseUpdateType();
            var stateSpy = sinon.spy(state, "transitionTo");
            scope.cancelPacsSearch();
            assert(stateSpy.calledWith('caseexchange.createcase'));
        });

        it('should navigate back to add to case screen if there is caseUpdateType present as "ADDCASE"', function (){
            caseExchangeDataService.setCaseUpdateType('ADDCASE');
            var stateSpy = sinon.spy(state, "transitionTo");
            scope.cancelPacsSearch();
            assert(stateSpy.calledWith('caseexchange.updatecase'));
        });

        it('should initialize pacs data with "selectedPatient.name.given" as null', function (){
            sinon.stub(selectedStudyListService,'getSelectedPatient',function(){return patient[0];});
            scope.initializePacsData();
            expect(scope.disablePatientField).to.equal(true);
        });

        it('should initialize pacs data with "selectedPatient.name.given" as an array', function (){
            sinon.stub(selectedStudyListService,'getSelectedPatient',function(){return patient[1];});
            scope.initializePacsData();
            expect(scope.disablePatientField).to.equal(true);
        });

        it('should call submitPacsSearch with zero total count in response ', function (){
            scope.pacsData = {};

            scope.pacsData.patientFirstName = "first name";
            scope.pacsData.patientLastName = "";
            scope.pacsData.patientMiddleName = "";

            var dicomDevice = {};
            scope.pacsData.dicomDevices = [];
            scope.pacsData.dicomDevices.push(dicomDevice);

            scope.dicomDevices = dicomDevices;
            scope.alertTypes = alertTypes;
            sinon.stub(pacsSearchMarshaller,'marshalPacsSearchData',function(pacsData){return pacsSearchData;});
            sinon.stub(selectedStudyListService,'getSelectedPatient',function(){return patient[1];});
            sinon.stub(pacsSearchService,'pacsSearch',function(){return fakePacsSearch("value");});
            scope.submitPacsSearch();
            expect(scope.searchPacsFormSubmitted).to.equal(true);
        });

        it('should call submitPacsSearch with positive total count in response ', function (){
            scope.pacsData = {};

            scope.pacsData.patientFirstName = "first name";
            scope.pacsData.patientLastName = "";
            scope.pacsData.patientMiddleName = "";

            var dicomDevice = {};
            scope.pacsData.dicomDevices = [];
            scope.pacsData.dicomDevices.push(dicomDevice);

            scope.dicomDevices = dicomDevices;
            scope.alertTypes = alertTypes;
            sinon.stub(pacsSearchMarshaller,'marshalPacsSearchData',function(pacsData){return pacsSearchData;});
            sinon.stub(selectedStudyListService,'getSelectedPatient',function(){return patient[1];});
            sinon.stub(pacsSearchService,'pacsSearch',function(){return fakePacsSearchCount("value");});
            scope.submitPacsSearch();
            expect(scope.searchPacsFormSubmitted).to.equal(true);
        });

        it('should push a dicom device in empty "pacsData.dicomDevices"', function (){
            var dicomDevice = {selected : false};
            scope.pacsData = {};
            scope.pacsData.dicomDevices = undefined;
            scope.toggleDeviceSelected(dicomDevice);
            expect(scope.pacsData.dicomDevices).to.have.length(1);
        });

        it('should select all the devices', function (){
            var dicomDevice = {selected : true,id : "12"};
            scope.pacsData = {};
            scope.pacsData.dicomDevices = [];
            scope.dicomDevices = [];
            scope.toggleDeviceSelected(dicomDevice);
            expect(scope.allDevicesSelected).to.equal(true);
        });

        it('should return false pacs device if already selected', function (){
            sinon.stub(pacsSearchService,'getPacsSearchParams',function(){return {};});
            expect(scope.isPacsSelected("1234")).to.equal(false);
        });

        it('should return true pacs device if already selected', function (){
            var pacsSearch={};
            var dicomDevicesList=[{id:"1234"}];
            pacsSearch.dicomDevices=dicomDevicesList;
            sinon.stub(pacsSearchService,'getPacsSearchParams',function(){return pacsSearch;});
            expect(scope.isPacsSelected("1234")).to.equal(true);
        });

        // Use Sinon to replace jQuery's ajax method with a spy.
        beforeEach(function() {
            sinon.stub($, 'ajax').yieldsTo('success', {});
        });

        // Restore jQuery's ajax method to its original state
        afterEach(function() {
            $.ajax.restore();
        });
    });
});