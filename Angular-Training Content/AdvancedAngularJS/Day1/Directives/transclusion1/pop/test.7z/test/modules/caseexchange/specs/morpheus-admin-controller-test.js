/*
 *  Morpheus-controller-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jyothi Jayaraman<Jyothi.Jayaraman@ge.com>
 */

/**
 * Test specs for Morpheus Controller
 */

define(['angular', 'angular-mocks',
        'modules/caseexchange/services/case-exchange-data-service',
        'modules/caseexchange/modules/morpheus/modules/admindashboard/controllers/morpheus-admin-controller'],
         function () {
    'use strict';

    var MODES = {
            create: 'AUTOCREATE'
        };

    var rootScope, scope, state, controller, caseExchangeDataService;

    describe('Morpheus Admin Controller Test Suite::', function() { 

        beforeEach(module('cloudav.caseExchange.morpheusAdminCtrl', function($provide) {})); 

    //     beforeEach(function () {
    //         module('cloudav.caseExchange.morpheusAdminCtrl', function ($provide) {
    //             $provide.value('$state', {
    //                 transitionTo: function (url) {
    //                 },
    //                 current: {
    //                     params: {
    //                         mode: MODES.create
    //                     }
    //                 }
    //             });

    //             $provide.value('$stateParams', {
    //                 id: function () {
    //                 }
    //             });
    //         });

    //         function mockUserDetails(value) {
    //             return {
    //                 promise : {
    //                     then : function(callback) {
    //                         callback("");
    //                     }
    //                 }
    //             }
    //         }
    //     });

    //     // Initialize the scope and controller variables
    //     beforeEach(inject(function($rootScope, $state, $controller, _caseExchangeDataService) {
    //         rootScope = $rootScope;
    //         scope = $rootScope.$new();
    //         state = $state;
    //         controller = $controller;
    //         caseExchangeDataService

    //         // Initialize the controller before each specs
    //         controller('MorpheusAdminCtrl', {
    //             $scope : scope
    //         });
            
    //     }));

    //     it('should have a controller', function() {
    //         assert.isDefined(controller, 'Controller is not defined');
    //     });
    });
});