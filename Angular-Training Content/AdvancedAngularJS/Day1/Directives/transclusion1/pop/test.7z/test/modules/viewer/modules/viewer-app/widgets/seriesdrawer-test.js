/*
 *  seriesdrawer-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Sylvain Rouquette <sylvain.rouquette@ge.com>
 */

/**
 * Spec file for Viewer > modules > viewer-app > widgets > series-drawer directive
 */
//

define(['angular', 'angular-mocks', 'viewerModule/widgets/series-drawer/directives/series-drawer'], function() {
    'use strict';

    describe('Series Selector Directive Test :', function() {
        var element, scope;


        describe('defined directive', function() {
            var portcontentMock, viewportParameterStorage, eventStub;

            beforeEach(module('cloudav.viewerApp.widgets', function($provide) {
                portcontentMock = {
                    setGroup: function() {},
                    getActivePort: sinon.stub().returns(0),
                    getActivePortIndex: sinon.stub().returns(0)
                };
                viewportParameterStorage = {
                    getGroups: sinon.stub(),
                    getGroup: sinon.stub(),
                    getCurrentConfiguration: function() {
                        return {
                            ports: [{
                                index: 0,
                                menu: false,
                                cssLayout: 'twoByTwo',
                                usePredefinedLayout: true,
                                getId: function() {
                                    return '0';
                                },
                                groupId: 'Group0'
                            }, {
                                index: 1,
                                menu: false,
                                cssLayout: 'twoByTwo',
                                usePredefinedLayout: true,
                                getId: function() {
                                    return '1';
                                },
                                groupId: 'Group2'
                            }, {
                                index: 2,
                                menu: false,
                                cssLayout: 'twoByTwo',
                                usePredefinedLayout: true,
                                getId: function() {
                                    return '2';
                                },
                                groupId: 'Group1'
                            }, {
                                index: 3,
                                menu: false,
                                cssLayout: 'twoByTwo',
                                usePredefinedLayout: true,
                                getId: function() {
                                    return '3';
                                },
                                groupId: 'Group1'
                            }]
                        };
                    }
                };
                $provide.value('$viewportParameterStorage', viewportParameterStorage);
                $provide.value('portContentFactory', portcontentMock);

            }));

            beforeEach(module('templates'));

            beforeEach(
                inject(function($compile, $rootScope) {
                    scope = $rootScope.$new();
                    element = $compile('<series-drawer />')(scope);
                    scope.$digest();
                })
            );

            it('should have a directive', function() {
                assert.isDefined(element, 'series-drawer Directive is not defined');
            });

            it('should have a child exams-container', function() {
                assert.isDefined(element.children('exams-container'));
            });

            it('should have a child images-container', function() {
                assert.isDefined(element.children('images-container'));
            });

            it('changes selected when the active port changes', function() {
                var group = [{
                    groupId: 'Group1'
                }];
                portcontentMock.getActivePort = sinon.stub().returns(group);
                viewportParameterStorage.getGroups.returns(group);
                var isolateScope = element.isolateScope();
                scope.$apply();
                assert.equal(isolateScope.selected, isolateScope.groups[0]);

                group = [{
                    groupID: 'Group2'
                }];

                portcontentMock.getActivePort = sinon.stub().returns(group);
                viewportParameterStorage.getGroups.returns(group);
                scope.$apply();
                expect(isolateScope.selected, isolateScope.groups[1]);
            });

            it('changes selected when setSelected is called', function() {
                var groups = [{
                    groupID: 'Group1'
                }, {
                    groupID: 'Group2'
                }];
                viewportParameterStorage.getGroups.returns(groups);
                scope.$apply();
                var isolateScope = element.isolateScope();
                assert.isDefined(isolateScope.selected);
                isolateScope.setSelected('Group1');
                assert.equal(isolateScope.selected.groupID, isolateScope.groups[0].groupID);
                isolateScope.setSelected('Group2');
                assert.equal(isolateScope.selected.groupID, isolateScope.groups[1].groupID);
            });

            it('Testing Add Groups function', function() {

                var isolateScope = element.isolateScope();
                var groups = [{
                    groupID: 'Group0',
                    seriesUID: 'UUID-1',
                    saveState: true,
                    secondaryCapture: false,
                    imageType: '2D',
                    modality: 'CT',
                    nbImages: 10,
                    date: '11/11/2015',
                    description: 'Group0 desc'
                }, {
                    groupID: 'Group1',
                    seriesUID: 'UUID-2',
                    saveState: false,
                    secondaryCapture: true,
                    imageType: '2D',
                    modality: 'CT',
                    nbImages: 10,
                    description: 'Group1 desc'
                }, {
                    groupID: 'Group2',
                    seriesUID: 'UUID-3',
                    saveState: false,
                    secondaryCapture: false,
                    imageType: '3D',
                    modality: 'CT',
                    nbImages: 10,
                    description: 'Group2 desc'
                }, {
                    groupID: 'Group3',
                    seriesUID: 'UUID-4',
                    saveState: false,
                    secondaryCapture: false,
                    imageType: '2D',
                    modality: 'CT',
                    nbImages: 10,
                    description: 'Group3 desc'
                }];

                viewportParameterStorage.getGroups.returns(groups);
                scope.$apply();
                for (var i = 0; i < groups.length; i++) {
                    expect(isolateScope.groups[i].groupID).to.equal(groups[i].groupID);
                    expect(isolateScope.groups[i].descriptions[0]).to.equal('Group' + i + ' desc');
                    if (i === 1) {
                        expect(isolateScope.groups[i].descriptions[1]).to.equal('Secondary Capture');

                    } else if (i === 3) {
                        expect(isolateScope.groups[i].descriptions[1]).to.equal('Multiframe');
                    } else {
                        expect(isolateScope.groups[i].descriptions[1]).to.equal('10 images');
                    }
                }

                expect(isolateScope.groups[0].descriptions[2]).to.equal('11/11/2015');
                expect(isolateScope.groups[0].modality).to.equal('Saved State');
                expect(isolateScope.groups[1].modality).to.equal('CT');
                expect(isolateScope.groups[2].modality).to.equal('CT');
                expect(isolateScope.groups[3].modality).to.equal('CT');
            });

            it('Testing double click function', function() {
                var isolateScope = element.isolateScope();

                var groups = [{
                    groupID: 'Group0'
                }, {
                    groupID: 'Group1'
                }];

                var selectedport = {
                    index: 0,
                    groupId: 'Group2',
                    getId: function() {
                        return '0';
                    }
                };

                viewportParameterStorage.getGroups.returns(groups);
                portcontentMock.getActivePort.returns(selectedport);
                viewportParameterStorage.getGroup.returns(groups[1]);
                scope.$apply();

                var spy = sinon.spy(isolateScope, 'setSelected');
                isolateScope.selected = groups[0];
                isolateScope.dbClickGroup('Group1');
                expect(spy.calledOnce).to.equal(true);
                expect(spy.calledWith('Group1')).to.equal(true);
            });

            it('Testing double click function not called when same group is selected', function() {
                var isolateScope = element.isolateScope();

                var group = {
                    groupID: 'Group0'
                };

                viewportParameterStorage.getGroup.returns(group);
                var selectedport = {
                    groupId: 'Group0'
                };

                var mock = sinon.mock(portcontentMock).expects('setGroup').never().withArgs(group, 0);

                portcontentMock.getActivePort.returns(selectedport);
                scope.$apply();

                var spy = sinon.spy(isolateScope, 'setSelected');
                isolateScope.selected = group;
                isolateScope.dbClickGroup('Group0');
                mock.verify();
                expect(spy.called).to.equal(false);
                expect(spy.calledWith('Group0')).to.equal(false);
            });

            it(' double click function should throw if group is not found', function() {
                var isolateScope = element.isolateScope();
                viewportParameterStorage.getGroup.returns(undefined);
                var selectedport = {
                    index: 0,
                    groupId: 'Group0'
                };

                portcontentMock.getActivePort.returns(selectedport);
                scope.$apply();

                expect(function() {
                    isolateScope.dbClickGroup('unknown group');
                }).to.throw(Error, 'group unknown group not found');
            });


            it('Test apparition of the scrollbar', function() {

                var isolateScope = element.isolateScope();

                var groups = [{
                    groupID: 1
                }, {
                    groupID: 2
                }, {
                    groupID: 3
                }, {
                    groupID: 4
                }, {
                    groupID: 5
                }, {
                    groupID: 6
                }];
                viewportParameterStorage.getGroups.returns(groups);
                scope.$apply();
                expect(isolateScope.scrollOn).to.equal(true);
            });
        });
    });
});
