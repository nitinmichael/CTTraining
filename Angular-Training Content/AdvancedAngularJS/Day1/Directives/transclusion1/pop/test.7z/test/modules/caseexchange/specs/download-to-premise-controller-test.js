/*
 *  download-to-premise-controller-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Henry Navarro<henry.navarro@ge.com>
 */

/**
 * Spec file for Download To Premise module controller
 */

define([
    'angular',
    'angular-mocks',
    'case-inbox/module',
    'case-inbox/controllers/download-to-premise-controller',
    'case-exchange/services/get-pacs-service',
    'mocks/case-exchange-mock-service',
    'mocks/fake-server'],
    function () {
        'use strict';
        var scope, rootScope, controller, getPacsServices, downloadCaseService, $q, state, $mockServerLoader, mockServer;

        describe('Download to Premise Controller Test Suite::',
            // Prep for the whole test suite
            function () {

                var mockDicomAttachmentData, mockDicomAppServiceData;
                // Mock the function dependencies and provide them to
                // the controller to be tested
                beforeEach(function() {

                    // Load the module for the mock data first
                    module('cloudav.caseExchange.mocks');
                    // Load the Sinon fake server.
                    module('cloudav.caseExchange.fakeServer');
                    module('Services.downloadCaseService');
                    module('cloudav.caseExchange.caseInbox.downloadToPremiseCtrl',
                        function ($provide) {
                            $provide.factory('GetPacsServices', ['$q',
                                function ($q) {
                                    function getPacsDevices() {
                                        return $q.when(caseDicomAttachment);
                                    }
                                    return {
                                        getPacsDevices: getPacsDevices
                                    }
                                }
                            ]);

                            $provide.value('$state', {
                                go: function (url) {},
                                current: { params: {} }
                            });

                            $provide.value('$stateParams', {id: function () {} });

                            $provide.factory('configurationService', ['$q', function($q){
                                return {
                                    getProperty: function(){
                                        return $q.when({});
                                    }
                                }
                            }]);

                        });
                    });


                // Initialize the scope and controller variables
                beforeEach(
                    inject(
                        function ($rootScope, $controller, _$q_, $state, _GetPacsServices_,_DownloadCaseService_, $MockServerLoader, CaseExchangeMocks) {
                            scope = $rootScope.$new();
                            rootScope = $rootScope;
                            controller = $controller;
                            $q = _$q_;
                            state = $state;
                            getPacsServices = _GetPacsServices_;
                            downloadCaseService = _DownloadCaseService_;

                            mockDicomAppServiceData = CaseExchangeMocks.getDicomApplicationService();

                            $mockServerLoader = $MockServerLoader;

                            // Call the init to initialize the Sinon Mock Data Server.
                            mockServer = $mockServerLoader.init();

                            // Initialize the controller before each spec
                            controller('DownloadToPremiseCtrl', {
                                $scope: scope,
                                getPacsServices: getPacsServices,
                                downloadCaseService: downloadCaseService
                            });

                            // Mocking the variable from parent controller as we don't have
                            // inheritance in place in unit testing.
                            scope.alertTypes = {
                                success: 'success',
                                error: 'error'
                            };
                            scope.showAlertMessage = function () {};

                            // Mock PACS Devices
                            scope.pacsDevices = CaseExchangeMocks.getPacsDevices();

                            scope.selectedDevice = CaseExchangeMocks.getSelectedDevice();

                            // Mock studies
                            scope.selectedCaseStudies = CaseExchangeMocks.getCaseStudies();

                            // Mock case id 
                            scope.selectedCase = {
                              id: "60158323287438185382575"  
                            };
                        }
                    )
                );

                it('should have a controller', function () {
                    assert.isDefined(controller, 'Controller is not defined');
                });

                it('should have a "cancelDownloadToPremise" function', function () {
                    assert.isDefined(scope.cancelDownloadToPremise, 'Controller scope has no "cancelDownloadToPremise" function');
                    assert(typeof scope.cancelDownloadToPremise === 'function', '"cancelDownloadToPremise" is not a function');
                });

                it('should have a "toggleStudySelection" function', function () {
                    assert.isDefined(scope.toggleStudySelection, 'Controller scope has no "toggleStudySelection" function');
                    assert(typeof scope.toggleStudySelection === 'function', '"toggleStudySelection" is not a function');
                });

                it('should have a "toggleDeviceSelection" function', function () {
                    assert.isDefined(scope.toggleDeviceSelection, 'Controller scope has no "toggleDeviceSelection" function');
                    assert(typeof scope.toggleDeviceSelection === 'function', '"toggleDeviceSelection" is not a function');
                });

                it('should have a "downloadCase" function', function () {
                    assert.isDefined(scope.downloadCase, 'Controller scope has no "downloadCase" function');
                    assert(typeof scope.downloadCase === 'function', '"downloadCase" is not a function');
                });

                it('should have a "selectedDevice" property', function () {
                    assert.isDefined(scope.selectedDevice, 'Controller scope has no "selectdDevice" property');
                });

                it('should have a "deviceSelected" property', function () {
                    assert.isDefined(scope.deviceSelected, 'Controller scope has no "deviceSelected" property');
                    assert(typeof scope.deviceSelected !== 'function', '"deviceSelected" is not a primitive');
                });

                it('should have a "studySelected" property', function () {
                    assert.isDefined(scope.studySelected, 'Controller scope has no "studySelected" property');
                    assert(typeof scope.studySelected !== 'function', ' "studySelected" is not a primitive');
                });

                it('should call the download service "downloadCaseAttachment" and return "success" when "download" button is clicked', function () {
                    var downloadCaseOperationSpy = sinon.spy(downloadCaseService, "downloadCaseAttachment");

                    /**
                     * This will fake the download case operation POST submit call.
                     * It will only configure the sever with service URL.
                     * Passing 200 status will force the server to return success
                     * Passing mockDicomAttachmentData will make the server to return the same back in success resolve.
                     */
                    $mockServerLoader.fakeDownloadCaseAttachment(scope.selectedCase.id, 200, mockDicomAttachmentData);

                    scope.downloadCase();

                    /**
                     * This will force the server to return the response.
                     * Based on the passed response status, it will return 200-Success OR 500-Failure
                     */
                    mockServer.respond();

                    rootScope.$apply();
                    expect(downloadCaseOperationSpy.calledOnce).to.be.true;
                });

                it('should call the download service "downloadCaseAttachment" and return "failure" when "download" button is clicked', function () {
                    var downloadCaseOperationSpy = sinon.spy(downloadCaseService, "downloadCaseAttachment");

                    /**
                     * This will fake the download case operation POST submit call.
                     * It will only configure the sever with service URL.
                     * Passing 200 status will force the server to return success
                     * Passing mockDicomAttachmentData will make the server to return the same back in success resolve.
                     */
                    $mockServerLoader.fakeDownloadCaseAttachment(scope.selectedCase.id, 500, mockDicomAttachmentData);

                    scope.downloadCase();

                    /**
                     * This will force the server to return the response.
                     * Based on the passed response status, it will return 200-Success OR 500-Failure
                     */
                    mockServer.respond();

                    // Apply the root scope again to resolve the promise.
                    rootScope.$apply();
                    expect(downloadCaseOperationSpy.calledOnce).to.be.true
                });

                it('should throw error and return "failure" when "download" button is clicked', function () {
                    var downloadCaseOperationSpy = sinon.spy(downloadCaseService, "downloadCaseAttachment");

                    /**
                     * This will fake the download case operation POST submit call.
                     * It will only configure the sever with service URL.
                     * Passing 200 status will force the server to return success
                     * Passing mockDicomAttachmentData will make the server to return the same back in success resolve.
                     */
                    $mockServerLoader.fakeDownloadCaseAttachment( null,500, null);

                    scope.downloadCase();

                    /**
                     * This will force the server to return the response.
                     * Based on the passed response status, it will return 200-Success OR 500-Failure
                     */
                    mockServer.respond();

                    // Apply the root scope again to resolve the promise.
                    rootScope.$apply();
                    expect(downloadCaseOperationSpy.calledOnce).to.be.true
                });

                it('it go back to case summary page on click of "cancelDownloadToPremise" button', function () {

                    var stateSpy = sinon.spy(state, "go");

                    scope.cancelDownloadToPremise();
                    expect(scope.$parent.downloading).to.be.false;
                    assert(stateSpy.calledWith('caseexchange.caseinbox'));
                });

                it('should toggle study when user select on study to be download to on premise', function () {
                    scope.toggleStudySelection();
                    expect(scope.studySelected).to.be.true;
                });

                it('should toggle device when user select on device for study to be download to on premise', function () {
                    scope.toggleDeviceSelection(scope.selectedDevice);
                    expect(scope.deviceSelected).to.be.true;
                });

                it('should set study and device data and validate the download flag when "downloadcase" function is called', function () {
                    scope.downloadCase();
                    expect(scope.selectedCaseStudies.length).to.be.equal(3);
                    expect(scope.pacsDevices.length).to.be.equal(2);
                    expect(scope.$parent.downloading).to.be.false;
                });

                it('should call navigate to normalization screen on call of loadNormalizationScreen()', function () {
                    scope.selectedCase = {};
                    scope.selectedCase.patient = {};

                    var stateSpy = sinon.spy(state, "go");
                    scope.loadNormalizationScreen();
                    assert(stateSpy.calledWith('caseexchange.caseinbox.normalization'));
                });

                it('should set studySelected to true if any of study is selected on call of isStudyAlreadySeleted()', function () {
                    scope.selectedCaseStudies[0].selectedForDownload = true;
                    scope.isStudyAlreadySeleted();
                    expect(scope.studySelected).to.be.true;
                });

                it('should set deviceSelected to true if any of dicom is selected on call of isDicomAlreadySeleted()', function () {
                    scope.pacsDevices[0].selectedForDownload = true;
                    scope.isDicomAlreadySeleted();
                    expect(scope.deviceSelected).to.be.true;
                });
            }
        );
    }
);
