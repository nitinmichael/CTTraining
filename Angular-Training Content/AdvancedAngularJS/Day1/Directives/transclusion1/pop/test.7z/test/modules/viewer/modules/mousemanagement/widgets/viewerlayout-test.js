/*
 *  viewerlayout-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Aamir Omar<omar.aamir@ge.com>
 */

/**
 * Spec file for Viewer > modules > mousemanagement > widgets > viewerLayout directive
 */

define(['angular', 'angular-mocks', 'mousemanagementModule/module', 'platformMock', 'imageAreaToolbarMocks',
        'mousemanagementModule/widgets/viewerlayout'],
    function () {
        'use strict';

        describe('viewerLayout Directive Test :', function () {
            var element, scope, isolatedScope, imageAreaToolbarFactory, itemClicked;

            beforeEach(module('cloudav.viewerApp.mousemanagement'));
            beforeEach(module('imageAreaToolbarFactoryMock'));
            beforeEach(module('platform'));
            beforeEach(module('templates'));

            beforeEach(module(function($provide) {
                $provide.service('$viewerLayoutService', function () {
                    this.setLayout = function (params) {
                        itemClicked = params.cssLayout;
                    };
                });
            }));

            beforeEach(
                inject(function ($compile, $rootScope, $viewerLayoutService) {
                    var html = '<viewer-layout></viewer-layout>';
                    scope = $rootScope.$new();
                    element = $compile(html)(scope);
                    scope.$digest();
                    isolatedScope = element.isolateScope();
                })
            );

            it('should have a directive', function () {
                assert.isDefined(element, 'viewer-layout Directive is not defined');
            });

            it('should have an isolated scope', function () {
                assert.isDefined(isolatedScope, 'viewer-layout Directive does not have an isolated scope');
            });

            it('should have default layouts', function () {
                assert.isDefined(isolatedScope.defaultLayouts, 'viewer-layout Directive does not have default layouts');
            });

            it('should have toolBtnClick function', function () {
                assert.isDefined(isolatedScope.toolBtnClick, 'viewer-layout Directive does not have toolBtnClick function');
            });

            it('should have data in default layout', function () {
                expect(isolatedScope.defaultLayouts.length).to.equal(6, 'DefaultLayouts in viewer-layout are incomplete');
            });

            it('should have data in default layout', function () {
                isolatedScope.defaultLayouts[0].onclick();
                expect(itemClicked).to.equal('oneByOne', 'DefaultLayouts in viewer-layout do not have a onclick function');
            });
        });
    });
