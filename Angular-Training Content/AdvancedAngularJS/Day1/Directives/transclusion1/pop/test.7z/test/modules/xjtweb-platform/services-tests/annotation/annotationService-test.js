define([ 'angular-mocks', 'modules/xjtweb-platform/services/annotation/annotationService', 'modules/xjtweb-platform/services/annotation/annotationCache' ], function() {
    describe('annotationService tests', function() {
        var xjtweb;
        var annotationService;
        var $httpBackend;

        beforeEach(module('xjtweb.platform.service.annotationService'));
        beforeEach(module('xjtweb.platform.service.annotationCache'));

        beforeEach(module(function($provide) {
            xjtweb = {
                XJResource : {},
            };
            $provide.value('$xjtweb', xjtweb);
        }));

        beforeEach(inject(function(_annotationService_, _$httpBackend_) {
            annotationService = _annotationService_;
            $httpBackend = _$httpBackend_;
        }));

        it('creates XJResource.getAnnotation override', function() {
            expect(xjtweb.XJResource.getAnnotation).to.exist;
        });

        it('throws an error when called without a callback', function() {
            var params = {};
            expect(function() {
                annotationService.loadAnnotations(params)
            }).to.Throw(Error);
        });

        it('creates correct 2D annotation URLs', function() {
            var resourceInfo = {
                spaceID : '1',
                studyUID : '2',
                seriesUID : '3',
                instanceUID : '4',
                viewType : '2D',
                url : 'BASE',
            };
            expect(annotationService.build2DUrl(resourceInfo)).to.equal('BASE/annotation/api/v1/space/1/studies/2/series/3/images/4');
        });

        it('creates correct 3D annotation URLs', function() {
            var resourceInfo = {
                spaceID : '1',
                studyUID : '2',
                seriesUID : '3',
                viewType : 'Some3DView',
                url : 'BASE',
            };
            expect(annotationService.build3DUrl(resourceInfo)).to.equal('BASE/annotation/api/v1/space/1/studies/2/series/3?3dViewType=Some3DView');
        });

        function create2DParams() {
            return {
                viewType : '2D',
                headerInfo : {
                    pixelResourceInfo : {
                        spaceID : '1',
                        studyUID : '2',
                        seriesUID : '3',
                        annotationBaseUrl : 'BASE'
                    },
                    SopInstanceUid : '4'
                },
                annotationCB : sinon.spy()
            };
        }

        it('loads 2D annotation', function() {
            var params = create2DParams();

            var url2D = 'BASE/annotation/api/v1/space/1/studies/2/series/3/images/4';

            var response = {
                someData : 1
            };
            $httpBackend.whenGET(url2D).respond(response);

            annotationService.loadAnnotations(params);

            $httpBackend.flush()
            params.annotationCB.callCount.should.equal(1);
            params.annotationCB.lastCall.args[0].should.deep.equal(response);

            // test the cache:
            annotationService.loadAnnotations(params);

            // we do not flush the httpBackend
            params.annotationCB.callCount.should.equal(2);
            params.annotationCB.lastCall.args[0].should.deep.equal(response);

        });

        it('returns default value on HTTP errors', function() {
            var params = create2DParams();

            var url2D = 'BASE/annotation/api/v1/space/1/studies/2/series/3/images/4';

            $httpBackend.whenGET(url2D).respond(403, null, null, 'unsufficient rights');

            annotationService.loadAnnotations(params);
            $httpBackend.flush()

            params.annotationCB.callCount.should.equal(1);
            params.annotationCB.lastCall.args[0].should.deep.equal([]);

            // the cache is not used when an error occurs:
            annotationService.loadAnnotations(params);
            $httpBackend.flush()

            params.annotationCB.callCount.should.equal(2);
            params.annotationCB.lastCall.args[0].should.deep.equal([]);

        });

        function doTest3DAnnotationLoading(localViewType, remoteViewType) {
            var params = {
                spaceUId : '1',
                studyInstanceUid : '2',
                seriesUId : '3',
                viewType : localViewType,
                url : 'BASE',
                annotationCB : sinon.spy()
            };

            var url3D = 'BASE/annotation/api/v1/space/1/studies/2/series/3?3dViewType=' + remoteViewType;

            var response = {
                someData : 1
            };
            $httpBackend.whenGET(url3D).respond(response);

            annotationService.loadAnnotations(params);

            $httpBackend.flush()
            params.annotationCB.callCount.should.equal(1);
            params.annotationCB.lastCall.args[0].should.deep.equal(response);

            // test the cache:
            annotationService.loadAnnotations(params);

            // we do not flush the httpBackend
            params.annotationCB.callCount.should.equal(2);
            params.annotationCB.lastCall.args[0].should.deep.equal(response);
        }

        it('loads 3D annotation', function() {
            doTest3DAnnotationLoading('Some3DView', 'Some3DView');
        });

        it('handles 3D view type conversions', function() {
            doTest3DAnnotationLoading('INFERIOR', 'Axial');
            doTest3DAnnotationLoading('LEFT', 'Sagittal');
            doTest3DAnnotationLoading('ANTERIOR', 'Coronal');
        });

    });
});