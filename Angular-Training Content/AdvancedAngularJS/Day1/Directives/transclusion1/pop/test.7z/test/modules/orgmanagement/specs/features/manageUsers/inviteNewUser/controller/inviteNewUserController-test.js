define(['angular',
        'angular-mocks',
        'orgMgmnt/features/manageUsers/inviteNewUser/controller/inviteNewUserController',
        'orgMgmnt/dataModels/userDataModel',
        'orgMgmnt/services/userService',
        'orgMgmnt/utilities/masterDataUtil',
        'orgMgmnt/widgets/ge-app-service/geAppService',
        'orgMgmnt/services/siteService'
    ],
    function(ng){
        'use strict';
        describe('Test the inviteNewUserController', function(){
            var inviteNewUserCtrl, scope,q,appServiceObj;
            var  form, _log, _state, _event,deferred,createUserDeferred;
            var _userMgmtService,_siteMgmtService,rootScope,_userDataModel,obj1,obj,obj3,firstNameArr,InviteNewUserController,searchUserByEmailIdDeferred,listOfSitesForLoggedInUserDeferred,deferredAppServicesLevel2;
            beforeEach( function(){
                module('Orgmanagement.Features.ManageUsers.Controller.InviteNewUserController');
                module('Orgmanagement.DataModel.UserDataModel');
                module('Orgmanagement.Services.UserService');
                module('Orgmanagement.Utilities.MasterData');
                module('Orgmanagement.Services.SiteService');
                module('ui.router');
            });

            /***when role selected is patient***/
            var role = {
                code: "patient",
                display: "Patient"
            };
            obj=[role];

            /***when role selected is practitioner***/
            var role2 = {
                code: "practitioner",
                display: "Healthcare Provider"
            };
            obj1=[role2];


            /***when role selected is neither patient nor healthcare provider***/
            var role3 = {
                code: "hello",
                display: "Healthcare Provider",
                roleTxt: "As the member of your site you can...(copy needed)"
            };
            obj3=[role3];
            beforeEach(inject(function($controller,$rootScope ,userDataModel, $q, $log, $state, $compile,userMgmtService,siteMgmtService,appServiceFactory){
                scope = $rootScope.$new();
                _userMgmtService = userMgmtService;
                _userDataModel = userDataModel;
                _siteMgmtService =siteMgmtService;
                q = $q;
                _log = $log;
                _state = $state
                searchUserByEmailIdDeferred= q.defer();
                listOfSitesForLoggedInUserDeferred = q.defer();
                deferredAppServicesLevel2 = q.defer();
                createUserDeferred = q.defer();
                deferred = q.defer();
                sinon.stub(_userMgmtService, 'searchUserByEmailId').returns(searchUserByEmailIdDeferred.promise);
                sinon.stub(_userMgmtService, 'listOfSiteForLoggedInUser').returns(listOfSitesForLoggedInUserDeferred.promise);
                sinon.stub(_siteMgmtService, 'getApplicationServices').returns(deferredAppServicesLevel2.promise);
                sinon.stub(_userMgmtService, 'createUser').returns(createUserDeferred.promise);
                _state.transitionTo = sinon.stub();
                 appServiceObj = appServiceFactory;
                sinon.stub(_log, 'info');
                _event = {
                    stopPropagation: sinon.spy()
                };
                inviteNewUserCtrl = $controller('inviteNewUserCtrl',{$scope:scope,userMgmtService:_userMgmtService,siteMgmtService:_siteMgmtService} );
            }));


            describe('When there is a XSS event', function(){
                it('and the user closes the alert box, it should test setting of the variable to hide alert', function(){
                    scope.closeAlert();
                    chai.expect(scope.closeAlertPressed.alertStatus).to.be.equal(1);
                });

              /*  it('and there is a rootScope emit of the event, it should test the event is consumed', function(){
                    var object = {message: "There is an attempt to insert scrpit"};
                    scope.$emit("SHOW_FAILURE_MESSAGE_NO_TIMEOUT",object.message);
                    chai.expect(scope.xssMessage).to.be.equal(object.message);
                    chai.expect(scope.closeAlertPressed.alertStatus).to.be.equal(0);
                });
*/

            });


                describe('When calling user related functions', function(){
                      it('createNewUserInfo  and calling data set to the model', function () {
                        firstNameArr =[];
                        firstNameArr.push('test1');
                        scope.formInviteUserInfo={
                            type:'Human',
                            firstName :firstNameArr,
                            lastName:'test2',
                            obj :obj1[0],
                            telecom :"'123','456','test@gmail.com'"
                        };
                      scope.createNewUserInfo();
                      chai.expect(_userDataModel.userObject(scope.formInviteUserInfo.type).type).to.equal('Human');

                    });


                    it('createNewUserInfo when radio button is not patient or practioner ', function () {
                        firstNameArr =[];
                        firstNameArr.push('test1');
                        scope.formInviteUserInfo={
                            type:'Human',
                            firstName :firstNameArr,
                            lastName:'test2',
                            obj :obj3[0],
                            telecom :"'123','456','test@gmail.com'",
                            address:'address1'
                        };
                        scope.createNewUserInfo();
                        //chai.expect(scope.role[0].code[0].code).to.not.equal('practitioner');
                        chai.expect(scope.role).to.be.undefined;
                    });

                    it('calling next button ', function () {
                        firstNameArr =[];
                        firstNameArr.push('test1');
                        scope.formInviteUserInfo={
                            email:'test@gmail.com',
                            type:'Human',
                            firstName :firstNameArr,
                            lastName:'test2',
                            obj :obj1[0],
                            telecom :"'123','456','test@gmail.com'",
                            address:'address1'
                        };
                        scope.parentInviteUserForm.inviteUserForm ={$valid: true};
                        scope.searchingUserPanel=true;
                        scope.nextInviteUserForm();
                        chai.expect(scope.createNewUserInfo.calledOnce);
                    });

                });

                describe('Search user by EmailId ', function(){
                    it('should check the searched user exists', function(done) {
                        scope.formInviteUserInfo.emailId = "abc@ge.com";
                        var responseData1 = {
                            "resourceType": "Bundle",
                            "title": "List of User resources",
                            "id": null,
                            "entry": [
                                {
                                    "title": "ResourcesUser",
                                    "id": "a8c4620e-155d-4f0d-bd79-5143518363d4",
                                    "content": {
                                        "resourceType": "ResourcesUser",
                                        "name": {
                                            "use": "official",
                                            "family": [
                                                "Chalmers"
                                            ],
                                            "given": [
                                                "Peter",
                                                "James"
                                            ]
                                        },
                                        "externalId": [
                                            {
                                                "system": "IDM",
                                                "value": "5beddb02-5c04-4545-a14a-ab1e9bfd24ff"
                                            },
                                            {
                                                "system": "UOM",
                                                "value": "a8c4620e-155d-4f0d-bd79-5143518363d4"
                                            },
                                            {
                                                "_id": "username50@ge.com",
                                                "system": "urn:hc.ge.com/pfh/platform/useremail"
                                            }
                                        ],
                                        "role": [
                                            {
                                                "code": [
                                                    {
                                                        "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                        "code": "practitioner",
                                                        "display": "practitioner"
                                                    }
                                                ],
                                                "scopingOrganization": {
                                                    "reference": "organization/5"
                                                },
                                                "status": "active"
                                            },
                                            {
                                                "code": [
                                                    {
                                                        "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                        "code": "practitioner",
                                                        "display": "practitioner"
                                                    }
                                                ],
                                                "scopingOrganization": {
                                                    "reference": "organization/6"
                                                },
                                                "status": "active"
                                            }
                                        ],
                                        "managingOrganization": {
                                            "organization": {
                                                "reference": "organization/1"
                                            },
                                            "department": {
                                                "reference": "organization/3"
                                            },
                                            "division": {
                                                "reference": "organization/2"
                                            },
                                            "manager": {
                                                "reference": "user/1"
                                            },
                                            "jobTitle": {
                                                "coding": [
                                                    {
                                                        "system": "http://hl7.org/fhir/v3/AdministrativeUser",
                                                        "version": "1",
                                                        "code": "Manager",
                                                        "primary": true
                                                    }
                                                ],
                                                "text": "Manager"
                                            },
                                            "costCenter": "oxz123456",
                                            "employeeNumber": "ID_123445"
                                        },
                                        "address": [
                                            {
                                                "line": [
                                                    "3300 Washtenaw Avenue, Suite 227"
                                                ],
                                                "city": "Ann Arbor",
                                                "state": "MI",
                                                "zip": "48104",
                                                "country": "USA"
                                            }
                                        ],
                                        "telecom": [
                                            {
                                                "system": "phone",
                                                "value": "(+1) 734-677-7777"
                                            },
                                            {
                                                "system": "email",
                                                "value": "username1@ge.com"
                                            }
                                        ],
                                        "preferredLanguage": "English",
                                        "type": "Human",
                                        "registrationActivation": {
                                            "activationCode": "xyz123456",
                                            "invitationCode": "1234xyz",
                                            "invitedBy": {
                                                "reference": "user/1"
                                            }
                                        },
                                        "assignedResource": [
                                            {
                                                "reference": "applicationservice/6"
                                            }
                                        ],
                                        "status": "inactive",
                                        "comment": "This is an Hospital Practioner 1",
                                        "principalName": "username50@ge.com",
                                        "affiliatedOrganization": [
                                            {
                                                "reference": "organization/1"
                                            },
                                            {
                                                "reference": "organization/6"
                                            }
                                        ],
                                        "gender": {
                                            "coding": [
                                                {
                                                    "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                                    "code": "M",
                                                    "display": "Male"
                                                }
                                            ]
                                        },
                                        "acceptedAgreement": [
                                            {
                                                "agreementUri": "http://goodcare.org/devices/id",
                                                "accepted": false
                                            }
                                        ]
                                    }
                                }
                            ]
                        };
                        var responseData = responseData1.entry[0].content.principalName;
                        scope.searchUserByEmailId(scope.formInviteUserInfo.emailId);
                        searchUserByEmailIdDeferred.resolve(responseData);
                        scope.$digest();
                        chai.expect(scope.showMessageIfUserExists).to.equal(true);
                        done();
                    });
                    it('should check no valid data is returned and  searched user does not exists', function(done) {
                        scope.formInviteUserInfo.emailId = "abc@ge.com";
                        var responseData = {"resourceType": null,
                            "issue": [
                                {
                                    "severity": null,
                                    "type": null,
                                    "details": null
                                }
                            ]
                        };
                        scope.searchUserByEmailId(scope.formInviteUserInfo.emailId);
                       searchUserByEmailIdDeferred.reject(responseData);
                        scope.$digest();
                        chai.expect(responseData.issue[0].details).to.be.null;
                        done();
                    });
                    it('should check the searched user does not exists and valid data is returned', function(done) {
                        scope.formInviteUserInfo.emailId = "abc@ge.com";
                        var responseData = {
                            "resourceType": "OperationOutcome",
                            "issue": [
                                {
                                    "severity": "error",
                                    "type": "exception",
                                    "details": "NO_MATCHING_RECORDS_FOUND"
                                }
                            ]
                        };
                        scope.searchUserByEmailId(scope.formInviteUserInfo.emailId);
                        searchUserByEmailIdDeferred.reject(responseData);
                        scope.$digest();
                        chai.expect(responseData).to.not.be.null;
                        done();
                    });

                    it('should check the searched user does not exists and  matching records found', function(done) {
                        scope.formInviteUserInfo.emailId = "abc@ge.com";
                        var responseData = {
                            "resourceType": "OperationOutcome",
                            "issue": [
                                {
                                    "severity": "error",
                                    "type": "exception",
                                    "details": "MATCHING_RECORDS_FOUND"
                                }
                            ]
                        };
                        chai.expect(responseData).to.not.be.null;
                        scope.searchUserByEmailId(scope.formInviteUserInfo.emailId);
                        searchUserByEmailIdDeferred.reject(responseData);
                        scope.$digest();
                        chai.expect(scope.displayUser).to.be.undefined;
                        done();
                    });

                });

                describe('test when the user clicks cancel button',function(){
                    it('should check if the user is redirected to manage user state',function(){
                        scope.onClickCancelBtn();
                        chai.expect(_state.transitionTo).to
                            .have.been.calledOnce
                            .and.calledWith('manageUser.manageUserList');
                    });
                });

                describe('test the click is stopped if invalid form', function(){
                    it('should test the click is stopped if invalid form', function(){
                        scope.parentInviteUserForm.inviteUserForm= {$invalid:true};
                        scope.nextInviteUserForm(_event);
                        //except will come when email validation comes in picture
                    });

                    it('Click on add button to load the  searched user widget when the entered input is valid' ,function(){
                        scope.parentInviteUserForm.inviteUserForm= {$invalid:false};
                        scope.searchNewUserDetails();
                        chai.expect(scope.searchingUserPanel).to.equal(false);
                        chai.expect(scope.showSearchWidget).to.equal(true);

                    });
                    it('Click on add button to load the entered input is invalid ' ,function(){
                        scope.parentInviteUserForm.inviteUserForm= {$invalid:true};
                        scope.searchNewUserDetails();
                        chai.expect(scope.searchingUserPanel).to.equal(false);
                        chai.expect(scope.showSearchWidget).to.equal(true);

                    });


                    it('Click on Cancel button ' ,function(){
                        scope.cancelUserDetails();
                        chai.expect(scope.searchingUserPanel).to.equal(false);
                        chai.expect(scope.showSearchWidget).to.equal(true);

                    });

                });

            describe('getListOfSitesForLoggedInUserMe , when service of logged in user is called', function() {
                it('getListOfSitesForLoggedInUserMe', function(done){
                    var responseData ={
                        "resourceType": "Bundle",
                        "title": "Title ",
                        "id": null,
                        "entry": [
                            {
                                "title": null,
                                "id": null,
                                "content": {
                                    "resourceType": "ResourcesUser",
                                    "role": [
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/09227e3e-1d92-4921-a944-3d22e43ad14c",
                                                "display": "GE Healthcare RSNA 3"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/480f2c99-8056-4a1f-9202-1bc3c9339cf4",
                                                "display": "GE Healthcare RSNA 4"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/a985795c-fae2-40b7-afc6-1f37921d2048",
                                                "display": "GE Healthcare RSNA VNA"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/4fcae497-335e-48b7-a58d-2f2418daa271",
                                                "display": "GE Healthcare RSNA 2"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/42c5cb4f-7fcd-46fc-9a58-f87739338444",
                                                "display": "GE Healthcare San Ramon"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/90acd143-d416-4635-8fdd-9b73d2989449",
                                                "display": "GE Healthcare Waukesha"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/734aef80-acd0-4d57-95ea-fd7337c2aef6",
                                                "display": "hgh"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/c6265710-b1cc-4e9c-ae28-5e53097ec206",
                                                "display": "ge hc"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/32dc4aa9-53ca-4a2a-84c6-13be86171179",
                                                "display": "TestCC2"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/72903570-3253-4ed5-ba0e-afd3300c8063",
                                                "display": "DE7859_site"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/63be3097-7efa-4d38-84d3-c5979d723630",
                                                "display": "Sreeram"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/b77c95b4-2162-40d9-b42f-2b8de63ae47c",
                                                "display": "test"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/3a736f1b-e168-4069-97cd-059b45cb0d88",
                                                "display": "aaaaaaaaaaaaaa"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/134d5e84-e030-442c-8712-f6a344836082",
                                                "display": "bbbbbbbbbbbbbbbb"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/7e95bd8f-5771-456d-8d65-ab65488ea444",
                                                "display": "MDT Budapest"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/e6290268-aec7-422c-a1f1-b6b38f3472b2",
                                                "display": "MDT Budapest 2"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/bd35963c-8256-48e5-8649-690800779a81",
                                                "display": "MDT Budapest 3"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/a26e1ef6-39d9-4a48-92d2-4148a35db212",
                                                "display": "Site1"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/5c78b2d1-ce99-4c12-b694-2e5e186b4a95",
                                                "display": "MDT Bud 1"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/37a6f6ed-c1fe-4ebe-b541-59000b64b88a",
                                                "display": "MDT Bud 2"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/b5b87d0b-369d-4747-9d08-120731f12d42",
                                                "display": "hali"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/1206a7c7-f905-49f3-b9b8-7c00eca1acb9",
                                                "display": "hali1"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "administrator",
                                                    "display": "administrator"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "site/d9b2e0da-6e2c-44a7-921b-c5595b07dbb4",
                                                "display": "MDT Bud 2"
                                            },
                                            "status": "active"
                                        }
                                    ]
                                }
                            },
                            {
                                "title": null,
                                "id": "480f2c99-8056-4a1f-9202-1bc3c9339cf4",
                                "content": {
                                    "resourceType": "Organization",
                                    "text": {
                                        "status": "generated",
                                        "div": "<div>GEHC RSNA Site6</div>"
                                    },
                                    "name": "GE Healthcare RSNA 4",
                                    "type": {
                                        "coding": [
                                            {
                                                "system": "urn:hc.ge.com/pfh/platform/orgtype",
                                                "code": "SITE",
                                                "display": "site"
                                            }
                                        ]
                                    },
                                    "telecom": [
                                        {
                                            "system": "phone",
                                            "value": "6679098876",
                                            "use": "mobile"
                                        }
                                    ],
                                    "address": [
                                        {
                                            "line": [
                                                "540  W. Northwest Highway"
                                            ],
                                            "city": "Barrington",
                                            "state": "IL",
                                            "zip": "60010",
                                            "country": "US"
                                        }
                                    ],
                                    "partOf": {
                                        "reference": "organization/13dbd09a-98e7-46a0-8d4f-f0ff261d8411"
                                    }
                                }
                            },
                            {
                                "title": null,
                                "id": "09227e3e-1d92-4921-a944-3d22e43ad14c",
                                "content": {
                                    "resourceType": "Organization",
                                    "text": {
                                        "status": "generated",
                                        "div": "<div>adfsadfsda234123423bjkabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb1234 adfsadfsda234123423bjkabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb</div>"
                                    },
                                    "name": "GE Healthcare RSNA 3",
                                    "type": {
                                        "coding": [
                                            {
                                                "system": "urn:hc.ge.com/pfh/platform/orgtype",
                                                "code": "SITE",
                                                "display": "site"
                                            }
                                        ]
                                    },
                                    "telecom": [
                                        {
                                            "system": "phone",
                                            "value": "6679098876",
                                            "use": "mobile"
                                        }
                                    ],
                                    "address": [
                                        {
                                            "line": [
                                                "540  W. Northwest Highway",
                                                "valid"
                                            ],
                                            "city": "Barrington",
                                            "state": "IL",
                                            "zip": "!@#$%^^&&123",
                                            "country": "US"
                                        }
                                    ],
                                    "partOf": {
                                        "reference": "organization/13dbd09a-98e7-46a0-8d4f-f0ff261d8411"
                                    }
                                }
                            }
                        ]
                    };

                    var response =responseData;
                    scope.getListOfSitesForLoggedInUserMe();
                    listOfSitesForLoggedInUserDeferred.resolve(response);
                    scope.$digest();
                    scope.userSiteListArray = response.entry;
                    chai.expect(scope.userSiteListArray.length).to.equal(1);
                    done();
                });
                it('getListOfSitesForLoggedInUserMe Failure', function(done){
                    var responseData =[ {
                        resourceType: 'abc',
                        lastName:'test2',
                        telecom :"'123','456','test@gmail.com'",
                        address:'address1'
                    }];
                    scope.getListOfSitesForLoggedInUserMe();
                    listOfSitesForLoggedInUserDeferred.reject(responseData);
                    scope.$digest();
                    chai.expect(_log.info.calledOnce);
                    done();
                });
            });



            describe('getListOfAppServiceLevel2ForSite , when site is selected', function() {
                it('getListOfAppServiceLevel2ForSite', function(done){
                    var responseData = {
                        "data": {
                            "resourceType": "Bundle",
                            "title": "List of all Application Servcies",
                            "id": null,
                            "entry": [
                                {
                                    "title": null,
                                    "id": "1365fec6-a6a8-49a2-8772-5f342cca724f",
                                    "content": {
                                        "resourceType": "ResourcesApplicationService",
                                        "type": "hl7-send",
                                        "name": "CPACS1",
                                        "endpoint": "1365fec6-a6a8-49a2-8772-5f342cca724f",
                                        "gateway": {
                                            "reference": "device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"
                                        },
                                        "owner": {
                                            "reference": "site/df5f2880-cc71-4401-8868-d85509eae041",
                                            "display": "YKTEST1"
                                        },
                                        "networkAddress": {
                                            "ip": "111.11.11.1111",
                                            "entityName": "AE_PACS",
                                            "port": 8080
                                        }
                                    }
                                },
                                {
                                    "title": null,
                                    "id": "bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e",
                                    "content": {
                                        "resourceType": "ResourcesApplicationService",
                                        "type": "dicom-send",
                                        "name": "CPACS",
                                        "endpoint": "bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e",
                                        "gateway": {
                                            "reference": "device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"
                                        },
                                        "owner": {
                                            "reference": "site/df5f2880-cc71-4401-8868-d85509eae041",
                                            "display": "YKTEST1"
                                        },
                                        "networkAddress": {
                                            "ip": "111.11.11.1111",
                                            "entityName": "AE_PACS",
                                            "port": 8080
                                        }
                                    }
                                },
                                {
                                    "title": null,
                                    "id": "fa5a4162-fcfd-4e36-8a25-89df29f40c3a",
                                    "content": {
                                        "resourceType": "ResourcesApplicationService",
                                        "type": "dicom-query-retrieve",
                                        "name": "CPACS",
                                        "endpoint": "fa5a4162-fcfd-4e36-8a25-89df29f40c3a",
                                        "gateway": {
                                            "reference": "device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"
                                        },
                                        "owner": {
                                            "reference": "site/df5f2880-cc71-4401-8868-d85509eae041",
                                            "display": "YKTEST1"
                                        },
                                        "networkAddress": {
                                            "ip": "111.11.11.1111",
                                            "entityName": "AE_PACS",
                                            "port": 8080
                                        }
                                    }
                                }
                            ]
                        },
                        "status": 200
                    };

                    var siteObjId= {
                        "check": true,
                        "obj": {
                            "code": [
                                {
                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                    "code": "administrator",
                                    "display": "administrator"
                                }
                            ],
                            "scopingOrganization": {
                                "reference": "site/09227e3e-1d92-4921-a944-3d22e43ad14c",
                                "display": "GE Healthcare RSNA 3"
                            },
                            "status": "active"
                        }
                    }
                   var selectedStatus ={
                       "check": true,
                       "obj": {
                           "content": {
                               "resourceType": "Organization",
                               "name": "YKSITE1"
                           }
                       }
                   } ;
                    scope.getListOfAppServiceLevel2ForSite(siteObjId,selectedStatus);
                    deferredAppServicesLevel2.resolve(responseData);
                    scope.$digest();
                    chai.expect(scope.applicationList.length).to.equal(3);
                    done();
                });
                it('getListOfAppServiceLevel2ForSite Failure', function(done){
                    var responseData = {
                        "data": {
                            "resourceType": "Bundle",
                            "title": "List of all Application Servcies",
                            "id": null,
                            "entry": [
                                {
                                    "title": null,
                                    "id": "1365fec6-a6a8-49a2-8772-5f342cca724f",
                                    "content": {
                                        "resourceType": "ResourcesApplicationService",
                                        "type": "hl7-send",
                                        "name": "CPACS1",
                                        "endpoint": "1365fec6-a6a8-49a2-8772-5f342cca724f",
                                        "gateway": {
                                            "reference": "device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"
                                        },
                                        "owner": {
                                            "reference": "site/df5f2880-cc71-4401-8868-d85509eae041",
                                            "display": "YKTEST1"
                                        },
                                        "networkAddress": {
                                            "ip": "111.11.11.1111",
                                            "entityName": "AE_PACS",
                                            "port": 8080
                                        }
                                    }
                                },
                                {
                                    "title": null,
                                    "id": "bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e",
                                    "content": {
                                        "resourceType": "ResourcesApplicationService",
                                        "type": "dicom-send",
                                        "name": "CPACS",
                                        "endpoint": "bcd6c548-f152-4bf0-8c2c-a99e7c1bcd6e",
                                        "gateway": {
                                            "reference": "device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"
                                        },
                                        "owner": {
                                            "reference": "site/df5f2880-cc71-4401-8868-d85509eae041",
                                            "display": "YKTEST1"
                                        },
                                        "networkAddress": {
                                            "ip": "111.11.11.1111",
                                            "entityName": "AE_PACS",
                                            "port": 8080
                                        }
                                    }
                                },
                                {
                                    "title": null,
                                    "id": "fa5a4162-fcfd-4e36-8a25-89df29f40c3a",
                                    "content": {
                                        "resourceType": "ResourcesApplicationService",
                                        "type": "dicom-query-retrieve",
                                        "name": "CPACS",
                                        "endpoint": "fa5a4162-fcfd-4e36-8a25-89df29f40c3a",
                                        "gateway": {
                                            "reference": "device/d091c801-7d7e-4f2b-ac83-0dc3a69446c6"
                                        },
                                        "owner": {
                                            "reference": "site/df5f2880-cc71-4401-8868-d85509eae041",
                                            "display": "YKTEST1"
                                        },
                                        "networkAddress": {
                                            "ip": "111.11.11.1111",
                                            "entityName": "AE_PACS",
                                            "port": 8080
                                        }
                                    }
                                }
                            ]
                        },
                        "status": 200
                    };

                    var siteObjId= {
                        "check": true,
                        "obj": {
                            "code": [
                                {
                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                    "code": "administrator",
                                    "display": "administrator"
                                }
                            ],
                            "scopingOrganization": {
                                "reference": "site/09227e3e-1d92-4921-a944-3d22e43ad14c",
                                "display": "GE Healthcare RSNA 3"
                            },
                            "status": "active"
                        }
                    }
                    var selectedStatus ={
                        "check": true,
                        "obj": {
                            "content": {
                                "resourceType": "Organization",
                                "name": "YKSITE1"
                            }
                        }
                    } ;
                    scope.getListOfAppServiceLevel2ForSite(siteObjId,selectedStatus);
                    deferredAppServicesLevel2.reject(responseData);
                    scope.$digest();
                    chai.expect(_log.info.calledOnce);
                    done();
                });
            });


            it('refreshAppSerView , when object is selected or checked', function(){
              var selectedStatus ={
                    "check": true,
                    "obj": {
                        "code": [
                            {
                                "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                "code": "administrator",
                                "display": "administrator"
                            }
                        ],
                        "scopingOrganization": {
                            "reference": "site/09227e3e-1d92-4921-a944-3d22e43ad14c",
                            "display": "GE Healthcare RSNA 3"
                        },
                        "status": "active"
                    }
                } ;
                scope.refreshAppSerView(selectedStatus);
                chai.expect(scope.getListOfAppServiceLevel2ForSite.calledOnce);
            });


            it('refreshAppSerView , when status is false', function(){
                var selectedStatus ={
                    "check": false,
                    "obj": {
                        "code": [
                            {
                                "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                "code": "administrator",
                                "display": "administrator"
                            }
                        ],
                        "scopingOrganization": {
                            "reference": "site/09227e3e-1d92-4921-a944-3d22e43ad14c",
                            "display": "GE Healthcare RSNA 3"
                        },
                        "status": "active"
                    }
                } ;

                scope.refreshAppSerView(selectedStatus);
                chai.expect(scope.responseObj).to.be.undefined;
            });
              it('previous button click', function(){
                scope.prevUserFrom();
                chai.expect(scope.inviteBtn).to.equal(false);
              });

              it('user check and uncheck the sites',function(){
                scope.selectedSitesForNewUser =[{"title":null,"id":"870a98ff-0628-4bbf-bd9c-f31b9a4dce91","content":{"resourceType":"Organization","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"Concord Medical Center"}]}}}];
                var selectedObj={"check":false,"obj":{"code": [{
                        "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                        "code": "administrator",
                        "display": "administrator"
                    }
                ],
                    "scopingOrganization": {
                        "reference": "site/09227e3e-1d92-4921-a944-3d22e43ad14c",
                        "display": "GE Healthcare RSNA 3"
                    },
                    "status": "active"}};
                scope.updateUserObj(selectedObj);
                chai.expect(scope.updateUserObj).to.have.length(1);
              });  it('user check and uncheck the sites ids are match',function(){
                  scope.selectedSitesForNewUser =[{"title":null,"id":"5fa7a5c1-8fdb-49ce-90c4-f8f9eadbd4cd","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>GE Healthcare  San Ramon Site 1</div>"},"name":"GE Healthcare San Ramon","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"site"}]},"telecom":[{"system":"phone","value":"6679098876","use":"mobile"}],"address":[{"line":["540  W. Northwest Highway"],"city":"Barrington","state":"IL","zip":"60010","country":"US"}],"partOf":{"reference":"organization/eb19e488-f81d-4d8a-b743-73bdf63de914"}},"role":{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"HealthcareProvider"}],"scopingOrganization":{"reference":"site/350143e8-80b3-47df-9411-f90befae04e3","display":"GE Healthcare San Ramon"},"status":"active"}}];
                  var selectedObj={"check":false,"obj":{"title":null,"id":"5fa7a5c1-8fdb-49ce-90c4-f8f9eadbd4cd","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>GEHC RSNA Site3</div>"},"name":"GE Healthcare RSNA VNA","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"site"}]},"telecom":[{"system":"phone","value":"6679098876","use":"mobile"}],"address":[{"line":["540  W. Northwest Highway"],"city":"Barrington","state":"IL","zip":"60010","country":"US"}],"partOf":{"reference":"organization/eb19e488-f81d-4d8a-b743-73bdf63de914"}},"role":{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"HealthcareProvider"}],"scopingOrganization":{"reference":"site/5fa7a5c1-8fdb-49ce-90c4-f8f9eadbd4cd","display":"GE Healthcare RSNA VNA"},"status":"active"}}};
                  scope.updateUserObj(selectedObj);
                  chai.expect(scope.updateUserObj).to.have.length(1);
                });

                it('user check and uncheck the sites ids are match',function(){
                   scope.selectedSitesForNewUser =[{"title":null,"id":"5fa7a5c1-8fdb-49ce-90c4-f8f9eadbd4cd","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>GE Healthcare  San Ramon Site 1</div>"},"name":"GE Healthcare San Ramon","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"site"}]},"telecom":[{"system":"phone","value":"6679098876","use":"mobile"}],"address":[{"line":["540  W. Northwest Highway"],"city":"Barrington","state":"IL","zip":"60010","country":"US"}],"partOf":{"reference":"organization/eb19e488-f81d-4d8a-b743-73bdf63de914"}},"role":{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"HealthcareProvider"}],"scopingOrganization":{"reference":"site/350143e8-80b3-47df-9411-f90befae04e3","display":"GE Healthcare San Ramon"},"status":"active"}}];
                   var selectedObj={"check":true,"obj":{"title":null,"id":"5fa7a5c1-8fdb-49ce-90c4-f8f9eadbd4cd","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>GEHC RSNA Site3</div>"},"name":"GE Healthcare RSNA VNA","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"site"}]},"telecom":[{"system":"phone","value":"6679098876","use":"mobile"}],"address":[{"line":["540  W. Northwest Highway"],"city":"Barrington","state":"IL","zip":"60010","country":"US"}],"partOf":{"reference":"organization/eb19e488-f81d-4d8a-b743-73bdf63de914"}},"role":{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"HealthcareProvider"}],"scopingOrganization":{"reference":"site/5fa7a5c1-8fdb-49ce-90c4-f8f9eadbd4cd","display":"GE Healthcare RSNA VNA"},"status":"active"}}};
                   scope.updateUserObj(selectedObj);
                   chai.expect(scope.updateUserObj).to.have.length(1);
                 });
                it('user check and uncheck the sites checked is false and id not matching ',function(){
                  scope.selectedSitesForNewUser =[{"title":null,"id":"870a98ff-0628-4bbf-bd9c-f31b9a4dce92","content":{"resourceType":"Organization","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"Concord Medical Center"}]}}}];
                  var selectedObj={"check":false,"obj":{"code": [
                      {
                          "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                          "code": "administrator",
                          "display": "administrator"
                      }
                  ],
                      "scopingOrganization": {
                          "reference": "site/09227e3e-1d92-4921-a944-3d22e43ad14c",
                          "display": "GE Healthcare RSNA 3"
                      },
                      "status": "active"}};
                  scope.updateUserObj(selectedObj);
                  chai.expect(scope.updateUserObj).to.have.length(1);
                });

                it('invite user successfully', function(done){
                scope.selectedSitesForNewUser =[{"title":null,"id":"8f24e3e9-0cd4-4b10-b61d-2de4d4374a1a","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>This is a test site</div>"},"name":"YKSITE3","address":[{"line":["3354, uuy","yyu"],"city":"BSD","state":"ALABAMA","zip":"66789","country":"United States of America"}],"partOf":{"reference":"organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}}},{"title":null,"id":"8f24e3e9-0cd4-4b10-b61d-2de4d4374a1a","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>This is a test site</div>"},"name":"YKSITE3","address":[{"line":["3354, uuy","yyu"],"city":"BSD","state":"ALABAMA","zip":"66789","country":"United States of America"}],"partOf":{"reference":"undefined"}}},{"title":null,"id":"8f24e3e9-0cd4-4b10-b61d-2de4d4374a1a","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>This is a test site</div>"},"name":"YKSITE3","address":[{"line":["3354, uuy","yyu"],"city":"BSD","state":"ALABAMA","zip":"66789","country":"United States of America"}],"partOf":{"reference":"organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}}}];
                scope.affiliatedOrganizationObj = [{"reference": "organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}]  ;

                var selectedItem= [{"siteName":"GE Healthcare San Ramon","siteId":"350143e8-80b3-47df-9411-f90befae04e3","appServiceList":[{"id":"074b1d9e-f9ee-45ef-8aec-05cc81cd9181","name":"EA San Ramon","serviceType":"dicom","capabilityArray":["send"],"capabilityArrayJSON":[{"name":"send","checkbox":true}]},{"id":"468afae6-3074-4da5-9115-613743047e35","name":"PACS San Ramon","serviceType":"dicom","capabilityArray":["send","query-retrieve"],"capabilityArrayJSON":[{"name":"send"},{"name":"query-retrieve"}]}]}];
                
                appServiceObj.setSelectedAppServices(selectedItem);
                scope.userObjectValue={"resourceType":"ResourcesUser","principalName":"aa@ge","type":"Human","name":{"use":"official","family":"John","given":["Peter","John"]},"telecom":[{"system":"phone","value":"778888","use":"mobile"},{"system":"phone","value":"985757","use":"home"},{"system":"email","value":"aa@ge","use":"work"}],"role":[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"patient","display":"Patient"}],"scopingOrganization":{"reference":"site/8f24e3e9-0cd4-4b10-b61d-2de4d4374a1a","display":"YKSITE3"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"patient","display":"Patient"}],"scopingOrganization":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE1"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"patient","display":"Patient"}],"scopingOrganization":{"reference":"site/facfd68e-2d7d-4409-a333-3dce6324ad2e","display":"YKSITE2"},"status":"active"}],"address":[{"line":[""],"city":"","state":"","zip":"","country":""}],"preferredLanguage":"English","gender":{"coding":[{"system":"http://hl7.org/fhir/v3/AdministrativeGender","code":"M","display":"Male"}]},"acceptedAgreement":[{"accepted":"false","agreementUri":"http://goodcare.org/devices/id"}],"registrationActivation":{"activationCode":"","invitationCode":"","invitedBy":{"reference":"user/1"},"sites":[{"reference":"site/8f24e3e9-0cd4-4b10-b61d-2de4d4374a1a","display":"YKSITE3"},{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE1"},{"reference":"site/facfd68e-2d7d-4409-a333-3dce6324ad2e","display":"YKSITE2"}]},"managingOrganization":{"costCenter":"","division":{"reference":"organization/2"},"department":{"reference":"organization/3"},"manager":{"reference":"user/1"},"jobTitle":{"text":"Manager","coding":[{"system":"","primary":"","code":"","version":""}]},"employeeNumber":""},"affiliatedOrganization":[{"reference":"organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}],"assignedResource":[],"status":"inactive","comment":"Peter comments"};
                scope.inviteUserViaEmail();
                var response = {id:""};
                createUserDeferred.resolve(response);
                scope.$digest();
                done();
                });

                it('invite user failure ', function(done){
                scope.selectedSitesForNewUser =[{"title":null,"id":"8f24e3e9-0cd4-4b10-b61d-2de4d4374a1a","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>This is a test site</div>"},"name":"YKSITE3","address":[{"line":["3354, uuy","yyu"],"city":"BSD","state":"ALABAMA","zip":"66789","country":"United States of America"}],"partOf":{"reference":"organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}}},{"title":null,"id":"8f24e3e9-0cd4-4b10-b61d-2de4d4374a1a","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>This is a test site</div>"},"name":"YKSITE3","address":[{"line":["3354, uuy","yyu"],"city":"BSD","state":"ALABAMA","zip":"66789","country":"United States of America"}],"partOf":{"reference":"undefined"}}},{"title":null,"id":"8f24e3e9-0cd4-4b10-b61d-2de4d4374a1a","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>This is a test site</div>"},"name":"YKSITE3","address":[{"line":["3354, uuy","yyu"],"city":"BSD","state":"ALABAMA","zip":"66789","country":"United States of America"}],"partOf":{"reference":"organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}}}];
                scope.affiliatedOrganizationObj = [{"reference": "organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}]  ;

                var selectedItem= [{"siteName":"GEHealthcareSTO-I","appServiceList":[{"capabilities":["send","retrieve"],"capabilitie":[{"name":"send","id":"2287ec33-3a6b-4654-85e3-81d4389ea8d8","appSerName":"EDGE","checkbox":true},{"name":"retrieve","id":"81d4389ea8d8-3a6b-4654-85e3-2287ec33","appSerName":"EDGE"}],"name":"EDGE","serviceType":"dicom"},{"capabilities":["send","retrieve"],"capabilitie":[{"name":"send","id":"2287ec33-3a6b-4654-85e3-81d4389ea8d8","appSerName":"EDGE"},{"name":"retrieve","id":"81d4389ea8d8-3a6b-4654-85e3-2287ec33","appSerName":"EDGE"}],"name":"EDGE","serviceType":"HL7"},{"capabilities":["send","retrieve"],"capabilitie":[{"name":"send","id":"2287ec33-3a6b-4654-85e3-81d4389ea8d8","appSerName":"CPACS"},{"name":"retrieve","id":"81d4389ea8d8-3a6b-4654-85e3-2287ec33","appSerName":"CPACS"}],"name":"CPACS","serviceType":"HL7"}]}];
                appServiceObj.setSelectedAppServices(selectedItem);
                scope.userObjectValue={"resourceType":"ResourcesUser","principalName":"aa@ge","type":"Human","name":{"use":"official","family":"John","given":["Peter","John"]},"telecom":[{"system":"phone","value":"778888","use":"mobile"},{"system":"phone","value":"985757","use":"home"},{"system":"email","value":"aa@ge","use":"work"}],"role":[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"patient","display":"Patient"}],"scopingOrganization":{"reference":"site/8f24e3e9-0cd4-4b10-b61d-2de4d4374a1a","display":"YKSITE3"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"patient","display":"Patient"}],"scopingOrganization":{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE1"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"patient","display":"Patient"}],"scopingOrganization":{"reference":"site/facfd68e-2d7d-4409-a333-3dce6324ad2e","display":"YKSITE2"},"status":"active"}],"address":[{"line":[""],"city":"","state":"","zip":"","country":""}],"preferredLanguage":"English","gender":{"coding":[{"system":"http://hl7.org/fhir/v3/AdministrativeGender","code":"M","display":"Male"}]},"acceptedAgreement":[{"accepted":"false","agreementUri":"http://goodcare.org/devices/id"}],"registrationActivation":{"activationCode":"","invitationCode":"","invitedBy":{"reference":"user/1"},"sites":[{"reference":"site/8f24e3e9-0cd4-4b10-b61d-2de4d4374a1a","display":"YKSITE3"},{"reference":"site/df5f2880-cc71-4401-8868-d85509eae041","display":"YKSITE1"},{"reference":"site/facfd68e-2d7d-4409-a333-3dce6324ad2e","display":"YKSITE2"}]},"managingOrganization":{"costCenter":"","division":{"reference":"organization/2"},"department":{"reference":"organization/3"},"manager":{"reference":"user/1"},"jobTitle":{"text":"Manager","coding":[{"system":"","primary":"","code":"","version":""}]},"employeeNumber":""},"affiliatedOrganization":[{"reference":"organization/81901f7c-c5fe-48a5-977b-2b5509d595d0"}],"assignedResource":[],"status":"inactive","comment":"Peter comments"};
                scope.inviteUserViaEmail();
                var response = {id:""};
                createUserDeferred.reject(response);
                scope.$digest();
                done();
                });

        });
    });
