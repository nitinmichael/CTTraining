define(['angular',
        'angular-mocks',
        'orgMgmnt/services/groupService'],
    function () {
        'use strict';

        describe('Test Group Service', function () {
            var groupMgmtService, $httpBackend, q, defer, uomServiceUrl, _masterDataModel, groupObj;
            before(function () {
                groupObj =
                {
                    "resourceType": "ResourcesUserGroup",
                    "member": [
                        {
                            "user": {
                                "reference": "user/3cc1f86d-4c81-46a4-a7f2-76c60a2c84b1",
                                "display": "Bradley Casper"
                            },
                            "role": "administrator"
                        },
                        {
                            "user": {
                                "reference": "user/0be3ec02-885f-4ef0-935b-51c5ecfc6786",
                                "display": "Peter"
                            },
                            "role": "owner"
                        }
                    ],
                    "managingOrganization": {
                        "reference": "organization/113de399-6a6a-4c4f-b292-f57b6f62cf14",
                        "display": "Kaiser"
                    },
                    "name": "Diabetes MDT Group",
                    "quantity": 2,
                    "type": "mdt",
                    "accessType": "public",
                    "active": true
                };
            });

            beforeEach(function() {
                module(function($provide){
                    $provide.service('masterDataModel', function(){
                        this.getGatewayUrl= sinon.spy();
                    });
                });
                module('Orgmanagement.Services.GroupService');
            });

            beforeEach(inject(function (_groupMgmtService_, _$httpBackend_, _$q_, masterDataModel) {
                groupMgmtService = _groupMgmtService_;
                $httpBackend = _$httpBackend_;
                q = _$q_;
                _masterDataModel = masterDataModel;
                defer = q.defer();
                uomServiceUrl = _masterDataModel.getGatewayUrl();
            }));
            describe('Get list of groups service', function(){
                it("checks getAllGroups services is called successfully with only userrole param", function(){
                    var userrole = 'owner',
                        url = uomServiceUrl+"/v1/group/_search?userrole="+userrole;
                    $httpBackend.expectGET(url).respond(200);
                    defer.resolve('7af61818-274f-4994-9352-3a5b274ae68b');
                    groupMgmtService.getAllGroups(userrole);
                });

                it("checks getAllGroups services is called successfully with all the parameters", function(){
                    var userrole = 'owner',
                        siteId = '113de399-6a6a-4c4f-b292-f57b6f62cf14',
                        selectedGrpType = 'all',
                        selectedActivityStatus = 'inactive',
                        url = uomServiceUrl+"/v1/group/_search?userrole="+userrole+'&siteid='+siteId+'&type='+selectedGrpType+'&status='+selectedActivityStatus;
                    $httpBackend.expectGET(url).respond(200);
                    defer.resolve('7af61818-274f-4994-9352-3a5b274ae68b');
                    groupMgmtService.getAllGroups(userrole, siteId, selectedGrpType, selectedActivityStatus);
                });

                it("checks getAllGroups services is not called successfully", function(){
                    var userrole = 'owner',
                        url = uomServiceUrl+"/v1/group/_search?userrole="+userrole;
                    $httpBackend.expectGET(url).respond(400);
                    defer.reject();
                    groupMgmtService.getAllGroups(userrole);
                });
            });

            describe('Deactivate group service', function(){
                it("checks toggleGroupActivityStatus services is called successfully", function(){
                    var groupObj = {content:{active:true}};
                    var url = uomServiceUrl+ "/v1/group/"+groupObj.id+"/status";
                    $httpBackend.expectPATCH(url).respond(200);
                    defer.resolve();
                    groupMgmtService.toggleGroupActivityStatus(groupObj);
                });

                it("checks toggleGroupActivityStatus services is not called successfully", function(){
                    var groupObj = {content:{active:true}};
                    var url = uomServiceUrl+ "/v1/group/"+groupObj.id+"/status";
                    $httpBackend.expectPATCH(url).respond(400);
                    defer.reject();
                    groupMgmtService.toggleGroupActivityStatus(groupObj);
                });
            });
            describe('Create Group service', function(){
                it("checks Create Group service is called successfully", function(){
                    var url = uomServiceUrl+"/v1/group";
                    $httpBackend.expectPOST(url,groupObj).respond(200);
                    defer.resolve();
                    groupMgmtService.createGroup(groupObj);
                });

                it("checks Create Group service is not called successfully", function(){
                    var url = uomServiceUrl+"/v1/group";
                    $httpBackend.expectPOST(url,groupObj).respond(400);
                    defer.reject();
                    groupMgmtService.createGroup(groupObj);
                });
            });

            describe('Update Group service', function(){
                var id ='1';
                it("checks Update Group service is called successfully", function(){
                    var url = uomServiceUrl+ "/v1/group/"+id+"/member";
                    $httpBackend.expectPUT(url,groupObj).respond(200);
                    defer.resolve();
                    groupMgmtService.updateGroupMembers(groupObj,id);
                });

                it("checks Update Group service is not called successfully", function(){
                    var url = uomServiceUrl+ "/v1/group/"+id+"/member";
                    $httpBackend.expectPUT(url,groupObj).respond(400);
                    defer.reject();
                    groupMgmtService.updateGroupMembers(groupObj,id);
                });
            });

            describe('Get Group Details service', function(){
                var id="1";
                it("checks Group Details service is called successfully", function(){
                    var url = uomServiceUrl+ "/v1/group/"+id+"?filterParam=level2";
                    $httpBackend.expectGET(url).respond(200);
                    defer.resolve();
                    groupMgmtService.getGroupDetails(id);
                });

                it("checks Group Details service is not called successfully", function(){
                    var url = uomServiceUrl+ "/v1/group/"+id+"?filterParam=level2";
                    $httpBackend.expectGET(url).respond(400);
                    defer.reject();
                    groupMgmtService.getGroupDetails(id);
                });
            });

            describe('Get User Details service', function(){
                var id="1";
                it("checks User Details service is called successfully", function(){
                    var url = uomServiceUrl+ "/v1/user/"+id;
                    $httpBackend.expectGET(url).respond(200);
                    defer.resolve();
                    groupMgmtService.getUserDetails(id);
                });

                it("checks User Details service is not called successfully", function(){
                    var url = uomServiceUrl+ "/v1/user/"+id;
                    $httpBackend.expectGET(url).respond(400);
                    defer.reject();
                    groupMgmtService.getUserDetails(id);
                });
            });

            describe('Update Group Details service', function(){
                var id ='1';
                it("checks Update Group Details service is called successfully", function(){
                    var url = uomServiceUrl+ "/v1/group/"+id;
                    $httpBackend.expectPUT(url,groupObj).respond(200);
                    defer.resolve();
                    groupMgmtService.updateGroupDetails(groupObj,id);
                });

                it("checks Update Group Details service is not called successfully", function(){
                    var url = uomServiceUrl+ "/v1/group/"+id;
                    $httpBackend.expectPUT(url,groupObj).respond(400);
                    defer.reject();
                    groupMgmtService.updateGroupDetails(groupObj,id);
                });
            });

            describe('Validate Group Name service', function(){
                it("checks Validate Group Name service is called successfully", function(){
                    var url = uomServiceUrl+"/v1/group?validateOnly=true";
                    $httpBackend.expectPOST(url,groupObj).respond(200);
                    defer.resolve();
                    groupMgmtService.isValidGroupName(groupObj);
                });

                it("checks Validate Group Name service is not called successfully", function(){
                    var url = uomServiceUrl+"/v1/group?validateOnly=true";
                    $httpBackend.expectPOST(url,groupObj).respond(400);
                    defer.reject();
                    groupMgmtService.isValidGroupName(groupObj);
                });
            });

            describe('Set Logged In User Details service', function(){
                it("checks Set Logged In User Details service is called successfully", function(){
                    var url = uomServiceUrl+"/v1/group/loggedinUser/details";
                    $httpBackend.expectGET(url).respond(200);
                    defer.resolve();
                    groupMgmtService.setLoggedInUserDetails();
                });

                it("checks Set Logged In User Details service is not called successfully", function(){
                    var url = uomServiceUrl+"/v1/group/loggedinUser/details";
                    $httpBackend.expectGET(url).respond(400);
                    defer.reject();
                    groupMgmtService.setLoggedInUserDetails();
                });

            });

            describe('Get Multi User Details service', function(){
                var members =  [
                    {
                        "id": "891a1d75-79cf-49d6-902f-3ccab357e22f",
                        "display": "Peter cook"
                    }
                ];
                it("checks Multi User Details service is called successfully", function(){
                    var url = uomServiceUrl+ "/v1/user/"+members[0].id;
                    $httpBackend.expectGET(url).respond(200);
                    defer.resolve();
                    groupMgmtService.getMultipleUsersDetails(members);
                });

                it("checks Multi User Details service is not called successfully", function(){
                    var url = uomServiceUrl+ "/v1/user/"+members[0].id;
                    $httpBackend.expectGET(url).respond(400);
                    defer.reject();
                    groupMgmtService.getMultipleUsersDetails(members);
                });
            });

        describe("Group list depending upon text given", function(){
            it("get group list from server for typeahead, success", function(){
                var searchParam ='test',
                    GROUP_SEARCH_URL = uomServiceUrl + '/v2/group/_search?name=test',
                    res=JSON.parse(JSON.stringify({data: "", status: 200,statusText: "OK"}));
                    
                $httpBackend.expectGET(GROUP_SEARCH_URL).respond(200);
                defer.resolve(res);
                groupMgmtService.findGroup(searchParam);
            });


            it("get organization list from server for typeahead, failure", function(){
                var searchParam ='test',
                    GROUP_SEARCH_URL = uomServiceUrl + '/v2/group/_search?name=test';
                    
                $httpBackend.expectGET(GROUP_SEARCH_URL).respond(400);
                defer.reject();
                groupMgmtService.findGroup(searchParam);
            });
        });
            afterEach(function () {
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });
    });
