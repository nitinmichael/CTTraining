define(['angular'], function(ng) {
    return ng.module('viewportParameterStorage', []).constant('viewportParameterStorageMock', {

        $get: function() {
            var that = this;
            that.currentConf = null;
            that.patientInfo = {
                id: '1234',
                title: 'Mr.',
                name: 'Jack Travis',
                age: '70',
                dob: '16/12/1944',
                gender: 'male'
            };

            that.studyInfo = {
                studyDescription: 'My Study desc',
                studyDate: '2015-11-27'
            };

            return {
                'ViewportParameterObj': function() {
                    var vpParmObj = this;
                    this.seriesUid = undefined;
                    this.renderingUrl = undefined;
                    this.annotationUrl = undefined;
                    this.ports = [{
                        index: 0,
                        menu: false,
                        cssLayout: 'twoByTwo',
                        usePredefinedLayout: true,
                        getId: function() {
                            return '0';
                        }
                    }, {
                        index: 1,
                        menu: false,
                        cssLayout: 'twoByTwo',
                        usePredefinedLayout: true,
                        getId: function() {
                            return '1';
                        }
                    }, {
                        index: 2,
                        menu: false,
                        cssLayout: 'twoByTwo',
                        usePredefinedLayout: true,
                        getId: function() {
                            return '2';
                        }
                    }, {
                        index: 3,
                        menu: false,
                        cssLayout: 'twoByTwo',
                        usePredefinedLayout: true,
                        getId: function() {
                            return '3';
                        }
                    }];
                    this.setSeriesUid = function(newSeriesUid) {
                        vpParmObj.seriesUid = newSeriesUid;
                    };
                    this.setRenderingUrl = function(newRenderingUrl) {
                        vpParmObj.renderingUrl = newRenderingUrl;
                    };
                    this.setAnnotationUrl = function(newAnnotationUrl) {
                        vpParmObj.annotationUrl = newAnnotationUrl;
                    };
                    this.setPorts = function(ports) {
                        vpParmObj.ports = ports;
                    };
                },
                'isViewportParameterObj': function() {},
                'setGroups': function(groups) {},
                'getGroups': sinon.stub(),
                'getGroup': sinon.stub().returns({
                    groupID: 'Group2',
                    seriesUID: 'UUID-2',
                    saveState: false,
                    secondaryCapture: true,
                    imageType: '2D',
                    modality: 'CT'
                }),
                'setCurrentConfiguration': function(config) {
                    that.currentConf = config;
                },
                'getCurrentConfiguration': function(config) {
                    return that.currentConf;
                },
                'getPatientInfo': function() {
                    return that.patientInfo;
                },
                'getStudyInfo': function() {
                    return that.studyInfo;
                },
                'setStudyInfo': function(study) {}
            };
        }
    });
});