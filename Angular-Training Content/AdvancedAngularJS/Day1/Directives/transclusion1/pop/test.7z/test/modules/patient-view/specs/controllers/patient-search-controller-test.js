/*
 *  patient-search-controller-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Eduardo Mioto<eduardo.mioto@ge.com>
 */

/**
 * Spec file for Patient Search controller module
 */

define([
    'postal',
    'angular',
    'angular-mocks',
    'patient-view/modules/patient-search/controllers/patient-search-controller'
],
function (postal, ng) {
    'use strict';

    var scope;
    var controller;
    var $rootScope;
    var $q;
    var patientManagementService;
    var uomService;
    var uomDeferred;

    var $Endpoint;

    var NSerrorMsgSpy;

    describe('Patient Search Controller Test Suite::', function () {

        var deferred;
        var patientSearchService;
        var NS;
        var postalMock;
        var Patient;
        var unsubscribe;

        beforeEach(function () {
            ng.module('Platform.Services.NotificationService', []);

            module(function ($provide) {
                $provide.value('translateFilter', function (value) {
                    return value;
                });

                $provide.service('NotificationService', function () {
                    this.addSuccessMessage = function (msg) {
                        console.log("Success message: ", msg);
                    };
                    this.addErrorMessage = function (msg) {
                        console.log("Error message: ", msg);
                    };
                });
            });
        });

        beforeEach(module('cloudav.patient-view.patient-search', function ($provide) {
            $provide.service('$Endpoint', function() {
                this.getEndpoint = function (key) {
                    return 'http://fakeendpoint.com';
                };
             });
        }));
        
        
        // Initialize the scope and controller variables
        beforeEach(inject(function (_$rootScope_, $controller, _$q_, PatientManagementService, PatientSearchService, UOMService, NotificationService, _Patient_) {
            $rootScope = _$rootScope_;
            scope = $rootScope.$new();
            controller = $controller;
            NS = NotificationService;
            Patient = _Patient_;

            patientManagementService = PatientManagementService;
            patientSearchService = PatientSearchService;
            uomService = UOMService;

            $q = _$q_;
            
            uomDeferred = $q.defer();
            sinon.stub(UOMService, 'getMyApplicationServices').returns(uomDeferred.promise);

            deferred = $q.defer();
            sinon.stub(PatientSearchService, 'search').returns(deferred.promise);

            postalMock = sinon.mock(postal);
            NSerrorMsgSpy = sinon.spy(NS, 'addErrorMessage');

            unsubscribe = sinon.spy();

            postalMock.expects('subscribe').withArgs(sinon.match({
                channel: Patient.channel,
                topic: Patient.topics.taggingPatient.error
            })).returns({ unsubscribe: unsubscribe });

            postalMock.expects('subscribe').withArgs(sinon.match({
                    channel: Patient.channel,
                    topic: Patient.topics.untaggingPatient.error
            })).returns({ unsubscribe: unsubscribe });
            
            // Initialize the controller before each spec
            controller('PatientSearchCtrl', {$scope: scope});
        }));

        afterEach(function() {
            patientSearchService.search.restore();
            postalMock.restore();
            NSerrorMsgSpy.restore();
        });

        it('should have a controller', function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        /** objects - Start */
        it('should have searchSubmitted object', function () {
            assert.isDefined(scope.searchSubmitted, 'Controller scope doesn\'t have "searchSubmitted" Boolean object defined');
        });
        it('should have searchReturned object', function () {
            assert.isDefined(scope.searchReturned, 'Controller scope doesn\'t have "searchReturned" Boolean object defined');
        });
        it('should have myApplicationServices object', function () {
            assert.isDefined(scope.myApplicationServices, 'Controller scope doesn\'t have "myApplicationServices" object defined');
        });
        /** objects - End */
        
        /** functions - Start */
        /** functions > definitions - Start */
        it('should have a showErrorMsg function', function () {
            assert.isFunction(scope.showErrorMsg, 'Controller scope doesn\'t have "showErrorMsg" function defined');
        });
        it('should have a validate function', function () {
            assert.isFunction(scope.validate, 'Controller scope doesn\'t have "validate" function defined');
        });
        it('should have a submitSearch function', function () {
            assert.isFunction(scope.submitSearch, 'Controller scope doesn\'t have "submitSearch" function defined');
        });
        it('should have a noResultsFound function', function () {
            assert.isFunction(scope.noResultsFound, 'Controller scope doesn\'t have "noResultsFound" function defined');
        });
		it('should have a noResultsFound function', function () {
            assert.isFunction(scope.onScript, 'Controller scope doesn\'t have "onScript" function defined');
        });
        /** functions > definitions End - Start */

        /** functions > complementing - Start */

        it('should define the myApplicationServices attribute', function () {
            assert.isDefined(scope.myApplicationServices, 'scope.myApplicationServices is not defined');
            expect(scope.myApplicationServices).to.eql({});

            var response = { entry: [{ id: '123' }, { id: '456' }]};
            uomDeferred.resolve(response);
            scope.$apply();

            expect(scope.myApplicationServices).to.eql(response);
        });

        it('should show error message that is passed to it', function () {
            scope.showErrorMsg('test error msg');
            expect(NSerrorMsgSpy.calledWith('test error msg')).to.be.true;
        });
        
        it('should not show error message when it was not passed to it', function () {
            scope.showErrorMsg();
            expect(NSerrorMsgSpy.called).to.be.false;
        });
		
        it('it should validate if results were found when the size of "list of patients" is zero and the searching was returned', function () {
            scope.searchReturned = true;
            scope.patients = [];
            expect(scope.noResultsFound()).to.equal(true);
        });
        
        it('it should validate if results were found when the size of "list of patients" is more than zero and the serching was returned', function () {
            scope.searchReturned = true;
            scope.patients = ['ex1','ex1'];
            expect(scope.noResultsFound()).to.equal(false);
        });
        
        it('it should validate if results were found when the size of "list of patients" is zero and the searching was not returned', function () {
            scope.searchReturned = false;
            scope.patients = [];
            expect(scope.noResultsFound()).to.equal(false);
        });
        
        it('it should validate if results were found when the size of "list of patients" is more than zero and the searching was not returned', function () {
            scope.searchReturned = false;
            scope.patients = ['ex1','ex1'];
            expect(scope.noResultsFound()).to.equal(false);
        });

        it('should show an error message when submiting without application services', function () {
            scope.patientCriteria = {};
            scope.patientCriteria.id = 548;
            scope.patientCriteria.givenName = '';
            scope.patientCriteria.familyName = '';
            scope.patientCriteria.birthDate = null;

            scope.myApplicationServices = {};

            scope.submitSearch();

            expect(NSerrorMsgSpy.calledWith('patient-view.noApplicationServiceAssigned')).to.be.true;
            expect(scope.searchSubmitted).to.be.false;

            scope.myApplicationServices = { entry: [1] };

            scope.submitSearch();
            expect(scope.searchSubmitted).to.be.true;
        });
        
        it('should submit the Search of Patient',   function () {
            scope.patients = [];

            scope.patientCriteria = {};
            scope.patientCriteria.id = 548;
            scope.patientCriteria.givenName = '';
            scope.patientCriteria.familyName = '';
            scope.patientCriteria.birthDate = null;

            scope.myApplicationServices = { entry: [1] };

            scope.submitSearch();

            expect(scope.searchSubmitted).to.equal(true);
        });

        it('should not submit the Search of Patient if the criteria is invalid', function () {
            expect(scope.searchSubmitted).to.be.false;
            scope.submitSearch();
            expect(scope.searchSubmitted).to.be.false;
        });

        it('should manage the Search of Patient successful return', function () {
            expect(scope.searchSubmitted).to.be.false;
            scope.patientCriteria.id = '123';
            scope.myApplicationServices = { entry: [1] };
            scope.submitSearch();
            expect(scope.searchSubmitted).to.be.true; 

            deferred.resolve([{id:1}]);
            $rootScope.$apply();
            expect(scope.patients).to.eql([{id:1}]);
            expect(scope.searchReturned).to.be.true;
            expect(scope.searchSubmitted).to.be.false;
        });

        it('should manage the Search of Patient error return', function () {
            expect(scope.searchSubmitted).to.be.false;
            scope.patientCriteria.id = '123';
            scope.myApplicationServices = { entry: [1] };
            scope.submitSearch();
            expect(scope.searchSubmitted).to.be.true; 

            deferred.reject();
            $rootScope.$apply();
            expect(scope.patients).to.eql([]);
            expect(scope.searchReturned).to.be.false;
            expect(scope.searchSubmitted).to.be.false;
            expect(NSerrorMsgSpy.calledWith('patient-view.unableToSearch')).to.be.true;
        });

        it('shoud watch patientCriteria.id', function () {
            scope.patientCriteria.id = '777';
            scope.patientCriteria.givenName = 'Callebe';
            scope.patientCriteria.familyName = 'Gomes';
            scope.patientCriteria.birthDate = new Date();

            scope.$apply();

            expect(scope.patientCriteria.id).to.equal('777');
            expect(scope.patientCriteria.givenName).to.equal('');
            expect(scope.patientCriteria.familyName).to.equal('');
            expect(scope.patientCriteria.birthDate).to.be.null;
        });

        it('should validate if $scope.patientCriteria is null or empty', function () {
            expect(scope.validate()).to.equal('patient-view.fillPatientDetails');
            scope.patientCriteria.givenName = 'Callebe';
            expect(scope.validate()).to.not.equal('patient-view.fillPatientDetails');
            scope.patientCriteria.givenName = '';
            scope.patientCriteria.birthDate = new Date();
            expect(scope.validate()).to.equal('patient-view.fillPatientDetails');
        });

        it('should validate if Criteria fields have more than 1 character', function () {
            scope.patientCriteria = {id: '1', givenName: '1', familyName: '1', birthDate: null};
            expect(scope.validate()).to.equal('patient-view.tooFewChars');
            scope.patientCriteria = {id: '11', givenName: '1', familyName: '1', birthDate: null};
            expect(scope.validate()).to.equal('patient-view.tooFewChars');
            scope.patientCriteria = {id: '11', givenName: '11', familyName: '1', birthDate: null};
            expect(scope.validate()).to.equal('patient-view.tooFewChars');
            scope.patientCriteria = {id: '11', givenName: '11', familyName: '1', birthDate: null};
            expect(scope.validate()).to.equal('patient-view.tooFewChars');
            scope.patientCriteria = {id: '11', givenName: '11', familyName: '11', birthDate: null};
            expect(scope.validate()).to.be.null;
        });

        it('should validate if criteria fields have invalid characters', function () {
            scope.patientCriteria = {id: '', givenName: 'abc*', familyName: '', birthDate: null};
            expect(scope.validate()).to.equal('patient-view.invalidCharacters');
            scope.patientCriteria = {id: '', givenName: 'abc\\', familyName: '', birthDate: null};
            expect(scope.validate()).to.equal('patient-view.invalidCharacters');
            scope.patientCriteria = {id: '', givenName: 'abc?', familyName: '', birthDate: null};
            expect(scope.validate()).to.equal('patient-view.invalidCharacters');
            scope.patientCriteria = {id: '', givenName: 'abc^', familyName: '', birthDate: null};
            expect(scope.validate()).to.equal('patient-view.invalidCharacters');
            scope.patientCriteria = {id: '', givenName: 'abc', familyName: '', birthDate: null};
            expect(scope.validate()).to.be.null;

            scope.patientCriteria = {id: '', givenName: '', familyName: 'abc*', birthDate: null};
            expect(scope.validate()).to.equal('patient-view.invalidCharacters');
            scope.patientCriteria = {id: '', givenName: '', familyName: 'abc\\', birthDate: null};
            expect(scope.validate()).to.equal('patient-view.invalidCharacters');
            scope.patientCriteria = {id: '', givenName: '', familyName: 'abc?', birthDate: null};
            expect(scope.validate()).to.equal('patient-view.invalidCharacters');
            scope.patientCriteria = {id: '', givenName: '', familyName: 'abc^', birthDate: null};
            expect(scope.validate()).to.equal('patient-view.invalidCharacters');
            scope.patientCriteria = {id: '', givenName: '', familyName: 'abc', birthDate: null};
            expect(scope.validate()).to.be.null;

            scope.patientCriteria = {id: 'aAbB0*@as\\?^', givenName: '', familyName: '', birthDate: null};
            expect(scope.validate()).to.equal('patient-view.invalidCharacters');
            scope.patientCriteria = {id: 'a-A.0/1_', givenName: '', familyName: '', birthDate: null};
            expect(scope.validate()).to.be.null;
        });

        it('should return the searchData', function () {
            expect(scope.searchData()).to.eql({
                id: '',
                givenName: '',
                familyName: '',
                birthDate: ''
            });

            var d = new Date();
            scope.patientCriteria.birthDate = d;
            expect(scope.searchData()).to.eql({
                id: '',
                givenName: '',
                familyName: '',
                birthDate: d.toJSON().split('T')[0]
            });            
        });

        it('should open datepicker', function () {
            scope.datepicker.opened = false;
            scope.open({
                stopPropagation: function () {},
                preventDefault: function () {}
            });
            expect(scope.datepicker.opened).to.be.true;
        });

        describe('Tag and Untag events', function () {
            it('should subscribe in postal to tag.error and untag.error topics and unsubscribe on $destroy', function () {
                postalMock.verify();

                scope.$destroy();

                expect(unsubscribe.calledTwice).to.be.true;
            });

            it("should show an error message when tag.error topic is published", function () {
                var $scope = $rootScope.$new();

                postalMock.restore();
                controller('PatientSearchCtrl', {$scope: $scope});

                postal.publish({
                    channel: Patient.channel,
                    topic: Patient.topics.taggingPatient.error,
                    data: {
                        getFullName: function () {
                            return "Ms. John Snow";
                        }
                    }
                });

                expect(NSerrorMsgSpy.calledWith("patient-view.tagUntagPatientError Ms. John Snow. patient-view.tryAgain")).to.be.true;

                postalMock = sinon.mock(postal);
            });
        });
		
		it('should the value of field id will be clear', function () {
            var fieldName = "id";
			scope.patientCriteria[fieldName] = 'anyvalue';
			
			scope.onScript(fieldName);
            expect(scope.patientCriteria[fieldName]).to.equal('');
        });
		
		 it('should the value of field givenName will be clear', function () {
            var fieldName = "givenName";
			scope.patientCriteria[fieldName] = 'anyvalue';
			
			scope.onScript(fieldName);
            expect(scope.patientCriteria[fieldName]).to.equal('');
        });
		
		 it('should the value of field familyName will be clear', function () {
            var fieldName = "familyName";
			scope.patientCriteria[fieldName] = 'anyvalue';
			
			scope.onScript(fieldName);
            expect(scope.patientCriteria[fieldName]).to.equal('');
        });
       
        /** functions > complementing End - Start */
        /** functions - End */
    });
});