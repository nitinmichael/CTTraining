define(['angular','postal','angular-mocks','orgMgmnt/widgets/ge-sitelist/listOfSites'],
    function (ng) {
        'use strict';
        describe('Tests ge-exception-handler controller', function(){
            var scope, getListofSitesCtrl,event,rootScope,compile,templateCache,siteObj,_$timeout;
            var createControllerScopeUsingIsolatedScope=function(str){
                var ele=angular.element('<ge-sitelist mode-type="'+str+'"></list-sites>');
                inject(function($rootScope,$compile,$templateCache,$controller,siteFactory,$timeout){
                    var templateHtml = $templateCache.get('./modules/orgmanagement/widgets/ge-sitelist/listOfSites.html');
                    if(!templateHtml) {
                       templateHtml = '<div data-ng-controller="getListofSites"></div>',
                    $templateCache.put('./modules/orgmanagement/widgets/ge-sitelist/listOfSites.html', templateHtml);
                    }
                    rootScope=$rootScope;
                    _$timeout = $timeout;
                    scope = $rootScope.$new();
                    scope.modeType=str;
                    scope.cancelsite=function()
                    {

                    }
                    scope.savesite=function()
                    {

                    }


                    $compile(ele)(scope);
                    scope.$digest();
                    getListofSitesCtrl = $controller('getListofSites', {$scope:scope,$timeout:_$timeout});
                    siteObj = siteFactory;

                });
            };
            beforeEach( function(){
                module('listOfSitesModules');
            });
            describe('Test mode type error scenarios', function () {
                it('checks mode type variable if context is specified', function(){
                    createControllerScopeUsingIsolatedScope('edit');
                    chai.expect(scope.modeType).to.equal('edit');
                });


                it('click on cancel button on list of sites ', function(){
                  scope.cancelManageUsersSiteList();
                  chai.expect(scope.modeType).to.equal('view');

                });

                it('test set header value factory ', function(){
                    siteObj.setSiteHeader("site1");
                    chai.expect(siteObj.getSiteHeader()).to.equal('site1');
                });

                it('test set save sites factory', function(){

                    siteObj.setSaveSites("site1");
                    chai.expect(siteObj.getSaveSites()).to.equal('site1');
                });

                it('factory getSaveSites  ', function(){
                    siteObj.getSaveSites();
                    chai.expect(siteObj.getSaveSites()).to.equal('site1');
                    });


                                          it('factory setListofSitesforLoginUser   ', function(){
                                            scope.userSiteListArray =[{"title":null,"id":"870a98ff-0628-4bbf-bd9c-f31b9a4dce91","content":{"resourceType":"Organization","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"Concord Medical Center"}]}}}];
                                            siteObj.setListofSitesforLoginUser(scope.userSiteListArray);
                                            chai.expect(siteObj.getListofSitesforLoginUser()).to.equal(scope.userSiteListArray);
                                            });


                    it('factory setDisplySites   ', function(){
                      scope.userSiteListArray =[{"title":null,"id":"870a98ff-0628-4bbf-bd9c-f31b9a4dce91","content":{"resourceType":"Organization","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"Concord Medical Center"}]}}}];
                      siteObj.setDisplySites(scope.userSiteListArray);
                      chai.expect(siteObj.getDisplySites()).to.equal(scope.userSiteListArray);
                      });

                      it('timeout call ', function(){
                              _$timeout.flush();
                      });


                it('user click on edit button on sites, view changes to view mode',function(){
                    scope.userSiteListArray =[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/480f2c99-8056-4a1f-9202-1bc3c9339cf4","display":"GE Healthcare RSNA 4"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/09227e3e-1d92-4921-a944-3d22e43ad14c","display":"GE Healthcare RSNA 3"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/13dbd09a-98e7-46a0-8d4f-f0ff261d8411","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a985795c-fae2-40b7-afc6-1f37921d2048","display":"GE Healthcare RSNA VNA"},"status":"active"}];
                    scope.listofSitesforLoginUserObj =[{"title":null,"id":"016d12bb-1205-4d39-8541-1449335c4cea","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>GEHC RSNA Site4</div>"},"name":"GE Healthcare RSNA 2_TOPAZ","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"site"}]},"telecom":[{"system":"phone","value":"6679098876","use":"mobile"}],"address":[{"line":["540  W. Northwest Highway"],"city":"Barrington","state":"IL","zip":"60010","country":"US"}],"partOf":{"reference":"organization/87c3128c-a77b-4c83-9e9b-6cc4555fd10c"}},"role":{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"HealthcareProvider"}],"scopingOrganization":{"reference":"site/016d12bb-1205-4d39-8541-1449335c4cea","display":"GE Healthcare RSNA 2_TOPAZ"},"status":"active"}}];
                    scope.mergeList =[{"check":false,"obj":{"title":null,"id":"016d12bb-1205-4d39-8541-1449335c4cea","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>GEHC RSNA Site4</div>"},"name":"GE Healthcare RSNA 2_TOPAZ","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"site"}]},"telecom":[{"system":"phone","value":"6679098876","use":"mobile"}],"address":[{"line":["540  W. Northwest Highway"],"city":"Barrington","state":"IL","zip":"60010","country":"US"}],"partOf":{"reference":"organization/87c3128c-a77b-4c83-9e9b-6cc4555fd10c"}},"role":{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"HealthcareProvider"}],"scopingOrganization":{"reference":"site/016d12bb-1205-4d39-8541-1449335c4cea","display":"GE Healthcare RSNA 2_TOPAZ"},"status":"active"}}},{"check":false,"obj":{"title":null,"id":"030569ae-dfe6-485b-a3a8-d744f9dc1979","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>Test Delete</div>"},"name":"Test Delete site","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"site"}]},"telecom":[{"system":"phone","value":"22323232","use":"mobile"}],"address":[{"line":["Test Delete"],"city":"Test Delete","state":"IL","zip":"12211212","country":"US"}],"partOf":{"reference":"organization/66f10159-4ec9-4970-82c4-44562c3429c5"}},"role":{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"HealthcareProvider"}],"scopingOrganization":{"reference":"site/030569ae-dfe6-485b-a3a8-d744f9dc1979","display":"Test Delete site"},"status":"active"}}}];
                    scope.editSites();
                    createControllerScopeUsingIsolatedScope('edit');
                    chai.expect(scope.modeType).to.equal('edit');
                });

                it('user click on edit button on sites with matching sites of logged in user and user in question' ,function(){
                    scope.userSiteListArray =[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/016d12bb-1205-4d39-8541-1449335c4cea","display":"GE Healthcare RSNA 4"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/09227e3e-1d92-4921-a944-3d22e43ad14c","display":"GE Healthcare RSNA 3"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/13dbd09a-98e7-46a0-8d4f-f0ff261d8411","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a985795c-fae2-40b7-afc6-1f37921d2048","display":"GE Healthcare RSNA VNA"},"status":"active"}];
                    scope.listofSitesforLoginUserObj =[{"title":null,"id":"016d12bb-1205-4d39-8541-1449335c4cea","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>GEHC RSNA Site4</div>"},"name":"GE Healthcare RSNA 2_TOPAZ","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"site"}]},"telecom":[{"system":"phone","value":"6679098876","use":"mobile"}],"address":[{"line":["540  W. Northwest Highway"],"city":"Barrington","state":"IL","zip":"60010","country":"US"}],"partOf":{"reference":"organization/87c3128c-a77b-4c83-9e9b-6cc4555fd10c"}},"role":{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"HealthcareProvider"}],"scopingOrganization":{"reference":"site/016d12bb-1205-4d39-8541-1449335c4cea","display":"GE Healthcare RSNA 2_TOPAZ"},"status":"active"}}];
                    scope.mergeList =[{"title":null,"id":"870a98ff-0628-4bbf-bd9c-f31b9a4dce91","content":{"resourceType":"Organization","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"Concord Medical Center"}]}}}];
                    scope.editSites();
                    createControllerScopeUsingIsolatedScope('edit');
                    chai.expect(scope.modeType).to.equal('edit');
                });

                it('edit sites create merge object check not matching cases',function(){
                    scope.userSiteListArray =[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/480f2c99-8056-4a1f-9202-1bc3c9339cf4","display":"GE Healthcare RSNA 4"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/09227e3e-1d92-4921-a944-3d22e43ad14c","display":"GE Healthcare RSNA 3"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/13dbd09a-98e7-46a0-8d4f-f0ff261d8411","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a985795c-fae2-40b7-afc6-1f37921d2048","display":"GE Healthcare RSNA VNA"},"status":"active"}];
                    scope.listofSitesforLoginUserObj =[{"title":null,"id":"016d12bb-1205-4d39-8541-1449335c4cea","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>GEHC RSNA Site4</div>"},"name":"GE Healthcare RSNA 2_TOPAZ","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"site"}]},"telecom":[{"system":"phone","value":"6679098876","use":"mobile"}],"address":[{"line":["540  W. Northwest Highway"],"city":"Barrington","state":"IL","zip":"60010","country":"US"}],"partOf":{"reference":"organization/87c3128c-a77b-4c83-9e9b-6cc4555fd10c"}},"role":{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"HealthcareProvider"}],"scopingOrganization":{"reference":"site/016d12bb-1205-4d39-8541-1449335c4cea","display":"GE Healthcare RSNA 2_TOPAZ"},"status":"active"}}];
                    scope.mergeList =[{"title":null,"id":"870a98ff-0628-4bbf-bd9c-f31b9a4dce91","content":{"resourceType":"Organization","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"Concord Medical Center"}]}}}];
                    scope.editSites();
                    createControllerScopeUsingIsolatedScope('edit');
                    chai.expect(scope.modeType).to.equal('edit');
                });

                it('edit sites for unmatching condition ',function(){
                    scope.userSiteListArray =[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/480f2c99-8056-4a1f-9202-1bc3c9339cf4","display":"GE Healthcare RSNA 4"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/09227e3e-1d92-4921-a944-3d22e43ad14c","display":"GE Healthcare RSNA 3"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/13dbd09a-98e7-46a0-8d4f-f0ff261d8411","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a985795c-fae2-40b7-afc6-1f37921d2048","display":"GE Healthcare RSNA VNA"},"status":"active"}];
                    scope.listofSitesforLoginUserObj =[{"title":null,"id":"016d12bb-1205-4d39-8541-1449335c4cea","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>GEHC RSNA Site4</div>"},"name":"GE Healthcare RSNA 2_TOPAZ","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"site"}]},"telecom":[{"system":"phone","value":"6679098876","use":"mobile"}],"address":[{"line":["540  W. Northwest Highway"],"city":"Barrington","state":"IL","zip":"60010","country":"US"}],"partOf":{"reference":"organization/87c3128c-a77b-4c83-9e9b-6cc4555fd10c"}},"role":{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"HealthcareProvider"}],"scopingOrganization":{"reference":"site/016d12bb-1205-4d39-8541-1449335c4cea","display":"GE Healthcare RSNA 2_TOPAZ"},"status":"active"}}];
                    scope.mergeList =[{"title":null,"id":"870a98ff-0628-4bbf-bd9c-f31b9a4dce91","content":{"resourceType":"Organization","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"Concord Medical Center"}]}}}];
                    scope.editSites();
                    createControllerScopeUsingIsolatedScope('view');
                    chai.expect(scope.modeType).not.be.undefined;
                });


            });

            describe('Testing  saving sites successfully', function () {

                it('checks the save sites', function(){
                    scope.role=[];
                    scope.mergeList =[{"check":true,"obj":{"title":null,"id":"016d12bb-1205-4d39-8541-1449335c4cea","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>GEHC RSNA Site4</div>"},"name":"GE Healthcare RSNA 2_TOPAZ","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"site"}]},"telecom":[{"system":"phone","value":"6679098876","use":"mobile"}],"address":[{"line":["540  W. Northwest Highway"],"city":"Barrington","state":"IL","zip":"60010","country":"US"}],"partOf":{"reference":"organization/87c3128c-a77b-4c83-9e9b-6cc4555fd10c"}},"role":{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"HealthcareProvider"}],"scopingOrganization":{"reference":"site/016d12bb-1205-4d39-8541-1449335c4cea","display":"GE Healthcare RSNA 2_TOPAZ"},"status":"active"}}},{"check":false,"obj":{"title":null,"id":"030569ae-dfe6-485b-a3a8-d744f9dc1979","content":{"resourceType":"Organization","text":{"status":"generated","div":"<div>Test Delete</div>"},"name":"Test Delete site","type":{"coding":[{"system":"urn:hc.ge.com/pfh/platform/orgtype","code":"SITE","display":"site"}]},"telecom":[{"system":"phone","value":"22323232","use":"mobile"}],"address":[{"line":["Test Delete"],"city":"Test Delete","state":"IL","zip":"12211212","country":"US"}],"partOf":{"reference":"organization/66f10159-4ec9-4970-82c4-44562c3429c5"}},"role":{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"HealthcareProvider"}],"scopingOrganization":{"reference":"site/030569ae-dfe6-485b-a3a8-d744f9dc1979","display":"Test Delete site"},"status":"active"}}}];
                    scope.saveSiteClick()

                    chai.expect(scope.modeType).to.equal('view');
                });

            });


        });

    }
);
