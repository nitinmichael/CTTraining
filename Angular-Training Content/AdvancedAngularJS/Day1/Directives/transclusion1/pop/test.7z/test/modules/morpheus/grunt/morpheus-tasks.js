module.exports = {
    copy:{
	    // Only copies the files specific to a module
        expand: true,
        //cwd: 'public/',
        dest: 'bin/',
        src: ['shell/*']
    },
    compress:{
        options: {
            archive: function () {
                return 'bin/morpheus.zip';
            }
        },
		files: [{ expand: true, src: ['public/modules/morpheus/*'] }]
    },
    karma:{
    	configFile: 'test/modules/morpheus/karma.conf.js'
    },
    shell: {
        command: 'pwd && cd test/modules/morpheus && pwd && mkdir -pv report/junit/test-report && java -jar /workspace/pfhtools_dev/sonar-karma-junit-parser1.0.0/parser.jar specs report/junit/TESTS-xunit.xml report/junit/test-report test.js'
    }

};
