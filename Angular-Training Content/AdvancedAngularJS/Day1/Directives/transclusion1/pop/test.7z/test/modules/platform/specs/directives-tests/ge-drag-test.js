/*
 * ge-drag-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular-mocks', 'jquery', 'modules/platform/directives/ge-drag'], function() {
    describe('Test  unselectable', function() {
        var scope, rootScope, element, $compile, $document, $timeout;

        var deviceManagerService = {
            isMobile: sinon.stub()
        };

        beforeEach(module('platform.directive.ge-drag'));

        beforeEach(module(function($provide) {
            $provide.value('$deviceManagerService', deviceManagerService);

        }));

        beforeEach(function() {
            inject(function($rootScope, _$compile_, _$document_, _$timeout_) {
                rootScope = $rootScope;
                $compile = _$compile_;
                $document = _$document_;
                scope = rootScope.$new();
                $timeout = _$timeout_;
                element = $compile("<div ge-drag=\"true\"></div>")(scope);
            });
        });

        it('initialize is called and events registred', function() {
            var spy = sinon.spy(scope, '$watch');
            scope.$apply();
            expect(element[0].draggable).to.equal(true);
        });

        it('keydown event must broadcast draggable:start event', function() {
            deviceManagerService.isMobile.returns(false);
            var spy = sinon.spy(rootScope, '$broadcast');
            //element.triggerHandler('mousedown', {'button' : 0});
           var event = document.createEvent('MouseEvent');
           event.initMouseEvent('mousedown', false, false, null, null, null, null, null, null, null, null, null, null, 0);
           element[0].dispatchEvent(event);

            $timeout.flush();

            // Create and dispatch event manually
            var mousemoveEvent = document.createEvent('MouseEvent');
            mousemoveEvent.initMouseEvent('mousemove', false, false, null, null, null, null, null, null, null, null, null, null, 0);
            mousemoveEvent.buttons = 1;
            $document[0].dispatchEvent(mousemoveEvent);
            rootScope.$apply();
            expect(spy.called).to.equal(true);
            expect(spy).calledWith('draggable:start');
            expect(spy).calledWith('draggable:move');
        });
    });
});
