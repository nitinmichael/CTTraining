/*
 *  message-field-directive-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jignesh Parekh<jignesh.parekh@ge.com>
 *  Monique Shotande<moniqueshotande@ge.com>
 */

/**
 * Spec file for Case Exchange > widgets > message-field directive
 */
'use strict';

define(['angular', 'angular-mocks',
        'widgets/message-field/message-field-directive'],
    function () {
    'use strict';
    describe('Message Field Directive Test Suite::', function () {
        var element, rootScope, scope, isolatedScope, template;

        beforeEach(function () {
            // Load actual module
            module('Directive.messageField', function ($provide, $translateProvider) {
                // This will provide the mock translation to $translate provider
                $translateProvider.translations('en', {});
            });

            // Load Templates
            module('templates');
        });

        beforeEach(
            inject(function ($compile, $rootScope) {

                element = angular.element(
                    '<message-field ' +
                    'field-id="caseMessage" ' +
                    'field-name="caseMessage" ' +
                    'field-model="formData.caseMessage" ' +
                    'field-maxlength="500" ' +
                    'field-disabled="false" ' +
                    'field-empty-check="noMessageAdded"></message-field>');


                rootScope = $rootScope;
                rootScope.formData = {};
                rootScope.formData.caseMessage = '';
                rootScope.noMessageAdded = false;
                scope = $rootScope.$new();

                $compile(element)(rootScope);
                // fire all the watches, so the scope expressions will be evaluated
                rootScope.$digest();
                isolatedScope = element.isolateScope();
                expect(true).to.equal(true);
            })
        );

        describe('defined directive', function() {
            it('should have a directive', function () {
                assert.isDefined(element, 'Directive is not defined');
            });

            it('should have "scope" object', function () {
                assert.isDefined(isolatedScope, 'directive scope doesn\'t exist');
            });

            // affirm all the scope variables are defined
            it('should have "fieldModel" object', function () {
                assert.isDefined(isolatedScope.fieldModel, 'directive scope doesn\'t have "fieldModel" object defined');
            });

            it('should have "fieldId" object', function () {
                assert.isDefined(isolatedScope.fieldId, 'directive scope doesn\'t have "fieldId" object defined');
            });

            it('should have "fieldName" object', function () {
                assert.isDefined(isolatedScope.fieldName, 'directive scope doesn\'t have "fieldName" object defined');
            });

            it('should have a "fieldMaxlength" variable', function () {
                assert.isDefined(isolatedScope.fieldMaxlength, 'Directive scope doesn\'t have "fieldMaxlength" variable defined');
            });

            it('should have "fieldDisabled" object', function () {
                assert.isDefined(isolatedScope.fieldDisabled, 'directive scope doesn\'t have "fieldDisabled" object defined');
            });

            it('should have "fieldEmptyCheck" object', function () {
                assert.isDefined(isolatedScope.fieldEmptyCheck, 'directive scope doesn\'t have "fieldEmptyCheck" object defined');
            });

            it('should have "remainingCharacters" object, initialized to "fieldMaxlength"', function () {
                expect(isolatedScope.remainingCharacters).to.not.be.undefined;
                assert.equal(isolatedScope.remainingCharacters, isolatedScope.fieldMaxlength, '"remainingCharacters" was not intialized to "fieldMaxlength"');
            });

            it('should have "fewCharsLeft" object', function () {
                assert.isDefined(isolatedScope.fewCharsLeft, 'directive scope doesn\'t have "fewCharsLeft" object defined');
            });

            it('should decrease the number of "remainingCharacters" as a message is written', function () {
                var MAXCHARS = isolatedScope.fieldMaxlength;
                var txt = '';

                for(var i = MAXCHARS; i > 0; i--) {
                    txt = txt + 'a'
                    rootScope.formData.caseMessage = txt;
                    isolatedScope.$apply();
                }
                expect(isolatedScope.noMessageAdded).to.equal(false);
                assert.equal(isolatedScope.remainingCharacters, 0, 'remainingCharacters variable should be 0');
            });

            it('should change the color of the "remainingCharacters" to red when remainingCharacters is less than or equal to  50', function () {
                var MAXCHARS = isolatedScope.fieldMaxlength;
                var txt = '';

                for(var i = MAXCHARS; i > 0; i--) {
                    txt = txt + 'a'
                    rootScope.formData.caseMessage = txt;
                    isolatedScope.$apply();

                    if(i <= 50) {
                        expect(isolatedScope.fewCharsLeft).to.equal(true);
                    }
                }
                expect(isolatedScope.noMessageAdded).to.equal(false);
                assert.equal(isolatedScope.remainingCharacters, 0, 'remainingCharacters variable should be 0');
            });

        });
    });

});