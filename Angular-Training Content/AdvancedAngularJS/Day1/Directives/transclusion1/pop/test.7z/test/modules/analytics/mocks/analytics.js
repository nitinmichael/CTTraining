/*  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jignesh Parekh<jignesh.parekh@ge.com>
 */

define(['angular'], function (angular) {

    /**
     * Angular Module which contains factory for Case Exchange mock data.
     */
    var mod = angular.module('cloudav.analytics.mocks', []);

    /**
     * Factory which contains methods to get mock data for Case Exchange module.
     */
    mod.factory('AnalyticsMocks', function () {

        /**
         * Function to get the moack data for "/me" service response
         * @returns meSuccessResponse: Mock object for "/me" service response.
         */
        function getMeServiceResponse(){
            var meSuccessResponse = {
                "externalId": [
                    {
                        "system": "IDM",
                        "value": "40c5bc1c-11e7-4eff-b5e1-42f474846022"
                    },
                    {
                        "system": "UOM",
                        "value": "f3eb410b-a95f-4b60-9ba2-c99cf8e2f4d3"
                    },
                    {
                        "_id": "username85@ge.com",
                        "system": "urn:hc.ge.com/pfh/platform/useremail"
                    }
                ],
                "role": [
                    {
                        "code": [
                            {
                                "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                "code": "practitioner",
                                "display": "practitioner"
                            }
                        ],
                        "scopingOrganization": {
                            "reference": "site/e23662b2-8c06-43ac-a37f-f2301386e60a"
                        },
                        "status": "active"
                    },
                    {
                        "code": [
                            {
                                "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                "code": "patient",
                                "display": "patient"
                            }
                        ],
                        "scopingOrganization": {
                            "reference": "organization/6"
                        },
                        "status": "active"
                    }
                ]
            };

            return meSuccessResponse;
        }

        return {
            getMeServiceResponse: getMeServiceResponse
        }
    });
});
