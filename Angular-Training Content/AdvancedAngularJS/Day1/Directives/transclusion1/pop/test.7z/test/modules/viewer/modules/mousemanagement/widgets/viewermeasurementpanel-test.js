/*
 *  viewermeasurementpanel-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author: Josselin Buils <josselin.buils@ge.com>
 */

/**
 * Spec file for Viewer > modules > mousemanagement > widgets > viewerMeasurementPanel directive
 */

define(['angular', 'angular-mocks', 'postal', 'GraphicalObjectMock', 'mousemanagementModule/module', 'platformMock', 'deviceManagerServiceMock', 'mousemanagementModule/widgets/viewermeasurementpanel'],
    function(angular, mocks, postal) {
        'use strict';

        describe('viewerMeasurementPanel directive test:', function() {
            var element,
                scope,
                measureManager,
                topicAddData;

            beforeEach(function() {
                module('templates');
                module('xjtweb-platform');
                module('deviceManagerServiceMock');
                module('platform');
                module('cloudav.viewerApp.mousemanagement');

                module(function($provide, GraphicalObjectMock) {
                    measureManager = GraphicalObjectMock.MeasureManagerMock(postal);

                    topicAddData = {
                        measure: measureManager
                    };

                    $provide.value('MeasureManager', measureManager);
                    $provide.value('translateFilter', function(value) {
                        return '{{' + value + '}}';
                    });
                });

                inject(function($compile, $rootScope) {
                    element = angular.element('<viewer-measurement-panel></viewer-measurement-panel>');
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$digest();
                });
            });

            it('should have a directive', function() {
                assert.isDefined(element, 'viewer-measurement-panel directive is not defined');
            });

            it('should have called MeasureManager.getMeasureList', function() {
                expect(measureManager.getMeasureList.calledOnce).to.equal(true);
            });

            it('should have called MeasureManager.getSelectedMeasure', function() {
                expect(measureManager.getSelectedMeasure.calledOnce).to.equal(true);
            });

            it('setSelected scope function should call MeasureManager.setSelectedMeasure', function() {
                scope.setSelected();
                expect(measureManager.setSelectedMeasure.calledOnce).to.equal(true);
            });

            it('getMeasurementIdForName scope function should return a measurement-panel-<measurementID>-name', function() {
                assert.equal(scope.getMeasurementIdForName("Dist. 1"), "measurement-panel-Dist._s1-name", "getMeasurementIdForName doesn't return the expected string" );
            });

            it('getMeasurementIdForValue scope function should return a measurement-panel-<measurementID>-value', function() {
                assert.equal(scope.getMeasurementIdForValue("Ang. 2"), "measurement-panel-Ang._s2-value", "getMeasurementIdForValue doesn't return the expected string" );
            });

            it('getFormattedMeasurementID function should return a formatted measurement ID', function() {
                assert.equal(getFormattedMeasurementID("Dist. 1"), "Dist._s1", "getFormattedMeasurementID doesn't return the expected string" );
            });

            it('getFormattedMeasurementID function should return a formatted measurement ID', function() {
                assert.equal(getFormattedMeasurementID("Dist._1"), "Dist._u1", "getFormattedMeasurementID doesn't return the expected string" );
            });

            it('getFormattedMeasurementID function should return a formatted measurement ID', function() {
                assert.equal(getFormattedMeasurementID("_Dist._ 1 "), "_uDist._u_s1_s", "getFormattedMeasurementID doesn't return the expected string" );
            });

            it('getFormattedMeasurementID function should return a formatted measurement ID', function() {
                assert.equal(getFormattedMeasurementID("D  is__t. _1"), "D_s_sis_u_ut._s_u1", "getFormattedMeasurementID doesn't return the expected string" );
            });

            it('getFormattedMeasurementID function should return a formatted measurement ID', function() {
                assert.equal(getFormattedMeasurementID("D u"), "D_su", "getFormattedMeasurementID doesn't return the expected string" );
            });

            it('getFormattedMeasurementID function should return a formatted measurement ID', function() {
                assert.equal(getFormattedMeasurementID("D_"), "D_u", "getFormattedMeasurementID doesn't return the expected string" );
            });

            it('XJTWEB.MEASURE_MANAGER.TOPIC.ADD event should update scope measures', function() {
                var addMeasureSubscribe = measureManager.subscribe.args[0],
                    addMeasureCallback = addMeasureSubscribe[1];
                addMeasureCallback(topicAddData);

                scope.$apply();
                expect(measureManager.getMeasureList.calledTwice).to.equal(true);
                expect(measureManager.getSelectedMeasure.calledTwice).to.equal(true);
            });

            it('XJTWEB.MEASURE.TOPIC.DESTROY event should update scope measures', function() {
                var addMeasureSubscribe = measureManager.subscribe.args[0],
                    addMeasureCallback = addMeasureSubscribe[1];
                addMeasureCallback(topicAddData);

                var destroyMeasureSubscribe = measureManager.subscribe.args[2],
                    destroyMeasureCallback = destroyMeasureSubscribe[1];
                destroyMeasureCallback();

                scope.$apply();
                expect(measureManager.getMeasureList.calledThrice).to.equal(true);
                expect(measureManager.getSelectedMeasure.calledThrice).to.equal(true);
            });

            it('XJTWEB.MEASURE_MANAGER.TOPIC.SELECTED_CHANGED event should update scope measures', function() {
                var selectedChangedSubscribe = measureManager.subscribe.args[1],
                    selectedChangedCallback = selectedChangedSubscribe[1];
                selectedChangedCallback();

                scope.$apply();
                expect(measureManager.getMeasureList.calledTwice).to.equal(true);
                expect(measureManager.getSelectedMeasure.calledTwice).to.equal(true)
            });
        });
    });
