define(['angular','angular-mocks','orgMgmnt/dataModels/siteDataModel'],
    function(ng){
        'use strict';

        describe('Test SiteData Model ', function(){
            var _siteDataModel;

            beforeEach( function(){
                module('Orgmanagement.DataModel.SiteDataModel');
            });

            beforeEach(inject(function(siteDataModel){
                _siteDataModel = siteDataModel;
            }));

            describe('When getIdentifierObject called ',function(){
                it('should test the return of variable', function(){
                    var identifierObject = _siteDataModel.getIdentifierObject();
                    chai.expect(identifierObject[0].system).to.be.equal('urn:hc.ge.com/pfh/platform/identifier');
                });
            });

            describe('When orgInfoObject  called ',function(){
                it('should test the return of variable', function(){
                    var  resource = "org";
                    var name = "gehc";
                    var address = ['line1 address'];
                    var ext = ['one'];
                    var orgInfoObject  = _siteDataModel.siteInfoObject (resource, name, address, ext);
                    chai.expect(orgInfoObject.name).to.be.equal(name);
                });
            });

            describe('When valueCodingObject called ',function(){
                it('should test the return of variable', function(){
                    var  code = "org";
                    var display = "gehc";
                    var valueCodingObject  = _siteDataModel.valueCodingObject (code, display);
                    chai.expect(valueCodingObject.valueCoding.code).to.be.equal(code);
                });
            });

            describe('When extensionObj called ',function(){
                it('should test the return of variable', function(){
                    var valueString = {value:'gehc'};
                    var valueCodingArr = [{coding:'reshare'}];
                    var extensionObj   = _siteDataModel.extensionObj(valueString, valueCodingArr);
                    chai.expect(extensionObj[0].value).to.be.equal(valueString.value);
                });

                it('should test the extension array length when valueString in null', function(){
                    var valueString = undefined;
                    var valueCodingArr = [{coding:'reshare'}];
                    var extensionObj   = _siteDataModel.extensionObj(valueString, valueCodingArr);
                    chai.expect(extensionObj).to.have.length(1);
                });

                it('should test the extension array length when valueCoding in null', function(){
                    var valueString = {value:'gehc'};
                    var valueCodingArr = undefined;
                    var extensionObj   = _siteDataModel.extensionObj(valueString, valueCodingArr);
                    chai.expect(extensionObj).to.have.length(1);
                });

                it('should test the extension array length with all value', function(){
                    var valueString = {value:'gehc'};
                    var valueCodingArr = [{coding:'reshare'}];
                    var extensionObj   = _siteDataModel.extensionObj(valueString, valueCodingArr);
                    chai.expect(extensionObj).to.have.length(2);
                });
            });

            describe('When getSiteAdminUpdateObj called ',function(){
                it('should test the return of variable', function(){
                    var siteId = '123',
                        adminToAdd=['34', '67'],
                        siteAdminObj = _siteDataModel.getSiteAdminUpdateObj(siteId, adminToAdd);
                    chai.expect(siteAdminObj).to.have.length(2);
                });

                it('should test the return of variable', function(){
                    var siteId = '123',
                        adminToRemove=['34', '67'],
                        adminToAdd = undefined,
                        siteAdminObj = _siteDataModel.getSiteAdminUpdateObj(siteId, adminToAdd, adminToRemove);
                    chai.expect(siteAdminObj).to.have.length(2);
                });
            });
        });
    });
