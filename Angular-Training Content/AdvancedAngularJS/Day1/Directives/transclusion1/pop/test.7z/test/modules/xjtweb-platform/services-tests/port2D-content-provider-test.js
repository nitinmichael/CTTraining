var home = 'modules/xjtweb-platform/services/';

define(['angular', 'angular-mocks', home + 'port2D-content-provider'], function() {
    'use strict';

    /**
     * @ngdoc service
     * @name xjtweb-platform.provider:port2DContentFactory-test
     * @author Benjamin Beeman
     *
     * @description TODO
     *
     * Copyright (c) 2015 by General Electric Company. All rights reserved.
     *
     * The copyright to the computer software herein is the property of General Electric Company. The software may be
     * used and/or copied only with the written permission of General Electric Company or in accordance with the terms
     * and conditions stipulated in the agreement/contract under which the software has been supplied.
     */
    describe('port2D-content-provider Unit Test, ', function() {

        var port2DContFactory;
        var logMsgListoner;
        var mock_get2DImageModelControllerUrl = "Mock_get2DImageModelControllerUrl";
        var mock_get2DPixelStreamerUrl = "mock_get2DPixelStreamerUrl";
        var mock_getAnnotationUrl = "Mock_get2DImageModelControllerUrl";
        var mock_cache;
        var mouseModeStoreService;
        var cacheFactory;

        var portObjMock = {
            vp2DEventBroker: "cpCanvasMock",
            vp2Dsvg: 'svgMock',
            vp2DOverlay: 'overlayCanvasMock'
        };

        function XpImageViewportMock(url, vp2Dcanvas, vp2Dsvg, vp2DOverlay, pluginRenderer) {
            this.url = url;
            this.vp2Dcanvas = vp2Dcanvas;
            this.vp2Dsvg = vp2Dsvg;
            this.vp2DOverlay = vp2DOverlay;
            this.pluginRenderer = pluginRenderer;
            this.setMouseModeStyle = sinon.spy();
            this.setImages = function() {

            };
            this.paint = function() {

            };
            this.getFrameIndex = function() {
                return 0;
            };
        }

        function H5Image2DRendererMock() {}

        function XpCompositeImageListMock() {}

        beforeEach(module('port2DContent'));

        var XpImageListCreateWatcher;

        beforeEach(module(function($provide) {
            $provide.value('$timeout', function(cb) {
                cb();
            });

            cacheFactory = {
                get: function() {
                    return mock_cache;
                },
                put: function(item) {
                    mock_cache = item;
                },
                destroy: sinon.spy()
            };

            $provide.value('$cacheFactory', function() {
                return cacheFactory;
            });

            $provide.factory('$xjtweb', function() {
                return {
                    'XJTWEB': {
                        'XpImageViewport': XpImageViewportMock,
                        'H5Image2DRenderer': H5Image2DRendererMock,
                        'XpCompositeImageList': XpCompositeImageListMock,
                        'XpImageMouseControls': {
                            'ZOOM': 'Mock_Zoom_Op',
                            'PAN': 'Mock_Pan_Op',
                            'WWWL': 'Mock_Windowing_Op',
                            'PAGE': 'Mock_Paging_Op',
                            'GENERAL': 'Mock_General_Op'
                        },
                        'XpImageList': {
                            'create': function(baseUrl, resourceInfo, imgListCB, groupID) {
                                XpImageListCreateWatcher = {
                                    'baseUrl': baseUrl,
                                    'resourceInfo': resourceInfo,
                                    'imgListCB': imgListCB,
                                    'groupID': groupID
                                };
                            }
                        },
                        'MouseModeStore': {
                            'PAGING_MODE': 666
                        }

                    }
                };
            });

            $provide.value('mouseModeStoreService', {
                MouseModeStore: {
                    setMouseMode2D: sinon.spy()
                }
            });

            $provide.factory('$logger', function() {
                return {
                    log: function(msg) {
                        logMsgListoner = msg;
                    }
                };
            });

            $provide.factory('$viewportParameterStorage', function() {
                return {
                    get2DImageModelControllerUrl: function() {
                        return mock_get2DImageModelControllerUrl;
                    },
                    get2DPixelStreamerUrl: function() {
                        return mock_get2DPixelStreamerUrl;
                    },
                    getAnnotationUrl: function() {
                        return mock_getAnnotationUrl;
                    }
                };
            });

            $provide.factory('annotStateService', function() {
                return {};
            });
        }));

        beforeEach(inject(function(port2DContentFactory, _mouseModeStoreService_) {
            port2DContFactory = port2DContentFactory;
            mouseModeStoreService = _mouseModeStoreService_;
        }));

        describe('Init port2DContentFactory:', function() {

            /**
             * @ngdoc method
             * @name InitPort2DContentFactoryTest
             * @methodOf xjtweb-platform.provider:port2DContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.port2DContentFactory port2DContentFactory} is created as an object.
             */
            it('port2DContentFactory should be a typeof object', function() {
                expect(typeof port2DContFactory).to.equal('object');
            });

            /**
             * @ngdoc method
             * @name InitPort2DContent_setUp2DPort_Test
             * @methodOf xjtweb-platform.provider:port2DContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.port2DContentFactory port2DContentFactory} is created with a
             *              setUp2DPort function.
             */
            it('port2DContFactory.setUp2DPort should be a typeof function', function() {
                expect(typeof port2DContFactory.setUp2DPort).to.equal('function');
            });

            /**
             * @ngdoc method
             * @name setUp2DPort_calls_XpImageViewport_Test
             * @methodOf xjtweb-platform.provider:port2DContentFactory-test
             *
             * @description This test method determines that the setUp2DPort attaches a XpImageViewport by the name of
             *              xp2DImageViewport to the port object.
             */
            it('xp2DImageViewport should be an instance of XpImageViewportMock and all the parameter should match up right.', function() {

                port2DContFactory.setUp2DPort(portObjMock);

                expect(portObjMock.xp2DImageViewport instanceof XpImageViewportMock).to.equal(true);
                expect(portObjMock.xp2DImageViewport.url).to.equal(undefined);
                expect(portObjMock.xp2DImageViewport.vp2Dcanvas).to.equal(portObjMock.vp2DEventBroker);
                expect(portObjMock.xp2DImageViewport.vp2Dsvg).to.equal(portObjMock.vp2Dsvg);
                expect(portObjMock.xp2DImageViewport.vp2DOverlay).to.equal(portObjMock.vp2DOverlay);
                expect(portObjMock.xp2DImageViewport.pluginRenderer instanceof H5Image2DRendererMock).to.equal(true);

            });

            /**
             * @ngdoc method
             * @name InitPort2DContent_set2DGroupOnPort_Test
             * @methodOf xjtweb-platform.provider:port2DContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.port2DContentFactory port2DContentFactory} is created with a
             *              set2DGroupOnPort function.
             */
            it('port2DContFactory.set2DGroupOnPort should be a typeof function', function() {
                expect(typeof port2DContFactory.set2DGroupOnPort).to.equal('function');
            });

            /**
             * @ngdoc method
             * @name set2DGroupOnPort_Test
             * @methodOf xjtweb-platform.provider:port2DContentFactory-test
             *
             * @description This test method tests the set2DGroupOnPort function.
             */
            it('port2DContFactory.set2DGroupOnPort: ', function() {
                logMsgListoner = '';
                XpImageListCreateWatcher = {};
                var resizeViewportCallCount = 0;
                var setImagesWatcher;
                var paintCallCount = 0;

                var portMock = {
                    resizeViewport: function() {
                        resizeViewportCallCount++;
                    },
                    xp2DImageViewport: {
                        setImages: function(images) {
                            setImagesWatcher = images;
                        },
                        paint: function() {
                            paintCallCount++;
                        },
                        getFrameIndex: function() {
                            return 0;
                        }
                    },

                    port2DReadyForSetup: false

                };

                var resourceInfoMock = {
                    spaceID: 'mockSpaceID',
                    groupID: 'mockGroupID',
                    studyUID: 'mockStudyUID',
                    seriesUID: 'mockSeriesUID',
                    instanceUIDs: undefined
                };

                portMock.cbForOnReady = [];
                port2DContFactory.set2DGroupOnPort(portMock, resourceInfoMock);

                mock_cache = undefined;
                portMock.cbForOnReady = null;
                port2DContFactory.set2DGroupOnPort(portMock, resourceInfoMock);

                expect(typeof portMock.cbForOnReady[0]).to.equal('function', 'if port2DReadyForSetup is false then set2DGroupOnPort should have added a cbForOnReady function and did not.');
                portMock.port2DReadyForSetup = true;
                portMock.cbForOnReady[0]();

                expect(typeof XpImageListCreateWatcher.imgListCB).to.equal('function', 'The imgListCB should have been a typeof function.');

                var callBackCalled = false;
                mock_cache = {
                    getImgListCBs: [function() {
                        callBackCalled = true;
                    }]
                };

                var mockGetPixelDataCB;
                XpImageListCreateWatcher.imgListCB({
                    size: function() {
                        return 10;
                    },
                    getImage: function() {
                        return {
                            getAnnotation: function() {},
                            getPixelData: function(cb) {
                                mockGetPixelDataCB = cb;
                            }
                        };
                    }
                });

                XpImageListCreateWatcher = {};
                resourceInfoMock.instanceUIDs = ['mockUID1', 'mockUID2', 'mockUID3'];
                mock_cache = undefined;
                port2DContFactory.set2DGroupOnPort(portMock, resourceInfoMock);
                expect(typeof XpImageListCreateWatcher.imgListCB).to.equal('function', 'The imgListCB should have been a typeof function.');
                expect(callBackCalled).to.equal(true, 'The getImgListCBs where not called.');
                expect(typeof mockGetPixelDataCB).to.equal('function', 'mockGetPixelDataCB should be a funciton and is not');
                mockGetPixelDataCB();
            });

            /**
             * @ngdoc method
             * @name InitPort2DContent_set2DMouseMode_Test
             * @methodOf xjtweb-platform.provider:port2DContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.port2DContentFactory port2DContentFactory} is created with a
             *              set2DMouseMode function.
             */
            it('port2DContFactory.set2DMouseMode should be a typeof function', function() {
                expect(typeof port2DContFactory.setMouseMode).to.equal('function');
            });

            /**
             * @ngdoc method
             * @name InitPort2DContent_getEventModes_Test
             * @methodOf xjtweb-platform.provider:port2DContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.port2DContentFactory port2DContentFactory} is created with a
             *              getEventModes function.
             */
            it('port2DContFactory.getEventModes should be a typeof function', function() {
                expect(typeof port2DContFactory.getEventModes).to.equal('function');

                port2DContFactory.getEventModes();

            });

            /**
             * @ngdoc method
             * @name InitPort2DContent_getSlicesNumber_Test
             * @methodOf xjtweb-platform.provider:port2DContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.port2DContentFactory port2DContentFactory} is created with a
             *              getSlicesNumber function.
             */
            it('port2DContFactory.getSlicesNumber should be a typeof function', function() {
                expect(typeof port2DContFactory.getSlicesNumber).to.equal('function');

                port2DContFactory.getSlicesNumber();
            });

            /**
             * @ngdoc method
             * @name set2DMouseMode_Test
             * @methodOf xjtweb-platform.provider:port2DContentFactory-test
             *
             * @description This test method determines that the set2DMouseMode functions correctly.
             */
            it('set2DMouseMode: ', function() {

                var portMock = {};
                port2DContFactory.setUp2DPort(portMock);
                expect(portMock.xp2DImageViewport.mockMouseOp).to.equal(undefined, ' No mouse mode must be set when the port is setup.');

                port2DContFactory.setMouseMode("ZOOM");
                expect(portMock.xp2DImageViewport.setMouseModeStyle.args[0][0]).to.equal('ZOOM', 'Setting the ZOOM mouse mode cursor style on viewports.');
                expect(mouseModeStoreService.MouseModeStore.setMouseMode2D.args[0][0]).to.equal('ZOOM', 'Setting the ZOOM mouse mode should have set the Zoom Op code on the MouseModeStore.');
            });

            /**
             * @ngdoc method
             * @name cleanUp_Test
             * @methodOf xjtweb-platform.provider:port2DContentFactory-test
             *
             * @description This test method determines that the cleanUp functions correctly.
             */
            it('cleanUp: ', function() {
                port2DContFactory.cleanUp();
                expect(cacheFactory.destroy.called).to.equal(true);
            });

            /**
             * @ngdoc method
             * @name pagingInvalidOnPort _Test
             * @methodOf xjtweb-platform.provider:port2DContentFactory-test
             *
             * @description This test method determines that the pagingInvalidOnPort functions correctly.
             */
            it('pagingInvalidOnPort: ', function() {
                expect(port2DContFactory.pagingInvalidOnPort({
                    xp2DImageViewport: {
                        pagingInvalidOnPort: function() {
                            return 'yop';
                        }
                    }
                })).to.equal('yop');
                expect(port2DContFactory.pagingInvalidOnPort({})).to.equal(true);
            });

            /**
             * @ngdoc method
             * @name rotateInvalidOnPort_Test
             * @methodOf xjtweb-platform.provider:port2DContentFactory-test
             *
             * @description This test method determines that the rotateInvalidOnPort functions correctly.
             */
            it('rotateInvalidOnPort: ', function() {
                expect(port2DContFactory.rotateInvalidOnPort({
                    xp2DImageViewport: {
                        rotateInvalidOnPort: function() {
                            return 'yop';
                        }
                    }
                })).to.equal('yop');
                expect(port2DContFactory.rotateInvalidOnPort({})).to.equal(true);
            });

            /**
             * @ngdoc method
             * @name getMouseMode_Test
             * @methodOf xjtweb-platform.provider:port2DContentFactory-test
             *
             * @description This test method determines that the getMouseMode functions correctly.
             */
            it('getMouseMode: ', function() {
                port2DContFactory.getMouseMode({});
                expect(port2DContFactory.getMouseMode({
                    xp2DImageViewport: {
                        getMouseMode: function() {
                            return 'yop';
                        }
                    }
                })).to.equal('yop');
            });
        });
    });
});
