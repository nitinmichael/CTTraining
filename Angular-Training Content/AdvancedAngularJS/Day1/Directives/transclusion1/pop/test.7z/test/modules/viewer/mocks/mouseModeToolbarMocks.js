define(['angular'], function(angular) {
    angular.module('mousemodetoolbarFactoryMock', []).factory('mousemodetoolbarFactory', function() {
        var json = {
            "title": "Mouse mode toolbar",
            "type": "simple-bar",
            "buttons": [{
                "id": "pointer_mode",
                "Name": "PAN",
                "title": "mousemanagement.mousePointer",
                "icon": {
                    "url": "./modules/viewer/modules/mousemanagement/images/icons/ViewerIcons_icon_Pan.svg"
                },
                "class": "right-toolbar-btn",
                "groupPanel": {
                    "id": "pointer_mode-group-panel",
                    "url": "./modules/platform/directives/toolBox/collapsed-btns-template.html",
                    "title": "Collapsed buttons popover",
                    "type": "popover",
                    "alignment": "vertical"
                },
                "panel": {

                },
                "onclick": ""
            }, {
                "id": "zoom_mode",
                "Name": "ZOOM",
                "title": "mousemanagement.mouseZoom",
                "icon": {
                    "url": "./modules/viewer/modules/mousemanagement/images/icons/ViewerIcons_icon_Zoom.svg"
                },
                "class": "right-toolbar-btn",
                "parentId": "pointer_mode",
                "onclick": ""
            }, {
                "id": "windowlevel_mode",
                "Name": "WINDOWING",
                "title": "mousemanagement.mouseWWWL",
                "icon": {
                    "url": "./modules/viewer/modules/mousemanagement/images/icons/ViewerIcons_icon_WWWL.svg"
                },
                "class": "right-toolbar-btn",
                "parentId": "pointer_mode",
                "onclick": ""
            }, {
                "id": "paging_mode",
                "Name": "PAGING",
                "title": "mousemanagement.mousePaging",
                "icon": {
                    "url": "./modules/viewer/modules/mousemanagement/images/icons/ViewerIcons_icon_Scroll.svg"
                },
                "class": "right-toolbar-btn",
                "parentId": "pointer_mode",
                "onclick": ""
            }, {
                "id": "rotate_mode",
                "Name": "ROTATE",
                "title": "mousemanagement.mouseRotate",
                "Class": "ico_rotate_sm.svg",
                "icon": {
                    "url": "./modules/viewer/modules/mousemanagement/images/icons/ViewerIcons_icon_rotate.svg"
                },
                "class": "right-toolbar-btn",
                "parentId": "pointer_mode",
                "onclick": ""
            }, {
                "id": "mouse_mode",
                "Name": "MOUSE",
                "title": "mousemanagement.mouse",
                "Class": "icon-ico_mouse_lg",
                "icon": {
                    "url": "./modules/viewer/modules/mousemanagement/images/icons/ViewerIcons_icon_Hang.svg"
                },
                "class": "right-toolbar-btn",
                "onclick": ""
            }]
        };
        return {
            success: function(callback) {
                callback(json);
            }
        };
    });
});
