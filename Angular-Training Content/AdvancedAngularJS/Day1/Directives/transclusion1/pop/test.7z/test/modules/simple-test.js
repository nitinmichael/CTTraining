define(['chai'], function () {
    'use strict';

    describe("A simple test suite", function () {
        'use strict';
    
        beforeEach(function () { });
        afterEach(function () { });
        it('should fail', function () { expect(true).to.equal(false); });
    });
});