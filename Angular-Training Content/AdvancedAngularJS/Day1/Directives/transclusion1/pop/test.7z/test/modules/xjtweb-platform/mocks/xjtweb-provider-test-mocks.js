angular.module('xjtweb-provider-test-mocks', []).constant('XjtwebProviderTestMocks', {

    XJTWEB_mock : function() {

        return {

            'type' : 'XJTWEB_MOCK',

            'getViewportTemplate' : function() {

                var testUrlString = 'modules/xjtweb-platform/directives/viewport/viewport-template.html';

                return testUrlString;
            }
        };
    }

});
