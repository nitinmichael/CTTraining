/*
 * patient-management-controller-test.js
 * 
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 * 
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */

define([
    'postal',
    'angular',
    'angular-mocks',
    'patient-view/controllers/patient-view-controller'
], function (postal, ng) {
    'use strict';

    describe('Patient View Controller Test Suite ::', function () {
        var $rootScope;
        var $controller;

        beforeEach(module('cloudav.patient-view.patient-view-controller'));

        beforeEach(inject(function (_$rootScope_, _$controller_) {
            $rootScope = _$rootScope_;
            $controller = _$controller_;
        }));

        it('should contruct the controller', function () {
            var $scope = $rootScope.$new();
            $controller('PatientViewCtrl', { $scope: $scope });
        });
    });
});