/*  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jignesh Parekh<jignesh.parekh@ge.com>
 */

define(['angular'], function (angular) {

    /**
     * Angular Module which contains factory for Case Exchange mock data.
     */
    var mod = angular.module('cloudav.caseExchange.mocks', []);

    /**
     * Factory which contains methods to get mock data for Case Exchange module.
     */
    mod.factory('CaseExchangeMocks', function () {

        /**
         * Function which will return the mock data for case headers
         * @returns:
         *  JSON object with mock case headers
         */
        function getUrl() {
            return "https://3.39.73.170:8943/app/main?jwt=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJnZW5lcmljX21pbUBnZS5jb20iLCJpYXQiOjE0NDE4Mjc2NDB9.ghPx67zWEdhkDFNfMJAg1ib-mT8NANHyJjt-sVpQHno#/dashboards/5568f7c908f3786020000006?embed=true&r=true&l=true&t=true&h=false";
        };

        return {
        	getUrl: getUrl
        }
    });
});
