/*
 * mdt-session-management-controller-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular', 'angular-mocks', 'mdt/modules/mdt-session-management/controllers/mdt-session-management-controller'], function () {
    'use strict';

    describe('MDT Session Management controller test cases', function () {
        var scope, state, stateParams, controller, MdtSessionService, MdtSessionDataService, NotificationService, getSessionHeadersStub;

        beforeEach(function () {
            angular.module('Platform.Services.NotificationService', []);
            angular.module('Platform.Directive.GenericList', []);
            
            getSessionHeadersStub = sinon.stub();
            module('Mdt.Module.MdtSessionDataService');
            module('Mdt.Module.MdtSessionManagementController', function ($provide) {
                $provide.value('MdtSessionService', {
                    then: function(fn){
                        fn({
                            getSessionHeaders: getSessionHeadersStub
                        });
                    }
                });
            });

            inject(function ($rootScope, $controller, _MdtSessionService_, _MdtSessionDataService_) {
                scope = $rootScope.$new();
                state = {
                    transitionTo: sinon.spy(),
                    go: sinon.spy()
                };
                stateParams = {
                    sessionId: null
                };
                MdtSessionService = _MdtSessionService_;
                MdtSessionDataService = _MdtSessionDataService_;
                NotificationService = {
                    addErrorMessage: sinon.spy()
                };

                //Initialize the controller
                controller =
                        $controller('MdtSessionManagementController', {
                            $scope: scope,
                            $state: state,
                            $stateParams: stateParams,
                            MdtSessionService: MdtSessionService,
                            MdtSessionDataService: MdtSessionDataService,
                            NotificationService: NotificationService
                        });
            });
        });

        it("should have a controller defined", function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it("should have a mdtSessionList undefined before initialization", function () {
            assert.isUndefined(scope.mdtSessionList, 'mdtSessionList is not defined');
        });

        it("should fill mdtSessionList with the data retrieved from getSessionHeaders", function () {
            var expectedSessions = [{
                "groupId": "1",
                "meetingId": "22",
                "groupName": "MDT Suicide group 1",
                "scheduling": null,
                "state": "PLANNED",
                "participants": [{"id": "1", "firstName": "Szabolcs", "lastName": "Beres"}, {
                    "id": "2",
                    "firstName": "Judit",
                    "lastName": "Bodi"
                }],
                "date": 86400000
            }];

            getSessionHeadersStub.callsArgWith(2, {data: expectedSessions});

            scope.getAllMdtSession();

            expect(scope.mdtSessionList).to.eql(expectedSessions);
        });

        it('should generate a state transition', function() {
            var session1 = {
                meetingId: 6677,
                cases: [
                    {id: 1122,
                        outcome: 'outcome1122'},
                    {id: 3344,
                        outcome: 'outcome3344'}
                ]
            };
            var session2 = {
                meetingId: 67,
                cases: [
                    {id: 12,
                        outcome: 'outcome12'},
                    {id: 34,
                        outcome: 'outcome34'}
                ]
            };
            scope.mdtSessionList = MdtSessionDataService.updateItemList([session1, session2]);
            MdtSessionDataService.retrieveSelectedItem(6677);

            scope.$digest();
            if( scope.selectedSessionObj.value===0  ) {
                scope.selectedSessionObj.value = 1;
            } else {
                scope.selectedSessionObj.value = 0;
            }
            scope.$digest();

            expect(state.go).calledOnce;
        });

        it("should call MdtSessionService with start and end of the current if 'Today' is selected", function () {
            var expectedStart = startOfToday();
            var expectedEnd = endOfToday();

            var expectedFilters = {
                from: expectedStart,
                to: expectedEnd,
                states: ["All"]
            };

            scope.updateSelectedTimeLimitFilter(_.find(scope.timeLimitFilterList, {label: "Today"}));

            expect(getSessionHeadersStub.calledTwice).to.equal(true);
            expect(getSessionHeadersStub.calledWith(expectedFilters)).to.equal(true);
        });

        it("should call MdtSessionService with start and end of next day if 'Tomorrow' is selected", function () {
            var expectedStart = startOfNextDay();
            var expectedEnd = endOfNextDay();

            var expectedFilters = {
                from: expectedStart,
                to: expectedEnd,
                states: ["All"]
            };

            scope.updateSelectedTimeLimitFilter(_.find(scope.timeLimitFilterList, {label: "Tomorrow"}));

            expect(getSessionHeadersStub.calledTwice).to.equal(true);
            expect(getSessionHeadersStub.calledWith(expectedFilters)).to.equal(true);
        });

        it("should call MdtSessionService with start of the day 30 days ago, and end of the current day if 'Last 30 days' is selected", function () {
            var expectedStart = thirtyDaysBefore();
            var expectedEnd = endOfToday();

            var expectedFilters = {
                from: expectedStart,
                to: expectedEnd,
                states: ["All"]
            };

            scope.updateSelectedTimeLimitFilter(_.find(scope.timeLimitFilterList, {label: "Last 30 days"}));

            expect(getSessionHeadersStub.calledTwice).to.equal(true);
            expect(getSessionHeadersStub.calledWith(expectedFilters)).to.equal(true);
        });

        it("should call MdtSessionService with the first and last day of the current month if 'This month' is selected", function () {
            var expectedStart = startOfThisMonth();
            var expectedEnd = endOfThisMonth();

            var expectedFilters = {
                from: expectedStart,
                to: expectedEnd,
                states: ["All"]
            };

            scope.updateSelectedTimeLimitFilter(_.find(scope.timeLimitFilterList, {label: "This month"}));

            expect(getSessionHeadersStub.calledTwice).to.equal(true);
            expect(getSessionHeadersStub.calledWith(expectedFilters)).to.equal(true);
        });

        it("should call MdtSessionService with failure", function () {
            getSessionHeadersStub.callsArgWith(3, {}, {}, {}, scope.mdtSessionListErrorHandler);

            scope.getAllMdtSession();

            expect(scope.mdtSessionList).to.be.an('array');
            expect(scope.mdtSessionList.length).to.equal(0);
            expect(scope.fetchingSessionList).to.be.false;
            expect(NotificationService.addErrorMessage.calledOnce).to.be.true;
        });

        function startOfThisMonth(now) {
            var today = new Date();
            return new Date(today.getFullYear(), today.getMonth(), 1, 0, 0, 0, 0);
        }

        function endOfThisMonth(now) {
            var today = new Date();
            return new Date(today.getFullYear(), today.getMonth() + 1, 0, 23, 59, 59, 999);
        }

        function startOfToday() {
            var today = new Date();
            return new Date(today.getFullYear(), today.getMonth(), today.getDate(), 0, 0, 0, 0);
        }

        function endOfToday() {
            var today = new Date();
            return new Date(today.getFullYear(), today.getMonth(), today.getDate(), 23, 59, 59, 999);
        }

        function thirtyDaysBefore() {
            var today = new Date();
            return new Date(today.getFullYear(), today.getMonth(), today.getDate() - 30, 0, 0, 0, 0);
        }

        function startOfNextDay(today) {
            var today = new Date();
            return new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1, 0, 0, 0, 0);
        }

        function endOfNextDay(today) {
            var today = new Date();
            return new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1, 23, 59, 59, 999);
        }
    });
});
