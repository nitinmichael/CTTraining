/*
 * my-mdt-controller-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular', 'angular-mocks', 'ng-sortable', 'mdt/modules/my-mdt/controllers/my-mdt-controller'], function () {
    'use strict';

    describe('My Mdt controller test cases', function () {
        var rootScope, scope, state, controller, MyMdtDataService, NotificationService, CaseExchangeDataService, getCaseParam, getCaseHeadersParam, $controller,
            getCaseHeadersPromise, getCaseDetailsPromise,
            getCaseHeadersArgs,    getCaseDetailsArgs, filter;

        filter = function() {
            return function() {
                return "";
            };
        };

        beforeEach(function () {
            getCaseHeadersParam = [];
            getCaseParam = {};

            var createHttpMock = function(defer){
                var promise = defer.promise;

                promise.success = function (fn) {
                    promise.then(function(data){
                        fn(data);
                    });
                    return promise;
                };
                promise.error = function(fn){
                    promise.then(null, function(data){
                        fn(data);
                    });
                    return promise;
                };

                var oldResolve = defer.resolve;
                defer.resolve = function(){
                    oldResolve.apply(defer, arguments);
                    rootScope.$apply(); // Have to trigger manually to apply promise resolving
                };

                var oldReject = defer.reject;
                defer.reject = function(){
                    oldReject.apply(defer, arguments);
                    rootScope.$apply();
                };

                return defer;
            };

            module('cloudav.mdt.myMdt.controllers', function ($provide) {
                $provide.value('$state', {
                    transitionTo : function(url) {
                    },
                    go : function(url) {
                    },
                    current : {
                        params : {}
                    }
                });

                $provide.value('CaseExchangeDataService', {
                    setSelectedCaseData: sinon.spy(),
                    setCaseUpdateType: sinon.spy()
                });

            });

            angular.module('Platform.Services.NotificationService',[])
                .service('NotificationService', [function(){
                    return {
                        addErrorMessage: sinon.stub()
                    }
                }]);

            inject(function ($rootScope, _$controller_, $state, _NotificationService_, _CaseExchangeDataService_, $q) {
                scope = $rootScope.$new();
                state = $state;
                rootScope = $rootScope;
                NotificationService = _NotificationService_;
                CaseExchangeDataService = _CaseExchangeDataService_;
                $controller = _$controller_;

                getCaseHeadersPromise = createHttpMock($q.defer());
                getCaseDetailsPromise = createHttpMock($q.defer());

                //Initialize the controller
                controller =
                    _$controller_('myMdtController', {
                        $rootScope: rootScope,
                        $scope: scope,
                        $state: state,
                        MyMdtDataService: {
                            then: function(fn){
                                fn({
                                    getCaseHeaders: function(){
                                        getCaseHeadersArgs = arguments;
                                        return getCaseHeadersPromise.promise;
                                    },
                                    getCase: function(){
                                        getCaseDetailsArgs = arguments;
                                        return getCaseDetailsPromise.promise;
                                    }
                                });
                            }
                        },
                        NotificationService: NotificationService,
                        CaseExchangeDataService: CaseExchangeDataService
                    });
            });
        });

        it("should have a controller defined", function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it("should call the success method when loading finished", function () {
            expect(scope.fetchingCaseList).to.be.true;
            expect(scope.caseList).to.be.empty;

            var data = [
                {
                    name: 'a',
                    mdtGroupName: 'Test Group'
                },
                {
                    name: 'b',
                    mdtGroupName: null
                },
                {
                    name: 'c'
                }
            ];

            getCaseHeadersPromise.resolve(data);

            expect(scope.fetchingCaseList).to.be.false;
            assert.isDefined(scope.caseList);
            expect(scope.caseList).to.be.length(1);

            var singleElement = scope.caseList[0];
            expect(singleElement.mdtGroupName).to.be.equal(data[0].mdtGroupName);
        });

        it("should call the notification service when error happened in list loading", function () {
            expect(scope.fetchingCaseList).to.be.true;
            expect(scope.caseList).to.be.empty;

            getCaseHeadersPromise.reject();

            expect(scope.fetchingCaseList).to.be.false;
            expect(scope.caseList).to.be.length(0);
            expect(NotificationService.addErrorMessage.calledOnce).to.be.true;
        });

        it("should call the success method when loading more cases finished", function () {
            expect(scope.fetchingCaseList).to.be.true;
            expect(scope.caseList).to.be.empty;

            var data = [
                {
                    name: 'a',
                    mdtGroupName: 'Test Group'
                },
                {
                    name: 'b',
                    mdtGroupName: null
                },
                {
                    name: 'c'
                }
            ];

            getCaseHeadersPromise.resolve(data);

            scope.loadMoreCase();

            expect(scope.fetchingCaseList).to.be.true;

            var data2 = [
                {
                    name: 'a',
                    mdtGroupName: 'Test Group2'
                },
                {
                    name: 'b',
                    mdtGroupName: null
                },
                {
                    name: 'c'
                }
            ];

            getCaseHeadersPromise.resolve(data2);

            expect(scope.fetchingCaseList).to.be.false;
            assert.isDefined(scope.caseList);
            expect(scope.caseList).to.be.length(2);
        });

        it("should load case when state changed to details", function() {
            var toState = {
                name: 'my-mdt.list.details'
            };
            var toParams = {
                caseId: 'ABA111'
            };

            rootScope.$broadcast('$stateChangeSuccess', toState, toParams);
            expect(scope.case).to.be.empty;
            expect(getCaseDetailsArgs).to.be.length(1);
            expect(getCaseDetailsArgs[0]).to.be.equal(toParams.caseId);

            var mockCase = {
                caseId: toParams.caseId,
                patient: {
                    name: 'Lorem Pista'
                }
            };
            getCaseDetailsPromise.resolve(mockCase);

            expect(scope.case).to.be.eql(mockCase);
            expect(scope.caseHasPatient).to.be.defined;
        });

        it("should call Notification service when error happens when loading details of a case", function() {
            var toState = {
                name: 'my-mdt.list.details'
            };
            var toParams = {
                caseId: 'ABA111'
            };

            rootScope.$broadcast('$stateChangeSuccess', toState, toParams);
            expect(scope.case).to.be.empty;
            expect(getCaseDetailsArgs).to.be.length(1);
            expect(getCaseDetailsArgs[0]).to.be.equal(toParams.caseId);
            expect(scope.isValid).to.be.false;

            getCaseDetailsPromise.reject();

            expect(scope.case).to.be.empty;
            expect(scope.isValid).to.be.false;
            expect(NotificationService.addErrorMessage.calledOnce).to.be.true;
        });

        it("should not load case when state is not details", function() {
            var toState = {
                name: 'my-mdt.list'
            };
            var toParams = {
                caseId: 'ABA111'
            };
            rootScope.$broadcast('$stateChangeSuccess', toState, toParams);

            expect(scope.case).to.be.undefined;
        });

        it("should set header details visibility", function() {
            rootScope.$broadcast('HeaderDetailIsVisible', true);

            expect(scope.headerDetailIsVisible).to.be.true;
        });

        it("should add to case", function() {
            scope.case = {id: "test"};
            scope.addToCase();

            expect(CaseExchangeDataService.setSelectedCaseData.calledOnce).to.be.true;
            expect(CaseExchangeDataService.setCaseUpdateType.calledOnce).to.be.true;
        });
    });
});
