define(['angular',
        'angular-mocks',
        'orgMgmnt/features/site/siteDetail/siteDetailModule'
    ],
    function(ng) {
        'use strict';

        describe('Test SiteDetailModule file', function(){
            var _rootScope, _stateProvider;

            beforeEach(function() {
                module('Orgmanagement.Features.Site.SiteDetail.SiteDetailModule'),function($stateProvider) {
                    _stateProvider = $stateProvider;
                }
            });

            it('should load the page.', inject(function($state){
                chai.expect($state).to.exist;
            }));
        });
    }
);