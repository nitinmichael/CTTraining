define([ 'angular-mocks', 'modules/platform/services/css-service' ], function(ngMocks) {
    describe('Test $cssService service', function() {

        beforeEach(module('platform.service.css-service'));
        beforeEach(function() {
            module(function($cssServiceProvider) {
                $cssServiceProvider.setMainUrl('/base/public/modules/platform/stylesheets/platform.css');
                $cssServiceProvider.setLightsOffUrl('/base/public/modules/platform/stylesheets/platform-Lts-off.css');
            });
        });
        beforeEach(module(function($provide) {
            $provide.factory('$windowResizeService', function() {
                return {
                    'invokeResize' : function() {
                    }
                }
            });
            $provide.factory('$logger', function() {
                return {
                    'log' : function() {
                    }
                }
            });
        }));

        it(' defines $cssService ', function() {
            inject(function($cssService) {
                expect($cssService).to.exist;
            })
        })
    });
});
