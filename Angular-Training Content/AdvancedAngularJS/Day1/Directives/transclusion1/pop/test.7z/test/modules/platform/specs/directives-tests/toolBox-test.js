define(['angular-mocks', 'modules/platform/directives/toolBox/toolBox'], function() {
    describe('Test toolBox', function() {
        var $rootScope, $scope, element;

        beforeEach(function() {
            module('platform.directive.toolBox');
            module('templates');

            module(function($provide) {
                $provide.factory('$popupCloserService', function() {
                    return {};
                });

                $provide.value('translateFilter', function(value) {
                    return value;
                });
            });

            inject(function($compile, _$rootScope_) {
                $rootScope = _$rootScope_;

                var parentScope = $rootScope.$new();
                parentScope.mytoolmodel = {
                    type: 'simple-bar',
                    buttons: []
                };

                element = $compile('<tool-box tool-model="mytoolmodel" />')(parentScope);
                parentScope.$digest();
                $scope = element.isolateScope();
            });
        });

        it('should replace the element with the appropriate content', function() {
            expect(element.html()).to.contain('getContentUrl');
        });

        it('setMenuBtnIcon should set the right menu icon if the hidden menu is displayed', function() {
            $scope.hiddenToolsOpen = true;
            $scope.setMenuBtnIcon();
            expect($scope.sideMenuBtnImg).to.equal('icon-chevron-right');
        });

        it('setMenuBtnIcon should set the left menu icon if the hidden menu is not displayed', function() {
            $scope.hiddenToolsOpen = false;
            $scope.setMenuBtnIcon();
            expect($scope.sideMenuBtnImg).to.equal('icon-chevron-left');
        });

        it('sideMenuBtnClick should show the hidden menu if it is not displayed', function() {
            $scope.hiddenToolsOpen = false;
            $scope.sideMenuBtnClick();
            expect($scope.hiddenToolsOpen).to.equal(true);
        });

        it('sideMenuBtnClick should hide the hidden menu if it is displayed', function() {
            $scope.hiddenToolsOpen = true;
            $scope.sideMenuBtnClick();
            expect($scope.hiddenToolsOpen).to.equal(false);
        });

        it('sideMenuBtnClick should call setMenuBtnIcon', function() {
            var spy = sinon.spy($scope, 'setMenuBtnIcon');
            $scope.sideMenuBtnClick();
            expect(spy.calledOnce).to.equal(true);
        });

        it('toolBtnClick should call the button onclick method according to the toolbox type', function() {
            var btn = {
                onclick: sinon.spy()
            };

            $scope.toolBtnClick();
            $scope.toolBtnClick({});

            $scope.toolModel.type = 'bar';
            $scope.toolBtnClick(btn);
            expect(btn.onclick.callCount).to.equal(1);

            $scope.toolModel.type = 'simple-bar';
            $scope.toolBtnClick(btn);
            expect(btn.onclick.callCount).to.equal(2);

            $scope.toolModel.type = 'mobile-menu';
            $scope.toolBtnClick(btn);
            expect(btn.onclick.callCount).to.equal(3);
        });

        it('toolBtnClick should call the altToolBoxBtnClick method according to the toolbox type', function() {
            $scope.altToolBoxBtnClick = sinon.spy();
            $scope.toolModel.type = '';
            $scope.toolBtnClick({});
            expect($scope.altToolBoxBtnClick.calledOnce).to.equal(true);
        });

        it('toolBtnClick should set the active tool in restricted tool mode', function() {
            var btn = {
                onclick: function() {},
                title: 'test'
            };
            $scope.activeToolMode = null;
            $scope.toolModel.restrictedToolMode = true;
            $scope.toolBtnClick(btn);
            expect($scope.activeToolMode).to.equal(btn.title);
        });

        it('toolBtnClick should not set the active tool if the button has a panel', function() {
            var btn = {
                onclick: function() {},
                title: 'test',
                panel: {}
            };
            $scope.activeToolMode = null;
            $scope.toolBtnClick(btn);
            expect($scope.activeToolMode).to.equal(null);
        });

        it('hiddenToolsOpen should hide the hidden tools and call setMenuBtnIcon if the hidden tools are displayed', function() {
            var spy = sinon.spy($scope, 'setMenuBtnIcon');

            $scope.hiddenToolsOpen = true;
            $scope.toolBtnClick({});

            expect($scope.hiddenToolsOpen).to.equal(false);
            expect(spy.calledOnce).to.equal(true);
        });

        it('isBtnSelected should return whether the button is selected according to the toolbox type', function() {
            var btn = {
                title: 'title'
            };

            $scope.toolModel.type = 'mobile-menu';
            expect($scope.isBtnSelected(btn)).to.equal(false);

            $scope.toolModel.restrictedToolMode = true;
            $scope.activeToolMode = btn.title;
            expect($scope.isBtnSelected(btn)).to.equal(true);

            btn.panel = {
                display: true
            };
            expect($scope.isBtnSelected(btn)).to.equal(btn.panel.display);

            $scope.toolModel.type = '';
            $scope.altButtonSelected = sinon.spy();
            $scope.isBtnSelected();
            expect($scope.altButtonSelected.calledOnce).to.equal(true);
        });

        it('setInnerToolModeContainerHandle should initialize a watch', function() {
            var spy = sinon.spy($scope, '$watch');
            $scope.setInnerToolModeContainerHandle();
            expect(spy.calledOnce).to.equal(true);
        });

        it('inToolModeContainer left margin should be set when its width changes', function() {
            var inToolModeContainer = {
                css: sinon.spy(),
                parent: function() {
                    return {
                        width: function() {
                            return 20;
                        }
                    };
                },
                width: function() {
                    return 10;
                }
            };

            $scope.setInnerToolModeContainerHandle(inToolModeContainer);
            $scope.$apply();

            expect(inToolModeContainer.css.calledWith('margin-left', '3px')).to.equal(true);
        });

        it('getContentUrl should return the template url according to the toolbox type', function() {
            $scope.toolModel.type = 'quickTools';
            expect($scope.getContentUrl()).to.equal('modules/platform/directives/toolBox/quickTools.html');

            $scope.toolModel.type = 'bar';
            expect($scope.getContentUrl()).to.equal('modules/platform/directives/toolBox/bar.html');

            $scope.toolModel.type = 'simple-bar';
            expect($scope.getContentUrl()).to.equal('modules/platform/directives/toolBox/simple-bar.html');

            $scope.toolModel.type = 'mobile-menu';
            expect($scope.getContentUrl()).to.equal('modules/platform/directives/toolBox/mobile-menu.html');

            $scope.toolModel.type = '';
            expect($scope.getContentUrl()).to.equal(undefined);
        });

        it('anyHiddenMenuOpen should return whether any side menu is open or not', function() {
            expect($scope.anyHiddenMenuOpen()).to.equal(false);
            $scope.hiddenToolsOpen = false;
            $scope.sideMenuBtnClick();
            expect($scope.anyHiddenMenuOpen()).to.equal(true);
        });

        it('isNonHiddenToolBtnDisabled test', function() {
            expect($scope.isNonHiddenToolBtnDisabled()).to.equal(false);
            expect($scope.isNonHiddenToolBtnDisabled(function() {
                return true;
            })).to.equal(true);
        });

        it('close should close the hidden menu if it is open and call setMenuBtnIcon', function() {
            var spy = sinon.spy($scope, 'setMenuBtnIcon');

            $scope.hiddenToolsOpen = true;
            $scope.close();

            expect($scope.hiddenToolsOpen).to.equal(false);
            expect(spy.calledOnce).to.equal(true);
        });

        it('catch the close event should close the side menu if it is open and if the clicked element is not the side menu', function() {
            var clickedElm = {
                    closest: function() {
                        return {
                            length: 1
                        };
                    },
                    classList: {
                        contains: function() {
                            return true;
                        }
                    },
                    parentElement: {
                        id: 'id'
                    }
                },
                spy = sinon.spy($scope, 'close');

            $rootScope.$broadcast('close');

            $scope.toolModel.sideMenuBtnID = clickedElm.parentElement.id;
            $rootScope.$broadcast('close', clickedElm);
            expect(spy.called).to.equal(false);

            $scope.toolModel.sideMenuBtnID = null;
            $rootScope.$broadcast('close', clickedElm);
            expect(spy.called).to.equal(true);
        });
    });
});
