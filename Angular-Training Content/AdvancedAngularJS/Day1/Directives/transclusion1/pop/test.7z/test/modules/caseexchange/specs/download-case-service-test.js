/*
 *  download-case-service-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Ketan Talreja<ketan.talreja@ge.com>
 */

/**
 * Spec file for Download Case Service module
 */

define(['angular','angular-mocks', 'modules/caseexchange/modules/case-inbox/services/download-case-service' ], function (ng) {
    'use strict';

    describe('Test Download Case Service', function () {
        beforeEach(module('Services.downloadCaseService', function($provide) {

            $provide.factory('configurationService', ['$q', function($q){
                return {
                    getProperty: function(){
                        return $q.when({});
                    }
                }
            }]);
        }));

        var DownloadCaseService;
        var httpBackend;
        var q, defer, rootScope;

        var caseAttachmentUrl = 'http://case-exchange-ui.caseworkflow.demo.grc-apps.svc.ice.ge.com/caseattachment/v1/case/1/attachment/store';

        // Initialize the scope and controller variables
        beforeEach(inject(function($httpBackend, _DownloadCaseService_, _$q_, _$rootScope_) {
            httpBackend = $httpBackend;
            rootScope = _$rootScope_;
            DownloadCaseService = _DownloadCaseService_;
            q = _$q_;
            defer = q.defer();
        }));

        it('should define a service', function () {
            assert.isDefined(DownloadCaseService, 'DownloadCaseService is defined');
        });

        describe('Download Case service', function() {
            it('should test DownloadCaseService is called successfully ', function () {
                var url=caseAttachmentUrl;
                DownloadCaseService.downloadCaseAttachment();
                defer.resolve();
                assert(httpBackend.whenPOST(url).respond(200));
            });

            it('should test DownloadCaseService is not called successfully ', function () {
                var url=caseAttachmentUrl;
                DownloadCaseService.downloadCaseAttachment();
                defer.resolve();
                assert(httpBackend.expectPOST(url).respond(400));
            });
        });

    });
});  