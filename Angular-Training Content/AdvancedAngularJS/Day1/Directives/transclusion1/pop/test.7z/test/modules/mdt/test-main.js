/*
 *  test-main.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * Karma-RequireJS configuration file for Case Exchange module
 */
var tests = [];
for (var file in window.__karma__.files) {
  if (window.__karma__.files.hasOwnProperty(file)) {
    if (/-test\.js$/.test(file)) {
      tests.push(file);
    }
  }
}
console.log(tests);
require.config({
    // Karma serves files under /base, which is the basePath from your config file
    baseUrl: '/base/public',
    paths: {
        "hdx":'uaf/hdx/js/hdx',
        'hdx-bootstrap': 'uaf/hdx/components/hdx-bootstrap/js/hdx-bootstrap',
        'jquery': 'uaf/hdx/components/3rdparty/jquery/jquery',
        'bootstrap': 'uaf/hdx/components/3rdparty/bootstrap/js',
        'prettify': "uaf/hdx/components/3rdparty/prettify/prettify",
        "typeahead": "uaf/hdx/components/3rdparty/typeahead.js/dist/typeahead.jquery",
        "bloodhound": "uaf/hdx/components/3rdparty/typeahead.js/dist/bloodhound",

        'angular': 'uaf/3rdparty/angular/angular',
        'angular-mocks': 'uaf/3rdparty/angular/angular-mocks',
        'angularTranslate': 'uaf/3rdparty/angular-translate/dist/angular-translate',
        'angularTranslatePartialLoader': 'uaf/3rdparty/angular-translate/dist/angular-translate-loader-partial/angular-translate-loader-partial',
        'lodash': 'uaf/3rdparty/lodash',
        'postal': 'uaf/3rdparty/postal/lib/postal',
        'angular-ui': 'uaf/hdx/components/3rdparty/angular-ui/ui-bootstrap-tpls-0.12.1',
        'angularRoute'    : 'uaf/3rdparty/angular-route/angular-route',
        'rich-popover' : './modules/mdt/3rdparty/rich-popover/js/rich-popover',
        'popover': 'uaf/hdx/components/3rdparty/bootstrap/js/popover',
        'tooltip': 'uaf/hdx/components/3rdparty/bootstrap/js/tooltip',
        'transition': 'uaf/hdx/components/3rdparty/bootstrap/js/transition',
        'bootstrap-timepicker'    : './modules/mdt/3rdparty/bootstrap-timepicker/js/bootstrap-timepicker',
        'timepicker'    : './modules/mdt/3rdparty/timepicker/js/timepicker',
        'oo-utils'    : './modules/mdt/3rdparty/oo-utils/src/js/oo-utils',
        'ng-sortable': './modules/mdt/3rdparty/ng-sortable/ng-sortable',
        'mdt': './modules/mdt',
        'widgets': './modules/mdt/widgets',
        'uiRouter': 'uaf/3rdparty/angular-ui-router/angular-ui-router'
    },
    shim: {
        'angular': { deps: ['jquery'], 'exports': 'angular' },
        'angular-mocks': {
            deps: ['angular'],
            'exports': 'angular.mock'
        },
        'angular-ui': {
            deps: ['angular']
        },
        'uiRouter': { deps: ['angular'] },
        'angularTranslate': { deps: ['angular'] },
        'angularTranslatePartialLoader': { deps: ['angularTranslate'] },

        'transition': ['jquery'],
        'tooltip': ['jquery'],
        'popover': ['jquery', 'tooltip'],
        'rich-popover': ['jquery', 'popover', 'transition']
    },
    // dynamically load all test files
    deps: tests,
    // start running the tests, once Require.js is done
    callback: window.__karma__.start
});
