/*
 * viewListGroupController-test.js
 * This test file is used to cover the unit test cases for view Group list controller(viewListGroupController.js)
 */
define(['angular', 'angular-mocks',
        'orgMgmnt/features/group/viewGroup/controllers/viewListGroupController',
        'orgMgmnt/services/groupService',
        'orgMgmnt/services/userService',
        'angular-ui'
    ],
    function(){
        'use strict';

        describe('Test the ViewListGroupController', function() {
            var scope, state, getAllGroups, deferred, getAllGroupsDeferred, toggleGroupStatusDeferred, spy, groupMgmtService,
                    spyToggleGroupStatus, setLoggedInUserStub, loggedInUserResult, _userService, groupList, findGroupDeferred, spyFindGroup;
            beforeEach( function(){
                module('Orgmanagement.Features.Group.ViewGroup.ViewListGroupController');
                module('Orgmanagement.Services.UserService');
            });

            beforeEach(module('Orgmanagement.Features.Group.ViewGroup.ViewListGroupController', function ($provide) {
                $provide.value('$state', {
                    transitionTo: function () { },
                    go: function () { }
                });
            }));

            beforeEach(function(){
                getAllGroups = {'entry':[{
                    "title": "UserGroup Resource",
                    "id": "428862f5-0c66-4fc6-8d85-78743f883fd6",
                    "content": {
                        "resourceType": "ResourcesUserGroup",
                        "member": [
                            {
                                "user": {
                                    "reference": "user/7af61818-274f-4994-9352-3a5b274ae68b",
                                    "display": "Balazs Nadasdi"
                                },
                                "role": "administrator"
                            },
                            {
                                "user": {
                                    "reference": "user/ecacaf79-7ca8-4294-87c7-3184c123fc97",
                                    "display": "Mamu Petrovics"
                                },
                                "role": "administrator"
                            }
                        ],
                        "managingOrganization": {
                            "reference": "organization/113de399-6a6a-4c4f-b292-f57b6f62cf14",
                            "display": "Kaiser"
                        },
                        "name": "WW",
                        "quantity": 3,
                        "identifier": {
                            "_id": "428862f5-0c66-4fc6-8d85-78743f883fd6",
                            "system": "urn:hc.ge.com/pfh/platform/groupType"
                        },
                        "type": "mdt",
                        "accessType": "public",
                        "active": true
                    }
                },
                {
                    "title": "UserGroup Resource",
                    "id": "30c64e28-9141-4d33-9b0e-43a58c2c1362",
                    "content": {
                        "resourceType": "ResourcesUserGroup",
                        "member": [
                            {
                                "user": {
                                    "reference": "user/7af61818-274f-4994-9352-3a5b274ae68b",
                                    "display": "Balazs Nadasdi"
                                },
                                "role": "administrator"
                            }
                        ],
                        "managingOrganization": {
                            "reference": "organization/113de399-6a6a-4c4f-b292-f57b6f62cf14",
                            "display": "Kaiser"
                        },
                        "name": "Kaiser MDT Group",
                        "quantity": 2,
                        "identifier": {
                            "_id": "30c64e28-9141-4d33-9b0e-43a58c2c1362",
                            "system": "urn:hc.ge.com/pfh/platform/groupType"
                        },
                        "type": "generic",
                        "accessType": "public",
                        "active": true
                    }
                },
                {
                    "title": "UserGroup Resource",
                    "id": "30c64e28-9141-4d33-9b0e-43a58c2c1362",
                    "content": {
                        "resourceType": "ResourcesUserGroup",
                        "member": [
                            {
                                "user": {
                                    "reference": "user/7af61818-274f-4994-9352-3a5b274ae68b",
                                    "display": "Balazs Nadasdi"
                                },
                                "role": "administrator"
                            }
                        ],
                        "managingOrganization": {
                            "reference": "organization/113de399-6a6a-4c4f-b292-f57b6f62cf14",
                            "display": "Kaiser"
                        },
                        "name": "Kaiser MDT Group",
                        "quantity": 2,
                        "identifier": {
                            "_id": "30c64e28-9141-4d33-9b0e-43a58c2c1362",
                            "system": "urn:hc.ge.com/pfh/platform/groupType"
                        },
                        "type": "mdt",
                        "accessType": "public",
                        "active": true
                    }
                }]};

                loggedInUserResult = {
                    "resourceType": "ResourcesUser",
                    "name": {
                        "use": "official",
                        "family": [
                            "Chalmers"
                        ],
                        "given": [
                            "Peter",
                            "James"
                        ]
                    },
                    "role": [
                        {
                            "scopingOrganization": {
                                "reference": "organization/74553d9a-7d1b-4f93-929c-72b6318a6178"
                            },
                            "status": "active"
                        }
                    ],
                    "address": [
                        {
                            "line": [
                                "3300 Washtenaw Avenue, Suite 227"
                            ],
                            "city": "Ann Arbor",
                            "state": "MI",
                            "zip": "48104",
                            "country": "USA"
                        }
                    ],
                    "telecom": [
                        {
                            "system": "phone",
                            "value": "(+1) 734-677-7777"
                        },
                        {
                            "system": "email",
                            "value": "peterjames98@ge.com"
                        }
                    ],
                    "preferredLanguage": "English",
                    "type": "Human",
                    "status": "active",
                    "comment": "This is an Hospital Practioner 1",
                    "principalName": "peterjames98@ge.com",
                    "gender": {
                        "coding": [
                            {
                                "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                "code": "M",
                                "display": "Male"
                            }
                        ]
                    },
                    "acceptedAgreement": [
                        {
                            "agreementUri": "http://goodcare.org/devices/id",
                            "accepted": false
                        }
                    ],
                    "externalId": [
                        {
                            "system": "IDM",
                            "value": "b9f2b0f9-03ab-4d94-bd33-f40b495fc4d5"
                        },
                        {
                            "system": "UOM",
                            "value": "034e2e9b-60b0-4856-85a7-c43779a11746"
                        }
                    ]
                };

                groupList = JSON.parse(JSON.stringify({"data":{"entry":[{"content":{"name":"test"}},{"content":{"name":"test1"}}]}, status:200}));
            });

            beforeEach(inject(function($controller,_groupMgmtService_,$rootScope,$compile,$state, $q, userMgmtService) {
                scope = $rootScope.$new();
                state= $state;
                deferred = $q.defer();
                getAllGroupsDeferred = $q.defer();
                toggleGroupStatusDeferred = $q.defer();
                findGroupDeferred = $q.defer();
                groupMgmtService = _groupMgmtService_;
                _userService = userMgmtService;
                spy = sinon.stub(groupMgmtService, 'getAllGroups').returns(getAllGroupsDeferred.promise);
                spyFindGroup = sinon.stub(groupMgmtService, 'findGroup').returns(findGroupDeferred.promise);
                spyToggleGroupStatus = sinon.stub(groupMgmtService, 'toggleGroupActivityStatus').returns(toggleGroupStatusDeferred.promise);
                setLoggedInUserStub = sinon.stub(_userService, 'getLoggedInUserDetails').returns(deferred.promise);
                $controller('ViewListGroupCtrl',{
                    $scope: scope,
                    $state: state
                });
                scope.$apply();
            }));

            it("On click of 'editGroup' it takes to group details page", function(){
                var stateSpy = sinon.spy(state, "go");
                scope.editGroup({id:'12sd-34av', content:{type:'mdt'}});
                chai.expect(stateSpy.calledWith('orgmanagement.groupDetails'));
            });

            it("On click of 'Create MDT Group' button, it opens form for creating new group", function(){
                var stateSpy = sinon.spy(state, "transitionTo");
                scope.createGroupPage();
                chai.expect(stateSpy.calledWith('orgmanagement.createGroup'));
            });

            beforeEach(function(done){
                deferred.resolve(JSON.parse(JSON.stringify(loggedInUserResult)));
                scope.$root.$digest();
                chai.expect(setLoggedInUserStub.calledOnce).to.be.true;
                done();
            });

            it("checks if 'getAllGroups' service is called successfully", function(done){
                getAllGroupsDeferred.resolve({data:getAllGroups,status:200});
                scope.$root.$digest();
                chai.expect(spy.calledOnce).to.be.true;
                done();
            });

            it("checks if 'getAllGroups' service is not called successfully", function(done){
                getAllGroupsDeferred.reject({data:getAllGroups,status:400});
                scope.$root.$digest();
                chai.expect(spy.calledOnce).to.be.true;
                done();
            });

            it("get all the groups when choosing 'All' in filter by group type", function(done){
                scope.selectedGrpType = 'all';
                scope.filterByGroupTypeActivityStatus();
                getAllGroupsDeferred.resolve({data:getAllGroups,status:200});
                scope.$root.$digest();
                chai.expect(spy.calledTwice).to.be.true;
                done();
            });

            it("get all the MDT groups when choosing 'MDT' in filter by group type", function(done){
                scope.selectedGrpType = 'mdt';
                scope.filterByGroupTypeActivityStatus();
                getAllGroupsDeferred.reject({data:getAllGroups,status:400});
                scope.$root.$digest();
                chai.expect(spy.calledTwice).to.be.true;
                done();
            });
            it("get list of all active group by choosing 'Active' from filter by user status", function(done){
                scope.selectedActivityStatus = 'active';
                scope.filterByGroupTypeActivityStatus();
                getAllGroupsDeferred.resolve({data:getAllGroups,status:200});
                scope.$root.$digest();
                chai.expect(spy.calledTwice).to.be.true;
                done();
            });

            it("get list of all group whether active or deactivated", function(done){
                scope.selectedActivityStatus = 'all';
                scope.filterByGroupTypeActivityStatus();
                getAllGroupsDeferred.resolve({data:getAllGroups,status:200});
                scope.$root.$digest();
                chai.expect(spy.calledTwice).to.be.true;
                done();
            });

            it("get list of all group with applied filter", function(done){
                scope.searchGroupText = 'test';
                scope.selectedGrpType = 'mdt';
                scope.filterByGroupTypeActivityStatus();
                findGroupDeferred.resolve(groupList);
                scope.$root.$digest();
                chai.expect(spyFindGroup.calledOnce).to.be.true;
                done();
            });

            it("deactivate group from list of groups called successfully", function(done){
                var grpObj = getAllGroups.entry[0];
                scope.toggleGroupActivityStatus(grpObj);
                toggleGroupStatusDeferred.resolve({data:grpObj,status:200});
                scope.$root.$digest();
                chai.expect(spyToggleGroupStatus.called).to.be.true;
                done();
            });

            it("deactivate group from list of groups not called successfully", function(done){
                var grpObj = getAllGroups.entry[0];
                scope.toggleGroupActivityStatus(grpObj);
                toggleGroupStatusDeferred.reject({data:grpObj,status:400});
                scope.$root.$digest();
                chai.expect(spyToggleGroupStatus.called).to.be.true;
                done();
            });

            it("on deactivate popup opening check if modal instance is defined", function(){
                var grpObj = getAllGroups.entry[0];
                scope.openDeactivatePopUp(grpObj);
                chai.expect(scope.modalInstance).to.not.be.undefined;
            });

            it('checks for state change listening function', function () {
                var spyNewCreateGroupId = sinon.stub(groupMgmtService, 'setNewCreatedGroupId');
                state.transitionTo('Organization');
                scope.$emit('$stateChangeStart');
                chai.expect(spyNewCreateGroupId.called).to.be.true;
            });

            describe('Test if XSS event has been taken care of when', function(){
                it('user tries to enter the script in input box it must show error on blur', function(){
                    scope.searchGroupTerm = '<script>';
                    scope.$apply();
                    var object = {message: "There is an attempt to insert script."};
                    scope.$emit("SHOW_FAILURE_MESSAGE_NO_TIMEOUT",object.message);
                    chai.expect(scope.closeAlertPressed).to.be.equal(0);
                });

                it('to close the XSS error message box, click on x button', function(){
                    scope.closeAlert();
                    chai.expect(scope.closeAlertPressed).to.be.equal(1);
                });
            });

            it('should filter group list from server after 3 characters typed', function(done){
                var text = 'test';
                scope.textToBeSearched = '';
                scope.searchedSuperSetData = [];

                scope.searchGroup(text);
                findGroupDeferred.resolve(groupList);
                scope.$root.$digest();

                chai.expect(scope.groupList).to.have.length(2);
                done();
            });

            it('should not open group list after 3 characters typed not found', function(done){
                var text = 'test2';
                scope.textToBeSearched = '';
                scope.searchedSuperSetData = groupList.data.entry;

                scope.searchGroup(text);
                findGroupDeferred.reject();
                scope.$root.$digest();

                chai.expect(scope.groupList).to.have.length(0);
                done();
            });

            it('should filter group list at clientside if 3 characters match superSetData', function(done){
                var text = 'test1';
                scope.textToBeSearched = 'tes';
                scope.searchedSuperSetData = groupList.data.entry;

                scope.searchGroup(text);
                findGroupDeferred.resolve(groupList);
                scope.$root.$digest();

                chai.expect(scope.groupList).to.have.length(1);
                done();
            });

            it('should not open group list at clientside if 3 characters not found', function(done){
                var text = 'test2';
                scope.textToBeSearched = 'tes';
                scope.searchedSuperSetData = groupList.data.entry;

                scope.searchGroup(text);
                findGroupDeferred.reject();
                scope.$root.$digest();

                chai.expect(scope.groupList).to.have.length(0);
                done();
            });

            describe('Test typeAhead Search for negative paths', function() {
                beforeEach(function() {
                    scope.searcTriggered=true;
                    getAllGroupsDeferred.resolve({data:getAllGroups,status:200});
                    scope.$root.$digest();
                });
                it('checks getAllGroups call incase typeahead-search was already triggered', function (done) {
                    chai.expect(scope.fullGroupList.length>0).to.be.true;
                    done();
                });
                it('checks searchGroup for less than 3 characters', function (done) {
                    scope.searchGroup('ab');
                    chai.expect(scope.fullGroupList.length===scope.groupList.length).to.be.true;
                    done();
                });
            });

            it('Test filter criteria for search in TypeAhead', function(){
                var searchCriteria,
                    searchParam = {'name': "ab", 'type': "mdt", 'active': true};
                scope.selectedGrpType = 'mdt';
                scope.selectedActivityStatus = 'active';

                searchCriteria = scope.getSearchFilterCriteria('ab');
                chai.expect(searchCriteria.name).to.be.equal(searchParam.name);
            });
        });

        describe('Test the modal instance conroller', function() {
            var scope,modal,filter,ModalInstanceCtrl1,
                modalInstance = { close: function() {}, dismiss: function() {}};
            beforeEach( function(){
                module('Orgmanagement.Features.Group.ViewGroup.ViewListGroupController');
            });
            beforeEach(inject(function($controller,$rootScope, $modal, $filter) {
                scope = $rootScope.$new();
                modal = $modal;
                filter = $filter;
                ModalInstanceCtrl1 = $controller('ModalInstanceCtrl1',{
                    $scope: scope,
                    $modalInstance: modalInstance,
                    groupObj: {}
                });
                scope.$apply();
            }));

            it('should have a controller', function () {
                assert.isDefined(ModalInstanceCtrl1, 'Controller is not defined');
            });
        });
    }
);
