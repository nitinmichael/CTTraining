angular.module('xjtweb-platform').constant('GraphicalObjectMock', {
    graphicalObjectFactoryMock: function() {
        return {
            get: function() {
                return "Ok";
            },
            createMeasure: function(measure) {
                var obj = new THREE.Object3D();
                obj.name = measure.id;
                return obj;
            },
            createCursor3D: function(cursor) {
                var obj = new THREE.Object3D();
                obj.name = cursor.id;
                return obj;
            },
            subscribe: sinon.spy(),
            deleteObject: function() {}
        };
    },

    CameraFactoryMock: function() {
        return {
            createOrthographicCamera: function() {
                return {
                    updateMatrixWorld: function() {},
                    position: {
                        z: 0
                    },
                    quaternion: {
                        x: 0,
                        y: 0,
                        z: 0,
                        w: 0
                    }
                };
            }
        };
    },

    RendererFactoryMock: function() {
        return {
            createWebGLRenderer: function() {
                return {
                    renderViewport: function() {}
                };
            }
        };
    },

    SceneManagerMock: function(isVolumeAdded, postal) {
        var result = {
            addViewport: function() {},
            addGroup: function() {},
            addMeasure: sinon.spy(),
            addCursor3D: sinon.spy(),
            mouseTo3DCoordinate: function() {
                return null;
            },
            channel: postal.channel(XJTWEB.SCENE_MANAGER.CHANNEL),
            render: sinon.spy(),
            publish: sinon.spy(),
            subscribe: sinon.spy(),
            destroy: sinon.spy(),
            exists: function() {
                return isVolumeAdded;
            },
            requestRender: sinon.spy()
        };
        return result;
    },

    SceneManagerNoIntersectMock: function() {
        return {
            mouseTo3DCoordinate: function() {
                return null;
            },
        };
    },
    SceneManagerIntersectMock: function() {
        return {
            mouseTo3DCoordinate: function() {
                return {
                    x: 10,
                    y: 10,
                    z: 10
                };
            },
        };
    },

    createMeasure: function(params) {
        var result = {
            type: 'distance',
            id: 'line1',
            parent_id: 'volume2',
            callbacks: {},
            color: 0xFF0000,
            points: [{
                x: 0,
                y: 0,
                z: 0
            }, {
                x: 1,
                y: 1,
                z: 1
            }],
            visible: true,
            subscribe: function(event, fn) {
                this.callbacks[event] = fn;
            },
            publishMock: function(event) {
                this.callbacks[event]();
            },
            remove: function() {
                this.callbacks[XJTWEB.MEASURE.TOPIC.REMOVE]();
            },
            setVisibility: function(state) {
                this.visible = state;
                this.publishMock(XJTWEB.MEASURE.TOPIC.VISIBILITY);
            }
        };
        for (var i in params) {
            if (params.hasOwnProperty(i)) {
                result[i] = params[i];
            }
        }
        return result;
    },

    raycasterFactoryIntersectMock: function() {
        return {
            createRaycaster: function() {
                return {
                    intersectObjects: function() {
                        return [{
                            object: {
                                name: XJTWEB.MANIPULATOR_NAME,
                                model: {},
                                quaternion: {
                                    copy: function() {}
                                },
                                object: {
                                    parent: {}
                                }
                            }
                        }];
                    },
                    setFromCamera: function() {}
                };
            },
        };
    },

    raycasterFactoryNoIntersectMock: function() {
        return {
            createRaycaster: function() {
                return {
                    intersectObjects: function() {
                        return [];
                    },
                    setFromCamera: function() {}
                };
            },
        };
    },

    MeasureManagerMock: function(postal) {

        var mock = {
            measure: null,
            addMeasure: function(measure) {
                this.measure = measure;
            },
            channel: postal.channel(XJTWEB.MEASURE_MANAGER.CHANNEL),
            publish: sinon.spy(),
            subscribe: sinon.spy(),
            destroy: sinon.spy(),
            getMeasureList: sinon.spy(),
            getSelectedMeasure: sinon.spy(),
            setSelectedMeasure: sinon.spy(),
            removeMeasure: function() {}
        };
        return mock;
    },


    CursorManagerMock: function(postal) {
        var cursorChannel = postal.channel(XJTWEB.CURSOR3D.CHANNEL);

        var cursor3DModelMock = function(volumeId) {
            var mock = {
                isCalled: false,
                parent_id: volumeId,
                channel: cursorChannel,
                position: undefined,
                name: undefined,
                id: undefined,
                subscribe: sinon.spy(),
                setPosition: function() {
                    this.isCalled = true;
                },
                getPosition: sinon.stub().returns([0, 0, 0])
            };
            return mock;
        };

        var mock = {
            selectedCursor: cursor3DModelMock('id'),
            createCursor3D: function(volumeID) {
                this.selectedCursor = cursor3DModelMock(volumeID);
                return this.selectedCursor;
            },
            setSelectedCursor: function() {},
            getSelectedCursor: function() {
                return this.selectedCursor;
            },
            getCursor: sinon.stub().returns({setPosition: sinon.spy()}),
            destroy: sinon.spy(),
            setPosition: sinon.spy()
        };
        return mock;
    }

});
