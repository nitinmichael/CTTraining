define(['angular-mocks', 'modules/platform/services/popup-closer-service'], function() {
    describe('Test $popupCloserService service', function() {
        var $document, $popupCloserService, $rootScope;

        beforeEach(function() {
            module('platform.service.popup-closer-service');

            module(function($provide) {
                $document = {
                    on: sinon.spy()
                };

                $provide.value('$document', $document);
            });

            inject(function(_$popupCloserService_, _$rootScope_) {
                $popupCloserService = _$popupCloserService_;
                $rootScope = _$rootScope_;
            });
        });

        it('should be defined', function() {
            expect($popupCloserService).to.exist;
        });

        it('touchend and click events should be catched', function() {
            expect($document.on.calledOnce).to.equal(true);
        });

        it('click outside a popover should send a close event', function() {
            var spy = sinon.spy($rootScope, '$broadcast'),
                e = {
                    target: 'target'
                };
            $document.on.args[0][1](e);
            expect(spy.calledWith('close', e.target)).to.equal(true);
        });

        it('closePopup should send a close event', function() {
            var spy = sinon.spy($rootScope, '$broadcast');
            $popupCloserService.closePopup();
            expect(spy.calledWith('close')).to.equal(true);
        });
    });
});
