define([ 'require', 'jquery' ], function(requireInfo, $) {

    describe('Test require-config used by tracing', function() {

        // we must NOT load the script using RequireJS (as it calls require.config(), it will interfere with the test
        // requirejs.config
        var scriptUrl = requireInfo.toUrl('modules/viewer/tracing/require-config.js');

        var scriptUrl;
        var rtree;
        var ngTracing;

        var createMocks = function() {
            // stub out the real require code until the test is executed
            sinon.stub(window, 'require')
            window.require.config = sinon.stub();

            // stub the other methods invoked by the script (RequireJS and Angular tracing methods)
            rtree = window.rtree || createMockRtree();
            ngTracing = window.ngTracing || createMockNgTracing();

            sinon.stub(rtree);
            sinon.stub(ngTracing);
        }

        var createMockRtree = function() {
            return {
                printModuleInfo : sinon.stub()
            };
        }

        var createMockNgTracing = function() {
            return {
                printModuleInfo : sinon.stub()
            };
        }

        var restoreMocks = function() {
            window.require.restore();
            sinon.restore(rtree);
            sinon.restore(ngTracing);
        };

        it('can be loaded', function(done) {

            $.ajax(scriptUrl, {
                dataType : 'text'
            }).fail(done).done(function(scriptContent) {
                try {
                    createMocks();

                    eval(scriptContent);

                    expect(require.config.called).to.equal(true);
                    expect(require.calledOnce).to.equal(true);

                    var requireCallback1 = require.getCall(0).args[1];

                    requireCallback1();
                    expect(require.calledTwice).to.equal(true);

                    var requireCallback2 = require.getCall(1).args[1];
                    requireCallback2();

                    expect(rtree.printModuleInfo.called).to.equal(true);
                } finally {
                    restoreMocks();
                }

                done();
            });
        });

    });
})