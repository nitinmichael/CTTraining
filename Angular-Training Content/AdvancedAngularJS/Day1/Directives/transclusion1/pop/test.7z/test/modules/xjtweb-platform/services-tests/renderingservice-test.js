define(['angular', 'angular-mocks', 'modules/xjtweb-platform/services/rendering-service'], function(ng, mocks) {
    'use strict';

    describe('renderingService service test', function() {
        var $httpBackend, $interval, $logger, $rootScope, renderingService, requestSessionHandler, requestDeleteSessionHandler, requestImageHandler, requestSessionConfigurationHandler, BddEventAccumulator;
        var groupUid = '12345678910';

        beforeEach(function() {

            module('cloudav.renderingService');

            module(function($provide) {
                $provide.factory('serviceDiscovery', function($q) {
                    return {
                        getServiceUrl: function(name) {
                            var deferred = $q.defer();
                            deferred.resolve('url');
                            return deferred.promise;
                        }
                    };
                });

                $provide.value('$logger', {
                    log: sinon.spy(),
                    fatal: sinon.spy(),
                    error: sinon.spy()
                });

                $provide.value(Date.class, {
                    getTime: function() {
                        return 0;
                    }
                });

                $provide.value('BddEventAccumulator', {
                    BDD_Events_Modes: {
                        CHANNEL: 'GMC_CHANNEL',
                        TOPIC: {
                            ALL: 'GMC.*.*',
                            INTERACTION: {
                                REQUEST_SENT: "GMC.INTERACTION.REQUEST_SENT"
                            },
                            VIEWPORT: {
                                UPDATE: 'GMC.VIEWPORT.UPDATE',
                                IMAGE_UPDATED: 'GMC.VIEWPORT.IMAGE_UPDATED'
                            }
                        }
                    },
                    appendNewEvent: function(data, event) {}
                });
            });

            inject(function(_$httpBackend_, _$rootScope_, _$interval_, _$logger_, _renderingService_) {
                $httpBackend = _$httpBackend_;
                $interval = _$interval_;
                $logger = _$logger_;
                $rootScope = _$rootScope_;
                renderingService = _renderingService_;

                requestSessionHandler = $httpBackend.when('GET', 'url/v1/session?groupUid=' + groupUid)
                    .respond(503, 'Service Unavailable');

                requestDeleteSessionHandler = $httpBackend.when('DELETE', 'url/v1/session')
                    .respond({});

                requestImageHandler = $httpBackend.when('POST', 'url/v1/image')
                    .respond({});

                requestSessionConfigurationHandler = $httpBackend.when('GET', '/rendering/session')
                    .respond(function() {
                        return [200, '', {
                            'X-RenderingSession': '{ "maxRetries": "20" , "keepAliveDelay": "30", "keepAliveTimeout": "600" }'
                        }, 'ok'];
                    });
            });
        });

        afterEach(function() {
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        });

        /*
         * @ngdoc method
         * @name renderingServiceServiceTest
         *
         * @description This test method determines that the renderingService works well
         */
        describe('Testing renderingService', function() {
            it('openSession should be defined', function() {
                assert(typeof renderingService.openSession === 'function', 'renderingService service should have a openSession function defined');
            });

            it('calling openSession with an invalid renderer type should return an error', function() {
                renderingService.openSession(groupUid, 'WXRT', 'url')
                    .then(function() {
                        assert(false, 'The returned promise of openSession called with an invalid rendererType must no be fulfilled');
                    }).catch(function(error) {
                        expect(error).to.equal('WXRT is not a valid rendererType');
                    });
                $rootScope.$apply();
            });

            it('calling openSession with a valid type must not return an error', function() {
                var attempts = 4;
                requestSessionHandler.respond(function() {
                    if (attempts === 2) {
                        return [200, '', null, 'ok'];
                    } else {
                        attempts = attempts - 1;
                        return [503, '', null, 'Service Unavailable'];
                    }
                });
                renderingService.openSession(groupUid, 'VR', 'url')
                    .then(function() {
                        assert(true, 'Should be successfull');
                    }).catch(function() {
                        assert(false, 'Should not return an error');
                    });
                $httpBackend.flush();
                $rootScope.$apply();
            });

            it('calling openSession must return an error if the number of attempts has been exceeded', function() {
                renderingService.openSession(groupUid, 'VR', 'url')
                    .then(function() {
                        assert(false, 'Should not be successfull');
                    }).catch(function(error) {
                        expect(error).to.equal('Exceeded number of attempts to get a session');
                    });
                $httpBackend.flush();
                $rootScope.$apply();
            });

            it('calling openSession with a valid type must not return an error', function() {
                requestSessionHandler.respond(function() {
                    return [200, '', null, 'ok'];
                });

                renderingService.openSession(groupUid, 'VR', 'url')
                    .then(function() {
                        assert(true, 'Should be successfull');
                    }).catch(function() {
                        assert(false, 'Should not return an error');
                    });
                $httpBackend.flush();
                $rootScope.$apply();
            });


            it('calling getImage should send an http request', function() {
                var renderingObj = {
                    rendererType: 'VR',
                    baseUrl: 'url',
                    data: {
                        prop1: 'value1'
                    }
                };

                var callback = function() {};

                var context = {
                    saveLastRTT: function() {}
                };

                renderingService.getImage(renderingObj, callback, context);
                $httpBackend.flush();
            });

            it('getImage should add a keep alive session if it does not exist', function() {
                var renderingObj = {
                    rendererType: 'VR',
                    baseUrl: 'url',
                    data: {
                        prop1: 'value1'
                    }
                };

                var callback = function() {};

                var context = {
                    saveLastRTT: function() {}
                };

                var spy = sinon.spy(renderingService, '_addKeepAliveSession');

                renderingService.getImage(renderingObj, callback, context);
                $httpBackend.flush();
                expect(renderingService._keepAlive().sessions.length).to.equal(1);

                renderingService.getImage(renderingObj, callback, context);
                $httpBackend.flush();
                expect(renderingService._keepAlive().sessions.length).to.equal(1);
            });

            it('initKeepAlive should be defined', function() {
                assert(typeof(renderingService._initKeepAlive), 'function', 'renderingService service should have a private initKeepAlive function defined');
            });

            it('initKeepAlive should defined keepAlive object', function() {
                renderingService._initKeepAlive();
                expect(typeof renderingService._keepAlive()).to.equal('object');
            });

            it('initKeepAlive should log an error if its already initialized', function() {
                renderingService._initKeepAlive();
                renderingService._initKeepAlive();
                expect($logger.error.calledOnce).to.equal(true);
            });

            it('addKeepAliveSession should add session if keepAlive object is defined', function() {
                renderingService._initKeepAlive(1, 10);
                renderingService._addKeepAliveSession('groupUid', 'type1');
                renderingService._addKeepAliveSession('groupUid', 'type2');
                expect(renderingService._keepAlive().sessions.length).to.equal(2);
            });

            it('addKeepAliveSession should not add session if keepAlive object is defined and session already added', function() {
                renderingService._initKeepAlive(1, 10);
                renderingService._addKeepAliveSession('groupUid', 'type', 'url', 1, 10);
                renderingService._addKeepAliveSession('groupUid', 'type', 'url', 1, 10);
                expect(renderingService._keepAlive().sessions.length).to.equal(1);
            });

            it('keep alive requests should be sent after the predefined delay', function() {
                renderingService._initKeepAlive(1, 10);
                renderingService._addKeepAliveSession('groupUid', 'type', 'url');
                $httpBackend.expectPOST('url/v1/image');
                $interval.flush(1000);
                $httpBackend.flush();
            });

            it('should stop keep alive after the predefined timeout', function() {
                renderingService._initKeepAlive(1, 0);
                renderingService._addKeepAliveSession('groupUid', 'type', 'url');
                $interval.flush(2000);
                expect(renderingService._keepAlive()).to.equal(undefined);
            });

            it('the stopKeepAlive function should stop the keep alive', function() {
                renderingService._initKeepAlive(1, 1);
                renderingService._addKeepAliveSession('groupUid', 'type', 'url');
                expect(typeof renderingService._keepAlive()).to.equal('object');

                renderingService.stopKeepAlive();
                expect(renderingService._keepAlive()).to.equal(undefined);
            });

            it('call the stopKeepAlive function should not throw any error if there is no keep alive', function() {
                var error = false;

                try {
                    renderingService.stopKeepAlive();
                } catch (e) {
                    error = true;
                }

                expect(error).to.equal(false);
            });

            it('isKeepAliveInitialized should return true if the keep alive is initialized or false otherwise', function() {
                expect(renderingService._isKeepAliveInitialized()).to.equal(false);
                renderingService._initKeepAlive(1, 10);
                expect(renderingService._isKeepAliveInitialized()).to.equal(true);
            });

            it('hasKeepAliveSession should return true if the keep alive session exists or false otherwise', function() {
                renderingService._initKeepAlive(1, 10);
                expect(renderingService._hasKeepAliveSession('type')).to.equal(false);
                renderingService._addKeepAliveSession('groupUid', 'type', 'url');
                expect(renderingService._hasKeepAliveSession('type')).to.equal(true);
            });
        });
    });
});
