/*
 * mdt-case-data-service-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/**
 * Created by 212408578 on 2015.12.08..
 */

define(['angular', 'angular-mocks', 'mdt/services/mdt-case-data-service'], function () {
    'use strict';
    describe("MdtSessionDataService ", function () {
        var MdtCaseDataService;

        beforeEach(function () {
            module('Mdt.Module.MdtCaseDataService');

            inject(function (_MdtCaseDataService_) {
                MdtCaseDataService = _MdtCaseDataService_;
            });
        });

        it("should return empty object when retrieveSelectedItem called with id = null", function () {
            var selectedCase = MdtCaseDataService.retrieveSelectedItem(null);
            expect(selectedCase).to.be.empty;
        });

        it("should return next case id", function () {
            var sessionId = "id";
            var session = {meetingId: sessionId,
                cases: [{id: "5",
                    status: "IN_REVIEW"},
                    {id: "6",
                        status: "IN_REVIEW"}]};
            MdtCaseDataService.updateItemList(session.cases);
            MdtCaseDataService.getSelectedItemObj().value = 0;
            MdtCaseDataService.retrieveSelectedItem("5");

            // relative to selected case
            var nextCaseId = MdtCaseDataService.getNextCaseId("5");
            expect(nextCaseId).to.be.equal("6");

            //relative to not selected case
            nextCaseId = MdtCaseDataService.getNextCaseId("5");
            expect(nextCaseId).to.be.null;

            MdtCaseDataService.updateItemList([]);
        });
    });
});
