/*
 *  slider-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *   Emna Turki <emna.turky@ge.com>
 */

/**
 * Spec file for Viewer > modules > mousemanagement > widgets > imageAreaToolbar directive
 */

define(['angular', 'angular-mocks', 'mousemanagementModule/module', 'platformMock', 'mousemanagementModule/widgets/slider'], function(angular) {
    'use strict';

    describe('Slider directive test:', function() {
        var element, scope, isolatedScope, httpBackend;

        beforeEach(function() {

            module('cloudav.viewerApp.mousemanagement');
            module('platform');
            module('templates');
            module('xjtweb-platform');

            inject(function($compile, $rootScope, $httpBackend) {

                $httpBackend.whenGET('./modules/viewer/modules/mousemanagement/images/icons/ViewerIcons_bookmark_vprev_lg.svg').respond('');
                $httpBackend.whenGET('./modules/viewer/modules/mousemanagement/images/icons/ViewerIcons_bookmark_vnext_lg.svg').respond('');

                element = angular.element('<slider></slider>');
                scope = $rootScope.$new();
                $compile(element)(scope);
                scope.$digest();
                isolatedScope = element.isolateScope();

                isolatedScope.innerSlider = {
                    mousedown: sinon.spy(),
                    mouseup: sinon.spy(),
                    bind: sinon.spy()
                };
                isolatedScope.$apply();

                $httpBackend.flush();
                httpBackend = $httpBackend;
            });
        });

        afterEach(function() {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('should have a directive', function() {
            assert.isDefined(element, 'slider directive is not defined');
        });

        it('innerSlider should be set up', function() {
            expect(isolatedScope.innerSlider.mousedown.calledOnce).to.equal(true);
            expect(isolatedScope.innerSlider.mouseup.calledOnce).to.equal(true);
            expect(isolatedScope.innerSlider.bind.called).to.equal(true);
        });

        it('innerSlider mousedown event should set isSliding to true', function() {
            isolatedScope.innerSlider.mousedown.args[0][0]();
            expect(isolatedScope.isSliding).to.equal(true);
        });

        it('innerSlider mouseup event should set isSliding to false', function() {
            isolatedScope.isSliding = true;
            isolatedScope.innerSlider.mouseup.args[0][0]();
            expect(isolatedScope.isSliding).to.equal(false);
        });

        it('innerSlider input event should set isSliding to true', function() {
            isolatedScope.innerSlider.bind.args[0][1]();
            expect(isolatedScope.isSliding).to.equal(true);
        });

        it('innerSlider input event should set delta', function() {
            isolatedScope.sliderVal = {
                getValue: function() {
                    return 1;
                }
            };
            isolatedScope.innerSlider.bind.args[0][1]();
            isolatedScope.innerSlider.bind.args[0][1]();
            expect(isolatedScope.delta).to.equal(0);
        });

        it('innerSlider input event should call onInputCallBack if defined', function() {
            isolatedScope.onInputCallBack = sinon.spy();
            isolatedScope.innerSlider.bind.args[0][1]();
            expect(isolatedScope.onInputCallBack.calledOnce).to.equal(true);
        });

        it('bookmarks buttons should be defined', function() {
            expect(typeof isolatedScope.scrollButtons[0].icon).to.equal('string');
            expect(typeof isolatedScope.scrollButtons[1].icon).to.equal('string');
            expect(typeof isolatedScope.scrollButtons[0].click).to.equal('function');
            expect(typeof isolatedScope.scrollButtons[1].click).to.equal('function');
        });

        it('set the slider value of sliderVal should set currentValue', function() {
            isolatedScope.sliderVal.slider = 42;
            expect(isolatedScope.currentValue).to.equal(42);
        });

        it('set setValue should set oldSliderValue', function() {
            isolatedScope.setValue = 42;
            isolatedScope.$apply();
            expect(isolatedScope.oldSliderValue).to.equal(42);
        });

        it('the setValue function of sliderValue should not set oldSliderValue if isSliding is true', function() {
            isolatedScope.isSliding = true;
            isolatedScope.sliderVal.setValue(42);
            expect(isolatedScope.oldSliderValue).to.not.equal(42);
        });
    });
});
