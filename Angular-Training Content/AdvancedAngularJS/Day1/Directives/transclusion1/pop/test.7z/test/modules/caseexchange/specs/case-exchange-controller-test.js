/*
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular', 'angular-mocks', 'case-inbox/module',
        'platform/directives/ge-notification/ge-notification-directive',
        'platform/services/notification-service'], function () {
    'use strict';
    describe('Case Exchange Controller Test Suite::', function () {
        var scope, controller, notificationService;
        beforeEach(function() {
            module('Services.caseExchangeDataService');
            module('cloudav.caseExchange.caseExchangeCtrl', function ($provide) {
                $provide.value('$state', {
                    transitionTo: function () {}
                });

                $provide.value('$stateParams', {});

                $provide.value('$Endpoint', {
                    getEndpointAsync: function(){
                        return {
                            then: function(callback){callback();}
                        };
                    }
                });

                $provide.factory('configurationService', ['$q', function($q){
                    return {
                        getProperty: function(){
                            return $q.when({});
                        }
                    }
                }]);

            });

            inject(function ($rootScope, $controller, NotificationService){
                scope = $rootScope.$new();
                controller = $controller;
                notificationService = NotificationService;
                //Initialize the controller
                controller('CaseExchangeCtrl', { $scope: scope });
            });
        });

        it('should have a controller', function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it('should have "alertTypes" variable defined', function () {
            assert.isDefined(scope.alertTypes, 'Scope doesn\'t have "alertTypes" variable defined');
        });

        describe('Test suite for "showAlertMessage" function', function(){
            var msgText, type;
            beforeEach(function () {
                msgText = 'This is a test message';
                type = 'success';
            });

            it('should have "showAlertMessage" function defined', function(){
                assert.isDefined(scope.showAlertMessage, 'Scope doesn\'t have "showAlertMessage" function defined');
            });

            it('should call the "addSuccessMessage" on call of "showAlertMessage" function with type success', function(){
                var addSuccessMessageSpy = sinon.spy(notificationService, 'addSuccessMessage');
                scope.showAlertMessage(msgText, type);
                expect(addSuccessMessageSpy.calledOnce).to.true;
            });

            it('should call the "addErrorMessage" on call of "showAlertMessage" function with type error', function(){
                var addErrorMessageSpy = sinon.spy(notificationService, 'addErrorMessage');
                type = 'error';
                scope.showAlertMessage(msgText, type);
                expect(addErrorMessageSpy.calledOnce).to.true;
            });

        });
    });

});
