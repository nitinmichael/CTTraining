define(['angular',
        'angular-mocks',
        'orgMgmnt/features/organization/organizationDetail/controllers/organizationDetailsController',
        'orgMgmnt/dataModels/organizationDataModel',
        'orgMgmnt/services/organizationService',
        'orgMgmnt/utilities/masterDataUtil',
        'angularTranslate',
        'angularTranslatePartialLoader',
        'orgMgmnt/services/organizationService',
        'orgMgmnt/services/userService'
    ],
    function() {
        'use strict';

        describe('Test the Organization Detail Controller', function () {
            var OrganizationDetailsCtrl, scope, Q, deferred, _log, rootScope, _state,_filter,
                loggedInUserContextServiceResponse, deffered1,deffered2,contact,df, findUserDeferred, searchUserResult,
                _userService, updateOrgAdminsDef, _orgMgmtService;
            var createOrgResponse=function (){
                var address = [];
                address.push({city:'',country:'',line:['some addr','some addr1'],state:{id:5},zip:2343});
                var extension = [
                    {
                        "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                        "valueString": "Sparx"
                    },
                    {
                        "url": "urn:hc.ge.com/pfh/platform/extension/orgresource:V1",
                        "valueResource":
                        {
                            "reference": "Organization/1",
                            "display": "Network is visible in Directory"
                        }


                    },
                    {
                        "url": "urn:hc.ge.com/pfh/platform/extension/orgresource:V1",
                        "valueResource":
                        {
                            "reference": "Organization/2",
                            "display": "Route network cases to"
                        }


                    },
                    {
                        "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                        "valueCoding": {
                            "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                            "code": "_case_reshare_inside_new_site",
                            "display": "Allow re-share"
                        }
                    },
                    {
                        "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                        "valueCoding": {
                            "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                            "code": "_case_reshare_outside_new_site",
                            "display": "Allow Clinician/Staff re-share outside this network"
                        }
                    },
                    {
                        "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                        "valueCoding": {
                            "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                            "code": "_case_download_inside_new_site",
                            "display": "Allow download of case files"
                        }
                    },
                    {
                        "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                        "valueCoding": {
                            "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                            "code": "_case_download_outside_new_site",
                            "display": "Allow Clinician/Staff to download outside this network"
                        }
                    },
                    {
                        "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                        "valueCoding": {
                            "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                            "code": "_case_reshare_outside_network",
                            "display": "Allow sharing outside of network"
                        }
                    },
                    {
                        "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                        "valueCoding": {
                            "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                            "code": "_case_download_inside_network",
                            "display": "Allow download of case files"
                        }
                    },
                    {
                        "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                        "valueCoding": {
                            "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                            "code": "_site_visible_network_users_default",
                            "display": "Sites visible to network users by default?"
                        }
                    },
                    {
                        "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                        "valueCoding": {
                            "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                            "code": "_case_route_network_admin",
                            "display": "Cases sent to network routed to Admin?"
                        }
                    }
                ];
                contact=JSON.parse(JSON.stringify([{"name":{"text":"jfk"},"telecom":[{"system":"phone","value":"333233-3333333333"},{"system":"email","value":"abc.abc.in"}]}]));
                var responseData ={data:{
                    orgName :'Manipal',
                    address :address,
                    contact:contact,
                    extension:extension,
                    entry:[{
                        id:"034e2e9b-60b0-4856-85a7-c43779a89678",
                        content:{
                            principalName: "yash23.yash23@ge.com",
                            name:{
                                given:["yash23"]
                            }
                        }
                    },
                    {
                            id:"034e2e9b-60b0-4856-85a7-c43779a11746",
                            content:{
                                principalName: "tushar.tari@ge.com",
                                name:{
                                    given:["Tushar","K"]
                                }
                            }
                    }]
                    },status:200};
                return responseData;
            };
            beforeEach(function () {
                module('Orgmanagement.Features.Organization.OrganizationDetail.OrganizationDetailsController');
                module('Orgmanagement.DataModel.OrgDataModel');
                module('Orgmanagement.Services.OrganizationService');
                module('Orgmanagement.Utilities.MasterData');
                module('ui.router');
                module('pascalprecht.translate');
                module('Orgmanagement.Services.OrganizationService');
                module('Orgmanagement.Services.UserService');
            });
            beforeEach(inject(function ($controller, $rootScope, orgDataModel, orgMgmtService ,$q, $log, $state, $filter, userMgmtService) {
                scope = $rootScope.$new();
                rootScope = $rootScope;
                orgDataModel = orgDataModel;
                _orgMgmtService = orgMgmtService;
                Q = $q;
                deferred = Q.defer();
                deffered1=Q.defer();
                df=Q.defer();
                _log = $log;
                _state = $state;
                _filter=$filter;
                findUserDeferred = $q.defer();
                updateOrgAdminsDef = $q.defer();
                _userService=userMgmtService;
                sinon.stub(orgMgmtService, 'updateOrganizationDetail').returns(deferred.promise);
                sinon.stub(orgMgmtService, 'getOrganizationDetail').returns(deferred.promise);
                sinon.stub(orgMgmtService, 'updateOrganizationNetworkSettings').returns(deferred.promise);
                sinon.stub(orgMgmtService, 'updateOrganizationDefaultNetworkSettings').returns(deferred.promise);
                sinon.stub(orgMgmtService, 'getOrgAdmins').returns(deffered1.promise);
                sinon.stub(orgMgmtService, 'updateOrgAdmins').returns(updateOrgAdminsDef.promise);
                sinon.stub(_userService, 'findUser').returns(findUserDeferred.promise);
                sinon.stub(_log, 'info');
                sinon.stub(orgMgmtService,'updateOrganizationAccountOwnerDetail').returns(df.promise);

                $rootScope.selectedOrg = {id:"656565"};
                $rootScope.countryStatesData =
                        [
                            {
                                "name": "United States of America",
                                "code": "US",
                                "states": [
                                    {
                                        "name": "Alabama",
                                        "code": "AL"
                                    },
                                    {
                                        "name": "Alaska",
                                        "code": "AK"
                                    },
                                    {
                                        "name": "American Samoa",
                                        "code": "AS"
                                    },
                                    {
                                        "name": "Arizona",
                                        "code": "AZ"
                                    },
                                    {
                                        "name": "Arkansas",
                                        "code": "AR"
                                    },
                                    {
                                        "name": "California",
                                        "code": "CA"
                                    },
                                    {
                                        "name": "Colorado",
                                        "code": "CO"
                                    },
                                    {
                                        "name": "Connecticut",
                                        "code": "CT"
                                    },
                                    {
                                        "name": "Delaware",
                                        "code": "DE"
                                    },
                                    {
                                        "name": "District Of Columbia",
                                        "code": "DC"
                                    },
                                    {
                                        "name": "Federated States Of Micronesia",
                                        "code": "FM"
                                    },
                                    {
                                        "name": "Florida",
                                        "code": "FL"
                                    },
                                    {
                                        "name": "Georgia",
                                        "code": "GA"
                                    },
                                    {
                                        "name": "Guam",
                                        "code": "GU"
                                    },
                                    {
                                        "name": "Hawaii",
                                        "code": "HI"
                                    },
                                    {
                                        "name": "Idaho",
                                        "code": "ID"
                                    },
                                    {
                                        "name": "Illinois",
                                        "code": "IL"
                                    },
                                    {
                                        "name": "Indiana",
                                        "code": "IN"
                                    },
                                    {
                                        "name": "Iowa",
                                        "code": "IA"
                                    },
                                    {
                                        "name": "Kansas",
                                        "code": "KS"
                                    },
                                    {
                                        "name": "Kentucky",
                                        "code": "KY"
                                    },
                                    {
                                        "name": "Louisiana",
                                        "code": "LA"
                                    },
                                    {
                                        "name": "Maine",
                                        "code": "ME"
                                    },
                                    {
                                        "name": "Marshall Islands",
                                        "code": "MH"
                                    },
                                    {
                                        "name": "Maryland",
                                        "code": "MD"
                                    },
                                    {
                                        "name": "Massachusetts",
                                        "code": "MA"
                                    },
                                    {
                                        "name": "Michigan",
                                        "code": "MI"
                                    },
                                    {
                                        "name": "Minnesota",
                                        "code": "MN"
                                    },
                                    {
                                        "name": "Mississippi",
                                        "code": "MS"
                                    },
                                    {
                                        "name": "Missouri",
                                        "code": "MO"
                                    },
                                    {
                                        "name": "Montana",
                                        "code": "MT"
                                    },
                                    {
                                        "name": "Nebraska",
                                        "code": "NE"
                                    },
                                    {
                                        "name": "Nevada",
                                        "code": "NV"
                                    },
                                    {
                                        "name": "New Hampshire",
                                        "code": "NH"
                                    },
                                    {
                                        "name": "New Jersey",
                                        "code": "NJ"
                                    },
                                    {
                                        "name": "New Mexico",
                                        "code": "NM"
                                    },
                                    {
                                        "name": "New York",
                                        "code": "NY"
                                    },
                                    {
                                        "name": "North Carolina",
                                        "code": "NC"
                                    },
                                    {
                                        "name": "North Dakota",
                                        "code": "ND"
                                    },
                                    {
                                        "name": "Northern Mariana Islands",
                                        "code": "MP"
                                    },
                                    {
                                        "name": "Ohio",
                                        "code": "OH"
                                    },
                                    {
                                        "name": "Oklahoma",
                                        "code": "OK"
                                    },
                                    {
                                        "name": "Oregon",
                                        "code": "OR"
                                    },
                                    {
                                        "name": "Palau",
                                        "code": "PW"
                                    },
                                    {
                                        "name": "Pennsylvania",
                                        "code": "PA"
                                    },
                                    {
                                        "name": "Puerto Rico",
                                        "code": "PR"
                                    },
                                    {
                                        "name": "Rhode Island",
                                        "code": "RI"
                                    },
                                    {
                                        "name": "South Carolina",
                                        "code": "SC"
                                    },
                                    {
                                        "name": "South Dakota",
                                        "code": "SD"
                                    },
                                    {
                                        "name": "Tennessee",
                                        "code": "TN"
                                    },
                                    {
                                        "name": "Texas",
                                        "code": "TX"
                                    },
                                    {
                                        "name": "Utah",
                                        "code": "UT"
                                    },
                                    {
                                        "name": "Vermont",
                                        "code": "VT"
                                    },
                                    {
                                        "name": "Virgin Islands",
                                        "code": "VI"
                                    },
                                    {
                                        "name": "Virginia",
                                        "code": "VA"
                                    },
                                    {
                                        "name": "Washington",
                                        "code": "WA"
                                    },
                                    {
                                        "name": "West Virginia",
                                        "code": "WV"
                                    },
                                    {
                                        "name": "Wisconsin",
                                        "code": "WI"
                                    },
                                    {
                                        "name": "Wyoming",
                                        "code": "WY"
                                    }
                                ]
                            }
                        ];
                loggedInUserContextServiceResponse={
                    "resourceType": "ResourcesUser",
                    "name": {
                        "use": "official",
                        "family": [
                            "Tari"
                        ],
                        "given": [
                            "Tushar",
                            "K"
                        ]
                    },
                    "telecom": [
                        {
                            "system": "phone",
                            "value": "(+1) 734-677-7777"
                        },
                        {
                            "system": "email",
                            "value": "tushar.tari@ge.com"
                        }
                    ],
                    "principalName": "tushar.tari@ge.com"
                };
                searchUserResult = {
                    "resourceType": "Bundle",
                    "title": "List of all groups for user",
                    "id": null,
                    "data": {
                        "entry": [
                            {
                                "title": null,
                                "id": "034e2e9b-60b0-4856-85a7-c43779a11746",
                                "content": {
                                    "resourceType": "ResourcesUser",
                                    "name": {
                                        "use": "official",
                                        "family": [
                                            "Tari"
                                        ],
                                        "given": [
                                            "Tushar",
                                            "K"
                                        ]
                                    },
                                    "externalId": [
                                        {
                                            "system": "IDM",
                                            "value": "b9f2b0f9-03ab-4d94-bd33-f40b495fc4d5"
                                        },
                                        {
                                            "system": "UOM",
                                            "value": "034e2e9b-60b0-4856-85a7-c43779a11746"
                                        },
                                        {
                                            "_id": "tushar.tari@ge.com",
                                            "system": "urn:hc.ge.com/pfh/platform/useremail"
                                        }
                                    ],
                                    "role": [
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "practitioner",
                                                    "display": "practitioner"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "organization/5"
                                            },
                                            "status": "active"
                                        },
                                        {
                                            "code": [
                                                {
                                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                    "code": "practitioner",
                                                    "display": "practitioner"
                                                }
                                            ],
                                            "scopingOrganization": {
                                                "reference": "organization/6"
                                            },
                                            "status": "active"
                                        }
                                    ],
                                    "managingOrganization": {
                                        "organization": {
                                            "reference": "organization/74553d9a-7d1b-4f93-929c-72b6318a6178"
                                        },
                                        "jobTitle": {
                                            "coding": [
                                                {
                                                    "system": "http://hl7.org/fhir/v3/AdministrativeUser",
                                                    "version": "1",
                                                    "code": "Manager",
                                                    "primary": true
                                                }
                                            ],
                                            "text": "Manager"
                                        },
                                        "employeeNumber": "ID_123445"
                                    },
                                    "telecom": [
                                        {
                                            "system": "phone",
                                            "value": "(+1) 734-677-7777"
                                        },
                                        {
                                            "system": "email",
                                            "value": "tushar.tari@ge.com"
                                        }
                                    ],
                                    "principalName": "tushar.tari@ge.com",
                                    "display": "Tushar K"
                                }
                            }
                        ]
                    }
                };
                deffered2=Q.defer();
                sinon.stub(_userService, 'getLoggedInUserDetails').returns(deffered2.promise);
                OrganizationDetailsCtrl = $controller('OrganizationDetailsCtrl', {
                    $scope: scope,
                    $rootScope: rootScope,
                    $filter: _filter,
                    orgMgmtService: orgMgmtService
                });

            }));


            it('should test the value of EditMode for network setting on click of editButton', function(){
                scope.editNetworkMode = true;
                scope.changeEditModeNetworkSetting();
                chai.expect(scope.editNetworkMode).to.be.false;
            });

            it('should test the value of EditMode for default network setting on click of editButton', function(){
                scope.editDefaultMode = false;
                scope.changeEditModeDefaultNetwork ();
                chai.expect(scope.editDefaultMode).to.be.true;
            });

            describe('Edit and update the Network Setting',function(){
                it('should test the valueResource array length when all are not set', function(){
                    scope.saveNetworkSetDetail();
                    chai.expect(scope.valueResourceArr).to.have.length(0);
                });

                it('should test the value coding array length when all true', function(){
                    scope.networkSettingObj.allowSharing = true;
                    scope.networkSettingObj.allowDownload = true;
                    scope.networkSettingObj.sitesVisibleToNetwork = true;
                    scope.networkSettingObj.OrgVisibleToPublic = true;

                    scope.saveNetworkSetDetail();
                    chai.expect(scope.valueCodingArr).to.have.length(4);
                });

                it('should test the value coding array length when all false', function(){
                    scope.networkSettingObj.allowSharing = false;
                    scope.networkSettingObj.allowDownload = false;
                    scope.networkSettingObj.sitesVisibleToNetwork = false;
                    scope.networkSettingObj.OrgVisibleToPublic = false;

                    scope.saveNetworkSetDetail();
                    chai.expect(scope.valueCodingArr).to.have.length(0);
                });

                it('should test when save network setting success', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.editNetworkMode=true;
                    scope.saveNetworkSetDetail();
                    deferred.resolve(createOrgResponse());
                    scope.$root.$digest();
                    done();
                    chai.expect(_log.info.calledWith(responseData));
                });

                it('should test when save network setting error', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    var responseData =createOrgResponse();
                    scope.editNetworkMode=true;
                    scope.saveNetworkSetDetail();
                    deferred.reject(responseData);
                    scope.$root.$digest();
                    chai.expect(_log.info.calledWith(responseData));
                });


                it('should test when cancelling the edit mode', function () {
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.orgDetailsObject = {};
                    scope.orgDetailsObject.extension= [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "Sparx"
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgresource:V1",
                            "valueResource":
                            {
                                "reference": "Organization/1",
                                "display": "Network is visible in Directory"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgresource:V1",
                            "valueResource":
                            {
                                "reference": "Organization/2",
                                "display": "Route network cases to"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_inside_new_site",
                                "display": "Allow re-share"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_new_site",
                                "display": "Allow Clinician/Staff re-share outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_new_site",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_outside_new_site",
                                "display": "Allow Clinician/Staff to download outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_network",
                                "display": "Allow sharing outside of network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_network",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_site_visible_network_users_default",
                                "display": "Sites visible to network users by default?"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_organization_visible_public_directory",
                                "display": "organization is visible in public directory"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_route_network_admin",
                                "display": "Cases sent to network routed to Admin?"
                            }
                        }
                    ];
                    scope.cancelOrgNetworkSetDetails();
                    chai.expect(scope.editNetworkMode).to.be.true;
                });
            });

            describe('Default Network Details', function(){
                it('should test the valuecoding array length when all true', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.networkDefSettingObj.reShare = true;
                    scope.networkDefSettingObj.reshareOutsideNetwork = true;
                    scope.networkDefSettingObj.downloadCaseFiles = true;
                    scope.networkDefSettingObj.downloadOutsideNetwork = true;
                    scope.saveDefaultNetworkDetail();
                    chai.expect(scope.valueCodingArr).to.have.length(4);
                });

                it('should test the valuecoding array length when all false', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.reShare = false;
                    scope.reshareOutsideNetwork = false;
                    scope.downloadCaseFiles = false;
                    scope.downloadOutsideNetwork = false;
                    scope.saveDefaultNetworkDetail();
                    chai.expect(scope.valueCodingArr).to.have.length(0);
                });

                it('should test cancelling the edit of defaultNetworkDetails', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.orgDetailsObject = {};
                    scope.orgDetailsObject.extension= [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "Sparx"
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgresource:V1",
                            "valueResource":
                            {
                                "reference": "Organization/1",
                                "display": "Network is visible in Directory"
                            }


                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgresource:V1",
                            "valueResource":
                            {
                                "reference": "Organization/2",
                                "display": "Route network cases to"
                            }


                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_inside_new_site",
                                "display": "Allow re-share"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_new_site",
                                "display": "Allow Clinician/Staff re-share outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_new_site",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_outside_new_site",
                                "display": "Allow Clinician/Staff to download outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_network",
                                "display": "Allow sharing outside of network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_network",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_site_visible_network_users_default",
                                "display": "Sites visible to network users by default?"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_route_network_admin",
                                "display": "Cases sent to network routed to Admin?"
                            }
                        }
                    ];
                    scope.cancelDefaultNetworkDetails();
                    chai.expect(scope.editDefaultMode).to.be.truthy;
                });

                it('should test success call of updateOrganizationDefaultNetworkSettings service', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.editDefaultMode=true;
                    scope.saveDefaultNetworkDetail();
                    deferred.resolve(createOrgResponse());
                    scope.$root.$digest();
                    chai.expect(scope.getOrganizationDetails.calledOnce);
                });

                it('should test failure call of updateOrganizationDefaultNetworkSettings service', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    var address = [];
                    address.push({city:'',country:'',line:['some addr','some addr1'],state:{id:5},zip:2343});
                    var extension = [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "Sparx"
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgresource:V1",
                            "valueResource":
                            {
                                "reference": "Organization/1",
                                "display": "Network is visible in Directory"
                            }


                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgresource:V1",
                            "valueResource":
                            {
                                "reference": "Organization/2",
                                "display": "Route network cases to"
                            }


                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_inside_new_site",
                                "display": "Allow re-share"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_new_site",
                                "display": "Allow Clinician/Staff re-share outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_new_site",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_outside_new_site",
                                "display": "Allow Clinician/Staff to download outside this network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_reshare_outside_network",
                                "display": "Allow sharing outside of network"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_download_inside_network",
                                "display": "Allow download of case files"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_site_visible_network_users_default",
                                "display": "Sites visible to network users by default?"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_route_network_admin",
                                "display": "Cases sent to network routed to Admin?"
                            }
                        }
                    ];

                    var responseData ={data:{
                        orgName :'Manipal',
                        address :address,
                        extension:extension,
                        contact:contact
                    },status:402};
                    scope.editDefaultMode=true;
                    scope.saveDefaultNetworkDetail();
                    deferred.reject(responseData);
                    scope.$root.$digest();
                    chai.expect(scope.getOrganizationDetails.notCalled);
                });
            });

            describe('updateOrganizationDetail Service', function(){
                it('should test the success response on updating organization details', function(done) {
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    var responseData =createOrgResponse();
                    scope.detailForm ={};
                    scope.detailForm.$error = true;
                    scope.saveOrgDetail();
                    deferred.resolve(responseData);
                    scope.$root.$digest();
                    chai.expect(scope.getOrganizationDetails.calledOnce);
                    done();
                });

                it('should test the error response on updating organization details', function(done) {
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    var responseData =createOrgResponse();
                    scope.detailForm ={};
                    scope.detailForm.$error = true;
                    scope.saveOrgDetail();
                    deferred.reject(responseData);
                    scope.$root.$digest();
                    chai.expect(scope.getOrganizationDetails.notCalled);
                    done();
                });

                it('should test the cancelling of edit mode', function () {
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.editModeOrgDetails=true;
                    var address = [];
                    address.push({city:'',country:'',line:['some addr','some addr1'],state:{id:5},zip:2343});
                    var extension = [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "Sparx"
                        }
                    ];
                    scope.orgDetailsObject ={
                        name :'Manipal',
                        address :address,
                        extension:extension,
                        telecom:[{system: "phone", value: "23443443123"}]
                    };
                    scope.cancelOrgDetails();
                    chai.expect(scope.editModeOrgDetails).to.be.truthy;
                });
                it('should test the address array if address line 2 is not present in cancel', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    var address = [];
                    address.push({city:'',country:'',line:['line1'],state:{id:5},zip:2343});
                    var extension = [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "Sparx"
                        }
                    ];
                    scope.orgDetailsObject ={
                        name :'Manipal',
                        address :address,
                        extension:extension,
                        telecom:[{system: "phone", value: "23443443123"}]
                    };
                    scope.cancelOrgDetails();
                    chai.expect(scope.address2).to.be.undefined;
                });

                it('should test that on cancelling the org edit, the org nick name is not overridden', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    var address = [];
                    address.push({city:'',country:'',line:['some addr'],state:{id:5},zip:2343});
                    var extension = [
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_site_visible_network_users_default",
                                "display": "Sites visible to network users by default?"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/orgpolicycode:V1",
                            "valueCoding": {
                                "system": "urn:hc.ge.com/pfh/platform/policy:V1",
                                "code": "_case_route_network_admin",
                                "display": "Cases sent to network routed to Admin?"
                            }
                        },
                        {
                            "url": "urn:hc.ge.com/pfh/platform/extension/entitynickname:V1",
                            "valueString": "Sparx"
                        }
                    ];

                    scope.orgDetailsObject ={
                        name :'Manipal',
                        address :address,
                        extension:extension,
                        contact:contact,
                        telecom:undefined
                    };

                    scope.cancelOrgDetails();
                    chai.expect(scope.nickName).to.be.equal('Sparx');
                });
                it('should test the address array if address line 2 is not present', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.Address = "Line1 Address";
                    scope.Address2 = undefined;
                    scope.detailForm ={};
                    scope.detailForm.$invalid = false;
                    scope.saveOrgDetail();
                    chai.expect(scope.addressArray).to.have.length(1);
                });

                it('should test Mandatory fields Presents before save', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.detailForm ={};
                    scope.detailForm.$invalid=true;
                    scope.saveOrgDetail();
                    chai.expect(scope.loadingOrgUpdateDetail).to.be.false;
                });

                it('should test the address array if address line 2 is present', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.Address = "Line1 Address";
                    scope.Address2 = "Line 2 Address";
                    scope.detailForm ={};
                    scope.detailForm.$error = true;
                    scope.saveOrgDetail();
                    chai.expect(scope.addressArray).to.have.length(2);
                });
            });

            describe('getOrganizationDetails Service', function(){
                it('should be called successfully',function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    var responseData =createOrgResponse();

                    scope.getOrganizationDetails();
                    deferred.resolve(responseData);
                    scope.$root.$digest();
                    done();

                    chai.expect(scope.orgName).to.be.equal(responseData.orgName);
                });

                it('should not be called successfully',function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    var responseData =createOrgResponse();
                    scope.getOrganizationDetails();
                    deferred.reject(responseData);
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.orgName).to.be.equal('');
                });
            });

            describe('When there is a XSS event', function(){
                it('and the user closes the alert box, it should test setting of the variable to hide alert', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.closeAlert();
                    chai.expect(scope.closeAlertPressed).to.be.equal(1);
                });

                it('and there is a rootScope emit of the event, it should test the event is consumed', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    var object = {message: "There is an attempt to insert scrpit"};
                    scope.$emit("SHOW_FAILURE_MESSAGE_NO_TIMEOUT",object.message);
                    chai.expect(scope.xssMessage).to.be.equal(object.message);
                    chai.expect(scope.closeAlertPressed).to.be.equal(0);
                });
            });
            describe('When country dropdown value is selected', function(){
                it('should test the states data for US country selected', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.getStatesForCountry("US");
                    chai.expect(scope.StateArray).to.have.length.above(10);
                });
                it('should test the Empty states data for blank country', function(){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.getStatesForCountry("");
                    chai.expect(scope.StateArray).to.be.empty;
                });
            });
            describe('Checks administrators list display values', function(){
                var otherAdmin={name: "yash23", "display":"yash23", principalName: "yash23.yash23@ge.com", id: "034e2e9b-60b0-4856-85a7-c43779a89678"};
                var youAdmin={name: "Tushar K", "display":"Tushar K", principalName: "tushar.tari@ge.com", id: "034e2e9b-60b0-4856-85a7-c43779a11746"};
                otherAdmin=JSON.parse(JSON.stringify(otherAdmin));
                youAdmin=JSON.parse(JSON.stringify(youAdmin));
                it('Checks nonLogged/OtherAdmin display values', function(done){
                    scope.LoggedInUser=loggedInUserContextServiceResponse;
                    chai.expect(scope.getUserForDisplay(otherAdmin)).to.be.equal('yash23 (yash23.yash23@ge.com)');
                    done();
                });
                it('Checks nonLogged/OtherAdmin display values', function(done){
                    scope.LoggedInUser={principalName: "tushar.tari@ge.com"};
                    chai.expect(scope.getUserForDisplay(youAdmin)).to.be.equal('Tushar K (orgmanagement.you)');
                    done();
                });
                it('Checks nonLogged/OtherAdmin display values if no email is present', function(done){
                    scope.LoggedInUser={principalName: "tushar.tari@ge.com"};
                    youAdmin.principalName=undefined;
                    chai.expect(scope.getUserForDisplay(youAdmin)).to.be.equal('Tushar K');
                    done();
                });
            });
            describe('Checks loadingOrgDetails overlay', function(){
                it('Checks orgAdmins resolves first and loadingOrgDetails resolution is pending', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.getOrganizationDetails();
                    deffered1.resolve(createOrgResponse());
                    scope.$digest();
                    chai.expect(scope.loadingOrgDetail).to.be.equal(true);
                    done();
                });
                it('Checks loading OrgDetails resolves first and adminList resolution is pending', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.getOrganizationDetails();
                    deferred.resolve(createOrgResponse());
                    scope.$digest();
                    chai.expect(scope.loadingOrgDetail).to.be.equal(true);
                    done();
                });
                it('Checks orgAdmins and loadingOrgDetails resolved', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.getOrganizationDetails();
                    scope.part1=true;
                    deffered1.reject(createOrgResponse());
                    scope.$digest();
                    chai.expect(scope.loadingOrgDetail).to.be.equal(false);
                    done();
                });
                it('Checks orgAdmins and loadingOrgDetails resolved', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.getOrganizationDetails();
                    scope.part2=true;
                    deferred.resolve(createOrgResponse());
                    scope.$digest();
                    chai.expect(scope.loadingOrgDetail).to.be.equal(false);
                    done();
                });



                it('Checks orgAdmins and loadingOrgDetails resolved', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.getOrganizationDetails();
                    scope.part1=true;
                    deffered1.resolve(createOrgResponse());
                    scope.$digest();
                    chai.expect(scope.loadingOrgDetail).to.be.equal(false);
                    done();
                });
                it('Checks orgAdmins and loadingOrgDetails resolved', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.getOrganizationDetails();
                    scope.part2=true;
                    deferred.reject(createOrgResponse());
                    scope.$digest();
                    chai.expect(scope.loadingOrgDetail).to.be.equal(false);
                    done();
                });
                it('Checks orgAdmins rejects first and orgdetails pending', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.getOrganizationDetails();
                    scope.part1=false;
                    deffered1.reject(createOrgResponse());
                    scope.$digest();
                    chai.expect(scope.loadingOrgDetail).to.be.equal(true);
                    done();
                });
                it('Checks telecom object to be defined', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.getOrganizationDetails();
                    scope.part2=true;
                    var r=createOrgResponse();
                    r.data.telecom=[];
                    r.data.telecom[0]={value:"9999999999"};
                    deferred.resolve(r);
                    scope.$digest();
                    chai.expect(scope.phoneNumber).to.be.equal('9999999999');
                    done();
                });
                it('Checks telecom object to be undefined', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.getOrganizationDetails();
                    scope.part2=true;
                    var r=createOrgResponse();
                    r.data.telecom=[];
                    deferred.resolve(r);
                    scope.$digest();
                    chai.expect(scope.phoneNumber).to.be.undefined;
                    done();
                });


            });
            describe('Checks setPhoneExtensionValue values', function(){
                it('Checks for undefined value', function(){
                    scope.setPhoneExtensionValue();
                    chai.expect(scope.accountOwnerDetailsSection.PhoneNumber).to.be.falsy;
                });
                it('Checks for value without extension', function(){
                    scope.setPhoneExtensionValue('1234567899');
                    chai.expect(scope.accountOwnerDetailsSection.PhoneNumber).to.be.equal('1234567899');
                });

            });
            describe('Checks logged in userContext success and failure modes', function(){
                it('Checks logged in userContext failure', function(done){
                    var res={};
                    deffered2.reject(res);
                    scope.$digest();
                    chai.expect(_log.error.calledOnce);
                    done();
                });
                it('Checks logged in userContext success', function(done){
                    var res={};
                    deffered2.resolve(res);
                    scope.$digest();
                    chai.expect(scope.LoggedInUser).to.be.empty;
                    done();
                });
            });
            describe('Checks sectionWise save/edit/cancel button methods', function(){
                it('Checks changeEditModeAccOwnerDiv cancel', function(done){
                    var res={};
                    deffered2.resolve(res);
                    var telecom = [{
                        system: "phone",
                        value: "extension-4556567667"
                    }, {system: "email", value: "abc@ge.com"}];
                    scope.contactTemp = [{name: {text: "accountOwner"}, telecom: telecom}];
                    scope.cancelAccOwnerSetDetails();
                    scope.$digest();
                    chai.expect(scope.editAccOwnerDiv).to.be.equal(true);
                    done();
                });
                it('Checks changeEditModeAccOwnerDiv', function(done){
                    var res={};
                    deffered2.resolve(res);
                    scope.changeEditModeAccOwnerDiv();
                    scope.$digest();
                    chai.expect(scope.editAccOwnerDiv).to.be.equal(false);
                    done();
                });
            });
            describe('Checks Save AccountOwner detials section', function(){
                it('Checks updateOrganizationAccountOwnerDetail success', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.$root.$digest();
                    scope.getOrganizationDetails();
                    deferred.resolve(createOrgResponse());
                    scope.$root.$digest();
                    var form1={
                        AccOwnerName:{$modelValue:"abc"},
                        EmailId:{$modelValue:"abc@ab.in"},
                        Extension:{$modelValue:"33333"},
                        PhoneNumber:{$modelValue:"9999999999"}
                    };
                    scope.saveAccOwnerDetail(form1);
                    var dresponse={data:{},status:200};
                    df.resolve(dresponse);
                    scope.$root.$digest();
                    chai.expect(_log.info.calledWith(dresponse));
                    done();
                });
                it('Checks updateOrganizationAccountOwnerDetail failure', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.$root.$digest();
                    scope.getOrganizationDetails();
                    deferred.resolve(createOrgResponse());
                    scope.$root.$digest();
                    var form1={
                        AccOwnerName:{$modelValue:"abc"},
                        EmailId:{$modelValue:"abc@ab.in"},
                        Extension:{$modelValue:"33333"},
                        PhoneNumber:{$modelValue:"9999999999"}
                    };
                    scope.saveAccOwnerDetail(form1);
                    var dresponse={data:{},status:200};
                    df.reject(dresponse);
                    scope.$root.$digest();
                    chai.expect(_log.info.calledWith(dresponse));
                    done();
                });
                it('Checks updateOrganizationAccountOwnerDetail success with no-extension', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.$root.$digest();
                    scope.getOrganizationDetails();
                    deferred.resolve(createOrgResponse());
                    scope.$root.$digest();
                    var form1={
                        AccOwnerName:{$modelValue:"abc"},
                        EmailId:{$modelValue:"abc@ab.in"},
                        Extension:{$modelValue:""},
                        PhoneNumber:{$modelValue:"9999999999"}
                    };
                    scope.saveAccOwnerDetail(form1);
                    var dresponse={data:{},status:200};
                    df.reject(dresponse);
                    scope.$root.$digest();
                    chai.expect(_log.info.calledWith(dresponse));
                    done();
                });
                it('Checks getPhoneNumber method post orgDetails are loaded', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.$root.$digest();
                    scope.getOrganizationDetails();
                    deferred.resolve(createOrgResponse());
                    scope.$root.$digest();
                    chai.expect(scope.getPhoneNumber()).to.be.equal('3333333333');
                    done();
                });
                it('Checks getPhoneNumber method initial case before orgDetails are loaded', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.$root.$digest();
                    chai.expect(scope.getPhoneNumber()).to.be.falsy;
                    done();
                });
                it('Checks getAccOwnerName method initial case before orgDetails are loaded', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.$root.$digest();
                    chai.expect(scope.getAccOwnerName()).to.be.falsy;
                    done();
                });
                it('Checks getEmailId method initial case before orgDetails are loaded', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.$root.$digest();
                    chai.expect(scope.getEmailId()).to.be.falsy;
                    done();
                });
                it('Checks getExtension method initial case before orgDetails are loaded', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.$root.$digest();
                    chai.expect(scope.getExtension()).to.be.falsy;
                    done();
                });
                it('Checks saveAccOwnerDetail method with XSS in extension', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.$root.$digest();
                    scope.getOrganizationDetails();
                    deferred.resolve(createOrgResponse());
                    scope.$root.$digest();
                    var form1={
                        AccOwnerName:{$modelValue:"abc"},
                        EmailId:{$modelValue:"abc@ab.in"},
                        Extension:{$modelValue:"<script>"},
                        PhoneNumber:{$modelValue:"9999999999"}
                    };
                    scope.accountOwnerDetailsSection.Extension="<script>";
                    scope.saveAccOwnerDetail(form1);
                    chai.expect(scope.getExtension()).to.be.falsy;
                    done();
                });
                it('Checks saveAccOwnerDetail method with invalid form', function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.$root.$digest();
                    scope.getOrganizationDetails();
                    deferred.resolve(createOrgResponse());
                    scope.$root.$digest();
                    var form1={
                        AccOwnerName:{$modelValue:""},
                        EmailId:{$modelValue:"abc@ab.in"},
                        Extension:{$modelValue:"<script>"},
                        PhoneNumber:{$modelValue:"9999999999"},
                        $invalid:true
                    };
                    scope.accountOwnerDetailsSection.Extension="<script>";
                    scope.saveAccOwnerDetail(form1);
                    chai.expect(scope.getExtension()).to.be.falsy;
                    done();
                });

                it("Checks saveAccOwnerDetail method with script in AccountOwner name", function(done){
                    deffered2.resolve(JSON.parse(JSON.stringify(loggedInUserContextServiceResponse)));
                    scope.$root.$digest();
                    scope.getOrganizationDetails();
                    deferred.resolve(createOrgResponse());
                    scope.$root.$digest();
                    var form1={
                        AccOwnerName:{$modelValue:"<script>"},
                        EmailId:{$modelValue:"abc@ab.in"},
                        Extension:{$modelValue:"123456"},
                        PhoneNumber:{$modelValue:"9999999999"},
                        $invalid:true
                    };
                    scope.accountOwnerDetailsSection.AccOwnerName="<script>";
                    scope.saveAccOwnerDetail(form1);
                    chai.expect(scope.getAccOwnerName()).to.be.falsy;
                    done();
                });
            });

            describe('Search user for making admin and select admin', function(){
                it('Search user for admin success', function(done){
                    scope.searchUserForAdmin("a");
                    findUserDeferred.resolve(searchUserResult);
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.searchingUsersForAdmin).to.be.false;
                });
                it('Check searchUserForAdmin function, reject', function (done) {
                    scope.searchUserForAdmin("abc");
                    findUserDeferred.reject();
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.noResultsForAdmin).to.be.true;
                });
                it('select administrator', function(){
                    var user ={
                        "data": {
                            "resourceType": "Bundle",
                            "title": null,
                            "id": '12-45gf-435',
                            "entry": [
                                {
                                    "title": null,
                                    "id": "034e2e9b-60b0-4856-85a7-c43779a11746",
                                    "content": {
                                        "resourceType": "ResourcesUser",
                                        "name": {
                                            "use": "official",
                                            "family": [
                                                "Tari"
                                            ],
                                            "given": [
                                                "Tushar",
                                                "K"
                                            ]
                                        },
                                        "externalId": [
                                            {
                                                "system": "IDM",
                                                "value": "b9f2b0f9-03ab-4d94-bd33-f40b495fc4d5"
                                            },
                                            {
                                                "system": "UOM",
                                                "value": "034e2e9b-60b0-4856-85a7-c43779a11746"
                                            },
                                            {
                                                "_id": "tushar.tari@ge.com",
                                                "system": "urn:hc.ge.com/pfh/platform/useremail"
                                            }
                                        ],
                                        "role": [
                                            {
                                                "code": [
                                                    {
                                                        "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                        "code": "practitioner",
                                                        "display": "practitioner"
                                                    }
                                                ],
                                                "scopingOrganization": {
                                                    "reference": "organization/5"
                                                },
                                                "status": "active"
                                            },
                                            {
                                                "code": [
                                                    {
                                                        "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                                        "code": "practitioner",
                                                        "display": "practitioner"
                                                    }
                                                ],
                                                "scopingOrganization": {
                                                    "reference": "organization/6"
                                                },
                                                "status": "active"
                                            }
                                        ],
                                        "managingOrganization": {
                                            "organization": {
                                                "reference": "organization/74553d9a-7d1b-4f93-929c-72b6318a6178"
                                            },
                                            "jobTitle": {
                                                "coding": [
                                                    {
                                                        "system": "http://hl7.org/fhir/v3/AdministrativeUser",
                                                        "version": "1",
                                                        "code": "Manager",
                                                        "primary": true
                                                    }
                                                ],
                                                "text": "Manager"
                                            },
                                            "employeeNumber": "ID_123445"
                                        },
                                        "telecom": [
                                            {
                                                "system": "phone",
                                                "value": "(+1) 734-677-7777"
                                            },
                                            {
                                                "system": "email",
                                                "value": "tushar.tari@ge.com"
                                            }
                                        ],
                                        "principalName": "tushar.tari@ge.com",
                                        "display": "Tushar K"
                                    }
                                }
                            ]
                        },
                        "status": 200,
                        "config": {},
                        "statusText": "OK"
                    };
                    scope.loggedInUser = loggedInUserContextServiceResponse;
                    scope.selectAdministrator(user.data.entry[0]);
                    chai.expect(scope.orgDetail.administrators.length).to.be.gt(0);
                });
                it('Checks nonLogged/OtherAdmin display values', function(done){
                    scope.LoggedInUser=loggedInUserContextServiceResponse;
                    chai.expect(scope.getUserForDisplay(searchUserResult.data.entry[0].content)).to.be.equal('Tushar K (orgmanagement.you)');
                    done();
                });
                it('Checks nonLogged/OtherAdmin display values if no email is present', function(done){
                    scope.LoggedInUser={principalName: "tushar.tari@ge.com"};
                    var youAdmin={name: "Tushar K", "display":"Tushar K", principalName: "tushar.tari@ge.com", id: "034e2e9b-60b0-4856-85a7-c43779a11746"};
                    chai.expect(scope.getUserForDisplay(youAdmin)).to.be.equal('Tushar K (orgmanagement.you)');
                    done();
                });
                it('Checks removeAdministrator button functionality', function(done){
                    var youAdmin={name: "Tushar K", "display":"Tushar K", principalName: "tushar.tari@ge.com", id: "034e2e9b-60b0-4856-85a7-c43779a11746"};
                    scope.removeAdministrator({user:youAdmin});
                    chai.expect(scope.orgDetail.administrators.length).to.be.equal(0);
                    done();
                });
                it('Edit site admins', function(){
                    scope.editOrgAdminDiv = true;
                    scope.editOrgAdmin();
                    chai.expect(scope.editOrgAdminDiv).to.be.false;
                });
                it('Cancel site admin editing', function(){
                    scope.administratorsTemp = [{"display":"Tushar Tari"}];
                    scope.cancelOrgAdminDiv();
                    chai.expect(scope.orgDetail.administrators).to.be.length(1);
                });
            });

            describe('Update org admin list', function(){
                it('checks updateOrgAdmins, admin to add called successfully', function(){
                    scope.adminBeforeEditId = ['1'];
                    scope.orgDetail.administrators = [{'id':'1'}, {'id':'2'}];
                    scope.updateOrgAdmins();
                    updateOrgAdminsDef.resolve({"data":"response"});
                    scope.$digest();
                    chai.expect(_orgMgmtService.updateOrgAdmins).called;
                });
                it('checks updateOrgAdmins, admin to remove called successfully', function(){
                    scope.adminBeforeEditId = ['1', '2'];
                    scope.orgDetail.administrators = [{'id':'1'}];
                    scope.updateOrgAdmins();
                    updateOrgAdminsDef.resolve({"data":"response"});
                    scope.$digest();
                    chai.expect(_orgMgmtService.updateOrgAdmins).called;
                });
                it('checks updateOrgAdmins not called successfully', function(){
                    scope.orgDetail.administrators = ['1'];
                    scope.adminBeforeEditId = [{'id':'1'}, {'id':'2'}];
                    scope.updateOrgAdmins();
                    updateOrgAdminsDef.reject({"data":"response"});
                    scope.$digest();
                    chai.expect(_orgMgmtService.updateOrgAdmins).called;
                });
            });

            describe('Checks accountOwnerSetter method', function(){
                it('Checks if contact data is undefined', function(){
                    scope.accountOwnerSetter();
                    chai.expect(scope.contact).to.be.undefined;
                });
                it('Checks if contact data do not have name field', function(){
                    var contact = JSON.parse(JSON.stringify([{
                        "telecom": [{"system": "phone", "value": "333233-3333333333"}, {
                            "system": "email",
                            "value": "abc.abc.in"
                        }]
                    }]));
                    scope.accountOwnerSetter(contact);
                    chai.expect(scope.accountOwnerDetailsSection.AccOwnerName).to.be.falsy;
                });
                it('Checks if contact data do not have name field', function(){
                    var contact = JSON.parse(JSON.stringify([{
                        "name": {"text": "jfk"}
                    }]));
                    scope.accountOwnerSetter(contact);
                    chai.expect(scope.contact[0].telecom).to.be.undefined;
                });
            });
        });


    });
