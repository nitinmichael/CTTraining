define(['angular',
        'angular-mocks',
        'orgMgmnt/features/user/selfRegistration/controllers/userSelfRegistrationController',
        'orgMgmnt/dataModels/userDataModel',
        'orgMgmnt/services/userService'
    ],
    function(ng){
        'use strict';

        describe('Test the userSelfRegistrationController', function(){
            var userSelfRegControllers, scope, q, deferred, _log,rootScope, _state,_userMgmtService;
            var _userDataModel,obj, firstNameArr,obj1,obj3,_event ;
            beforeEach( function(){
                module('Orgmanagement.Features.User.SelfRegistration.UserSelfRegistrationController');
                module('Orgmanagement.Services.UserService');
                module('Orgmanagement.DataModel.UserDataModel');
                module('Orgmanagement.Utilities.MasterData');
                module('ui.router');
            });

            /***when role selected is patient***/
           var role = {
                code: "patient",
                display: "Patient",
                roleTxt: "As a patient, you can(copy needed)"
            };
            obj=[role];

            /***when role selected is practitioner***/
            var role2 = {
                code: "practitioner",
                display: "Healthcare Provider",
                roleTxt: "As the member of your site you can...(copy needed)"
            };
            obj1=[role2];


            /***when role selected is neither patient nor healthcare provider***/
            var role3 = {
                code: "hello",
                display: "Healthcare Provider",
                roleTxt: "As the member of your site you can...(copy needed)"
            };
            obj3=[role3];

            beforeEach(inject(function($controller,$rootScope,userDataModel,userMgmtService, $q, $log, $state){
                scope = $rootScope.$new();
                rootScope=$rootScope;
                rootScope.roleValue=obj.code;
                rootScope.defaultOrgIds = ["123","456","789"];
                rootScope.uomServiceUrl = "http://uom-case-api-gateway.grc-apps.svc.ice.ge.com";
                _userDataModel = userDataModel;
                _userMgmtService = userMgmtService;
                q = $q;
                _log = $log;
                _state = $state;
                deferred = q.defer();
                _event = {
                    stopPropagation: sinon.spy()
                };
                sinon.stub(_userMgmtService, 'createUser').returns(deferred.promise);
                sinon.stub(_log, 'info');
                _state.transitionTo = sinon.stub();
                /** root scope should be injected if there are objects binded to the rootscope**/
                userSelfRegControllers = $controller('UserSelfRegController',{$scope:scope, userMgmtService:_userMgmtService, $rootScope:rootScope});
            }));

            describe('Object creation for user management', function() {
                it('prevSelfRegForm ', function () {
                    scope.currentStepValue = 2;
                    scope.prevSelfRegForm();
                    chai.expect(scope.currentStepValue).to.be.equal(1);
                });

               it('createUserInfo  and calling the user object creation method', function () {
                   firstNameArr =[];
                   firstNameArr.push('test1');
                    scope.formSelfRegInfo={
                        email:'test@gmail.com',
                        type:'Human',
                        firstName :firstNameArr,
                        lastName:'test2',
                        obj :obj[0],
                        telecom :"'123','456','test@gmail.com'",
                        address:'address1'
                   };
                    scope.createUserInfo();
                   chai.expect(scope.email).to.equal('test@gmail.com');
                });


                it('createUserInfo when role is practioner', function () {
                    firstNameArr =[];
                    firstNameArr.push('test1');
                    scope.formSelfRegInfo={
                        email:'test@gmail.com',
                        type:'Human',
                        firstName :firstNameArr,
                        lastName:'test2',
                        obj :obj1[0],
                        telecom :"'123','456','test@gmail.com'",
                        address:'address1'
                    };
                    scope.createUserInfo();
                    chai.expect(scope.role[0].code[0].code).to.equal('practitioner');

                });
            });


            describe('Object creation for user management and calling service', function() {

                it('create user response and call the service', function(done){
                    firstNameArr =[];
                    firstNameArr.push('test1');
                    scope.formSelfRegInfo={
                        email:'test@gmail.com',
                        type:'Human',
                        firstName :firstNameArr,
                        lastName:'test2',
                        obj :obj[0],
                        telecom :"'123','456','test@gmail.com'",
                        address:'address1'
                    };
                    var data={
                        id:'123'
                    }
                    var responseData = {
                        resourceType: 'abc',
                        firstName :firstNameArr,
                        lastName:'test2',
                        telecom :"'123','456','test@gmail.com'",
                        address:'address1',
                        data : data.id
                    };
                    scope.userCreation();
                    deferred.resolve(responseData);
                    scope.$digest();
                    chai.expect(_log.info.calledOnce);
                    done();
                });



                it('create user reject', function(done){
                    firstNameArr =[];
                    firstNameArr.push('test1');
                    scope.formSelfRegInfo={
                        email:'test@gmail.com',
                        type:'Human',
                        firstName :firstNameArr,
                        lastName:'test2',
                        obj :obj[0],
                        telecom :"'123','456','test@gmail.com'",
                        address:'address1'
                    };

                    var data={
                        id:'123'
                    }
                    var responseData = {
                        resourceType: 'abc',
                        firstName :firstNameArr,
                        lastName:'test2',
                        telecom :"'123','456','test@gmail.com'",
                        address:'address1',
                        data : data.id
                    };
                    scope.userCreation();
                    deferred.reject(responseData);
                    scope.$digest();
                    chai.expect(_log.info.calledOnce);
                    done();
                });

            });

            describe('When user clicks on next button &  validates password  ', function(){
                it('When user clicks on next button ', function(){
                    scope.formSelfRegInfo={
                        email:'test@gmail.com',
                        type:'Human',
                        firstName :firstNameArr,
                        lastName:'test2',
                        obj :obj[0],
                        telecom :"'123','456','test@gmail.com'",
                        address:'address1'
                    };
                    scope.parentSelfRegForm.selfRegForm ={$valid: true};
                    scope.nextSelfRegForm();
                   chai.expect(scope.userCreation.calledOnce);
                });


              it('createUserInfo when radio button is not patient or practioner ', function () {
                    firstNameArr =[];
                    firstNameArr.push('test1');
                    scope.formSelfRegInfo={
                        email:'test@gmail.com',
                        type:'Human',
                        firstName :firstNameArr,
                        lastName:'test2',
                        obj :obj3[0],
                        telecom :"'123','456','test@gmail.com'",
                        address:'address1'
                    };
                    scope.createUserInfo();
                   chai.expect(scope.role).to.not.equal('practitioner');
                   chai.expect(scope.role).to.not.equal('patient');
                });



                it('confirm password if does not match', function () {
                    firstNameArr =[];
                    firstNameArr.push('test1');
                    scope.formSelfRegInfo={
                        email:'test@gmail.com',
                        type:'Human',
                        firstName :firstNameArr,
                        lastName:'test2',
                        obj :obj3[0],
                        telecom :"'123','456','test@gmail.com'",
                        address:'address1',
                        password:'Happy1',
                        confirmPassword:'Happy2'
                    };
                    scope.parentSelfRegForm.selfRegForm ={$invalid: true};
                    scope.parentSelfRegForm.selfRegForm={$dirty: true};
                    scope.createUserInfo();
                    /***watch can be listened by making digest and apply call***/
                    scope.$digest();
                    scope.$apply();
                    chai.expect(scope.formSelfRegInfo).to.not.equal('Happy2');
                });


                it('confirm password if  matches', function () {
                    firstNameArr =[];
                    firstNameArr.push('test1');
                    scope.formSelfRegInfo={
                        email:'test@gmail.com',
                        type:'Human',
                        firstName :firstNameArr,
                        lastName:'test2',
                        obj :obj3[0],
                        telecom :"'123','456','test@gmail.com'",
                        address:'address1',
                        password:'Happy1',
                        confirmPassword:'Happy1'
                    };
                    scope.parentSelfRegForm.selfRegForm ={$invalid: true};
                    scope.parentSelfRegForm.selfRegForm={$dirty: true};
                    scope.createUserInfo();
                    /***watch can be listened by making digest and apply call***/
                    scope.$digest();
                    scope.$apply();
                    chai.expect(scope.formSelfRegInfo.password).to.equal('Happy1');
                });

                it('will test the kohinoor host and assign the default org id', function(){
                    rootScope.uomServiceUrl = "http://uom-case-api-gateway.grc-apps.svc.ice.ge.com";
                    scope.createUserInfo();
                    chai.expect(scope.defaultOrgId).to.equal("123");
                });

                it('will test the cloudav int host and assign the default org id', function(){
                    rootScope.uomServiceUrl = "http://case-api-gateway.cloudav.int.grc-apps.svc.ice.ge.com";
                    scope.createUserInfo();
                    chai.expect(scope.defaultOrgId).to.equal("456");
                });
                it('will test the local host and assign the default org id', function(){
                    rootScope.uomServiceUrl = "http://localhost";
                    scope.createUserInfo();
                    chai.expect(scope.defaultOrgId).to.equal("789");
                });


            });


            describe('When there is a XSS event on user screen ', function(){
                it('and the user closes the alert box, it should test setting of the variable to hide alert', function(){
                    scope.closeAlert();
                    chai.expect(scope.closeAlertPressed).to.be.equal(1);
                });

                it('and there is a rootScope emit of the event, it should test the event is consumed ', function(){
                    var object = {message: "There is an attempt to insert scrpit"};
                    scope.$emit("SHOW_FAILURE_MESSAGE_NO_TIMEOUT",object.message);
                    chai.expect(scope.xssMessage).to.be.equal(object.message);
                    chai.expect(scope.closeAlertPressed).to.be.equal(0);
                });
            });


            describe('test the click is stopped if invalid form', function(){
                it('should test the click is stopped if invalid form', function(){
                    scope.parentSelfRegForm.selfRegForm= {$invalid:true};
                    scope.currentStepValue = 2;
                    scope.nextSelfRegForm(_event);
                    chai.expect(scope.currentStepValue).to.be.equal(2);
                });

            });





        });
    });


