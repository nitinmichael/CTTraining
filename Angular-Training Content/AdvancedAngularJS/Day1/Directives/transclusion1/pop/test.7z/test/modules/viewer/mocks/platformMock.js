define(['angular'], function(angular){
angular.module('platform', []).provider(
    '$toolFactory',
    function toolFactoryProvider() {

        var fn = function (conf) {
return conf;
        };
        this.$get = function () {
            return {
                'Icon': fn,
                'toolPanelObj': fn,
                'toolBoxObj': fn,
                'toolBtnObj': fn,
                'makeToolBtnObjs': fn,
                'defaultToolBoxObj': function (conf) {
                    this.title = 'Default title';
                    this.type = 'bar';
                    this.buttons = [];
                }
            };
        };


    }).service('$windowResizeService', function () {
          this.addCBforOnResize = function (newCBfunction) {

          };
        });
});
