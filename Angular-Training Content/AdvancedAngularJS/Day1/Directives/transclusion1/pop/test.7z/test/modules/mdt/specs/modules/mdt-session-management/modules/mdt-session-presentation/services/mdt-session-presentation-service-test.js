/*
 * mdt-session-presentation-service-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular', 'angular-mocks', 'mdt/modules/mdt-session-management/modules/mdt-session-presentation/services/mdt-session-presentation-service'], function () {
    'use strict';

    describe("MdtSessionPresentationService", function () {
        var MdtSessionPresentationService, $httpBackend;
        var ROOT_URL = 'http://localhost:8080';
        var CASE_SERVICE_URL = 'http://caseservice.ge.com';

        beforeEach(function () {
            angular.module('Services.caseExchangeDataService', []);
            //
            module('Services.caseExchangeDataService', function($provide) {
                $provide.value('CaseExchangeDataService', {
                    getServiceURL: function() {
                        return CASE_SERVICE_URL;
                    }
                })
            });

            module('Mdt.Module.MdtSessionPresentationService', function ($provide) {
                // add a mock $Endpoint provider - it will return ROOT_URL for any endpoint)
                $provide.value('$Endpoint', {
                    getEndpoint: function () {
                        return ROOT_URL;
                    },
                    getEndpointAsync: function(){
                        return {
                            then: function(success){
                                var publicAPI = success(ROOT_URL);
                                return {
                                    then: function(fn){
                                        fn(publicAPI);
                                    }
                                };
                            }
                        };
                    }
                });
            });

            inject(function (_MdtSessionPresentationService_, _$httpBackend_) {
                MdtSessionPresentationService = _MdtSessionPresentationService_;
                $httpBackend = _$httpBackend_;
            });
        });

        describe("MdtSessionPresentationService service test suite", function () {
            describe("getDetails service test suite", function () {
                it("should call get service with the meeting id", function () {
                    var sessionId = '22';
                    $httpBackend.expectGET(ROOT_URL + '/views/manage-meetings/meeting-details/' + sessionId).respond({});
                    MdtSessionPresentationService.then(function(service){
                        service.getDetails(sessionId);
                    });
                    $httpBackend.flush();
                });

                it("should call get service with the meeting id and handlers", function () {
                    var sessionId = '22';
                    $httpBackend.expectGET(ROOT_URL + '/views/manage-meetings/meeting-details/' + sessionId).respond({});
                    MdtSessionPresentationService.then(function(service){
                        service.getDetails(sessionId, function(result){}, function(){});
                    });
                    $httpBackend.flush();
                });
            });

            describe("getCaseDetails service test suite", function () {
                it("should call get service with the meeting id and the caseid", function () {
                    var sessionId = '22';
                    var caseId = "33";
                    $httpBackend.expectGET(ROOT_URL + '/views/presentation/' + sessionId + '/cases/' + caseId).respond({});
                    MdtSessionPresentationService.then(function(service){
                        service.getCaseDetails(sessionId, caseId);
                    });
                    $httpBackend.flush();
                });

                it("should call get service with the meeting id and handlers", function () {
                    var sessionId = '22';
                    var caseId = "33";
                    $httpBackend.expectGET(ROOT_URL + '/views/presentation/' + sessionId + '/cases/' + caseId).respond({});
                    MdtSessionPresentationService.then(function(service){
                        service.getCaseDetails(sessionId, caseId, function(result){}, function(){});
                    });
                    $httpBackend.flush();
                });
            });

            describe("markCaseAsReviewed service test suite", function () {
                it("should call markCaseAsReviewed service with the meeting id and the caseid", function () {
                    var sessionId = '22';
                    var caseId = "33";
                    $httpBackend.expectPUT(ROOT_URL + '/views/presentation/set-case-state/' + sessionId + '/cases/' + caseId + "/state?state=CLOSED").respond({});
                    MdtSessionPresentationService.then(function(service){
                        service.markCaseAsReviewed(sessionId, caseId, "comment");
                    });
                    $httpBackend.flush();
                });

                it("should call markCaseAsReviewed service with the meeting id and handlers", function () {
                    var sessionId = '22';
                    var caseId = "33";
                    $httpBackend.expectPUT(ROOT_URL + '/views/presentation/set-case-state/' + sessionId + '/cases/' + caseId + "/state?state=CLOSED").respond({});
                    MdtSessionPresentationService.then(function(service){
                        service.markCaseAsReviewed(sessionId, caseId, "comment", function(result){}, function(){});
                    });
                    $httpBackend.flush();
                });
            });

            afterEach(function () {
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

    });
});
