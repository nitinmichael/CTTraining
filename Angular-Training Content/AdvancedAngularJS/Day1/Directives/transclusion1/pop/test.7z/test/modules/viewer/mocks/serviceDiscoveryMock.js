define(['viewerMockModule'], function(viewerMockModule) {
    return viewerMockModule.factory('serviceDiscovery', function ($q) {
        return {
            getServiceUrl: function (serviceName) {
                return $q.when(serviceName);
            },
            getApplicationVersion: function () {

            }
        };
    });
});
