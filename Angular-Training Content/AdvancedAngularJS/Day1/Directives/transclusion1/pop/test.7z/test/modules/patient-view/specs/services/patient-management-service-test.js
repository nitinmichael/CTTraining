/*
 *  patient-management-service-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * @author: Callebe Gomes <callebe.gomes@ge.com>
 *
 * Spec file for Patient Management service module
 */

define([
    'angular',
    'angular-mocks',
    'patient-view/modules/patient-management/services/patientManagementService'
],
function () {
    'use strict';

    describe('Patient Management Service Test Suite::', function () {

        var PatientManagementService;
        var $httpBackend;
        var $q;
        var $rootScope;
        var endpoint;
        var $Endpoint;
        var Patient;
        var deferred;

        var resolvePromise = function () {
            deferred.resolve($Endpoint.getEndpoint());
        };

        beforeEach(module('cloudav.patient-view.patient-management', function ($provide) {
            $provide.service('$Endpoint', function() {
                this.getEndpoint = function (key) {
                    return 'http://ge.test.fake.nonexistentdomain';
                };

                this.getEndpointAsync = function () { };
            });
        }));
        
        // Initialize the scope and controller variables
        beforeEach(inject(function (_PatientManagementService_, _$Endpoint_, _$httpBackend_, _$q_, _$rootScope_, _Patient_) {
            PatientManagementService = _PatientManagementService_;
            $Endpoint = _$Endpoint_;
            $httpBackend = _$httpBackend_;
            $q = _$q_;
            $rootScope = _$rootScope_;
            Patient = _Patient_;

            deferred = $q.defer();
            sinon.stub($Endpoint, 'getEndpointAsync').returns(deferred.promise);
        }));

        afterEach(function () {
            $Endpoint.getEndpointAsync.restore();
        });

        it('should define a service', function () {
            assert.isDefined(PatientManagementService, 'PatientManagementService is not defined');
        });

        describe('PatientManagementService', function () {
            var listMyPatientsHandler;

            var listMyPatientsResponse = { totalRecords: 0, listPatientVO: [ { identifier: [1] } ] };

            beforeEach(function () {
                listMyPatientsHandler = $httpBackend.when('GET', $Endpoint.getEndpoint() + '/patient-view/v1/mypatient')
                    .respond(200, listMyPatientsResponse);
            });

            it('should define a .listMyPatients method', function () {
                assert.isDefined(PatientManagementService.listMyPatients, '.listMyPatients method not defined');
                assert.isFunction(PatientManagementService.listMyPatients, '.listMyPatients is not a function');
            });

            it('should send a GET listMyPatients request', function () {
                $httpBackend
                    .expect('GET', $Endpoint.getEndpoint() + '/patient-view/v1/mypatient?limit=10&offset=0')
                    .respond(200, { totalRecords: 0, listPatientVO: [] });

                resolvePromise();
				
				PatientManagementService.listMyPatients(0, 10, null);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should send a GET listMyPatients request ignoring nonvalid page', function () {
                $httpBackend
                    .expect('GET', $Endpoint.getEndpoint() + '/patient-view/v1/mypatient?limit=10&offset=0')
                    .respond(200, { totalRecords: 0, listPatientVO: [] });

                resolvePromise();
				
				PatientManagementService.listMyPatients(0, 10, null);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should send a GET listMyPatients request asking for a specifc page', function () {
                $httpBackend
                    .expect('GET', $Endpoint.getEndpoint() + '/patient-view/v1/mypatient?limit=10&offset=0')
                    .respond(200, { totalRecords: 0, listPatientVO: [] });

                resolvePromise();
				
				PatientManagementService.listMyPatients(0, 10, null);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should send a GET listMyPatients request ignoring nonvalid records per page', function () {
                $httpBackend
                    .expect('GET', $Endpoint.getEndpoint() + '/patient-view/v1/mypatient?limit=10&offset=0')
                    .respond(200, { totalRecords: 0, listPatientVO: [] });

                resolvePromise();
				
				PatientManagementService.listMyPatients(0, 10, null);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should send a GET listMyPatients request asking for a specifc page size', function () {
                $httpBackend
                    .expect('GET', $Endpoint.getEndpoint() + '/patient-view/v1/mypatient?limit=10&offset=0')
                    .respond(200, { totalRecords: 0, listPatientVO: [] });

                resolvePromise();
				
				PatientManagementService.listMyPatients(0, 10, null);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should send a GET listMyPatients request asking for a specifc ordernation', function () {
                $httpBackend
                    .expect('GET', $Endpoint.getEndpoint() + '/patient-view/v1/mypatient?limit=10&offset=0')
                    .respond(200, { totalRecords: 0, listPatientVO: [] });
                
                resolvePromise();
				
				PatientManagementService.listMyPatients(0, 10, null);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should send a GET listMyPatients request asking for a descending or ascending ordenation', function () {
                $httpBackend
                    .expect('GET', $Endpoint.getEndpoint() + '/patient-view/v1/mypatient?limit=10&offset=0')
                    .respond(200, { totalRecords: 0, listPatientVO: [] });

                resolvePromise();
				
				PatientManagementService.listMyPatients(0, 10, null);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should call the "then" promise callback when the listMyPatients returns'
                + 'successfully and pass the data as argument', function () {
                var successCallbackSpy = sinon.spy();
                var errorCallbackSpy = sinon.spy();

                resolvePromise();

                PatientManagementService.listMyPatients().then(successCallbackSpy, errorCallbackSpy);
                $httpBackend.flush();

                assert(successCallbackSpy.called, 'listMyPatients not calling the successCallbackSpy or not passing the right response');
                assert(!errorCallbackSpy.called, 'listMyPatients calling the errorCallbackSpy inappropriately');
            });

            it('should call the "then" exception callback when the listMyPatients fail'
                + 'and pass the status code as argument', function () {
                $httpBackend.when('GET', $Endpoint.getEndpoint() + '/patient-view/v1/mypatient?limit=10&offset=0')
                    .respond(400);
                var successCallbackSpy = sinon.spy();
                var errorCallbackSpy = sinon.spy();

                resolvePromise();
		
				PatientManagementService.listMyPatients(0, 10, null).then(successCallbackSpy, errorCallbackSpy);
                $httpBackend.flush();

                assert(errorCallbackSpy.calledWith(400), 'listMyPatients not calling the errorCallbackSpy or not passing the right response');
                assert(!successCallbackSpy.called, 'listMyPatients calling the successCallbackSpy inappropriately');
            });

            it('should call the "then" exception callback when the getEndpointAsync fails', function () {
                var successCallbackSpy = sinon.spy();
                var errorCallbackSpy = sinon.spy();

                PatientManagementService.listMyPatients(0, 10, null).then(successCallbackSpy, errorCallbackSpy);

                expect(successCallbackSpy.called).to.be.false;
                expect(errorCallbackSpy.called).to.be.false;

                deferred.reject();
                $rootScope.$apply();

                expect(successCallbackSpy.called).to.be.false;
                expect(errorCallbackSpy.called).to.be.true;
            });
        });
    });
});
