/*
 * ge-generic-list-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define([ 'angular-mocks',  'modules/platform/directives/ge-notification/ge-notification-directive' ], function() {
    'use strict';


    describe('Generic list controller', function () {
        var scope, deregisterSpy, rootScopeCallback, rootScopeEvent, $controller, controller;

        beforeEach(module('Platform.Directive.Notification'));
        beforeEach(function () {
            inject(function ($rootScope, _$controller_) {
                scope = $rootScope.$new();
                deregisterSpy = sinon.spy();
                var rootScope = {
                    $on: function(eventName, fn){
                        rootScopeCallback = fn;
                        rootScopeEvent = eventName;
                        return deregisterSpy;
                    }
                };

                $controller = _$controller_;
                controller = _$controller_('geNotificationController', {
                    $scope: scope,
                    $rootScope: rootScope
                });
            });
        });

        it("should have a controller defined", function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it('should handles "notification:add" broadcast event', function(){
            expect(rootScopeEvent).to.be.equal('notification:add');
            expect(rootScopeCallback).not.to.be.undefined;

            var exampleMessage = "Lorem Pista went to somewhere";
            scope.messages = [];
            rootScopeCallback(null, exampleMessage);
            expect(scope.messages.length).to.be.equal(1);
            expect(scope.messages[0]).to.be.equal(exampleMessage);
        });

        it('should be able to remove message', function(){
            var exampleMessage = "Lorem Pista went to somewhere";
            scope.messages = [];
            rootScopeCallback(null, exampleMessage);

            expect(scope.messages.length).to.be.equal(1);
            expect(scope.messages[0]).to.be.equal(exampleMessage);

            scope.closeAlert();
            expect(scope.messages.length).to.be.equal(0);
        });

        it('should deregister the "notification:add listener"', function () {
            scope.$destroy();
            expect(deregisterSpy.calledOnce).to.be.true;
        });

    });

    describe('Generic list directive', function() {
        var $compile;
        var $rootScope;

        beforeEach(module('templates'));
        beforeEach(module('Platform.Directive.Notification', function ($provide) {
            ['translateFilter'].forEach(function(f){
                $provide.value(f, function(val){
                    return val;
                });
            });
        }));

        beforeEach(inject(function(_$compile_, _$rootScope_) {
            $compile = _$compile_;
            $rootScope = _$rootScope_;
        }));

        it('should be defined', function() {
            var scope = $rootScope.$new();
            var element = $compile("<ge-notification></ge-notification>")(scope);
            $rootScope.$digest();
            var html = element.html();
            expect(html).to.have.length.of.at.least(1);
        });
    });
});