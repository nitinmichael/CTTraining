angular.module('cloudav.renderingService', []).constant('renderingServiceMock', {
    renderingServiceMock: function() {
        return {
            openSession: sinon.spy(),
            stopKeepAlive: sinon.spy()
        };
    }
});
