/*
 * mdt-session-service-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular', 'angular-mocks', 'mdt/modules/mdt-session-management/services/mdt-session-service'], function () {
    'use strict';

    describe("MdtSessionService", function () {
        var MdtSessionService, $httpBackend;
        var ROOT_URL = 'http://localhost:8080';
        var CASE_SERVICE_URL = 'http://caseservice.ge.com';

        beforeEach(function () {
            angular.module('Services.caseExchangeDataService', []);

            module('Services.caseExchangeDataService', function($provide) {
                $provide.value('CaseExchangeDataService', {
                    getServiceURL: function() {
                        return CASE_SERVICE_URL;
                    }
                })
            });

            module('Mdt.Module.MdtSessionService', function ($provide) {
                // add a mock $Endpoint provider - it will return ROOT_URL for any endpoint)
                $provide.value('$Endpoint', {
                    getEndpoint: function () {
                        return ROOT_URL;
                    },
                    getEndpointAsync: function(){
                        return {
                            then: function(success){
                                var publicAPI = success(ROOT_URL);
                                return {
                                    then: function(fn){
                                        fn(publicAPI);
                                    }
                                };
                            }
                        };
                    }
                });
            });

            inject(function (_MdtSessionService_, _$httpBackend_) {
                MdtSessionService = _MdtSessionService_;
                $httpBackend = _$httpBackend_;
            });
        });

        describe("MdtSessionService service test suite", function () {

            describe("getSessionHeaders service test suite", function () {
                it("should call session headers list service", function () {
                    $httpBackend.expectGET(ROOT_URL + '/views/manage-meetings/list-meetings').respond({});
                    MdtSessionService.then(function(service){
                        service.getSessionHeaders();
                    });
                    $httpBackend.flush();
                });
            });

            describe("reorderCases service test suite", function () {
                it("should call put on reorder-cases service", function () {
                    $httpBackend.expectPUT(ROOT_URL + '/views/manage-meetings/reorder-cases').respond({});
                    MdtSessionService.then(function(service) {
                        service.reorderCases();
                    });
                    $httpBackend.flush();
                });
            });

            describe("getProgressiveSessionDetails test suite", function(){
                it("should call the defined API endpoint", function(){
                    var sessionId = "ABC123";
                    $httpBackend
                        .expectGET(ROOT_URL + '/views/manage-meetings/meeting-frame/' + sessionId)
                        .respond({
                            id: sessionId
                        });

                    var successCallback = sinon.spy(),
                        promiseCallback = sinon.spy();

                    MdtSessionService.then(function(service) {
                        var promise = service.getProgressiveSessionDetails(sessionId, successCallback);
                        promise.success(promiseCallback);
                    });

                    $httpBackend.flush();

                    expect(successCallback.calledOnce).to.be.true;
                    expect(promiseCallback.calledOnce).to.be.true;
                });

                it("should call proper callbacks based on success or error", function(){
                    var sessionId = "ABC123";
                    $httpBackend
                        .when('GET', ROOT_URL + '/views/manage-meetings/meeting-frame/' + sessionId)
                        .respond(401, '');

                    var successCallback = sinon.spy(),
                        failureCallback = sinon.spy(),
                        promiseCallback = sinon.spy();

                    MdtSessionService.then(function(service) {
                        var promise = service.getProgressiveSessionDetails(sessionId, successCallback, failureCallback);
                        promise.error(promiseCallback);
                    });
                    $httpBackend.flush();

                    expect(successCallback.callCount).to.be.equal(0);
                    expect(failureCallback.callCount).to.be.equal(1);
                    expect(promiseCallback.callCount).to.be.equal(1);

                    MdtSessionService.then(function(service) {
                        var promise = service.getProgressiveSessionDetails(sessionId, successCallback);
                        promise.error(promiseCallback);
                    });

                    $httpBackend.flush();

                    expect(successCallback.callCount).to.be.equal(0);
                    expect(failureCallback.callCount).to.be.equal(1);
                    expect(promiseCallback.callCount).to.be.equal(2);
                });
            });

            describe("getCaseHeader test suite", function(){
                it("should call the defined API endpoint", function(){
                    var caseId = "ABC123";
                    $httpBackend
                        .expectGET(ROOT_URL + '/views/manage-meetings/case-header/' + caseId)
                        .respond({
                            id: caseId
                        });

                    var successCallback = sinon.spy(),
                        promiseCallback = sinon.spy();

                    MdtSessionService.then(function(service) {
                        var promise = service.getCaseHeader(caseId, successCallback);
                        promise.success(promiseCallback);
                    });

                    $httpBackend.flush();

                    expect(successCallback.calledOnce).to.be.true;
                    expect(promiseCallback.calledOnce).to.be.true;
                });

                it("should call proper callbacks based on success or error", function(){
                    var caseId = "ABC123";
                    $httpBackend
                        .when('GET', ROOT_URL + '/views/manage-meetings/case-header/' + caseId)
                        .respond(401, '');

                    var successCallback = sinon.spy(),
                        failureCallback = sinon.spy(),
                        promiseCallback = sinon.spy();

                    MdtSessionService.then(function(service) {
                        var promise = service.getCaseHeader(caseId, successCallback, failureCallback);
                        promise.error(promiseCallback);
                    });

                    $httpBackend.flush();

                    expect(successCallback.callCount).to.be.equal(0);
                    expect(failureCallback.callCount).to.be.equal(1);
                    expect(promiseCallback.callCount).to.be.equal(1);

                    MdtSessionService.then(function(service) {
                        var promise = service.getCaseHeader(caseId, successCallback);
                        promise.error(promiseCallback);
                    });

                    $httpBackend.flush();

                    expect(successCallback.callCount).to.be.equal(0);
                    expect(failureCallback.callCount).to.be.equal(1);
                    expect(promiseCallback.callCount).to.be.equal(2);
                });
            });

            afterEach(function () {
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

    });
});
