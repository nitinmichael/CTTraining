define(['angular', 'angular-mocks','orgMgmnt/dataModels/organizationDataModel'],
    function(ng){
        'use strict';

        describe('Test Organization Data Model ', function(){
            var _orgDataModel;

            beforeEach( function(){
                module('Orgmanagement.DataModel.OrgDataModel');
            });

            beforeEach(inject(function(orgDataModel){
                _orgDataModel = orgDataModel;
            }));

            describe('When orgInfoObject is called', function(){
                it('should test the return value', function(){
                    var  resource = "org";
                    var name = "gehc";
                    var address = ['line1 address'];
                    var ext = ['one'];
                    var orgInfoObject  = _orgDataModel.orgInfoObject (resource, name, address, ext);
                    chai.expect(orgInfoObject.name).to.be.equal(name);
                });
            });

            describe('When getOrgAdminUpdateObj called ',function(){
                it('should test the return of variable', function(){
                    var orgId = '123',
                        adminToAdd=['34', '67'],
                        orgAdminObj = _orgDataModel.getOrgAdminUpdateObj(orgId, adminToAdd);
                    chai.expect(orgAdminObj).to.have.length(2);
                });

                it('should test the return of variable', function(){
                    var orgId = '123',
                        adminToRemove=['34', '67'],
                        adminToAdd = undefined,
                        orgAdminObj = _orgDataModel.getOrgAdminUpdateObj(orgId, adminToAdd, adminToRemove);
                    chai.expect(orgAdminObj).to.have.length(2);
                });
            });
        });
    });
