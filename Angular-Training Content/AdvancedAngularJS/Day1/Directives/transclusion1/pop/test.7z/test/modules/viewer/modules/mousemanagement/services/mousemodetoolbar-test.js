/*
 * mousemodetoolbar-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 *
 * @author: Josselin BUILS <josselin.buils@ge.com>
 */

/**
 * Spec file for Viewer > modules > mousemanagement > services > mousemodetoolbar service
 */
define(['angular', 'deviceManagerServiceMock', 'mousemanagementModule/module', 'mousemanagementModule/services/mousemodetoolbar'], function() {
    'use strict';

    describe('mousemodetoolbar:', function() {
        var imageAreaToolbarFactory,
            imagingToolbarFactory,
            mousemodetoolbarFactory;

        beforeEach(module('deviceManagerServiceMock'));

        beforeEach(module('cloudav.viewerApp.mousemanagement'), function($provide) {
            $provide.value('$http', {
                success: function() {
                    return 'ok';
                }
            });
        });

        beforeEach(inject(function(_imageAreaToolbarFactory_, _imagingToolbarFactory_, _mousemodetoolbarFactory_) {
            imageAreaToolbarFactory = _imageAreaToolbarFactory_;
            imagingToolbarFactory = _imagingToolbarFactory_;
            mousemodetoolbarFactory = _mousemodetoolbarFactory_;
        }));

        it('imageAreaToolbarFactory should do a http request', function() {
            imageAreaToolbarFactory.success(function(data) {
                expect(data).to.equal('ok');
            });
        });

        it('imagingToolbarFactory should do a http request', function() {
            imagingToolbarFactory.success(function(data) {
                expect(data).to.equal('ok');
            });
        });

        it('mousemodetoolbarFactory should do a http request', function() {
            mousemodetoolbarFactory.success(function(data) {
                expect(data).to.equal('ok');
            });
        });
    });
});
