/*
 * ge-age-filter-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define([ 'angular-mocks',  'modules/platform/filters/ge-age-filter' ], function() {
    describe('Age calculator filter', function() {
        var $filter;

        beforeEach(module('platform.filter.ge-age-filter'));
        beforeEach(inject(function(_$filter_) {
            $filter = _$filter_('geAge');
        }));

        it("should have a filter defined", function () {
            assert.isDefined($filter, 'filter is not defined');
        });

        it('should calculate age based on data obj', function(){
            var dateObj = new Date(),
                requiredAge = 30;
            dateObj.setFullYear(dateObj.getFullYear() - requiredAge);
            dateObj.setDate(dateObj.getDate() - 1);

            var age = $filter(dateObj);

            expect(age).to.be.equal(requiredAge);
        });

        it('should calculate age based on data obj corrected if actual date is not passed', function(){
            var dateObj = new Date(),
                requiredAge = 30;
            dateObj.setFullYear(dateObj.getFullYear() - requiredAge);
            dateObj.setDate(dateObj.getDate() + 1);

            var age = $filter(dateObj);

            expect(age).to.be.equal(requiredAge - 1);
        })

    });
});