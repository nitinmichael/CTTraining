 define(['angular', 'angular-mocks', 'modules/xjtweb-platform/services/viewer-layout-service'], function(ng, mocks) {
    'use strict';

    describe('viewerLayoutService', function() {
        var element;
        var scope;
        var viewerLayoutSvc;
        var jsonMock;

        beforeEach(module('viewerLayoutService'));

        beforeEach(module(function($provide) {
            $provide.factory('$logger', function(){
                return {};
            });
        }));

        beforeEach(inject(function($compile, $rootScope) {
            scope = $rootScope.$new();

            scope.visiblePorts = 4;
            scope.cssLayout = 'twoByTwo';
            scope.usePredefinedLayout = false;

             scope.$on('viewerLayoutChange', function(event, args) {
                 scope.visiblePorts = args.visiblePorts;
                 scope.cssLayout = args.cssLayout;
                 scope.usePredefinedLayout = args.usePredefinedLayout;
             });

            scope.$digest();
        }));

        beforeEach(inject(function ($viewerLayoutService) {
            viewerLayoutSvc = $viewerLayoutService;
        }));

        /**
         * @ngdoc method
         * @name ViewerLayoutServiceTest
         * @methodOf xjtweb-platform.$viewerLayoutService
         *
         * @description This test method determines that the $viewerLayoutService takes an object as parameter and
         *              update the scope with the content of the object. //
         */
        describe('Testing $viewerLayoutService', function() {

            it('setLayout should throw an exception when params is not an object', function() {
                expect(function() {
                    viewerLayoutSvc.setLayout(null);
                }).to.throw(TypeError, 'params should be an object');
                expect(function() {
                    viewerLayoutSvc.setLayout('not_an_object');
                }).to.throw(TypeError, 'params should be an object');
            });

            it('scope values should be updated', function() {
                var testData = { 'visiblePorts': 2, 'cssLayout': 'oneByOne', 'usePredefinedLayout': true };
                viewerLayoutSvc.setLayout(testData);

                expect(scope.visiblePorts).to.equal(2);
                expect(scope.cssLayout).to.equal('oneByOne');
                expect(scope.usePredefinedLayout).to.equal(true);
            });

        });
    });
});
