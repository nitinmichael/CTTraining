define(['angular-mocks', 'modules/platform/services/tool-provider'], function() {
    describe('Test $toolFactory service', function() {
        var $logger, $toolFactory;

        beforeEach(function() {
            module('platform.service.tool-provider');

            module(function($provide) {
                $logger = {
                    error: sinon.spy()
                };

                $provide.value('$logger', $logger);
            });

            inject(function(_$toolFactory_) {
                $toolFactory = _$toolFactory_;
            });
        });

        it('should defines $toolFactory', function() {
            expect($toolFactory).to.exist;
        });

        it('should generate an icon object', function() {
            expect(new $toolFactory.Icon()).to.eql({});
            expect($logger.error.calledWith('icon created without a configuration object.'));

            expect(new $toolFactory.Icon({})).to.eql({});
            expect($logger.error.calledWith('icon created without an url or a css class.'));

            expect(new $toolFactory.Icon({
                url: 'pikachu.svg'
            })).to.eql({
                url: 'pikachu.svg',
                type: 'svg',
                urlLightsOff: undefined
            });
            expect($logger.error.calledWith('icon created without a lights off string URL.'));

            expect(new $toolFactory.Icon({
                url: 'snorlax.png',
                urlLightsOff: 'asleepSnorlax.png',
            })).to.eql({
                url: 'snorlax.png',
                type: 'bitmap',
                urlLightsOff: 'asleepSnorlax.png'
            });

            expect(new $toolFactory.Icon({
                class: 'meow'
            })).to.eql({
                type: 'css',
                class: 'meow'
            });
        });
    });
});
