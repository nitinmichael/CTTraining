define(['angular', 'modules/viewer/modules/linking/module'], function(angular) {
    angular.module('cloudav.viewerApp.linkingviewport')
        .constant('linkingMocks', {
            linkingFilterMock: function($q) {
                var filters = {};
                filters.zoom = {};
                filters.zoom.filter = function(viewId, data) {
                    return true;
                };
                filters.zoom2 = {};
                filters.zoom2.filter = function(viewId, data) {
                    return false;
                };

                var createPromise = function(callback, viewId, data) {
                    return $q(function(resolve, reject) {
                        if (callback(viewId, data)) {
                            resolve(true);
                        } else {
                            reject(false);
                        }
                    });
                };


                return {
                    check: function(eventName, viewId, data) {
                        var promises = [];
                        var eventFilters = filters[eventName];
                        for (var i in eventFilters) {
                            promises.push(createPromise(eventFilters[i], viewId, data));
                        }
                        return $q.all(promises);
                    },
                    add: function(eventName, filter, callback) {}
                };
            },
            linkingFilterTestCallbackMocks: function() {
                var mock = {
                    filters: [],
                    add: function(eventName, filter, callback) {
                        this.filters[filter] = callback;
                    },
                    destroy: sinon.spy()
                };
                return mock;
            },
            linkingManagerMock: function() {
                return {
                    viewEventEmitter: null,
                    publish: sinon.spy(),
                    subscribe: function() {},
                    unscrible: function() {},
                    link: function(id) {},
                    unlink: function() {},
                    destroy: sinon.spy()
                };
            },
            linkingSettingsMock: {
                LINKING_CHANNEL: 'LINKING_CHANNEL',
                SAME_TYPE_FILTER: 'SAME_TYPE_FILTER',
                NOT_VR_VIEW_RECEIVER: 'NOT_VR_VIEW_RECEIVER',
                SAME_RENDERER_TYPE_FILTER: 'SAME_RENDERER_TYPE_FILTER'
            }
        });
});
