/*
 *  case-inbox-controller-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Henry Navarro<henry.navarro@ge.com>
 */

/**
 * Spec file for Case Inbox controller module
 */

define(['angular',
        'angular-mocks',
        'case-inbox/module',
        'case-inbox/controllers/case-inbox-controller',
        'case-exchange/services/case-exchange-data-service',
        'mocks/case-exchange-mock-service'], function () {

    'use strict';
    var scope, controller, rootScope, caseDataService, caseExchangeDataService, getPacsServices, getBillingOrganizationsService, caseTransactions, caseDetailsJSON, caseHeaderJSON, caseReviewedDetailsJSON, caseDicomAttachment,
    $q, caseUpdateType,  mockServer, $mockServerLoader, meServiceResponse, timeout, caseExchangeMocks, billingOrganizationList, billingOrganizations, callback = 'success';

    describe('Case Inbox Controller Test Suite::', function () {

        beforeEach(function() {
            // Load the module for the mock data first
            module('cloudav.caseExchange.mocks');
            // Load the Sinon fake server.
            module('cloudav.caseExchange.fakeServer');

            module('cloudav.caseExchange.caseInboxCtrl', function ($provide) {

                $provide.factory('CaseDataService', ['$q', function ($q) {
                    function getCaseDetails() {
                        return $q.when(caseDetailsJSON);
                    }

                    function getCaseHeaders() {
                        return $q.when(caseHeaderJSON);
                    }

                    function markCaseAsReviewed() {
                        return $q.when(caseReviewedDetailsJSON);
                    }

                    return {
                        getCaseHeaders: getCaseHeaders,
                        getCaseDetails: getCaseDetails,
                        markCaseAsReviewed: markCaseAsReviewed
                    }
                }]);

                $provide.factory('GetPacsServices', ['$q', function ($q) {
                    function getPacsDevices() {
                        var deferred = $q.defer(),
                            promise = deferred.promise;

                        if(callback === 'success'){
                            deferred.resolve(caseDicomAttachment);
                        }
                        else{
                            deferred.reject('error');
                        }
                        return promise;
                    }

                    return {
                        getPacsDevices: getPacsDevices
                    }
                }]);

                $provide.factory('GetBillingOrganizationsService', ['$q', function ($q) {
                    function getOrganizationsForLoggedInUser() {
                        var deferred = $q.defer(),
                            promise = deferred.promise;

                        if(callback === 'success'){
                            deferred.resolve(billingOrganizations);
                        }
                        else{
                            deferred.reject('error');
                        }
                        return promise;
                    }

                    return {
                        getOrganizationsForLoggedInUser: getOrganizationsForLoggedInUser
                    }
                }]);

                $provide.value('$state', {
                    transitionTo: function (url) {
                    },
                    current: {
                        params: {}
                    },
                    go: function() {}
                });

                $provide.value('$stateParams', {
                    id: function () {
                    }
                });

                $provide.factory('configurationService', ['$q', function($q){
                    return {
                        getProperty: function(){
                            return $q.when({});
                        }
                    }
                }]);
            })
        });

        // Initialize the scope and controller variables
        beforeEach(inject(
            function ($rootScope, $controller, _$q_, _CaseDataService_, _CaseExchangeDataService_, _GetPacsServices_, _GetBillingOrganizationsService_, CaseExchangeMocks, $MockServerLoader,
                      $timeout) {
                scope = $rootScope.$new();
                rootScope = $rootScope;
                controller = $controller;
                $q = _$q_;
                caseDataService = _CaseDataService_;
                caseExchangeDataService = _CaseExchangeDataService_;
                getPacsServices = _GetPacsServices_;
                getBillingOrganizationsService = _GetBillingOrganizationsService_;
                timeout = $timeout;
                caseExchangeMocks = CaseExchangeMocks;
                caseTransactions = CaseExchangeMocks.getCaseTransactions();
                caseDetailsJSON = CaseExchangeMocks.getCaseDetails();
                caseHeaderJSON = CaseExchangeMocks.getCaseHeaders();
                caseDicomAttachment = CaseExchangeMocks.getCaseDicomAttachment();
                billingOrganizations = CaseExchangeMocks.getBillingOrganizationsDetails();
                meServiceResponse = CaseExchangeMocks.getMeServiceResponse();

                caseReviewedDetailsJSON = CaseExchangeMocks.getCaseDetails();
                
                caseReviewedDetailsJSON.participants[0].reviewed = true;

                // Initialize the controller before each spec
                controller('CaseInboxCtrl', {
                    $scope: scope,
                    caseDataService: caseDataService,
                    caseExchangeDataService: caseExchangeDataService,
                    getBillingOrganizationsService: getBillingOrganizationsService
                });

                // Mocking the variable from parent controller as we don't have inheritance in place in unit testing.
                scope.alertTypes = {
                    success: 'success',
                    error: 'error'
                };

                // Mocking the method from parent controller as we don't have inheritance in place in unit testing.
                scope.showAlertMessage = function () {
                };
                
                $mockServerLoader = $MockServerLoader;
                // Call the init to initialize the Sinon Mock Data Server.
                mockServer = $mockServerLoader.init();
            }
        ));

        it('should have a controller', function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it('should call blockUI if user doesn\'t have any role', function(){
            meServiceResponse.role = null;
            caseExchangeDataService.setCurrentUser(meServiceResponse);
            // Initialize the controller before each specs
            controller('CaseInboxCtrl', {
                $scope: scope,
                caseDataService: caseDataService,
                caseExchangeDataService: caseExchangeDataService,
                getPacsServices: getPacsServices,
                getBillingOrganizationsService: getBillingOrganizationsService
            });
            timeout.flush();
            expect(scope.loadUI).to.equal(false);
        });

        it('should have a "launchCreateCase" function', function () {
            assert.isDefined(scope.launchCreateCase, 'Controller scope doesn\'t have "launchCreateCase" function defined');
        });

        it('should have a "showCases" function', function () {
            assert.isDefined(scope.showCases, 'Controller scope doesn\'t have "showCases" function defined');
        });

        it('should have a "searchCases" function', function () {
            assert.isDefined(scope.searchCases, 'Controller scope doesn\'t have "searchCases" function defined');
        });

        it('should have a "showFilterCases" function', function () {
            assert.isDefined(scope.showFilterCases, 'Controller scope doesn\'t have "showFilterCases" function defined');
        });

        it('should have an "offset" property', function () {
            assert.isDefined(scope.offset, 'Controller scope doesn\'t have "offset" property defined');
        });

        it('should have a "limit" property', function () {
            assert.isDefined(scope.limit, 'Controller scope doesn\'t have "limit" property defined');
        });

        it('should have a "selectedCase" property', function () {
            assert.isDefined(scope.selectedCase, 'Controller scope doesn\'t have "selectedCase" property defined');
        });

        it('should have a "cases" property', function () {
            assert.isDefined(scope.cases, 'Controller scope doesn\'t have "cases" property defined');
        });

        it('should have a "caseDetails" property', function () {
            assert.isDefined(scope.caseDetails, 'Controller scope doesn\'t have "caseDetails" property defined');
        });

        it('should have a "caseUpdateType" property', function () {
            assert.isDefined(scope.caseUpdateType, 'Controller scope doesn\'t have "caseUpdateType" property defined');
        });

        it('should have a "caseUpdateType.ADD_CASE" property', function () {
            assert.isDefined(scope.caseUpdateType.ADD_CASE, 'Controller scope doesn\'t have "caseUpdateType.ADD_CASE" property defined');
        });

        it('should have a "caseUpdateType.ADD_USERS" property', function () {
            assert.isDefined(scope.caseUpdateType.ADD_USERS, 'Controller scope doesn\'t have "caseUpdateType.ADD_USERS" property defined');
        });

        it('should have a "showingMoreDetailsOnPatientBanner" property', function () {
            assert.isDefined(scope.showingMoreDetailsOnPatientBanner, 'Controller scope doesn\'t have "showingMoreDetailsOnPatientBanner" property defined');
        });

        it('should have a "isCurrentUserPatient" property', function () {
            assert.isDefined(scope.isCurrentUserPatient, 'Controller scope doesn\'t have "isCurrentUserPatient" property defined');
        });

        // Use Sinon to replace jQuery's ajax method with a spy.
        beforeEach(function () {
            sinon.stub($, 'ajax').yieldsTo('success', {});
        });

        // Restore jQuery's ajax method to its original state
        afterEach(function () {
            $.ajax.restore();
        });

        it('should have inboxType "ALL" when showFilterCases() is called with default filters', function () {
            scope.showFilterCases();

            expect(scope.inboxType).to.equal('ALL');
        });

        // begin: test cases for case list patient search

        it('should search when search text is at least 2 characters', function () {
            scope.search.text = 'ab';
            scope.isFetchingCases = false;
            scope.lastCaseFetched = false;
            scope.searchCases();
            expect(scope.isFetchingCases).to.be.true;
        });

        it('should search when search text is blank and a previous search had been done', function () {
            scope.search.text = 'ab';
            scope.searchCases();
            scope.isFetchingCases = false;
            scope.searchText = '';
            scope.searchCases();
            expect(scope.caseSearchMessage.length).to.equal(0);
        });

        it('should not search when search text has length 1 and a previous search had been done', function () {
            scope.search.text = 'ab';
            scope.searchCases();
            scope.isFetchingCases = false;
            scope.search.text = 'a';
            scope.searchCases();
            expect(scope.errorMessage.length).not.to.equal(0);
        });

        it('should not search and show message when search text is less than 2 characters', function () {
            scope.search.text = 'a';
            scope.searchCases();
            expect(scope.errorMessage.length).not.to.equal(0);
        });

        it('should not search and show message when search text is other than allowed characters', function () {
            scope.search.text = '@@';
            scope.searchCases();
            expect(scope.errorMessage.length).not.to.equal(0);
        });

        it('should hide case details after a search is done', function () {
            scope.showDetails = true;
            scope.search.text = 'ab';
            scope.searchCases();
            expect(scope.showDetails).to.be.false;
        });

        it('should search for cases using lowercased search text', function () {
            scope.search.text = 'UPPERCASE';
            scope.inboxType = 'ALL';
            scope.offset = 0;
            scope.limit = 10;
            scope.isFetchingCases = false;
            scope.lastCaseFetched = false;
            scope.searchCases();
            expect(scope.transformedSearchText).to.equal('uppercase');
        });

        it('should not search while fetching cases', function () {
            var showCasesSpy = sinon.spy(scope, 'showCases');
            scope.isFetchingCases = true;
            scope.searchCases();
            assert(showCasesSpy.notCalled);
        });

        it('should not search while fetching cases', function () {
            scope.search.text = '';
            scope.searchCases();
            expect(scope.search.text).to.equal(null);
        });

        // end: test cases for case list patient search

        it('should display case list with case selected and case detail section open', function () {
            caseExchangeDataService.setSelectedCaseDetails(caseHeaderJSON[1].id, 100);
            scope.inboxType = 'ALL';
            angular.element = $;
            caseExchangeDataService.setCurrentUser(meServiceResponse);
            scope.showCases();
            rootScope.$apply();
            timeout.flush();
            expect(scope.cases[1].id).to.equal(caseExchangeDataService.getSelectedCaseDetails().id);
         });

        it('should populate case details when showCaseDetails() is called', function () {
            caseExchangeDataService.setCurrentUser(meServiceResponse);
            scope.showCaseDetails(caseDetailsJSON);
            rootScope.$apply();
            expect(scope.selectedCase.transactions.id).to.eql(caseTransactions.id);
        });

        it('should unselect case when case is already selected and showCaseDetails() is called', function () {
            scope.selectedCase = caseDetailsJSON;
            caseExchangeDataService.setCurrentUser(meServiceResponse);
            scope.showCaseDetails(caseDetailsJSON);
            rootScope.$apply();

            expect(scope.selectedCase).to.be.a('null');
            expect(scope.showDetails).to.be.false;
        });

        it('should select case when case is not already selected and showCaseDetails() is called', function () {
            caseExchangeDataService.setCurrentUser(meServiceResponse);
            scope.showCaseDetails(caseDetailsJSON);
            rootScope.$apply();

            expect(scope.selectedCase.id).to.equal(caseDetailsJSON.id);
            expect(scope.showDetails).to.be.true;
        });

        it('should calculate the age of the patient from his/her dob', function () {
            //This test creates a date object which is 14.5 years in the past from
            //the current date to simulate the DOB of someone who is 14 years old
            var currentDate = new Date();
            var yearInMillseconds = 365 * 24 * 60 * 60 * 1000;
            var pastDate = new Date();
            pastDate.setTime(currentDate.getTime() - 14.5 * yearInMillseconds);
            var birthDate = pastDate.getDate() + "-" + caseExchangeMocks.getMonthAbbreviation(pastDate.getMonth()) + "-" + pastDate.getFullYear();

            var patientAge = caseExchangeDataService.calculatePatientAge(birthDate);

            expect(patientAge).to.equal(14);
        });

        it('should convert the string date to a date object', function () {
            var convertedDate = caseExchangeDataService.convertToDate('2000.12.12');

            expect(convertedDate).to.be.an.instanceOf(Date);
            expect(convertedDate.getFullYear()).to.equal(2000);
            expect(convertedDate.getMonth() + 1).to.equal(12);
            expect(convertedDate.getDate()).to.equal(12);
        });

        it('should set the case update type as "ADDUSERS"', function () {
            scope.selectedCase = caseDetailsJSON;
            scope.updateCase("ADDUSERS");
            expect(caseExchangeDataService.getCaseUpdateType()).to.equal('ADDUSERS');
        });

        it('should have a "getPacsDevices" function', function () {
            assert.isDefined(scope.getPacsDevices, 'Controller scope doesn\'t have "getPacsDevices" function defined');
        });

        it('should call getPacsSevices.getPacsDevices when scope.getPacsDevices is called', function () {
            var getPacsDevicesSpy = sinon.spy(getPacsServices, 'getPacsDevices')
            scope.getPacsDevices();
            assert(getPacsDevicesSpy.calledOnce);
        });


        it('should toggle the "showingMoreDetailsOnPatientBanner" flag value on call of the function "togglePatientBannerDetails"', function(){
            scope.showingMoreDetailsOnPatientBanner = false;
            scope.togglePatientBannerDetails();
            expect(scope.showingMoreDetailsOnPatientBanner).to.be.true;
        });

        it('should reset value for the flag "showingMoreDetailsOnPatientBanner" on "showCaseDetails" function call', function(){
            scope.selectedCase = caseDetailsJSON;
            scope.showingMoreDetailsOnPatientBanner = true;
            caseExchangeDataService.setCurrentUser(meServiceResponse);
            scope.showCaseDetails({ id: 2 });
            rootScope.$apply();
            expect(scope.showingMoreDetailsOnPatientBanner).to.be.false;
        });

        it('should set $scope.downloading to true when $scope.launchDownloadToPremise() is called', function() {
            scope.isCaseTxnStatusCompleted = true;
            scope.selectedCaseStudies = [{}];
            scope.pacsDevices = [{}];
            scope.launchDownloadToPremise();
            expect(scope.downloading).to.be.true;
        });


        it('should call getBillingOrganizationsService when launchCreateCase is called',
            inject( function($state, $stateParams) {
                var getBillingOrgSpy = sinon.spy(getBillingOrganizationsService, 'getOrganizationsForLoggedInUser');
                scope.launchCreateCase();
                rootScope.$apply();
                assert(getBillingOrgSpy.calledOnce);
            })
        );

        it('should call getBillingOrganizationsService when launchCreateCase is called',
            inject( function($state, $stateParams) {
                billingOrganizations = [];
                var getBillingOrgSpy = sinon.spy(getBillingOrganizationsService, 'getOrganizationsForLoggedInUser');
                scope.launchCreateCase();
                rootScope.$apply();
                assert(getBillingOrgSpy.calledOnce);
            })
        );

        it('should call getBillingOrganizationsService when launchCreateCase is called',
            inject( function($state, $stateParams) {
                callback = 'error';
                billingOrganizations = [];
                var getBillingOrgSpy = sinon.spy(getBillingOrganizationsService, 'getOrganizationsForLoggedInUser');
                scope.launchCreateCase();
                rootScope.$apply();
                assert(getBillingOrgSpy.calledOnce);
            })
        );

        it('should call $state.transitionTo() when $scope.launchCreateCaseView() is called',
            inject( function($state, $stateParams) {
                var stateTransitionSpy = sinon.spy($state, 'transitionTo');
                scope.launchCreateCaseView();
                assert(stateTransitionSpy.calledOnce);
            })
        );

        it('should call $state.go("viewer.start" if $scope.openViewer() is called with DICOM attachment',
            inject( function($state) {
                var stateGoSpy = sinon.spy($state, 'go');
                scope.selectedCase = { 'id': '123456789.12345' };
                scope.openViewer({ type: scope.attachmentType.DICOM, uid: '123456789.12345.74125.7'});
                assert(stateGoSpy.withArgs('viewer.start').calledOnce);
            })
        );

        it('should call $state.go("viewer.start" if $scope.openViewer() is called with DICOM attachment',
            inject( function($state) {
                var stateGoSpy = sinon.spy($state, 'go');
                scope.selectedCase = { 'id': '123456789.12345' };
                scope.openViewer({ type: scope.attachmentType.DICOM, uid: '123456789.12345.74125.7'});
                assert(stateGoSpy.withArgs('viewer.start').calledOnce);
            })
        );

        it('should not call $state.go("viewer.load" if $scope.openViewer() is called with DICOM attachment',
            inject( function($state) {
                var stateGoSpy = sinon.spy($state, 'go');
                scope.selectedCase = { 'id': '123456789.12345' };
                scope.openViewer({ type: scope.attachmentType.NONDICOM, uri: 'www.ge.com'});
                expect(stateGoSpy).to.have.not.been.called;
            })
        );

        it('should return if $scope.showCaseDetails() is called with no selected case',
            function() {
                scope.showDetails = false;
                scope.showCaseDetails();
                assert(scope.showDetails === false);
            }
        );

        it('should set scope.cases to empty array when caseHeader is forced to return no cases',
            function() {
                // expand Angular's jQLite to full JQuery
                var getCaseHeadersStub = sinon.stub(caseDataService, 'getCaseHeaders');
                getCaseHeadersStub.returns($q.when({}));
                angular.element = $;
                caseExchangeDataService.setCurrentUser(meServiceResponse);
                scope.showCases();
                rootScope.$apply();
                expect(scope.cases.length ===  undefined || scope.cases.length === 0).to.be.true;
            }
        );

        it('should return 2 cases when showCases() is called in the presence of mock case headers',
            function() {
                // expand Angular's jQLite to full JQuery
                angular.element = $;
                caseExchangeDataService.setCurrentUser(meServiceResponse);
                scope.showCases();
                rootScope.$apply();

                expect(scope.cases.length, 2, '2 cases should have been fetched from mock');
            }
        );

        it('should call error handler when mock case headers are forced to fail',
            function() {
                // expand Angular's jQLite to full JQuery
                angular.element = $;
                var getCaseHeadersStub = sinon.stub(caseDataService, 'getCaseHeaders');
                getCaseHeadersStub.returns($q.reject({'error' : 'dummyError', 'status' : 200}));

                var showAlertMessageSpy = sinon.spy(scope, 'showAlertMessage');
                scope.showCases();
                rootScope.$apply();

                expect(showAlertMessageSpy).to.have.been.called;
            }
        );

        it('should not call service for getting case headers if lastCaseFetched is true',function(){
            var getCaseHeadersSpy = sinon.spy(caseDataService, 'getCaseHeaders');
            scope.lastCaseFetched = true;
            scope.showCases();
            rootScope.$apply();
            assert(getCaseHeadersSpy.notCalled);
        });

        it('should call $state.transitionTo("send-to-mdt" if $scope.sendToMDT() is called',
            inject( function($state) {
                var stateTransitionToSpy = sinon.spy($state, 'transitionTo');
                scope.selectedCase = { 'id': '123456789.12345' };
                scope.sendToMDT();
                assert(stateTransitionToSpy.withArgs('mdt-session.send-to-mdt').calledOnce);
            })
        );

        it('should verify the document is supported by document viewer or not', function() {
            scope.isDocumentNotSupportedByDocViewer(caseDetailsJSON.transactions[0].attachments[2]);
            expect(caseDetailsJSON.transactions[0].attachments[2].notSupportedByDocViewer).to.be.true;
        });

        it('should set "hasCurrentUserReviewedCase" to true after reviewed case', function() {
            scope.selectedCase = caseDetailsJSON;
            scope.selectedItemObj.selectedItem = caseDetailsJSON;
            scope.selectedCase.hasCurrentUserReviewedCase = false;
            scope.markCaseAsReviewed();
            rootScope.$apply();
            expect(scope.selectedCase.hasCurrentUserReviewedCase).to.be.true;
        });
    });
});
