define([ 'postal', 'angular', 'angular-mocks', 'modules/xjtweb-platform/services/service-locator' ], function(postal) {
    'use strict';

    describe('service Locator', function() {

        var serviceLocatorHandle;
        var mockedRegisterInput = [];
        var mockedBddCallbackFnInput;
        var BddEventAccumulator;

        beforeEach(module('service-locator'));
        beforeEach(module(function($provide) {
            postal.reset();
            $provide.factory('$xjtweb', function() {
                return {
                    XJTWEB : {
                        ServiceLocator : {
                            register : function(MockText, MockFactory) {
                                mockedRegisterInput.push({
                                    mockTest : MockText,
                                    mockFactory : MockFactory
                                })
                            }
                        },
                        SERVICE : {
                            LINKING_MANAGER : 'Mock_LINKING_MANAGER',
                            GRAPHICAL_OBJECT_FACTORY : 'Mock_GRAPHICAL_OBJECT_FACTORY',
                            SCENE_MANAGER : 'Mock_SCENE_MANAGER',
                            CURSOR_MANAGER : 'Mock_CURSOR_MANAGER',
                            GMC : 'Mock_GMC'
                        },
                        GMC : {
                            CHANNEL : 'Mock_GMC_CHANNEL',
                            TOPIC : {
                                ALL : 'Mock_GMC_TOPIC_ALL'
                            }
                        },
                        bddCallback : function(input) {
                            mockedBddCallbackFnInput = input;
                        }
                    }
                };
            });
            $provide.factory('linkingManager', function() {
                return {
                    mock : 'mock_linkingManager'
                };
            });
            $provide.factory('SceneManager', function() {
                return {
                    mock : 'mock_SceneManager'
                };
            });
            $provide.factory('GraphicalObjectFactory', function() {
                return {
                    mock : 'mock_GraphicalObjectFactory'
                };
            });
            $provide.factory('CursorManager', function() {
                return {
                    mock : 'mock_CursorManager'
                };
            });
            
            BddEventAccumulator = {
                BDD_Events_Modes : {
                    CHANNEL: 'GMC_CHANNEL',
                    TOPIC: {
                        ALL: 'GMC.*.*',
                        INTERACTION: {
                            REQUEST_SENT: "GMC.INTERACTION.REQUEST_SENT"
                        },
                        VIEWPORT: {
                            UPDATE: 'GMC.VIEWPORT.UPDATE',
                            IMAGE_UPDATED: 'GMC.VIEWPORT.IMAGE_UPDATED'
                        }
                    }
                },
                mock : 'mock_BddEventAccumulator',
                appendEvent: sinon.spy(),
                appendNewEvent: sinon.spy(),
            };
            $provide.value('BddEventAccumulator', BddEventAccumulator);
        }));

        beforeEach(inject(function(serviceLocator) {
            serviceLocatorHandle = serviceLocator;
        }));

        it('serviceLocator should have been a type of object.', function() {
            expect(typeof serviceLocatorHandle).to.equal('object');
        });

        it('serviceLocator should have contained a registerServices function.', function() {
            expect(typeof serviceLocatorHandle.registerServices).to.equal('function');
        });

        it('serviceLocator should have registed the linkngManager.', function() {
            serviceLocatorHandle.registerServices();
            expect(mockedRegisterInput[0].mockTest).to.equal('Mock_LINKING_MANAGER');
            expect(mockedRegisterInput[0].mockFactory.mock).to.equal('mock_linkingManager');
        });

        it('serviceLocator should have registed the GraphicalObjectFactory.', function() {
            serviceLocatorHandle.registerServices();
            expect(mockedRegisterInput[1].mockTest).to.equal('Mock_GRAPHICAL_OBJECT_FACTORY');
            expect(mockedRegisterInput[1].mockFactory.mock).to.equal('mock_GraphicalObjectFactory');
        });

        it('serviceLocator should have registed the SceneManager.', function() {
            serviceLocatorHandle.registerServices();
            expect(mockedRegisterInput[2].mockTest).to.equal('Mock_SCENE_MANAGER');
            expect(mockedRegisterInput[2].mockFactory.mock).to.equal('mock_SceneManager');
        });

        it('serviceLocator should have registed the CursorManager.', function() {
            serviceLocatorHandle.registerServices();
            expect(mockedRegisterInput[3].mockTest).to.equal('Mock_CURSOR_MANAGER');
            expect(mockedRegisterInput[3].mockFactory.mock).to.equal('mock_CursorManager');
        });

        it('serviceLocator should have registed the GMC postal channel.', function() {
            serviceLocatorHandle.registerServices();
            expect(mockedRegisterInput[4].mockTest).to.equal('Mock_GMC');
            expect(typeof mockedRegisterInput[4].mockFactory.bus.subscriptions.Mock_GMC_CHANNEL).to.equal('object');
        });

        it('serviceLocator should have registed the Mock_GMC_TOPIC_ALL to the postal channel.', function() {
            serviceLocatorHandle.registerServices();
            expect(typeof mockedRegisterInput[4].mockFactory.bus.subscriptions.Mock_GMC_CHANNEL.Mock_GMC_TOPIC_ALL).to.equal('object');
            expect(typeof mockedRegisterInput[4].mockFactory.bus.subscriptions.Mock_GMC_CHANNEL.Mock_GMC_TOPIC_ALL[0].callback).to.equal('function');
        });

        it('XJTWEB.GMC.TOPIC.ALL callback function should call the bddCallback and input the envelope.', function() {
            serviceLocatorHandle.registerServices();
            var mock_data = 'mocked_data';
            var mock_envelope = 'mocked_envelope';
            mockedRegisterInput[4].mockFactory.bus.subscriptions.Mock_GMC_CHANNEL.Mock_GMC_TOPIC_ALL[0].callback(mock_data, mock_envelope);
            expect(mockedBddCallbackFnInput).to.equal(mock_envelope);
            expect(BddEventAccumulator.appendEvent.calledOnce).to.equal(true);
            expect(BddEventAccumulator.appendEvent.calledWith(mock_envelope)).to.equal(true);
        });

    });
});
