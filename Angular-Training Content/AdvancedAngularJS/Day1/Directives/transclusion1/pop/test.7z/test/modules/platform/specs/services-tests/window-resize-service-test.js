define([ 'angular-mocks', 'modules/platform/services/window-resize-service' ], function(ngMocks) {
    describe('Test  $windowResizeService service', function() {

        beforeEach(module('platform.service.window-resize-service'));
        beforeEach(module(function($provide) {
            $provide.factory('$logger', function() {
                return {

                }
            });
        }));

        it(' defines $windowResizeService ', function() {
            inject(function($windowResizeService) {
                expect($windowResizeService).to.exist;
            })
        })
    });
});