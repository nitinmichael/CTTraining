/**
 *  manageUserDetailsController-test
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular',
        'angular-mocks',
        'orgMgmnt/features/manageUsers/manageUserDetails/controllers/manageUserDetailsController',
        'orgMgmnt/services/userService',
        'orgMgmnt/widgets/ge-app-service/geAppService',
        'orgMgmnt/widgets/ge-sitelist/listOfSites'
    ],
    function(ng) {
        'use strict';

        describe('Test the Manage User Detail Controller', function () {
            var ManageUserDetailsCtrl,saveManageUsersSiteListDeferred,scope, orgDataModel, Q, deferred, _log, _rootscope, _state, form,_userMgmtService,listOfSiteForUserDeferred,listOfSitesForLoggedInUserDeferred,listOfApplicationServiceForUserDeferred,listOfApplicationServiceForlistofSitesDeferred;
            beforeEach(function () {
                module('Orgmanagement.Features.ManageUsers.ManageUserDetailsController');
                module('Orgmanagement.Services.UserService');
                module('Orgmanagement.Utilities.MasterData');
                module('ui.router');
            });
            beforeEach(inject(function ($controller, $rootScope, $q, $log, $state,userMgmtService) {
                scope = $rootScope.$new();
                _userMgmtService=userMgmtService;
                Q = $q;
                deferred = Q.defer();
                listOfSiteForUserDeferred = Q.defer();
                saveManageUsersSiteListDeferred = Q.defer();
                listOfSitesForLoggedInUserDeferred = Q.defer();
                listOfApplicationServiceForUserDeferred = Q.defer();
                listOfApplicationServiceForlistofSitesDeferred =  Q.defer();
                sinon.stub(_userMgmtService, 'saveManageUsersSiteList').returns(saveManageUsersSiteListDeferred.promise);
                sinon.stub(_userMgmtService, 'listOfSiteForUser').returns(listOfSiteForUserDeferred.promise);
                sinon.stub(_userMgmtService, 'listOfSiteForLoggedInUser').returns(listOfSitesForLoggedInUserDeferred.promise);
                sinon.stub(_userMgmtService, 'listOfApplicationServiceForUser').returns(listOfApplicationServiceForUserDeferred.promise);
                sinon.stub(_userMgmtService, 'listOfApplicationServiceForlistofSites').returns(listOfApplicationServiceForlistofSitesDeferred.promise);

                _log = $log;
                _state = $state;
                sinon.stub(_log, 'info');
                $rootScope.userObject=
                {
                    "title": "ResourcesUser",
                    "id": "01c3c4ac-e5bd-49ea-95ef-8ff225dedd9b",
                    "content": {
                    "resourceType": "ResourcesUser",
                        "name": {
                        "use": "official",
                            "family": [
                            "Misra"
                        ],
                            "given": [
                            "Swagatika",
                            "M"
                        ]
                    },
                    "role": [
                        {
                            "code": [
                                {
                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                    "code": "practitioner",
                                    "display": "practitioner"
                                }
                            ],
                            "scopingOrganization": {
                                "reference": "organization/5"
                            },
                            "status": "active"
                        },
                        {
                            "code": [
                                {
                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                    "code": "practitioner",
                                    "display": "practitioner"
                                }
                            ],
                            "scopingOrganization": {
                                "reference": "organization/6"
                            },
                            "status": "active"
                        }
                    ],
                        "address": [
                        {
                            "line": [
                                "3300 Washtenaw Avenue, Suite 227"
                            ],
                            "city": "Ann Arbor",
                            "state": "MI",
                            "zip": "48104",
                            "country": "USA"
                        }
                    ],
                        "telecom": [
                        {
                            "system": "phone",
                            "value": "(+1) 734-677-7777"
                        },
                        {
                            "system": "email",
                            "value": "swagatika@ge.com"
                        }
                    ],
                        "preferredLanguage": "English",
                        "type": "Human",
                        "status": "inactive",
                        "comment": "This is an Hospital Practioner 1",
                        "principalName": "swagatika123@ge.com",
                        "gender": {
                        "coding": [
                            {
                                "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                "code": "M",
                                "display": "Male"
                            }
                        ]
                    },
                    "acceptedAgreement": [
                        {
                            "agreementUri": "http://goodcare.org/devices/id",
                            "accepted": false
                        }
                    ]
                }

                };


                scope.userDetailsForActiveUser =
                {
                    "title": "ResourcesUser",
                    "id": "01c3c4ac-e5bd-49ea-95ef-8ff225dedd9b",
                    "content": {
                    "resourceType": "ResourcesUser",
                        "name": {
                        "use": "official",
                            "family": [
                            "Misra"
                        ],
                            "given": [
                            "Swagatika",
                            "M"
                        ]
                    },
                    "role": [
                        {
                            "code": [
                                {
                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                    "code": "practitioner",
                                    "display": "practitioner"
                                }
                            ],
                            "scopingOrganization": {
                                "reference": "organization/5"
                            },
                            "status": "active"
                        },
                        {
                            "code": [
                                {
                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                    "code": "practitioner",
                                    "display": "practitioner"
                                }
                            ],
                            "scopingOrganization": {
                                "reference": "organization/6"
                            },
                            "status": "active"
                        }
                    ],
                        "address": [
                        {
                            "line": [
                                "3300 Washtenaw Avenue, Suite 227"
                            ],
                            "city": "Ann Arbor",
                            "state": "MI",
                            "zip": "48104",
                            "country": "USA"
                        }
                    ],
                        "telecom": [
                        {
                            "system": "phone",
                            "value": "(+1) 734-677-7777"
                        },
                        {
                            "system": "email",
                            "value": "swagatika@ge.com"
                        }
                    ],
                        "preferredLanguage": "English",
                        "type": "Human",
                        "status": "inactive",
                        "comment": "This is an Hospital Practioner 1",
                        "principalName": "swagatika123@ge.com",
                        "gender": {
                        "coding": [
                            {
                                "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                "code": "M",
                                "display": "Male"
                            }
                        ]
                    },
                    "acceptedAgreement": [
                        {
                            "agreementUri": "http://goodcare.org/devices/id",
                            "accepted": false
                        }
                    ]
                }
                };
                ManageUserDetailsCtrl = $controller('ManageUserDetailsCtrl', {$scope: scope,userMgmtService:_userMgmtService});
            }));


              describe('Manage Users Sites test cases', function () {
                it('Test basic info of the user is loaded showUserDetailsFirstPanel', function () {
                    scope.showUserDetailsFirstPanel();
                });

                it('Test basic info of the user is loaded showUserDetailsFirstPanel with else test', function () {
                  scope.userDetailsForActiveUser =
                  {
                      "title": "ResourcesUser",
                      "id": "01c3c4ac-e5bd-49ea-95ef-8ff225dedd9b",
                      "content": {
                      "resourceType": "ResourcesUser",
                          "name": {
                          "use": "official",
                              "family": [
                              "Misra"
                          ],
                              "given": [
                              "Swagatika",
                              "M"
                          ]
                      },
                      "role": [
                          {
                              "code": [
                                  {
                                      "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                      "code": "practitioner"

                                  }
                              ],
                              "scopingOrganization": {
                                  "reference": "organization/5"
                              },
                              "status": "active"
                          },
                          {
                              "code": [
                                  {
                                      "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                      "code": "practitioner",
                                      "display": "practitioner"
                                  }
                              ],
                              "scopingOrganization": {
                                  "reference": "organization/6"
                              },
                              "status": "active"
                          }
                      ],
                          "address": [
                          {
                              "line": [
                                  "3300 Washtenaw Avenue, Suite 227"
                              ],
                              "city": "Ann Arbor",
                              "state": "MI",
                              "zip": "48104",
                              "country": "USA"
                          }
                      ],
                          "telecom": [
                          {
                              "system": "phone"

                          },
                          {
                              "system": "email",
                              "value": "swagatika@ge.com"
                          }
                      ],
                          "preferredLanguage": "English",
                          "type": "Human",
                          "status": "inactive",
                          "comment": "This is an Hospital Practioner 1",
                          "principalName": "swagatika123@ge.com",
                          "gender": {
                          "coding": [
                              {
                                  "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                  "code": "M",
                                  "display": "Male"
                              }
                          ]
                      },
                      "acceptedAgreement": [
                          {
                              "agreementUri": "http://goodcare.org/devices/id",
                              "accepted": false
                          }
                      ]
                  }
                  };
                    scope.showUserDetailsFirstPanel();
                });

                it('click save sites for the user and succsses',function(done){
                    scope.userSiteListArray =[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/480f2c99-8056-4a1f-9202-1bc3c9339cf4","display":"GE Healthcare RSNA 4"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/09227e3e-1d92-4921-a944-3d22e43ad14c","display":"GE Healthcare RSNA 3"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/13dbd09a-98e7-46a0-8d4f-f0ff261d8411","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a985795c-fae2-40b7-afc6-1f37921d2048","display":"GE Healthcare RSNA VNA"},"status":"active"}];
                    scope.saveManageUsersSiteList(scope.userSiteListArray);
                    var response = {};

                    saveManageUsersSiteListDeferred.resolve(response);
                    scope.$digest();
                    chai.expect(scope.userSiteListArray).to.have.length(0);
                     done();

                });

                  it('click save sites for the user and succsses',function(done){
                      scope.userSiteListArray =[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/480f2c99-8056-4a1f-9202-1bc3c9339cf4","display":"GE Healthcare RSNA 4"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/09227e3e-1d92-4921-a944-3d22e43ad14c","display":"GE Healthcare RSNA 3"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/13dbd09a-98e7-46a0-8d4f-f0ff261d8411","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a985795c-fae2-40b7-afc6-1f37921d2048","display":"GE Healthcare RSNA VNA"},"status":"active"}];
                      scope.saveManageUsersSiteList();
                      var response = {};

                      saveManageUsersSiteListDeferred.reject(response);
                      scope.$digest();
                      chai.expect(scope.userSiteListArray).to.have.length(4);
                      done();

                  });

                  it('click cancel on site save edit button',function(){
                      scope.cancelManageUsersSiteList();
                  });


              });


            describe('List of sites for the users ', function(){
                it('should test the success response on  display list of sites for user users ', function(done){
                    var response1 =[{"title":"ResourcesUser","id":"0a365faf-b0a3-49a9-aff5-c5d3a7b72277","content":{"resourceType":"ResourcesUser","name":{"use":"official","family":["ytryrty"],"given":["yrtyr"]},"role":[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"patient","display":"Patient"}],"scopingOrganization":{"reference":"organization/"},"status":"pending"}],"address":[{"line":[null]}],"telecom":[{"system":"phone","value":"423423","use":"mobile"},{"system":"phone","value":"424332432","use":"home"},{"system":"email","value":"tryr@dfgMarimba","use":"work"}],"preferredLanguage":"English","type":"Human","status":"inactive","comment":"This is an Hospital Practioner 1","principalName":"tryr@dfgMarimba","gender":{"coding":[{"system":"http://hl7.org/fhir/v3/AdministrativeGender","code":"M","display":"Male"}]},"acceptedAgreement":[{"agreementUri":"http://goodcare.org/devices/id","accepted":false}]}}];
                    var response ={entry:response1};
                    var item=[
          {
            "title": null,
            "id": "2287ec33-3a6b-4654-85e3-81d4389ea8d8",
            "content": {
              "resourceType": "ResourcesApplicationService",
              "type": "dicom-send",
              "name": "EDGE",
              "endpoint": "2287ec33-3a6b-4654-85e3-81d4389ea8d8",
              "gateway": {
                "reference": "device/14a346f2-6c9d-4339-b8df-e8dc29665d5b",
                "display": "Sparx"
              },
              "owner": {
                "reference": "site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1",
                "display": "Concord Medical Center"
              },
              "networkAddress": {
                "ip": "3.39.74.34",
                "entityName": "AE_LHK_VNV_EDG2",
                "port": 104
              }
            }
          }
        ];
                    scope.listSitesForUser();
                    var responseData = {
                        "title": "ResourcesUser",
                        "id": "e462c689-d88c-4124-8309-f86510abae18",
                        "content": {
                            "resourceType": "ResourcesUser",
                            "managingOrganization": {
                                "organization": {
                                    "reference": "organization/5bb62345-1e4b-4ae4-b076-829d6662e661"
                                }
                            },
                            "principalName": "uom.cloudav44@ge.com"
                        }
                    } ;
                    var item=[
          {
            "title": null,
            "id": "2287ec33-3a6b-4654-85e3-81d4389ea8d8",
            "content": {
              "resourceType": "ResourcesApplicationService",
              "type": "dicom-send",
              "name": "EDGE",
              "endpoint": "2287ec33-3a6b-4654-85e3-81d4389ea8d8",
              "gateway": {
                "reference": "device/14a346f2-6c9d-4339-b8df-e8dc29665d5b",
                "display": "Sparx"
              },
              "owner": {
                "reference": "site/a20e9818-4a1d-426b-a8de-ad8a0e15e9e1",
                "display": "Concord Medical Center"
              },
              "networkAddress": {
                "ip": "3.39.74.34",
                "entityName": "AE_LHK_VNV_EDG2",
                "port": 104
              }
            }
          }
        ];

                    listOfSiteForUserDeferred.resolve(response);
                    scope.$digest();
                    chai.expect(response.entry).to.have.length(1);
                    done();
                });

                it('should test the failure of  list of sites for user', function(done){

                    scope.listSitesForUser();
                    var responseData =  {"resourceType":"OperationOutcome","issue":[{"severity":"error","type":"exception","details":"Resource Not Found"}]} ;
                    listOfSiteForUserDeferred.reject(responseData);
                    scope.$digest();
                    chai.expect(responseData.issue[0].details).to.equal('Resource Not Found');
                    done();
                });


            });

        describe('list of sites  for the LoggedInUser', function(){
            it('should test the success response on  display list of sites  for the LoggedInUser ', function(done){
                var response1 =[{"title":"ResourcesUser","id":"0a365faf-b0a3-49a9-aff5-c5d3a7b72277","content":{"resourceType":"ResourcesUser","name":{"use":"official","family":["ytryrty"],"given":["yrtyr"]},"role":[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"patient","display":"Patient"}],"scopingOrganization":{"reference":"organization/"},"status":"pending"}],"address":[{"line":[null]}],"telecom":[{"system":"phone","value":"423423","use":"mobile"},{"system":"phone","value":"424332432","use":"home"},{"system":"email","value":"tryr@dfgMarimba","use":"work"}],"preferredLanguage":"English","type":"Human","status":"inactive","comment":"This is an Hospital Practioner 1","principalName":"tryr@dfgMarimba","gender":{"coding":[{"system":"http://hl7.org/fhir/v3/AdministrativeGender","code":"M","display":"Male"}]},"acceptedAgreement":[{"agreementUri":"http://goodcare.org/devices/id","accepted":false}]}}];
                  var response ={entry:response1};
                scope.listOfSitesForLoggedInUser();
                var responseData = {
                    "title": "ResourcesUser",
                    "id": "e462c689-d88c-4124-8309-f86510abae18",
                    "content": {
                        "resourceType": "ResourcesUser",
                        "managingOrganization": {
                            "organization": {
                                "reference": "organization/5bb62345-1e4b-4ae4-b076-829d6662e661"
                            }
                        },
                        "principalName": "uom.cloudav44@ge.com"
                    }
                } ;

                listOfSitesForLoggedInUserDeferred.resolve(response);
                scope.$digest();
                chai.expect(_log.info.calledOnce);
                chai.expect(response.entry).to.have.length(1);
                done();
            })

            it('should test the failure of  list of sites  for the LoggedInUser', function(done){
                scope.listOfSitesForLoggedInUser();
                var responseData =  {"resourceType":"OperationOutcome","issue":[{"severity":"error","type":"exception","details":"Resource Not Found"}]} ;
                listOfSitesForLoggedInUserDeferred.reject(responseData);
                scope.$digest();
                chai.expect(responseData.issue[0].details).to.equal('Resource Not Found');
                done();
            });
    });

    describe('list of Application Services for user', function(){
        it('should test the success response on  list of Application Services for user ', function(done){
            var response1 =[{"content":{"name":"App1","owner":{"display":"name"},"type":"dicom-send"}},{"content":{"name":"App2","owner":{"display":"name"},"type":"dicom-send"}},
            {"content":{"name":"App1","owner":{"display":"name"},"type":"dicom-retrieve"}},{"content":{"name":"App1","owner":{"display":"Site2"},"type":"dicom-retrieve"}}];
            var response ={entry:response1};
            scope.listOfApplicationServicesForUser();
            listOfApplicationServiceForUserDeferred.resolve(response);
            scope.$digest();
            chai.expect(_log.info.calledOnce);
            chai.expect(response.entry).to.have.length(4);
            done();
        })

        it('should test the success response on  list of Application Services for user Not matching case ', function(done){
          var output =[{"siteName":"name2","appServiceList":[{"capabilities":["send"],"name":"EDGE","serviceType":"dicom"}]}];
            var response1 =[{"content":{"name":"App1","owner":{"display":"name2"},"type":"dicom-send"}},{"content":{"name":"App1","owner":{"display":"name2"},"type":"dicom-send"}}];
            var response ={entry:response1};
            scope.listOfApplicationServicesForUser();
            listOfApplicationServiceForUserDeferred.resolve(response);
            scope.$digest();
            chai.expect(_log.info.calledOnce);
            chai.expect(response.entry).to.have.length(2);
            done();
        })

        it('test not match else case', function(done){
            var response1 =
            [{"content":{"name":"App1","owner":{"display":"name3"},"type":"dicom-send"}},
            {"content":{"name":"App1","owner":{"display":"name2"},"type":"dicom-send"}},{"content":{"name":"App1","owner":{"display":"name2"},"type":"dicom-send"}}];
            var response ={entry:response1};
            scope.listOfApplicationServicesForUser();
            listOfApplicationServiceForUserDeferred.resolve(response);
            scope.$digest();
            chai.expect(_log.info.calledOnce);
            chai.expect(response.entry).to.have.length(3);
            done();
        })

        it('should test the failure of list of Application Services for user', function(done){
            scope.listOfApplicationServicesForUser();
            var responseData =  {"resourceType":"OperationOutcome","issue":[{"severity":"error","type":"exception","details":"Resource Not Found"}]} ;
            listOfApplicationServiceForUserDeferred.reject(responseData);
            scope.$digest();
            chai.expect(responseData.issue[0].details).to.equal('Resource Not Found');
            done();
        });


        it('should test list of application Service for list of sites success', function(done){
            var response1 =
            [{"content":{"name":"App1","owner":{"display":"name3"},"type":"dicom-send"}},
            {"content":{"name":"App1","owner":{"display":"name2"},"type":"dicom-send"}},{"content":{"name":"App1","owner":{"display":"name2"},"type":"dicom-send"}}];
            var response ={entry:response1};
            scope.bulklistOfApplicationServiceForSite();
            listOfApplicationServiceForlistofSitesDeferred.resolve(response);
            scope.$digest();
            chai.expect(_log.info.calledOnce);
            chai.expect(response.entry).to.have.length(3);
            done();
        })
        it('should test list of application Service for list of sites failure', function(done){
          scope.bulklistOfApplicationServiceForSite();
          var responseData =  {"resourceType":"OperationOutcome","issue":[{"severity":"error","type":"exception","details":"Resource Not Found"}]} ;
          listOfApplicationServiceForlistofSitesDeferred.reject(responseData);
          scope.$digest();
          chai.expect(responseData.issue[0].details).to.equal('Resource Not Found');
          done();
        })
});

      });

    });
