/*
 * mdt-session-case-item-directive-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular', 'jquery',
        'angular-mocks',
        'modules/mdt/modules/mdt-session-management/directives/mdt-session-case-item/mdt-session-case-item-directive'
    ],
    function () {
        'use strict';
        var $rootScope, scope, isolatedScope, $compile,
            successFn, errorFn;

        describe('MDT session case item directive test suite::', function () {
            beforeEach(function () {
                console.log('Start new test');

                var promiseMock = {
                    success: function(fn){
                        successFn = fn;
                        return promiseMock;
                    },
                    error: function(fn){
                        errorFn = fn;
                        return promiseMock;
                    }
                };

                angular.module('Services.caseExchangeDataService', []);
                module('Services.caseExchangeDataService', function($provide) {
                    $provide.value('caseExchangeDataService', {
                        getCaseHeader: function(){
                            return promiseMock;
                        }
                    });
                });

                module('Mdt.Module.MdtSessionService', function($provide) {
                    $provide.value('MdtSessionService', {
                        then: function(fn){
                            fn({
                                getCaseHeader: function(){
                                    return promiseMock;
                                }
                            });
                        }
                    });
                    ['geNaFilter', 'gePatientNameFilter', 'translateFilter'].forEach(function(fname){
                        $provide.value(fname, function(){
                        });
                    });
                });

                //Load actual module
                module('Mdt.Module.MdtSessionCaseItemDirective', function ($provide) {
                });

                //Load Templates
                module('templates');

                //Create new scope
                inject(function (_$compile_, _$rootScope_) {
                    $rootScope = _$rootScope_;
                    $compile = _$compile_;
                    scope = $rootScope.$new();
                });
            });


            beforeEach(function () {
                var html = '<mdt-session-case-item></mdt-session-case-item>';

                var element = $compile(html)(scope);

                scope.$digest();
                isolatedScope = element.isolateScope();
            });

            it('initial values okay', function () {
                expect(isolatedScope.case).to.be.null;
                expect(isolatedScope.error).to.be.false;
            });

            it('display received data', function () {
                var data = {
                    name: 'Lorem Pista'
                };
                successFn(data);
                expect(isolatedScope.case).to.be.equal(data);
                expect(isolatedScope.error).to.be.false;
            });

            it('display received data', function () {
                errorFn();
                expect(isolatedScope.case).to.be.null;
                expect(isolatedScope.error).to.be.true;
            });

        });
    });
