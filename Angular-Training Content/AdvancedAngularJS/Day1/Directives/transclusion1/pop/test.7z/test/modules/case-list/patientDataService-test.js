var chai = require(chai);
var expect = chai.expect;
//require('mocha');
//var should = chai.should();
//var chaiAsPromised = require('chai-as-promised');
//chai.use(chaiAsPromised);
//chai.use(require('chai-things'));
//var ng = require('angular');
//var myMockModule = angular.mock.module('seed-project.caselist', []);
//require('angular-mocks');

var patients = [ {
	"name" : "Lillian",
	"id" : "123",
	"dob" : "1/1/1990",
	"studyDate" : "04/06/2015"
}, {
	"name" : "Nik",
	"id" : "111",
	"dob" : "1/1/1990",
	"studyDate" : "04/06/2015"
} ];



define(['angular', 'angular-mocks', 'caselistModule'], function (ng, mocks) {
    'use strict';
    
	describe('patientDataService', function () {
        
        beforeEach(module('seed-project.caselist'));
        
		var patientData;
		var $httpBackend;
		
		beforeEach(mocks.inject(function (_patientData_) {
			console.log("get to inject at all?");
			
			patientData = _patientData_; // service
			$httpBackend = _$httpBackend_;
			
			console.log("In describe/foreach");
			
//			$httpBackend.whenGET('/patientData').respond(patients);
			$httpBackend.whenGET('/patientData').respond({userId: 'userX'}, {'A-Token': 'xxx'});

		}));
		
		console.log("before IT");
		
		it('should receive all patient data', function() {

			console.log("get to IT at all?");
			
			expect("hello").to.equal("hello");
			
			patientData.getPatientData().then(function(data) {
//				expect(data).to.equal(patients);
				expect(data).to.equal({userId: '123'}, {'A-Token': 'xxx'});
			});
			$httpBackend.flush();

		});

	})
});
