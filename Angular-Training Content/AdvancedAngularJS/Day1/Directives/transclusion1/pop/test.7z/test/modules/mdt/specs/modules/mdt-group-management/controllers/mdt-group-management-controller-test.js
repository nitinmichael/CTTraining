/*
 * mdt-group-management-controller-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular', 'angular-mocks', 'mdt/modules/mdt-group-management/controllers/mdt-group-management-controller'], function () {
    'use strict';

    describe('MDT Group Management controller test cases', function () {
        var scope, stateParams, state, controller, MdtGroupService, NotificationService, MdtGroupDataService, successHandler, errorHandler;

        beforeEach(function () {
            angular.module('Platform.Directive.GenericList', []);
            angular.module('Platform.Services.NotificationService', []);

            module('Mdt.Module.MdtGroupManagementController', function ($provide) {
                $provide.value('MdtGroupService', {
                    then: function(fn){
                        fn({
                            getGroupHeaders: function(success, error){
                                successHandler = success;
                                errorHandler = error;
                                return {
                                    then: sinon.spy()
                                };
                            }
                        });
                    }
                });
            });
            module('Mdt.Module.MdtGroupDataService');

            inject(function ($rootScope, $controller, _MdtGroupService_, _MdtGroupDataService_) {
                scope = $rootScope.$new();
                state = {
                    transitionTo: sinon.spy(),
                    go: sinon.spy()
                };
                stateParams = {
                    groupId: null
                };
                MdtGroupService = _MdtGroupService_;
                MdtGroupDataService = _MdtGroupDataService_;
                NotificationService = {
                    addErrorMessage: sinon.spy()
                };

                //Initialize the controller
                controller = $controller('MdtGroupManagementController', {
                    $scope: scope,
                    $stateParams: stateParams,
                    $state: state,
                    MdtGroupService: MdtGroupService,
                    NotificationService: NotificationService,
                    MdtGroupDataService: MdtGroupDataService
                });
            });
        });

        it("should have a controller defined", function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it("should initialize group header list when controller creation", function() {
            var result = {
                data: {
                    name: "Lorem Pista"
                }
            };

            successHandler(result);
            expect(scope.mdtGroupList).to.be.equal(result.data);
            expect(scope.fetchingGroupList).to.be.false;
        });

        it("should handle errors", function() {
            errorHandler();
            expect(scope.mdtGroupList).to.be.empty;
            expect(scope.fetchingGroupList).to.be.false;
            expect(NotificationService.addErrorMessage.calledOnce).to.be.true;
        });

        it('should generate a state transition', function() {
            var group1 = {
                groupId: 6677
            };
            var group2 = {
                groupId: 67
            };
            scope.mdtGroupList = MdtGroupDataService.updateItemList([group1, group2]);
            MdtGroupDataService.retrieveSelectedItem(6677);

            scope.$digest();
            if( scope.selectedGroupObj.value===0  ) {
                scope.selectedGroupObj.value = 1;
            } else {
                scope.selectedGroupObj.value = 0;
            }
            scope.$digest();

            expect(state.go).calledOnce;
        });
    });
});
