/*
 *  slidermanager-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author: Abdel Kana
 */
var home = 'modules/xjtweb-platform/services/';
define(['angular', 'angular-mocks', home + 'slider-manager'], function(angular) {
    'use strict';

    describe('Slider manager provider test ', function() {
        var sManager;

        var portMocks = [ {
            index : 0,
            rendererType : 'VR',
            active2D : false
        }, {
            index : 1,
            rendererType : 'MPR',
            active2D : false
        }, {
            index : 2,
            rendererType : 'MPR',
            active2D : true
        }];
        

        beforeEach(module('slider-manager'));
        beforeEach(module(function($provide) {
          $provide.factory('$xjtweb', function() {
              return {
                  'XJTWEB' : {
                  }
              }
          });

          $provide.factory('portContentFactory', function() {
              return {
              }
          });
        }));

        beforeEach(inject(function(sliderManager) {
            sManager = sliderManager;
        }));

        describe('Init sliderManager', function() {

            /**
             * @ngdoc method
             * @name InitSliderManagerTest
             * @methodOf xjtweb-platform.provider:sliderManager-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.sliderManager sliderManager} is created as an object.
             */
            it('sliderManager should be a typeof object', function() {
                expect(typeof sManager).to.equal('object');
            });

            /**
             * @ngdoc method
             * @name InitSliderManager_getSliderMin_Test
             * @methodOf xjtweb-platform.provider:sliderManager-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.sliderManager sliderManager} is created with a
             *              getSliderMin function.
             */
            it('sliderManager.getSliderMin should be a typeof function', function() {
                expect(typeof sManager.getSliderMin).to.equal('function');
            });

            /**
             * @ngdoc method
             * @name undefined_getSliderMin_Test
             * @methodOf xjtweb-platform.provider:sliderManager-test
             *
             * @description This test sets an active port to null and verifies that getSliderMin returns undefined
             */
            it('sliderManager.getSliderMin should be undefined if the active port is not initialized', function() {
                var min = sManager.getSliderMin(null);
                expect(min).to.equal(undefined);
            });
            
            /**
             * @ngdoc method
             * @name VR_getSliderMin_Test
             * @methodOf xjtweb-platform.provider:sliderManager-test
             *
             * @description his test sets an active port to "VR" port and verifies that getSliderMin returns undefined
             */
            it('sliderManager.getSliderMin should return undefined if the active port is VR type', function() {
                var activePort = portMocks[0];
                var min = sManager.getSliderMin(activePort);
                expect(min).to.equal(undefined);
            });
            
            /**
             * @ngdoc method
             * @name 3D_MPR_getSliderMin_Test
             * @methodOf xjtweb-platform.provider:sliderManager-test
             *
             * @description his test sets an active port to "MPR" port and verifies that getSliderMin returns 0
             */
            it('sliderManager.getSliderMin should return 0 if the active port is MPR type', function() {
                var activePort = portMocks[1];
                var min = sManager.getSliderMin(activePort);
                expect(min).to.equal(0);
            });
            
            /**
             * @ngdoc method
             * @name 2D_getSliderMin_Test
             * @methodOf xjtweb-platform.provider:sliderManager-test
             *
             * @description his test sets an active port to "2D" port and verifies that getSliderMin returns 1
             */
            it('sliderManager.getSliderMin should return 0 if the active port is 2D port', function() {
                var activePort = portMocks[2];
                var min = sManager.getSliderMin(activePort);
                expect(min).to.equal(1);
            });

            /**
             * @ngdoc method
             * @name InitSliderManager_sliderCallback_Test
             * @methodOf xjtweb-platform.provider:sliderManager-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.sliderManager sliderManager} is created with a
             *              sliderCallback function.
             */
            it('sliderManager.sliderCallback should be a typeof function', function() {
                expect(typeof sManager.sliderCallback).to.equal('function');
            });

            /**
             * @ngdoc method
             * @name InitSliderManager_previousButtonAction_Test
             * @methodOf xjtweb-platform.provider:sliderManager-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.sliderManager sliderManager} is created with a
             *              previousButtonAction function.
             */
            it('sliderManager.previousButtonAction should be a typeof function', function() {
                expect(typeof sManager.sliderCallback).to.equal('function');
            });

            /**
             * @ngdoc method
             * @name InitSliderManager_nextButtonAction_Test
             * @methodOf xjtweb-platform.provider:sliderManager-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.sliderManager sliderManager} is created with a
             *              nextButtonAction function.
             */
            it('sliderManager.nextButtonAction should be a typeof function', function() {
                expect(typeof sManager.nextButtonAction).to.equal('function');
            });
        });

    });
});
