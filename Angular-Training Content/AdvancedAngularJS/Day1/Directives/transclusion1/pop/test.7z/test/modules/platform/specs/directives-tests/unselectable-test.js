define([ 'angular-mocks', 'modules/platform/directives/unselectable' ], function(ngMocks) {
    describe('Test  unselectable', function() {
        var $compile;
        var $rootScope;

        beforeEach(module('platform.directive.unselectable'));
        beforeEach(module('templates'));

        beforeEach(inject(function(_$compile_, _$rootScope_) {
            $compile = _$compile_;
            $rootScope = _$rootScope_;
        }));

        it('Replaces the element with the appropriate content', function() {
            var scope = $rootScope.$new();
            var element = $compile("<div unselectable></div>")(scope);
            expect(element.attr('class')).to.contain('unselectable');
        });
    });
});