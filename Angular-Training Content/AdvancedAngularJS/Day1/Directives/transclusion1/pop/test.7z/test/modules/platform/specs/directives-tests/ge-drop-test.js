/*
 * ge-drag-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular-mocks', 'jquery', 'modules/platform/directives/ge-drop'], function() {
    describe('Test  unselectable', function() {
        var scope, rootScope, element, $compile, $document, $timeout;

        beforeEach(module('platform.directive.ge-drop'));

        beforeEach(function() {
            inject(function($rootScope, _$compile_, _$document_, _$timeout_) {
                rootScope = $rootScope;
                $compile = _$compile_;
                $document = _$document_;
                scope = rootScope.$new();
                $timeout = _$timeout_;
            });
        });

        it('must run onDragStart on draggable:start event broadcasted', function() {
            scope.start = sinon.spy();
            element = $compile("<div ge-drop=\"true\" ge-drag-start=\"start($data)\"></div>")(scope);
            rootScope.$broadcast('draggable:start', {
                obj: {
                    x: element.clientX,
                    y: element.clientY
                }
            });
            $timeout.flush();
            scope.$apply();
            expect(scope.start.called).to.equal(true);
        });


        it('must run onDragMove on draggable:move event broadcasted', function() {
            scope.move = sinon.spy();
            element = $compile("<div ge-drop=\"true\" ge-drag-move=\"move($data)\"></div>")(scope);
            rootScope.$broadcast('draggable:move', {
                obj: {
                    x: element.clientX,
                    y: element.clientY
                }
            });
            $timeout.flush();
            scope.$apply();
            expect(scope.move.called).to.equal(true);
        });

        it('must run onDragEnd on draggable:end event broadcasted', function() {
            scope.end = sinon.spy();
            element = $compile("<div ge-drop=\"true\" ge-drop-success=\"end($data)\"></div>")(scope);
            var dragElement = $compile("<div>drag</div>")(scope);
            element[0].getBoundingClientRect = sinon.stub();
            element[0].getBoundingClientRect.returns({
                left: 100,
                right: 100,
                bottom: 100,
                top: 100
            });
            rootScope.$broadcast('draggable:end', {
                x: 100,
                y: 100,
                element: dragElement
            });
            $timeout.flush();
            scope.$apply();
            expect(scope.end.called).to.equal(true);
        });
    });
});
