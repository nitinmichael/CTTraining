define([ 'angular', 'angular-mocks', 'modules/xjtweb-platform/services/mouse-mode-store-factory' ], function() {

    /**
     * @ngdoc service
     * @name xjtweb-platform.provider:mouse-mode-store-factory-test
     * @author Benjamin Beeman
     *
     * @description This is the test suite for the {@link xjtweb-platform.MouseModeStoreService MouseModeStoreService}.
     *
     * Copyright (c) 2015 by General Electric Company. All rights reserved.
     *
     * The copyright to the computer software herein is the property of General Electric Company. The software may be
     * used and/or copied only with the written permission of General Electric Company or in accordance with the terms
     * and conditions stipulated in the agreement/contract under which the software has been supplied.
     */
    describe('Test mouse-mode-store-factory', function() {

        var mouseModeStoreService;
        var MouseModeStore = function(){};

        var configManagementServiceMock = {
            getMouseModesForCurrentUser : sinon.stub()
        };

        beforeEach(module('mouse-mode-store'));
        beforeEach(module(function($provide) {
            $provide.value('$xjtweb', {
                XJTWEB: {
                    MouseModeStore: MouseModeStore
                }
            });
            $provide.constant('configManagementService', configManagementServiceMock);
        }));

        beforeEach(inject(function(_mouseModeStoreService_) {
            mouseModeStoreService = _mouseModeStoreService_;
        }));

        /**
         * @ngdoc method
         * @name Init-mouse-mode-store-factoryTest
         * @methodOf xjtweb-platform.provider:mouse-mode-store-factory-test
         *
         * @description This test method determines that the
         *              {@link xjtweb-platform.MouseModeStoreService MouseModeStoreService} is created as an object.
         */
        it('mouseModeStoreService should have been defined as an object.', function() {
            expect(typeof mouseModeStoreService.MouseModeStore).to.equal('object');
        })

    });
});