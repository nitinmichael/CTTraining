define(['angular', 'angular-mocks', 'modules/viewer/services/constants', 'modules/viewer/services/viewerOrchestration','serviceDiscoveryMock'], function (ng, mocks) {
  'use strict';

  describe('viewerOrchestration service test', function () {
    var scope, orchestrationService, httpBackend;

    beforeEach(module('cloudav.constants'));
    beforeEach(module('cloudav.viewerMockModule'));

    beforeEach(module('cloudav.viewerOchestration'));

    beforeEach(inject(function ($rootScope, _orchestrationService_, $httpBackend) {

      $httpBackend.when('GET', 'pfh_hcimg_av_volume_controller/dicomgroupmgt/api/v1/space/321506619594628858811/_split')
              .respond({groupId: '12345'}, {groupId: '54321'});

      $httpBackend.when('GET', 'pfh_hcimg_av_volume_controller/volumemgt/api/v1/model/321506619594628858811')
              .respond({groupId: '321506619594628858811'});

      $httpBackend.when('GET', 'pfh_hcimg_av_presentationstate_provider/321506619594628858811/123456789')
              .respond({groupId: '123456789'});

      orchestrationService = _orchestrationService_;
      httpBackend = $httpBackend;
      scope = $rootScope.$new();

    }));

    afterEach(function () {
      httpBackend.verifyNoOutstandingExpectation();
      httpBackend.verifyNoOutstandingRequest();
    });

    it('getGroups should be defined', function () {
      assert(typeof(orchestrationService.getGroups), 'function', 'viewerOrchestration service should have a getGroups function defined');
    });

    it('getGroups should return a deferred.promise', function () {
      scope.$apply();

      httpBackend.expectGET('pfh_hcimg_av_volume_controller/dicomgroupmgt/api/v1/space/321506619594628858811/_split');
      var caseuid = '321506619594628858811';

      var getGroups = orchestrationService.getGroups(caseuid);

      assert.isDefined(getGroups, 'viewerOrchestration : getGroups method should return a result');
      httpBackend.flush();
    });

    it('getVolumeInfo should be defined', function () {
      assert(typeof(orchestrationService.getVolumeInfo), 'function', 'viewerOrchestration service should have a getVolumeInfo function defined');
    });

    it('getVolumeInfo should return a deferred.promise', function () {
      scope.$apply();
      httpBackend.expectGET('pfh_hcimg_av_volume_controller/volumemgt/api/v1/model/321506619594628858811');
      var groupId = '321506619594628858811';
      var getVolumeInfo = orchestrationService.getVolumeInfo(groupId);

      assert.isDefined(getVolumeInfo, 'viewerOrchestration : getVolumeInfo method should return a result');
      httpBackend.flush();
    });

    it('getSaveState should be defined', function () {
      assert(typeof(orchestrationService.getSaveState), 'function', 'viewerOrchestration service should have a getSaveState function defined');
    });

    it('getSaveState should return a deferred.promise', function () {
      scope.$apply();

      httpBackend.expectGET('pfh_hcimg_av_presentationstate_provider/presentationstate/v1/space/321506619594628858811/instance/123456789').respond(200);
      var caseId = '321506619594628858811';
      var imageSetId = '123456789';
      var getSaveState = orchestrationService.getSaveState(caseId, imageSetId);

      assert.isDefined(getSaveState, 'viewerOrchestration : getSaveState method should return a result');
      httpBackend.flush();
    });
  });
});
