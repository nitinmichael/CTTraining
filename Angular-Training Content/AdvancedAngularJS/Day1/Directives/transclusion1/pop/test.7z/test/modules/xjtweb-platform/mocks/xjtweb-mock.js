var XJTWEB = XJTWEB || {};

function xjtwebMockCameraFactory() {

}

function MockConstructor() {

}

(function(xjt) {

    xjt.RendererFactory = MockConstructor;

    xjt.CameraFactory = MockConstructor;

    xjt.AnnotationHelper = MockConstructor;

    xjt.CameraFactory = xjtwebMockCameraFactory;

    xjt.CURSOR3D = {
        NAME: 'CURSOR3D',
        CHANNEL: 'CURSOR3D_CHANNEL',
        TOPIC: {
            DESTROY: 'CURSOR3D.DESTROY',
            UPDATE: 'CURSOR3D.UPDATE'
        }
    };

    xjt.SCENE_MANAGER = {
        CHANNEL: 'SCENE_MANAGER_CHANNEL',
        TOPIC: {
            RENDER: 'SCENE_MANAGER.RENDER',
            ADD_GROUP: 'SCENE_MANAGER.ADD_GROUP'
        }
    };
    xjt.VIEWPORT_UPDATE = {
        CHANNEL: 'VIEWPORT_UPDATE_CHANNEL',
        TOPIC: {
            SWITCH_TYPE: 'VIEWPORT_UPDATE.SWITCH_TYPE'
        }
    };
    
    xjt.MEASURE_MANAGER = {
        CHANNEL: 'MEASURE_MANAGER_CHANNEL',
        TOPIC: {
            SELECT_PREV: 'MEASURE_MANAGER.SELECT_PREV',
            SELECT_NEXT: 'MEASURE_MANAGER.SELECT_NEXT'
        }
    };

})(XJTWEB);
