/*
 * ge-todate-filter-filter-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define([ 'angular-mocks',  'modules/platform/filters/ge-todate-filter' ], function() {
    describe('Patient name filter tests', function() {
        var $filter;

        beforeEach(module('platform.filter.ge-todate-filter'));
        beforeEach(inject(function(_$filter_) {
            $filter = _$filter_('geToDate');
        }));

        it("should have a filter defined", function () {
            assert.isDefined($filter, 'filter is not defined');
        });

        it("should return a date object with defined year-month-day", function () {
            var dateString = '19880909',
                dateObj = $filter(dateString);

            expect(dateObj instanceof Date).to.be.true;
            expect(dateObj.getFullYear()).to.be.equal(1988);
            expect(dateObj.getMonth()).to.be.equal(8);
            expect(dateObj.getDate()).to.be.equal(9);
        });

        it("should return a date object with defined year-month-day when contains dot", function () {
            var dateString = '1988.09.09',
                dateObj = $filter(dateString);

            expect(dateObj instanceof Date).to.be.true;
            expect(dateObj.getFullYear()).to.be.equal(1988);
            expect(dateObj.getMonth()).to.be.equal(8);
            expect(dateObj.getDate()).to.be.equal(9);
        });

        it("should return undefined when the date is not set", function () {
            var dateString = undefined,
                dateObj = $filter(dateString);

            expect(dateObj).to.be.undefined;
        });

        it("should return undefined when the date is not enough long", function () {
            var dateString = '198809',
                dateObj = $filter(dateString);

            expect(dateObj).to.be.undefined;
        });

    });
});