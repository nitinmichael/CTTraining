/**
 *  verifyNewUserCtrl-test
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */define(['angular',
        'angular-mocks',
        'verifyNewUser/controller/verifyNewUserCtrl',
        'angularTranslate',
        'angularTranslatePartialLoader'
    ],
    function(ng){
        'use strict';
        describe('Test the verifyNewUserCtrl', function(){
            var verifyNewUserCtrl, scope,q;
            var  form, _log, _state, _event,deferred;
            var _userMgmtService,_siteMgmtService,rootScope;
            beforeEach( function(){
                module('VerifyUser.Controller.VerifyNewUserCtrl');
                // module('ui.router');
            });

            var appDescriptors = [
                {
                    abstract: true,
                    autoStart: "false",
                    href: "/viewer",
                    name: "viewer"
                },
                {
                    abstract: true,
                    autoStart: "true",
                    href: "/orgmanagement",
                    name: "orgmanagement"
                }];

            beforeEach(function () {
                module('VerifyUser.Controller.VerifyNewUserCtrl', function ($provide) {
                    $provide.provider('uaf.appshell.AppConfig', function () {
                        this.getAppDescriptors = function(){
                            return appDescriptors;
                        }

                        this.$get = function() {
                            return this;
                        };
                    });
                    $provide.provider('$Endpoint', function () {
                        this.getEndpoint = function(){
                            return endPoint;
                        }

                        this.$get = function() {
                            return this;
                        };
                    });
                });
            });

            beforeEach(inject(function($controller,$rootScope , $q, $log ){
                scope = $rootScope.$new();
                q = $q;
                _log = $log;

                verifyNewUserCtrl = $controller('verifyNewUserCtrl',{$scope:scope});
            }));

            describe('When there is a XSS event', function(){
                it('and the user closes the alert box, it should test setting of the variable to hide alert', function(){
                    scope.closeAlert();
                    chai.expect(scope.closeAlertPressed).to.be.equal(1);
                });

                it('and there is a rootScope emit of the event, it should test the event is consumed', function(){
                    var object = {message: "There is an attempt to insert scrpit"};
                    scope.$emit("SHOW_FAILURE_MESSAGE_NO_TIMEOUT",object.message);
                    chai.expect(scope.xssMessage).to.be.equal(object.message);
                    chai.expect(scope.closeAlertPressed).to.be.equal(0);
                });

            });


        });
    });





