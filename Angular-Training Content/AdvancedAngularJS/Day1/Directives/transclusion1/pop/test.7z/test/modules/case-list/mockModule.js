
//myMockModule = angular.mock.module('seed-project.caselist', []);
define(['angular'], function (ng) {
    'use strict';
    var app = ng.module('seed-project.caselist', []);
})