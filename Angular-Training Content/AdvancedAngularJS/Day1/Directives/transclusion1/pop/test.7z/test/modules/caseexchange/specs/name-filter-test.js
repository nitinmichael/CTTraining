/*
 *  message-field-directive-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jignesh Parekh<jignesh.parekh@ge.com>
 *  Monique Shotande<moniqueshotande@ge.com>
 */

/**
 * Spec file for Case Exchange > filters > name-filter directive
 */
'use strict';

define(['angular', 'angular-mocks',
        'filters/name-filter'],
    function () {
    'use strict';

    describe('Name Filter Test Suite::', function () {
        var nameFilter;

        beforeEach(function () {
            // Load actual module
            module('Filters.name');

        });

        beforeEach(
            inject(function (_nameFilter_) {
                nameFilter = _nameFilter_;
            })
        );

        describe('defined filter', function() {

            it('should return full name when name arrays are given', function () {
                var names = {
                    family: ["Johnson", "Smith"],
                    given: ["Peter", "James"]
                }
                var fullName = nameFilter(names);
                expect(fullName).to.equal("Johnson Smith, Peter James");
            });

        });
    });

});
