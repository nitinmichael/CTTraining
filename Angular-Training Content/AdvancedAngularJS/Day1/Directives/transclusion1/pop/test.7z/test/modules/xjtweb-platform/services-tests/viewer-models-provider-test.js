var home = 'modules/xjtweb-platform/services/';

define([ 'angular', 'angular-mocks', home + 'viewer-models-provider', 'mocks/volumeControllerMock' ], function(ng, mocks) {
    'use strict';

    /**
     * @ngdoc service
     * @name xjtweb-platform.provider:$viewerModelsFactory-test
     * @author Omar Aamir
     *
     * @description TODO
     *
     * Copyright (c) 2015 by General Electric Company. All rights reserved.
     *
     * The copyright to the computer software herein is the property of General Electric Company. The software may be
     * used and/or copied only with the written permission of General Electric Company or in accordance with the terms
     * and conditions stipulated in the agreement/contract under which the software has been supplied.
     */
    describe('viewer-models-provider Unit Test, ', function() {

        var $viewerModelsFactory, $xjtweb, $logger, errorMsg, warnMsg, volumeCtlrMock, canvasMock, msg;

        var createPort = function () {
            var config = {
                index: 1,
                groupId: '12345',
                seriesUid: '1254',
                volumeInfo: {},
                fov: 1,
                annotLevel: 'full',
                viewType: 'left',
                rendererType: 'vr',
                vrRenderType: 'mip',
                windowWidth: 125,
                windowLevel: 47,
                orientation: [1, 0, 0, 0, 1, 0, 0, 0, 1],
                lookPt: [-1, 0, 0],
                menu: true,
                cssLayout: 'twoBytwo',
                usePredefinedLayout: true,
                annotationUrl: 'annoUrl',
                renderingUrl: 'renderin_url',
                isSaveState: false,
                visible: true
            };
            return new $viewerModelsFactory.PortObj(config);
        };

        var xjtWebPortObjMock = function () {
            return {
                ww: null,
                wl: null,
                height: null,
                setWindowing: function (ww, wl) {
                    this.ww = ww;
                    this.wl = wl;
                },
                setViewHeight: function (h) {
                    this.height = h;
                },
                setCamera: function () {

                }
            }
        };

        var webGLMock = {
            camera: {
                updateProjection: function () {

                }
            }
        };

        var mockUpdateVPImage = function () {
            msg = 'ViewPort image updated !';
        };


        beforeEach(module('viewerModels'));
        beforeEach(module('cloudav.volumeControllerMocks'));

        beforeEach(module(function($provide, volumeControllerMock) {
            volumeCtlrMock = volumeControllerMock;
        }));

        beforeEach(module(function($provide) {
            $provide.factory('$xjtweb', function() {
                return {
                    'setWebGLRendererSize' : function(webGLContext, vp_rect) {
                        setWebGLRendererSizeCallParams.webGLContext = webGLContext;
                        setWebGLRendererSizeCallParams.vp_rect = vp_rect;

                    },
                    'XJTWEB' : {
                        MouseModeStore : {
                            STARTING_MODE_NAME : "PAGING_MODE"
                        }
                    }
                }
            });
            $provide.factory('$logger', function() {
                return {
                    'error' : function(msg) {
                        errorMsg = msg;
                    },
                    'warn': function (msg) {
                        warnMsg = msg;
                    }
                }
            });

            canvasMock = {
                clientWidth: 10,
                clientHeight: 10,
                setAttribute: function (key, value) {
                    this[key] = value;
                }
            };
        }));

        beforeEach(inject(function(_$viewerModelsFactory_, _$xjtweb_, _$logger_) {
            $viewerModelsFactory = _$viewerModelsFactory_;
            $xjtweb = _$xjtweb_;
            $logger = _$logger_;
        }));

        describe('Init $viewerModelsFactory:', function() {

            it('$viewerModelsFactory should be a typeof object', function() {
                expect(typeof $viewerModelsFactory).to.equal('object');
            });

            it('$viewerModelsFactory.Group should be a typeof function', function() {
                expect(typeof $viewerModelsFactory.Group).to.equal('function');
            });

            it('$viewerModelsFactory.Volume should be a typeof function', function() {
                expect(typeof $viewerModelsFactory.Volume).to.equal('function');
            });

            it('$viewerModelsFactory.Study should be a typeof function', function() {
                expect(typeof $viewerModelsFactory.Study).to.equal('function');
            });

            it('$viewerModelsFactory.Series should be a typeof function', function() {
                expect(typeof $viewerModelsFactory.Series).to.equal('function');
            });

            it('$viewerModelsFactory.Patient should be a typeof function', function() {
                expect(typeof $viewerModelsFactory.Patient).to.equal('function');
            });

            it('$viewerModelsFactory.SaveState should be a typeof function', function() {
                expect(typeof $viewerModelsFactory.SaveState).to.equal('function');
            });

            it('$viewerModelsFactory.PortObj should be a typeof function', function() {
                expect(typeof $viewerModelsFactory.PortObj).to.equal('function');
            });

            it('$viewerModelsFactory.Group should create an Object', function() {
                var config = volumeCtlrMock.split().groups['1.2.840.113619.2.218.98921247546.30282.1191502771894.2_1.2.840.113619.2.218.98921247546.30282.1191502771894.3_eec765b1'];
                var grp = new $viewerModelsFactory.Group(config);

                expect(typeof grp).to.equal('object');
                assert.isDefined(grp);
                assert.equal(grp.date, null);
                assert.equal(grp.description , '');
                assert.equal(grp.groupID , '1.2.840.113619.2.218.98921247546.30282.1191502771894.2_1.2.840.113619.2.218.98921247546.30282.1191502771894.3_eec765b1');
                assert.equal(grp.imageType , '3D');
                assert.equal(grp.modality , 'CT');
                assert.equal(grp.saveState , false);
                assert.equal(grp.secondaryCapture , false);
                assert.equal(grp.seriesUID , '1.2.840.113619.2.218.98921247546.30282.1191502771894.3');
                assert.equal(grp.spaceID , '409f54ec-5710-4f4b-b0d2-c343a4726e2c');
                assert.equal(grp.studyUID , '1.2.840.113619.2.218.98921247546.30282.1191502771894.2');
                assert.equal(grp.firstInstanceUID , '1.2.840.113619.2.218.98921247546.30282.1191502771935.14');
                assert.equal(grp.nbImages , 188);
                assert.deepEqual(grp.pixelSpacing , [0.390625, 0.390625]);
            });

            it('$viewerModelsFactory.Group should create an Object and log error messages', function() {
                var badConfig = {
                    groupID: null,
                    date: '18/02/1988',
                    imageType: 12,
                    modality: 1,
                    saveState: 'Yes',
                    secondaryCapture: 'No',
                    seriesUID: null,
                    spaceID: null,
                    studyUID: null,
                    instanceUIDs: undefined,
                    pixelSpacing: 1
                };
                var grp = new $viewerModelsFactory.Group(badConfig);

                assert.equal(errorMsg, 'group created without studyUID');
                assert.isUndefined(grp.groupID);
                assert.equal(grp.date, '18/02/1988');
            });

            it('$viewerModelsFactory.Volume should create an Object', function() {
                var config = volumeCtlrMock.getVolumeModel();
                var vol = new $viewerModelsFactory.Volume(config);

                expect(typeof vol).to.equal('object');
                assert.isDefined(vol);
                assert.equal(vol.defaultWindowLevel, 150);
                assert.equal(vol.defaultWindowWidth , 750);
                assert.deepEqual(vol.dimensions , [512, 512, 188]);
                assert.equal(vol.groupUid , '1.2.840.113619.2.218.98921247546.30282.1191502771894.2_1.2.840.113619.2.218.98921247546.30282.1191502771894.3_eec765b1');
                assert.deepEqual(vol.resampledDirX , [-1, 0, 0]);
                assert.deepEqual(vol.resampledDirY , [0, -1, 0]);
                assert.deepEqual(vol.resampledOrigin , [78, 125, 40.125]);
                assert.equal(vol.resampledSliceSpacing , 0.6216755319148937);
                assert.equal(vol.slicesNumber , 188);
                assert.deepEqual(vol.pixelSpacing , [0.390625, 0.390625, 0.6216755319148937]);
                assert.equal(vol.intercept , -1024);
                assert.equal(vol.slope , 1);
                assert.equal(vol.modality , '_');
                assert.deepEqual(vol.orientation , [[-1, 0, 0], [0, -1, 0], [0, 0, 1]]);
            });

            it('$viewerModelsFactory.Volume should create an Object and log error messages', function() {
                var badConfig = {
                    groupUid: null,
                    modality: 1,
                    windowWidth: 'not a number',
                    windowLevel: 'not a number',
                    intercept: 'not a number',
                    slope: 'not a number'
                };
                var vol = new $viewerModelsFactory.Volume(badConfig);

                assert.equal(errorMsg, 'volume created without a groupUid');
                assert.isUndefined(vol.groupUid);
                assert.isNull(vol.slope);
            });

            it('$viewerModelsFactory.Study should create an Object', function() {
                var config = volumeCtlrMock.split().studies['1.2.840.113619.2.218.98921247546.30282.1191502771894.2'];
                var study = new $viewerModelsFactory.Study(config);

                expect(typeof study).to.equal('object');
                assert.isDefined(study);
                assert.equal(study.studyDate, '2015-10-22');
                assert.equal(study.studyDescription, 'Study Desc');
                assert.equal(study.studyID , '1.2.840.113619.2.218.98921247546.30282.1191502771894.2');
            });

            it('$viewerModelsFactory.Study should create an Object having null properties', function() {
                var badConfig = {
                    date: 123,
                    description: 12,
                    instanceUID: 0
                };
                var study = new $viewerModelsFactory.Study(badConfig);

                assert.isDefined(study.studyID);
                assert.isNull(study.studyID);
                assert.isDefined(study.studyDescription);
                assert.isNull(study.studyDescription);
                assert.isDefined(study.studyDate);
                assert.isNull(study.studyDate);
            });

            it('$viewerModelsFactory.Series should create an Object', function() {
                var config = volumeCtlrMock.split().series['1.2.840.113619.2.218.98921247546.30282.1191502771894.3'];
                var serie = new $viewerModelsFactory.Series(config);

                expect(typeof serie).to.equal('object');
                assert.isDefined(serie);
                assert.equal(serie.seriesSOPInstanceUID, '1.2.840.113619.2.218.98921247546.30282.1191502771894.3');
                assert.equal(serie.modality, 'CT');
                assert.equal(serie.seriesSOPclassUID , '1.2.840.10008.5.1.4.1.1.2');
                assert.equal(serie.seriesDescription, 'Series desc');
            });

            it('$viewerModelsFactory.Series should create an Object having null properties', function() {
                var badConfig = {
                    "instanceUID": 123
                };
                var serie = new $viewerModelsFactory.Series(badConfig);

                assert.isDefined(serie);
                assert.isDefined(serie.seriesSOPInstanceUID);
                assert.isNull(serie.seriesSOPInstanceUID);
                assert.isDefined(serie.modality);
                assert.isNull(serie.modality);
                assert.isDefined(serie.seriesSOPclassUID);
                assert.isNull(serie.seriesSOPclassUID);
                assert.isDefined(serie.seriesDescription);
                assert.isNull(serie.seriesDescription);
            });

            it('$viewerModelsFactory.Patient should create an Object', function() {
                var config = volumeCtlrMock.split().patient;
                var pat = new $viewerModelsFactory.Patient(config);

                expect(typeof pat).to.equal('object');
                assert.isDefined(pat);
                assert.isNull(pat.title);
                assert.equal(pat.dob, '');
                assert.isNull(pat.age);
                assert.equal(pat.name, 'Demo - Cardiac Coronary Disease');
                assert.equal(pat.gender, '');
                assert.equal(pat.id, 'AW212745087.798.1191502771');
            });

            it('$viewerModelsFactory.Series should create an Object having null properties', function() {
                var badConfig = {
                    "title": 'Mr',
                    "age":'55'
                };
                var pat = new $viewerModelsFactory.Patient(badConfig);

                assert.isDefined(pat);
                assert.isDefined(pat.id);
                assert.isNull(pat.id);
                assert.equal(pat.title, 'Mr');
                assert.equal(pat.age, '55');
                assert.isDefined(pat.dob);
                assert.isNull(pat.dob);
                assert.isDefined(pat.name);
                assert.isNull(pat.name);
                assert.isDefined(pat.gender);
                assert.isNull(pat.gender);
            });

            it('$viewerModelsFactory.SaveState should create an Object', function() {
                var config = volumeCtlrMock.getSaveState();
                var ss = new $viewerModelsFactory.SaveState(config);

                expect(typeof ss).to.equal('object');
                assert.isDefined(ss);
                assert.equal(ss.correlationID, '877441dsdsqsdsqffd');
                assert.deepEqual(ss.volumes, []);
                assert.deepEqual(ss.viewports, []);
                assert.deepEqual(ss.measurements, []);
                assert.deepEqual(ss.cursors, []);
            });

            it('$viewerModelsFactory.Series should create an Object having null properties', function() {
                var badConfig = {
                    "correlationID": null,
                    "body": {

                    }
                };
                var ss = new $viewerModelsFactory.SaveState(badConfig);

                assert.isDefined(ss);
                assert.isNull(ss.correlationID);
                assert.isNull(ss.volumes);
                assert.isNull(ss.viewports);
                assert.isNull(ss.measurements);
                assert.isNull(ss.cursors);
            });

            it('$viewerModelsFactory.PortObj should create an Object', function() {
                var port = createPort();

                expect(typeof port).to.equal('object');
                assert.isDefined(port);
                assert.equal(port.index, 1);
                assert.equal(port.active2D, false);
                assert.equal(port.groupId, '12345');
                assert.equal(port.seriesUid, '1254');
                assert.deepEqual(port.volumeInfo, {});
                assert.equal(port.fov, 1);
                assert.equal(port.annotLevel, 'full');
                assert.equal(port.viewType, 'left');
                assert.equal(port.rendererType, 'vr');
                assert.equal(port.vrRenderType, 'mip');
                assert.equal(port.windowWidth, 125);
                assert.equal(port.windowLevel, 47);
                assert.deepEqual(port.orientation, [1, 0, 0, 0, 1, 0, 0, 0, 1]);
                assert.deepEqual(port.lookPt, [-1, 0, 0]);
                assert.equal(port.menu, true);
                assert.equal(port.cssLayout, 'twoBytwo');
                assert.equal(port.usePredefinedLayout, true);
                assert.equal(port.annotationUrl, 'annoUrl');
                assert.equal(port.renderingUrl, 'renderin_url');
                assert.equal(port.isSaveState, false);
                assert.equal(port.visible, true);

                assert.equal(port.getId(), 1);
            });

            it('$viewerModelsFactory.PortObj should create an Object and log error messages', function() {
                var badConfig = {
                    index: 'not number'
                };
                var port = new $viewerModelsFactory.PortObj(badConfig);

                expect(typeof port).to.equal('object');
                assert.isDefined(port);
                assert.isUndefined(port.index);
                assert.equal(port.active2D, false);
                assert.isUndefined(port.groupId);
                assert.isUndefined(port.seriesUid);
                assert.isUndefined(port.volumeInfo);
                assert.isNull(port.fov);
                assert.isNull(port.annotLevel);
                assert.isNull(port.viewType);
                assert.isNull(port.rendererType);
                assert.isNull(port.vrRenderType);
                assert.isNull(port.windowWidth);
                assert.isNull(port.windowLevel);
                assert.isNull(port.orientation);
                assert.isNull(port.lookPt);
                assert.equal(port.menu, false);
                assert.equal(port.cssLayout, 'twoByTwo');
                assert.equal(port.usePredefinedLayout, true);
                assert.isNull(port.annotationUrl);
                assert.isNull(port.renderingUrl);
                assert.equal(port.isSaveState, false);
                assert.equal(port.visible, true);

                assert.equal(errorMsg, 'viewPortObj created without an index.');
                assert.equal(warnMsg, 'viewPortObj created without valid volumeInfo object.');

                assert.equal(port.getId(), null);
            });

            it('$viewerModelsFactory.PortObj should apply saved state', function() {
                var port = createPort();
                port.viewPortObject = xjtWebPortObjMock();


                assert.isDefined(port);
                assert.isDefined(port.viewPortObject);
                assert.isNull(port.viewPortObject.ww);
                assert.isNull(port.viewPortObject.wl);
                assert.isNull(port.viewPortObject.height);

                port.applySaveState();

                assert.isDefined(port.viewPortObject.ww);
                assert.isDefined(port.viewPortObject.wl);
                assert.isDefined(port.viewPortObject.height);
            });

            it('$viewerModelsFactory.PortObj should resize 2D viewport', function() {
                var port = createPort();
                port.viewPortObject = xjtWebPortObjMock();
                port.portReady = true;
                port.port2DSetup = true;
                port.active2D = true;
                port.vp2Dcanvas = canvasMock;
                port.vp2Dsvg = canvasMock;
                port.vp2DOverlay = canvasMock;
                port.xp2DImageViewport = {paint: function () {}};

                assert.isUndefined(port.vp2Dcanvas.height);
                assert.isUndefined(port.vp2Dcanvas.width);

                port.resizeViewport();

                assert.isDefined(port.vp2Dcanvas.height);
                assert.isDefined(port.vp2Dcanvas.width);
                assert.equal(port.vp2Dcanvas.height, canvasMock.clientHeight);
                assert.equal(port.vp2Dcanvas.width, canvasMock.clientWidth);

            });

            it('$viewerModelsFactory.PortObj should resize 3D viewport', function() {
                var port = createPort();
                port.viewPortObject = xjtWebPortObjMock();
                port.portReady = true;
                port.active2D = false;
                port.port3DSetup = true;
                port.vp3Dcanvas = canvasMock;
                port.vp3Dsvg = canvasMock;
                port.vp3DOverlay = canvasMock;
                port.viewPortObject.resizeImage = function () {};
                port.viewPortObject.getAspectRatio = function () {return 0.5};
                port.viewPortObject.getViewHeight = function () {return 12;};

                assert.isUndefined(port.vp3Dcanvas.height);
                assert.isUndefined(port.vp3Dcanvas.width);

                port.resizeViewport(webGLMock);

                assert.isDefined(port.vp3Dcanvas.height);
                assert.isDefined(port.vp3Dcanvas.width);
                assert.equal(port.vp3Dcanvas.height, canvasMock.clientHeight);
                assert.equal(port.vp3Dcanvas.width, canvasMock.clientWidth);

            });

            it('$viewerModelsFactory.PortObj should refresh 2D viewport', function() {
                var port = createPort();
                port.viewPortObject = xjtWebPortObjMock();
                port.portReady = true;
                port.port2DSetup = true;
                port.active2D = true;
                port.vp2Dcanvas = canvasMock;
                port.vp2Dsvg = canvasMock;
                port.vp2DOverlay = canvasMock;
                port.xp2DImageViewport = {paint: function () {}};

                assert.isUndefined(port.vp2Dcanvas.height);
                assert.isUndefined(port.vp2Dcanvas.width);

                port.refresh();

                assert.isDefined(port.vp2Dcanvas.height);
                assert.isDefined(port.vp2Dcanvas.width);
                assert.equal(port.vp2Dcanvas.height, canvasMock.clientHeight);
                assert.equal(port.vp2Dcanvas.width, canvasMock.clientWidth);

            });

            it('$viewerModelsFactory.PortObj should refresh 3D viewport', function() {
                var port = createPort();
                port.viewPortObject = xjtWebPortObjMock();
                port.portReady = true;
                port.active2D = false;
                port.port3DSetup = true;
                port.updateViewportImage = mockUpdateVPImage;

                port.refresh();

                assert.isDefined(msg);
                assert.equal(msg, 'ViewPort image updated !');

            });

        });

    });
});
