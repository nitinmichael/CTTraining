/*
 *  get-pacs-service-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Ketan Talreja<ketan.talreja@ge.com>
 */

/**
 * Spec file for Get Pacs Service module
 */

define([
    'angular',
    'angular-mocks',
    'modules/caseexchange/services/get-pacs-service',
    'mocks/case-exchange-mock-service',
    'mocks/fake-server'], function () {
    'use strict';

    describe('Test GetPacs Service suite', function () {
        var getPacsService, rootScope, originalAjax, $mockServerLoader, mockServer;

        beforeEach(function () {
            // Load the module for the mock data first
            module('cloudav.caseExchange.mocks');
            // Load the Sinon fake server.
            module('cloudav.caseExchange.fakeServer');

            // store original $.ajax
            originalAjax = $.ajax;
            // provide mock services for getPacsServices
            module('Services.getPacsServices', function ($provide) {
                $provide.factory('configurationService', ['$q', function ($q) {
                    return {
                        getProperty: function () {
                            return $q.when({});
                        }
                    }
                }]);
            });
            // inject dependencies for getPacsServices
            inject(function (_GetPacsServices_, _CaseExchangeDataService_, $rootScope, $MockServerLoader) {
                getPacsService = _GetPacsServices_;
                rootScope = $rootScope;
                $mockServerLoader = $MockServerLoader;
                mockServer = $mockServerLoader.init();
            });
        });

        // restore $.ajax for use by other test suites
        afterEach(function () {
            $.ajax = originalAjax;
        });

        it('should define a service', function () {
            assert.isDefined(getPacsService, 'GetPacsService is defined');
        });

        describe('Testing successful getPacsService.getPacsDevices() method', function () {
            it('should indicate success when set up to run normally', function (done) {
                var isSuccessful = false;
                $mockServerLoader.fakeGetPacsDevicesCall(200, {});
                getPacsService.getPacsDevices().then(
                        function onResolve(data) {
                            isSuccessful = true;
                            done();
                        },

                        function onError(errorMessage) {
                        }
                );

                // respond will trigger the success of getPACSDevice call.
                mockServer.respond();
                rootScope.$apply();

                assert(isSuccessful, 'normal run should have succeeded');
            });

        });

        describe('Testing failed getPacsService.getPacsDevices() arising from invalid "me" service result', function () {

            var isSuccessful = true, failedMeJSON = {};

            it('should indicate failure when set up to fail', function (done) {

                $.ajax = function (options) {
                    if (options.url.indexOf('user/me') >= 0) {
                        options.success(failedMeJSON);
                    }
                    if (options.url.indexOf('applicatonservice') >= 0) {
                        // if this part is reached, the test fails
                        isSuccessful = true;
                    }
                    else {
                        options.error();
                        isSuccessful = false;
                        done();
                    }
                };

                getPacsService.getPacsDevices().then(
                        function onResolve(data) {
                        },

                        function onError(errorMessage) {
                        }
                );
                assert(!isSuccessful, 'should have failed');
            });

        });
    });
});