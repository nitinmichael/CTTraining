/*
 * viewtypeswitch-test.js
 * 
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 * 
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 * 
 * @author: Stéphane Breton <stephane.bretone@ge.com>
 */

/**
 * Spec file for Viewer > modules > viewer-app > widgets > view-type-switch directive
 */
//
define([ 'angular', 'angular-mocks', 'viewerModule/widgets/viewtypeswitch' ], function() {
    'use strict';

    describe('viewTypeSwitch Directive Test :', function() {
        var element, scope;

        beforeEach(module('cloudav.viewerApp.widgets'));
        beforeEach(module('templates'));

        beforeEach(function() {
            var xjresourceMock = {
                volume3D : {
                    images : {
                        length : 42
                    }
                }
            };
            window.XJResource = xjresourceMock;
        });
        afterEach(function() {
            delete window.XJResource;
        });

        beforeEach(inject(function($compile, $rootScope) {
            var html = angular.element('<view-type-switch />');
            scope = $rootScope.$new();
            element = $compile(html)(scope);
            scope.$digest();
        }));

        describe('defined directive', function() {
            it('should have a directive', function() {
                
                assert.isDefined(element, 'view-type-switch Directive is not defined');
            });

            it('should have a clickViewTypeSwitch function in the scope', function() {
                expect(typeof (scope.clickViewTypeSwitch)).to.equal('function', 'view-type-switch Directive do not have a clickViewTypeSwitch function in the scope');
            });

            it('should open the viewTypeSwitch popover', function() {
                var port = {
                    menu : false
                }
                scope.clickViewTypeSwitch(port);
                expect(port.menu).to.equal(true, 'view-type-switch Directive : the clickViewTypeSwitch function should return true');
            });
            it('should disable the 3d item because slice number is inferior than 5', function() {
                var port = {
                    volumeInfo:{
                        slicesNumber : 3
                    }
                };
                var is3dItemDisabled = scope.disable3DItem(port);
                expect(is3dItemDisabled).to.equal(true, 'view-type-switch Directive : the disable3DItem function should return true');
            });
            it('should enable the 3d item because slice number is superiro than 5', function() {
                var port = {
                    volumeInfo:{
                        slicesNumber : 400
                    }
                };
                var is3dItemDisabled = scope.disable3DItem(port);
                expect(is3dItemDisabled).to.equal(false, 'view-type-switch Directive : the disable3DItem function should return true');
            });
            it('should disable the MIP item because 3d item is not selected', function() {
                var port = {
                    volumeInfo:{
                        slicesNumber : 400
                    }
                };
                var isMIPItemDisabled = scope.disableItem(port,'coronal');
                expect(isMIPItemDisabled).to.equal(true, 'view-type-switch Directive : the items MIP, MinIP or VRendering should be disabled');
            });
            it('should enabled the MIP item because 3d item is selected and the slices number is superior than 5', function() {
                var port = {
                    volumeInfo:{
                        slicesNumber : 400
                    }
                };
                var isMIPItemDisabled = scope.disableItem(port,'vrItem');
                expect(isMIPItemDisabled).to.equal(false, 'view-type-switch Directive : the items MIP, MinIP or VRendering should be enabled');
            });
        });
    });
});
