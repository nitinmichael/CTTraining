var tests = [];
for (var file in window.__karma__.files) {
  if (window.__karma__.files.hasOwnProperty(file)) {
    if (/-test\.js$/.test(file)) {
      tests.push(file);
    }
  }
}

require.config({
  // Karma serves files under /base, which is the basePath from your config file
  baseUrl: '/base/public',

  paths: {
	  // Is this loaded at all? why giving it a junk name did not cause complain?
      'angular'         : './uaf/3rdparty/angular/angular',
      'angular-mocks'   : './uaf/3rdparty/angular/angular-mocks',
      'angular-ui'		: './uaf/3rdparty/angular-ui/ui-bootstrap-tpls-0.12.1',
      'angularRoute'    : './uaf/3rdparty/angular-route/angular-route',
      'angularTranslate': './uaf/3rdparty/angular-translate/dist/angular-translate',
      'angularTranslatePartialLoader': './uaf/3rdparty/angular-translate/dist/angular-translate-loader-partial/angular-translate-loader-partial',
      'lodash'          : './uaf/3rdparty/lodash',
      'postal'          : './uaf/3rdparty/postal/lib/postal',
      'hdx'             : './uaf/hdx/js/hdx',
      'hdx-bootstrap'   : './uaf/hdx/components/hdx-bootstrap/js/hdx-bootstrap',
      'jquery'          : './uaf/hdx/components/3rdparty/jquery/dist/jquery',
      'bootstrap'       : './uaf/hdx/components/3rdparty/bootstrap/js',
      'prettify'        : "./uaf/hdx/components/3rdparty/prettify/prettify",
      'directive'       : "./uaf/hdx/components/3rdparty/angular-ui/ui-bootstrap-tpls-0.12.1",

      'mocha'			: '/base/node_modules/mocha/mocha',
      'adapter'			: '/base/node_modules/karma-mocha/adapter',
      'chai'			: '/base/node_modules/chai/chai',
      'chai-as-promised': '/base/node_modules/karma-chai-plugins/node_modules/chai-as-promised/lib/chai-as-promised',

      'caselistModule'	: './modules/case-list/module',
      'patientData'		: './modules/case-list/services/patientData',
      'viewerModule'    : './modules/viewer/modules/viewer-app/module',

      'mockModule'	    : '/base/test/modules/mockModule',
      'myService'		: '/base/test/modules/myService'

  },
  shim: {
      'angular'         : { 'exports':'angular' },
      'angular-mocks'   : {
			deps:['angular'],
			'exports':'angular.mock'
		},

	  'mockModule'      : {
		  deps:['angular', 'angular-mocks'],
		  'export': 'mockModule'},

	  'myService'       : {
		  'exports':'myService',
		  deps:['mockModule'],
		  'export': 'myService'
	  }
  },

  // dynamically load all test files
  deps: tests,

  // start running the tests, once Require.js is done
  callback: window.__karma__.start
});
