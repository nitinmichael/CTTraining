define([ 'require', 'jquery', 'modules/viewer/tracing/rjs-tracing' ], function(requireInfo, $) {

    describe('Test RequireJS tracing', function() {

        var scriptUrl = requireInfo.toUrl('modules/viewer/tracing/rjs-tracing.js');

        it(' can be loaded multiple times', function(done) {

            $.ajax(scriptUrl, {
                dataType : 'text'
            }).fail(done).success(function(scriptText) {
                doTestMultipleLoading(scriptText);
                done();
            });
        })

        var doTestMultipleLoading = function(scriptText) {
            var originalRtree = window.rtree;
            try {
                delete window.rtree;

                expect(window.rtree).to.equal(undefined);

                eval(scriptText);

                var rtree1 = window.rtree;
                expect(rtree1).to.exist;

                // re-run the script
                eval(scriptText);

                // window.rtree is the same:
                expect(window.rtree).to.equal(rtree1);
            } finally {
                window.rtree = originalRtree;
            }
        }

        describe(' tests with intercepted console', function() {
            var rtree;
            beforeEach(function() {

                rtree = new window.rtree.constructor();

                sinon.stub(console, 'log');

                sinon.spy(rtree.logger, 'error');
                sinon.spy(rtree.logger, 'warn');
                sinon.spy(rtree.logger, 'info');

            });
            afterEach(function() {
                rtree.logger.error.restore();
                rtree.logger.warn.restore();
                rtree.logger.info.restore();

                sinon.restore(rtree.logger);

                console.log.restore();
            });

            var loadModule = function(moduleName, moduleUrl, depModuleNamesList) {
                if (moduleUrl === undefined) {
                    moduleUrl = moduleName;
                }

                if (depModuleNamesList === undefined) {
                    depModuleNamesList = [];
                }

                var depModulesList = depModuleNamesList.map(function(name) {
                    return {
                        name : name
                    }
                });

                rtree.onResourceLoad('_', {
                    name : moduleName,
                    originalName : moduleName,
                    url : moduleUrl
                }, depModulesList);

            };

            it(' registers for RequireJS load events', function() {
                var realRequire = window.require;
                window.require = {};
                try {
                    rtree.interceptRJSmoduleLoading();
                    expect(window.require.onResourceLoad).to.exist;
                } finally {
                    window.require = realRequire;
                }
            });

            it(' registers loaded module', function() {

                loadModule('testName', 'someUrl');

                expect(Object.getOwnPropertyNames(rtree.tree)).lengthOf(1);
                expect(rtree.tree).to.have.property('testName');
                expect(rtree.urlMap).to.have.property('someUrl');

                console.log.should.be.not.called;
            });

            it(' normalizes URLs ', function() {

                loadModule('test1', './a/b/c/.././d/.');

                expect(Object.getOwnPropertyNames(rtree.tree)).lengthOf(1);
                expect(rtree.urlMap).to.have.property('a/b/d');

                expect(rtree.normalizeUrl('.//a')).to.equal('a');

                console.log.should.be.not.called;
            });

            it(' issues error on the same module name occurring multiple times ', function() {

                loadModule('test11', 'url1');
                loadModule('test11', 'url2');

                expect(Object.getOwnPropertyNames(rtree.tree)).lengthOf(1);

                rtree.logger.error.should.be.called;
                console.log.should.be.called;
            });

            it(' issues error on loading the same URL under different module names ', function() {

                loadModule('testA', 'url1');
                loadModule('testB', 'url1');

                expect(Object.getOwnPropertyNames(rtree.tree)).lengthOf(2);
                expect(Object.getOwnPropertyNames(rtree.urlMap)).lengthOf(1);

                rtree.logger.error.should.be.called;
                console.log.should.be.called;
            });

            it(' issues error on missing dependencies ', function() {

                loadModule('testA', 'url1', [ 'dep1' ]);

                expect(Object.getOwnPropertyNames(rtree.tree)).lengthOf(1);
                expect(rtree.tree['testA'].delayedDepNames).to.deep.equal([ 'dep1' ]);

                rtree.logger.error.should.be.called;
                console.log.should.be.called;
            });

            it(' recognizes magic module dependencies ', function() {

                loadModule('testA1', 'url11', [ 'require', 'module' ]);

                expect(Object.getOwnPropertyNames(rtree.tree)).lengthOf(1);
                expect(rtree.tree['testA1'].delayedDepNames).lengthOf(0);

                console.log.should.be.not.called;
            });

            it(' handles dependencies ', function() {

                loadModule('testMA', 'urlA');
                loadModule('testMB', 'urlB', [ 'testMA' ]);

                expect(Object.getOwnPropertyNames(rtree.tree)).lengthOf(2);

                var module1 = rtree.tree['testMA'];
                var module2 = rtree.tree['testMB'];

                expect(module2.delayedDepNames).lengthOf(0);
                expect(module2.deps).lengthOf(1);
                expect(module2.deps[0]).to.equal(module1);

                console.log.should.be.not.called;
            });

            it(' handles delayed dependencies ', function() {

                loadModule('testMB', 'urlB', [ 'testMA' ]);
                loadModule('testMA', 'urlA');

                expect(Object.getOwnPropertyNames(rtree.tree)).lengthOf(2);

                var module1 = rtree.tree['testMA'];
                var module2 = rtree.tree['testMB'];

                expect(module2.delayedDepNames).lengthOf(1);
                expect(module2.deps).lengthOf(0);

                console.log.should.be.called;

                console.log.reset();

                rtree.resolveDelayedDependencies();

                expect(module2.deps).lengthOf(1);
                expect(module2.deps[0]).to.equal(module1);

                expect(module1.requiredBy).lengthOf(1);
                expect(module1.requiredBy[0]).to.equal(module2);

                console.log.should.not.be.called;

                // resolving can be called multiple times:

                rtree.resolveDelayedDependencies();

                expect(module2.deps).lengthOf(1);
                expect(module2.deps[0]).to.equal(module1);

                expect(module1.requiredBy).lengthOf(1);
                expect(module1.requiredBy[0]).to.equal(module2);

                console.log.should.not.be.called;

            });

            it(' warns on unresolved delayed dependencies ', function() {

                loadModule('testMB', 'urlB', [ 'testMA' ]);

                expect(Object.getOwnPropertyNames(rtree.tree)).lengthOf(1);

                var module2 = rtree.tree['testMB'];

                expect(module2.delayedDepNames).lengthOf(1);
                expect(module2.deps).lengthOf(0);

                rtree.resolveDelayedDependencies();

                expect(module2.delayedDepNames).lengthOf(1);
                expect(module2.deps).lengthOf(0);

                rtree.logger.warn.should.be.called;
            });

            it(' prints summary ', function() {

                loadModule('testMA', 'urlA');

                rtree.printModuleInfo();
                expect(rtree.urls).lengthOf(1);

                rtree.logger.info.should.be.called;
            });

            it(' prints summaries multiple times correctly ', function() {

                loadModule('testMA', 'urlA');

                rtree.printModuleInfo();
                expect(rtree.urls).lengthOf(1);

                rtree.printModuleInfo();
                expect(rtree.urls).lengthOf(1);

                rtree.logger.info.should.be.called;
            });

            it(' prints summary and errors', function() {

                loadModule('testMA-1', 'urlA');
                loadModule('testMA-2', 'urlA');

                rtree.printModuleInfo();

                rtree.logger.info.should.be.called;
                rtree.logger.error.should.be.called;

            });
        });

    });
})