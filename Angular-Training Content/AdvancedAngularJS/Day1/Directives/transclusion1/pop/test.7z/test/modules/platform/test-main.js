/**
 * @ngdoc object
 * @name platform.object:test-main
 * @author Benjamin Beeman
 *
 * @description This is the main configuration file for the {@link platform} module.
 */
var tests = [];
for ( var file in window.__karma__.files) {
    if (window.__karma__.files.hasOwnProperty(file)) {
        if (/-test\.js$/.test(file)) {
            tests.push(file);
        }
    }
}

/**
 * @ngdoc object
 * @name require config
 * @propertyOf platform.object:test-main
 * @description require.config is the section of the platform test-main.js file where all require configurations
 *              are done for the platform tests.
 *
 */
require.config({
    // Karma serves files under /base, which is the basePath from your config file
    baseUrl : '/base/public',

    paths : {
        // Is this loaded at all? why giving it a junk name did not cause complain?
        'angular' : 'uaf/3rdparty/angular/angular',
        'angular-mocks' : 'uaf/3rdparty/angular/angular-mocks',
        'angular-ui' : 'uaf/3rdparty/angular-ui/ui-bootstrap-tpls-0.12.1',
        'angularRoute' : 'uaf/3rdparty/angular-route/angular-route',
        'angularTranslate' : 'uaf/3rdparty/angular-translate/dist/angular-translate',
        'angularTranslatePartialLoader' : 'uaf/3rdparty/angular-translate/dist/angular-translate-loader-partial/angular-translate-loader-partial',
        'lodash' : 'uaf/3rdparty/lodash',
        'postal' : 'uaf/3rdparty/postal/lib/postal',
        'hdx' : 'uaf/hdx/js/hdx',
        'hdx-bootstrap' : 'uaf/hdx/components/hdx-bootstrap/js/hdx-bootstrap',
        'jquery' : 'uaf/hdx/components/3rdparty/jquery/dist/jquery',
        'bootstrap' : 'uaf/hdx/components/3rdparty/bootstrap/js',
        'prettify' : "uaf/hdx/components/3rdparty/prettify/prettify",
        'directive' : "uaf/hdx/components/3rdparty/angular-ui/ui-bootstrap-tpls-0.12.1",
        'hammer' : "modules/platform/3rdparty/hammer.js-master/hammer.min"
    },
    shim : {
        'angular' : {
            deps: ['jquery'],
            'exports' : 'angular'
        },
        'angular-mocks' : {
            deps : [ 'angular' ],
            'exports' : 'angular.mock'
        },
        'angularTranslatePartialLoader' : {
            deps : [ 'angular', 'angularTranslate' ],
            'exports' : 'angularTranslatePartialLoader'
        }
    },

    // dynamically load all test files
    deps : tests,

    // start running the tests, once Require.js is done
    callback : window.__karma__.start
});

