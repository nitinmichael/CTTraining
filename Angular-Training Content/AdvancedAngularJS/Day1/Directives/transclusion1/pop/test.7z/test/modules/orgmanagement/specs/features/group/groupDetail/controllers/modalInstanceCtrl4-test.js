/*
 * groupDetailController-test.js
 * This test file is used to cover the unit test cases for Edit MDT or Generic Group controller(groupDetailController.js)
 */
define(['angular', 'angular-mocks',
        'orgMgmnt/features/group/groupDetail/controllers/groupDetailController',
        'orgMgmnt/services/groupService',
        'orgMgmnt/dataModels/groupDataModel'
    ],
    function () {
        'use strict';

        describe('Test the ModalInstanceCtrl4', function () {
            var scope,_modalInstance,filter,transitionParams,ModalInstanceCtrl4;
            beforeEach(function () {
                module('Orgmanagement.Features.Group.GroupDetail.GroupDetailController');
            });
            beforeEach(module('Orgmanagement.Features.Group.GroupDetail.GroupDetailController', function () {
                _modalInstance=JSON.parse(JSON.stringify({"result":{"$$state":{"status":0,"pending":[[{"promise":{"$$state":{"status":0}}},null,null,null]]}},"opened":{"$$state":{"status":0}}}));
                _modalInstance["close"]=function(){};
                _modalInstance["dismiss"]=function(){};
                transitionParams=JSON.parse(JSON.stringify({"toState":{"title":"Manage Users","name":"manageUser","templateUrl":"./modules/orgmanagement/features/manageUsers/views/manageUserMain.html","controller":"ManageUserMainCtrl","href":"/manageUser","autoStart":"true","parent":"secure","url":"/manageUser/:id"},"toParams":{"id":"4"}}));
            }));

            beforeEach(inject(function ($controller, $rootScope,$filter) {
                scope = $rootScope.$new();
                filter=$filter;
                ModalInstanceCtrl4 = $controller('ModalInstanceCtrl4', {
                    $scope: scope,
                    $modalInstance: _modalInstance,
                    $filter:filter,
                    transitionParams:transitionParams
                });
                sinon.stub(_modalInstance, 'close');
                sinon.stub(_modalInstance, 'dismiss');
            }));
            it('should have a controller', function () {
                assert.isDefined(ModalInstanceCtrl4, 'Controller is not defined');
            });
            it('checks goAheadAndNavigate functioanlity', function () {
                scope.goAheadAndNavigate();
                chai.expect(_modalInstance.close).calledWith(transitionParams);

            });
            it('checks goBackAndSave functioanlity', function () {
                scope.goBackAndSave();
                chai.expect(_modalInstance.dismiss).calledWith('close');
            });


        });
    });
