/*
 *  mobile-menu-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author: Josselin Buils <josselin.buils@ge.com>
 */

/**
 * Spec file for Viewer > modules > mousemanagement > widgets > mobileMenu directive
 */

define(['angular', 'angular-mocks', 'jquery', 'mousemanagementModule/module', 'platformMock', 'imageAreaToolbarMocks',
        'mousemanagementModule/widgets/mobile-menu'],
    function () {
        'use strict';

        describe('mobileMenu directive test :', function () {
            var $document,
                element,
                scope;

            beforeEach(module('cloudav.viewerApp.mousemanagement'));
            beforeEach(module('imageAreaToolbarFactoryMock'));
            beforeEach(module('platform'));
            beforeEach(module('templates'));

            beforeEach(
                inject(function ($compile, $rootScope, _$document_) {
                    $document = _$document_;

                    element = angular.element('<mobile-menu></mobile-menu>');
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$digest();
                })
            );

            it('should have a directive', function () {
                assert.isDefined(element, 'mobile-menu directive is not defined');
            });

            it('should have menu object', function () {
                assert.isDefined(scope.menuItems, 'mobile-menu directive does not have menuItems object');
            });

            it('should have title', function () {
                assert.equal(scope.menuItems.title, 'Mobile menu', 'mobile-menu directive has incorrect title');
            });

            it('should have type', function () {
                assert.equal(scope.menuItems.type, 'mobile-menu', 'mobile-menu directive has incorrect type');
            });

            it('should have default buttons', function () {
                assert.isArray(scope.menuItems.buttons);
                assert.equal(scope.menuItems.buttons.length, 3, 'mobile-menu directive has incorrect number of buttons');
            });

            it('should close the menu after a touchdown out of the menu', function () {
                angular.element(document.body).append('<div class="mobile-menu"></div>');
                $('.mobile-menu').addClass('expanded');
                expect($('.mobile-menu').hasClass('expanded')).to.equal(true);
                $document.triggerHandler('mousedown');
                expect($('.mobile-menu').hasClass('expanded')).to.equal(false);
            });
        });
    });
