// Karma configuration
module.exports = function (config) {
    'use strict';

    config.set({

        // base path that will be used to resolve all patterns (eg. files, exclude)
        //  basePath: '../../..',

        basePath: '../../..',


        // frameworks to use
        // available frameworks: https://npmjs.org/browse/keyword/karma-adapter
        frameworks: ['mocha',  'requirejs','chai-as-promised', 'sinon-chai', 'chai'],


        // list of files / patterns to load in the browser
        files: [
            // loading the anguler library first to avoid angular dependent library error
            //'public/uaf/3rdparty/angular/angular.js',
            {pattern: 'public/uaf/**/*.js', included: false},
            { pattern: 'public/modules/verifyNewUser/**/*.js', included: false },
            {pattern: 'test/modules/verifyNewUser/**/*-test.js', included: false},
            'test/modules/verifyNewUser/test-main.js'
        ],

        // list of files to exclude
        exclude: [
        ],

        // preprocess matching files before serving them to the browser
        // available preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor
        preprocessors: {
            'public/modules/verifyNewUser/**/*.js': 'coverage'
            //'public/modules/orgmanagement/**/!(*main|*module).js': ['coverage']
        },

        junitReporter: {
            outputFile: 'test/modules/verifyNewUser/report/junit/TESTS-xunit.xml',
            suite: ''
        },


        // test results reporter to use
        // possible values: 'dots', 'progress'
        // available reporters: https://npmjs.org/browse/keyword/karma-reporter
        reporters: ['progress','coverage','junit'],

        // web server port
        port: 9876,

        // enable / disable colors in the output (reporters and logs)
        colors: true,

        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG

        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: true,

        // start these browsers
        // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
        browsers: ['PhantomJS'],

        coverageReporter: { dir : 'test/modules/verifyNewUser/report/coverage',
            reporters: [
                {type : 'lcovonly',subdir: 'lcovonly'},
                {type : 'html',subdir: 'html'}
            ]},

        // Continuous Integration mode
        // if true, Karma captures browsers, runs the tests and exits
        singleRun: true,
        plugins: [
            'karma-chrome-launcher',
            'karma-phantomjs-launcher',
            'karma-requirejs',
            'karma-mocha',
            'karma-chai',
            'karma-chai-as-promised',
            'karma-sinon-chai',
            'karma-coverage',
            'karma-junit-reporter'
        ]
    });
};
