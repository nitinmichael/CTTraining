define([ 'require', 'jquery', 'modules/viewer/tracing/angular-tracing' ], function(requireInfo, $) {

    describe('Test AngularJS tracing', function() {

        var scriptUrl = requireInfo.toUrl('modules/viewer/tracing/angular-tracing.js');

        it(' can be loaded multiple times', function(done) {

            $.ajax(scriptUrl, {
                dataType : 'text'
            }).fail(done).success(function(scriptText) {
                doTestMultipleLoading(scriptText);
                done();
            });
        })

        var doTestMultipleLoading = function(scriptText) {

            var originalNgTracing = window.ngTracing;
            var originalNgMockTracing = window.ngMockTracing;

            try {
                delete window.ngTracing;
                delete window.ngMockTracing;

                expect(window.ngTracing).to.equal(undefined);
                expect(window.ngMockTracing).to.equal(undefined);

                eval(scriptText);

                var ng1 = window.ngTracing;
                var ngMock1 = window.ngMockTracing;

                expect(ng1).to.exist;
                expect(ngMock1).to.exist;

                // re-run the script
                eval(scriptText);

                // the exposed global objects are the same:
                expect(window.ngTracing).to.equal(ng1);
                expect(window.ngMockTracing).to.equal(ngMock1);

            } finally {
                window.ngTracing = originalNgTracing;
                window.ngMockTracing = originalNgMockTracing;
            }

        }

        describe(' tests ngTracing object capabilities', function() {
            var ngTracing;
            var rtreeMock;

            beforeEach(function() {
                rtreeMock = createRTreeMock();
                ngTracing = new window.ngTracing.constructor(rtreeMock);
            });

            var createRTreeMock = function() {
                var mock = {};
                var logger = {};
                logger.info = sinon.stub();
                logger.warn = sinon.stub();
                logger.error = sinon.stub();

                mock.logger = logger;
                mock.urlMap = {};
                mock.tree = {};
                return mock;
            };

            it(' can push map values', function() {
                var map = {};

                ngTracing.pushToMap(map, 'a', 'b');
                expect(map).to.deep.equal({
                    a : [ 'b' ]
                });

                ngTracing.pushToMap(map, 'a', 'c');
                expect(map).to.deep.equal({
                    a : [ 'b', 'c' ]
                });

            });

            it(' can return the caller source ', function() {

                var sourceUrl = ngTracing.getCallerSourceUrl(3);
                expect(sourceUrl).to.have.string('angular-tracing-test.js');

            });

            it(' uses default caller index of 4 ', function() {

                sinon.stub(ngTracing, '_getCallStack');
                ngTracing._getCallStack.returns('0\n1\n2\n3\n4\n5\n6')

                var sourceUrl = ngTracing.getCallerSourceUrl();
                expect(sourceUrl).to.have.string('4');

            });

            it(' handles window.origin ending in a slash ', function() {

                sinon.stub(ngTracing, '_getWindowOrigin');
                ngTracing._getWindowOrigin.returns('hackedWindowOrigin/');
                sinon.stub(ngTracing, '_getCallStack');
                ngTracing._getCallStack.returns('0\n1\n2\n3\n hackedWindowOrigin/sourceFile.js \n5\n6')

                var sourceUrl = ngTracing.getCallerSourceUrl();
                expect(sourceUrl).to.have.string('sourceFile.js');

            });

            it(' can test whether a list contains an item ', function() {

                expect(ngTracing.listContains([ 'a' ], 'b')).not.to.be.ok;
                expect(ngTracing.listContains([ 'a', 'b' ], 'a')).to.be.ok;

            });

            var createAMD = function(url, deps) {
                return {
                    normUrl : url,
                    deps : deps
                };
            };

            it(' can test collect AMD dependencies recursively ', function() {

                var moduleA = createAMD('urlA', []);
                var moduleB = createAMD('urlB', [ moduleA ]);
                var moduleC = createAMD('urlC', [ moduleB ]);

                // create a circular dependency:
                moduleA.deps.push(moduleC);

                var result = [];
                ngTracing.collectDepUrls(moduleC, result);
                expect(result).to.deep.equal([ 'urlC', 'urlB', 'urlA' ]);

            });

            var createNgModule = function(name, deps) {
                return {
                    name : name,
                    deps : deps,
                    url : 'url:' + name
                };
            };

            it(' can test collect Angular dependencies recursively ', function() {

                var moduleA = createNgModule('A', [ 'C' ]);
                var moduleB = createNgModule('B', [ 'A' ]);
                var moduleC = createNgModule('C', [ 'B' ]);

                ngTracing.ngMap['A'] = moduleA;
                ngTracing.ngMap['B'] = moduleB;
                ngTracing.ngMap['C'] = moduleC;

                var result = [];

                ngTracing.collectNgModuleDeps(moduleC, result);
                expect(result).to.deep.equal([ moduleC, moduleB, moduleA ]);

            });

            it(' reports missing Angular dependencies ', function() {

                var moduleA = createNgModule('A', [ 'C' ]);

                ngTracing.ngMap['A'] = moduleA;

                var result = [];
                ngTracing.collectNgModuleDeps(moduleA, result);

                expect(result).to.deep.equal([ moduleA ]);

                expect(ngTracing.rtree.logger.warn.called).to.equal(true);

            });

            it(' does not report "ng" as a missing Angular dependency ', function() {

                var moduleA = createNgModule('A', [ 'ng' ]);

                ngTracing.ngMap['A'] = moduleA;

                var result = [];
                ngTracing.collectNgModuleDeps(moduleA, result);

                expect(result).to.deep.equal([ moduleA ]);

                expect(ngTracing.rtree.logger.warn.called).to.equal(false);

            });

            it(' warns on missing AMD info ', function() {

                var referringSource = 'someUrl.js';
                ngTracing.checkDeps('ngModuleA', referringSource);

                expect(ngTracing.rtree.logger.warn.called).to.equal(true);
                expect(ngTracing.rtree.logger.warn.getCall(0).args[1]).to.equal(referringSource);

            });

            it(' warns on missing Angular module info ', function() {

                var amdModule = createAMD('someUrl.js', []);
                ngTracing.rtree.urlMap[amdModule.normUrl] = [ amdModule ];

                ngTracing.checkDeps('ngModuleA', amdModule.normUrl);

                expect(ngTracing.rtree.logger.warn.called).to.equal(true);
                expect(ngTracing.rtree.logger.warn.getCall(0).args[1]).to.equal('ngModuleA');

            });

            it(' issues error on unreachable Angular module ', function() {

                var amdModule = createAMD('someUrl.js', []);
                var ngModuleA = createNgModule('ngModuleA', []);

                ngTracing.rtree.urlMap[amdModule.normUrl] = [ amdModule ];
                ngTracing.ngMap[ngModuleA.name] = ngModuleA;

                ngTracing.checkDeps(ngModuleA.name, amdModule.normUrl);

                expect(ngTracing.rtree.logger.warn.called).to.equal(false);
                expect(ngTracing.rtree.logger.error.called).to.equal(true);

            });

            it(' can assess if an Angular module is accessible ', function() {

                var ngModuleA = createNgModule('ngModuleA', []);
                var definingAMDModule = createAMD(ngModuleA.url, []);
                var referringAMD = createAMD('someUrl.js', [ definingAMDModule ]);

                ngTracing.rtree.urlMap[referringAMD.normUrl] = [ referringAMD ];

                ngTracing.ngMap[ngModuleA.name] = ngModuleA;

                ngTracing.checkDeps(ngModuleA.name, referringAMD.normUrl);

                expect(ngTracing.rtree.logger.warn.called).to.equal(false);
                expect(ngTracing.rtree.logger.error.called).to.equal(false);

            });

            it(' can assess if a transient Angular module dependency is missing ', function() {

                var ngModuleB = createNgModule('ngModuleB', []);

                var ngModuleA = createNgModule('ngModuleA', [ ngModuleB.name ]);
                var definingAMDModule = createAMD(ngModuleA.url, []);
                var referringAMD = createAMD('someUrl.js', [ definingAMDModule ]);

                ngTracing.rtree.urlMap[referringAMD.normUrl] = [ referringAMD ];

                ngTracing.ngMap[ngModuleA.name] = ngModuleA;
                ngTracing.ngMap[ngModuleB.name] = ngModuleB;

                ngTracing.checkDeps(ngModuleA.name, referringAMD.normUrl, true);

                expect(ngTracing.rtree.logger.warn.called).to.equal(true);
                expect(ngTracing.rtree.logger.error.called).to.equal(false);

            });

            it(' can assess if a transient Angular module dependency is available ', function() {

                var ngModuleB = createNgModule('ngModuleB', []);
                var ngModuleA = createNgModule('ngModuleA', [ ngModuleB.name ]);

                var definingAMDModule = createAMD(ngModuleA.url, []);
                var definingAMDModuleB = createAMD(ngModuleB.url, []);

                var referringAMD = createAMD('someUrl.js', [ definingAMDModule, definingAMDModuleB ]);

                ngTracing.rtree.urlMap[referringAMD.normUrl] = [ referringAMD ];

                ngTracing.ngMap[ngModuleA.name] = ngModuleA;
                ngTracing.ngMap[ngModuleB.name] = ngModuleB;

                ngTracing.checkDeps(ngModuleA.name, referringAMD.normUrl, true);

                expect(ngTracing.rtree.logger.warn.called).to.equal(false);
                expect(ngTracing.rtree.logger.error.called).to.equal(false);

            });

            describe(' test Angular module interception', function() {

                var originalAngularObject;
                var angularModuleStub;

                beforeEach(function() {
                    originalAngularObject = window.angular;

                    angularModuleStub = sinon.stub();
                    window.angular = {
                        module : angularModuleStub
                    };
                });

                afterEach(function() {
                    if (originalAngularObject) {
                        window.angular = originalAngularObject;
                    } else {
                        // the global angular object was not defined
                        delete window.angular;
                    }
                });

                it(' intercepts Angular.module function', function() {

                    expect(angular.module).to.equal(angularModuleStub);
                    var intercept = sinon.spy(ngTracing, 'intercept');

                    ngTracing.interceptNgModuleFunction();

                    intercept.should.be.calledOnce;
                    expect(intercept.returnValues[0]).to.equal(angular.module);
                    expect(angular.module).not.to.equal(angularModuleStub);
                    expect(originalAngularModule).to.equal(angularModuleStub);
                });
            });

            it('intercepts Angular module definition', function() {

                var getCallerSource = sinon.stub(ngTracing, 'getCallerSourceUrl');
                var moduleDefUrl = 'http://someUrl';

                getCallerSource.returns(moduleDefUrl);

                var moduleFunc = ngTracing.intercept(sinon.stub());

                var moduleDeps = [ 'moduleB' ];
                moduleFunc('moduleA', moduleDeps);

                expect(ngTracing.ngUrlMap[moduleDefUrl]).to.deep.equal([ {
                    name : 'moduleA',
                    deps : moduleDeps
                } ]);
                expect(ngTracing.ngMap['moduleA']).to.deep.equal({
                    name : 'moduleA',
                    url : moduleDefUrl,
                    deps : moduleDeps
                });

                expect(ngTracing.rtree.logger.warn.called).to.equal(false);
                expect(ngTracing.rtree.logger.error.called).to.equal(false);

                // what happens if the caller source is unknown:
                getCallerSource.returns(undefined);
                moduleFunc('moduleA', moduleDeps);

                expect(ngTracing.rtree.logger.warn.called).to.equal(false);
                expect(ngTracing.rtree.logger.error.called).to.equal(false);

            });

            it('warns on Angular module overwriting', function() {

                var moduleFunc = ngTracing.intercept(sinon.stub());

                var getCallerSource = sinon.stub(ngTracing, 'getCallerSourceUrl');

                getCallerSource.returns('url1');
                moduleFunc('moduleA', []);

                getCallerSource.returns('url2');
                moduleFunc('moduleA', []);

                expect(Object.getOwnPropertyNames(ngTracing.ngUrlMap)).to.have.lengthOf(2);

                expect(ngTracing.rtree.logger.warn.called).to.equal(true);
                expect(ngTracing.rtree.logger.error.called).to.equal(false);

            });

            it('intercepts Angular module reference', function() {

                var getCallerSource = sinon.stub(ngTracing, 'getCallerSourceUrl');
                var moduleRefUrl = 'http://someUrl';

                getCallerSource.returns(moduleRefUrl);

                var moduleFunc = ngTracing.intercept(sinon.stub());

                moduleFunc('moduleA');

                expect(ngTracing.rtree.logger.warn.called).to.equal(false);
                expect(ngTracing.rtree.logger.error.called).to.equal(false);

                expect(ngTracing.moduleRefs[moduleRefUrl]).to.deep.equal([ 'moduleA' ]);
                expect(ngTracing.moduleRefsR['moduleA']).to.deep.equal([ moduleRefUrl ]);

                // quietly ignores the case when the referring source is unknown:
                getCallerSource.returns(undefined);

                moduleFunc('moduleA');

                expect(ngTracing.rtree.logger.warn.called).to.equal(false);
                expect(ngTracing.rtree.logger.error.called).to.equal(false);
            });

            it('can analyze Angular module callmaps', function() {

                var checkDepsFunc = sinon.spy(ngTracing, 'checkDeps');

                var callMap = {
                    url1 : [ 'A', 'B' ],
                    url2 : [ 'C' ]
                };

                var result1 = ngTracing.checkNgModuleReferences(callMap, true);
                var result2 = ngTracing.checkNgModuleReferences(callMap, false);

                expect(result1.sourceCount).to.equal(2);
                expect(result1.callCount).to.equal(3);

                expect(checkDepsFunc.callCount).to.equal(6);
            });

            it('can analyze recorded Angular module callmaps when instructed', function() {

                var checkNgModuleRefs = sinon.spy(ngTracing, 'checkNgModuleReferences');

                ngTracing.checkModuleRefs();

                checkNgModuleRefs.should.be.calledOnce;

                expect(ngTracing.rtree.logger.info.callCount).to.equal(2);
                expect(ngTracing.rtree.logger.warn.called).to.equal(false);
                expect(ngTracing.rtree.logger.error.called).to.equal(false);
            });

            describe(' Test angular.module access', function() {

                var defineAngularAMD = function() {
                    var angularUrl = 'location-from-where-angular-is-loaded.js';
                    var angularAMD = createAMD(angularUrl, []);
                    ngTracing.rtree.tree[ngTracing.angularAMDName] = angularAMD;
                    return angularAMD;
                };

                var createUserModule = function() {
                    var userModule = createAMD('userModule', []);

                    // simulate angular.module call from the user module:
                    var getCallerSource = sinon.stub(ngTracing, 'getCallerSourceUrl');
                    getCallerSource.returns(userModule.normUrl);

                    var moduleFunc = ngTracing.intercept(sinon.stub());
                    moduleFunc('A', []);

                    return userModule
                };

                it('can verify whether angular is available through RequireJS dependencies', function() {

                    var angularAMD = defineAngularAMD();
                    var userModule = createUserModule();

                    userModule.deps.push(angularAMD);
                    ngTracing.rtree.urlMap[userModule.normUrl] = [ userModule ];

                    ngTracing.checkAngularAccess();

                    expect(ngTracing.rtree.logger.info.callCount).to.equal(2);
                    expect(ngTracing.rtree.logger.warn.called).to.equal(false);
                    expect(ngTracing.rtree.logger.error.called).to.equal(false);
                });

                it('issues error if angular is not specified as RequireJS dependency', function() {

                    var angularAMD = defineAngularAMD();
                    var userModule = createUserModule();

                    // the userModule does NOT depend on angular:
                    // userModule.deps.push(angularAMD);
                    ngTracing.rtree.urlMap[userModule.normUrl] = [ userModule ];

                    ngTracing.checkAngularAccess();

                    expect(ngTracing.rtree.logger.info.callCount).to.equal(2);
                    expect(ngTracing.rtree.logger.warn.called).to.equal(false);
                    expect(ngTracing.rtree.logger.error.called).to.equal(true);

                });

                it('issues a warning if no AMD info is available when checking angular access', function() {

                    var angularAMD = defineAngularAMD();
                    var userModule = createUserModule();

                    userModule.deps.push(angularAMD);
                    // simulate that the user module loading was not intercepted by RequireJS:
                    // ngTracing.rtree.urlMap[userModule.normUrl] = [userModule];

                    ngTracing.checkAngularAccess();

                    expect(ngTracing.rtree.logger.info.callCount).to.equal(2);
                    expect(ngTracing.rtree.logger.warn.called).to.equal(true);
                    expect(ngTracing.rtree.logger.error.called).to.equal(false);

                });

                describe('Test ngMockTracing', function() {
                    var ngMockTracing;

                    beforeEach(function() {
                        ngMockTracing = new window.ngMockTracing.constructor(ngTracing);
                    });

                    describe(' angular.mock.module intercepting', function() {
                        var originalWindowModule;
                        var originalAngularModule;
                        var originalMockModule;

                        beforeEach(function() {
                            originalWindowModule = window.module;
                            originalAngularModule = window.angular;
                            if (originalAngularModule) {
                                originalMockModule = window.angular.mock;
                            }
                        });

                        afterEach(function() {
                            window.module = originalWindowModule;
                            window.angular = originalAngularModule;
                            if (originalMockModule) {
                                window.angular.mock.module = originalMockModule;
                            }
                        });

                        it('intercepts angular.mock.module and window.module function', function() {
                            var originalMockModuleFunction = sinon.stub();

                            window.angular = {
                                mock : {
                                    module : originalMockModuleFunction
                                }
                            };
                            window.module = originalMockModuleFunction;

                            var interceptSpy = sinon.spy(ngMockTracing, 'intercept');

                            ngMockTracing.interceptModuleFunction();

                            var interceptedFunc = interceptSpy.returnValues[0];

                            expect(interceptSpy.getCall(0).args[0]).to.equal(originalMockModuleFunction);
                            expect(window.angular.mock.module).to.equal(interceptedFunc);
                            expect(window.module).to.equal(interceptedFunc);

                        });

                        it('intercepts angular.mock.module only (no window.module function)', function() {
                            var originalMockModuleFunction = sinon.stub();

                            window.angular = {
                                mock : {
                                    module : originalMockModuleFunction
                                }
                            };
                            if (window.module) {
                                delete window.module;
                            }

                            var interceptSpy = sinon.spy(ngMockTracing, 'intercept');

                            ngMockTracing.interceptModuleFunction();

                            var interceptedFunc = interceptSpy.returnValues[0];

                            expect(interceptSpy.getCall(0).args[0]).to.equal(originalMockModuleFunction);
                            expect(window.angular.mock.module).to.equal(interceptedFunc);
                            expect(window.module).to.be.undefined;

                        });
                    });

                    it('records mock.module calls', function() {
                        var stubModuleFunc = sinon.stub();

                        var interceptedModuleFunc = ngMockTracing.intercept(stubModuleFunc);

                        // it can be called without arguments:
                        interceptedModuleFunc();

                        // it can be called with function arguments:
                        interceptedModuleFunc(function() {
                        });

                        // it can be called with module name arguments:
                        interceptedModuleFunc('moduleA');

                        expect(Object.getOwnPropertyNames(ngMockTracing.ngMockModuleCalls)).to.be.lengthOf(1);
                        expect(Object.getOwnPropertyNames(ngMockTracing.ngMockModuleCallsR)).to.be.lengthOf(1);

                    });

                    it('performs mock.module calls analysis', function() {

                        var checkerFuncSpy = sinon.spy(ngTracing, 'checkNgModuleReferences');

                        ngMockTracing.checkMockModuleCalls();

                        expect(checkerFuncSpy.getCall(0).args[0]).to.equal(ngMockTracing.ngMockModuleCalls);
                        expect(checkerFuncSpy.getCall(0).args[1]).to.equal(true);
                    });
                });
            });

        });

    });
})