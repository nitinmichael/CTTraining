/*
 *  patient-search-service-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Eduardo Mioto<eduardo.mioto@ge.com>
 */

/**
 * Spec file for Patient Search service
 */

define([
    'angular',
    'angular-mocks',
    'patient-view/modules/patient-search/services/patientSearchService'
],
function (ng, mocks) {
    'use strict';

    var patientSearchService;
    var httpBackend;
    var q, defer;
    var endpoint;
    var $Endpoint;

    describe('Repository Search Service', function () {
        beforeEach(module('cloudav.patient-view.patient-search', function ($provide) {
            endpoint = function () {
                return 'http://ge.test.fake.nonexistentdomain';
            };
            $provide.value('endpoint', endpoint);


            //

            $provide.service('$Endpoint', function() {

                this.getEndpoint = function (key) {
                    return 'http://ge.test.fake.nonexistentdomain';
                };

             });

        }));

        beforeEach(inject(function(PatientSearchService, _$Endpoint_, $httpBackend,$q) {
            httpBackend = $httpBackend;
            $Endpoint = _$Endpoint_;
            patientSearchService = PatientSearchService;
            q = $q;
            defer = q.defer();
        }));

        describe('Search service', function(){
            it('should test search is called successfully ', function () {
 
                var request = {};
                var httpCode = 200;
                var url = endpoint() + '/patient-view/v1/mypatient/search';
                httpBackend.expectPOST(url,request).respond(httpCode, {
                    list: [{ name: '', identifier: [{system: '', value: ''}] }]
                });
                defer.resolve();
                patientSearchService.search(request);
                httpBackend.flush();
                httpBackend.verifyNoOutstandingExpectation();
                httpBackend.verifyNoOutstandingRequest();
            });

            it('should test search is called successfully ', function () {

                var request = {};
                var httpCode = 200;
                var url = endpoint() + '/patient-view/v1/mypatient/search';
                httpBackend.expectPOST(url,request).respond(httpCode, {
                    list: [{ name: '' }]
                });
                defer.resolve();
                patientSearchService.search(request);
                httpBackend.flush();
                httpBackend.verifyNoOutstandingExpectation();
                httpBackend.verifyNoOutstandingRequest();
            });

            it('should test search is not called  successfully ', function () {
     
                var request = {};
                var httpCode = 400;
                var url = endpoint() + '/patient-view/v1/mypatient/search';
                httpBackend.expectPOST(url,request).respond(httpCode);
                defer.resolve();
                patientSearchService.search(request);
                httpBackend.flush();
                httpBackend.verifyNoOutstandingExpectation();
                httpBackend.verifyNoOutstandingRequest();
            });
        });
    });
});