/**
 * @ngdoc service
 * @name xjtweb-platform.test.graphicalobjectfactory-test
 *
 * @description This is the test suite for the graphicalobjectfactory.
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */
define([ 'angular', 'angular-mocks', 'modules/xjtweb-platform/services/graphical-object-factory' ], function(ng, mocks) {
    'use strict';

    describe('Measure manager', function() {
        var mockChannel;
        var graphicalobjectfactory;

        function mockGraphicalObjectFactory() {
        }

        beforeEach(module('graphical-object'));

        beforeEach(module(function($provide) {
            $provide.factory('$xjtweb', function() {
                return {
                    XJTWEB : {
                        GraphicalObjectFactory : mockGraphicalObjectFactory
                    }
                };
            });
        }));

        beforeEach(inject(function(GraphicalObjectFactory) {
            graphicalobjectfactory = GraphicalObjectFactory;
        }));

        /**
         * @ngdoc method
         * @name graphicalobjectfactory_Init_Test
         * @methodOf xjtweb-platform.test.graphicalobjectfactory-test
         *
         * @description This test method determines that the GraphicalObjectFactory is created as an instance of an
         *              XJTWEB.GraphicalObjectFactory.
         */
        it('graphicalobjectfactory should be a typeof object', function() {
            expect(graphicalobjectfactory instanceof mockGraphicalObjectFactory).to.equal(true);
        });
    });
});
