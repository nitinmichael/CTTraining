/*
 *  case-automation-service-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 */

/**
 * Spec file for Case Automation Service Test module
 */

define([
    'angular',
    'angular-mocks',
    'modules/caseexchange/modules/case-automation/services/case-automation-service',
    'mocks/case-exchange-mock-service',
    'mocks/fake-server'], function () {
    'use strict';

    describe('Test Get Instructions Details', function () {
        var caseAutomationService, rootScope, originalAjax, $mockServerLoader, mockServer;
        
        beforeEach(function () {
            // Load the module for the mock data first
            module('cloudav.caseExchange.mocks');
            // Load the Sinon fake server.
            module('cloudav.caseExchange.fakeServer');

            // store original $.ajax
            originalAjax = $.ajax;
            // provide mock services for caseAutomationService
            module('Services.caseAutomationService', function ($provide) {
                $provide.factory('configurationService', ['$q', function ($q) {
                    return {
                        getProperty: function () {
                            return $q.when({});
                        }
                    }
                }]);
            });
            // inject dependencies for caseAutomationService
            inject(function (_CaseAutomationService_, _CaseExchangeDataService_, $rootScope, $MockServerLoader) {
                caseAutomationService = _CaseAutomationService_;
                rootScope = $rootScope;
                $mockServerLoader = $MockServerLoader;
                mockServer = $mockServerLoader.init();
            });
        });
        
     // restore $.ajax for use by other test suites
        afterEach(function () {
            $.ajax = originalAjax;
        });

        it('should define a service', function () {
            assert.isDefined(caseAutomationService, 'CaseAutomationService is defined');
        });

        describe('Testing successful getCaseAutomationInstructions() method', function () {
            it('should indicate success when set up to run normally', function (done) {
                var isSuccessful = false;
                $mockServerLoader.fakeInstructionListCall(200, {});
                caseAutomationService.getCaseAutomationInstructions(10,10,10).xhr.then(
                        function onResolve(data) {
                            isSuccessful = true;
                            done();
                        },

                        function onError(errorMessage) {
                        }
                );

                // respond will trigger the success of getCaseAutomationInstructions call.
                mockServer.respond();
                rootScope.$apply();

                assert(isSuccessful, 'normal run should have succeeded');
            });

        });

       describe('Testing failed getCaseAutomationInstructions() arising from invalid "me" service result', function () {

            var isSuccessful = true, failedMeJSON = {};

            it('should indicate failure when set up to fail', function (done) {

                $.ajax = function (options) {
                    if (options.url.indexOf('user/me') >= 0) {
                        options.success(failedMeJSON);
                    }
                    if (options.url.indexOf('applicatonservice') >= 0) {
                        // if this part is reached, the test fails
                        isSuccessful = true;
                    }
                    else {
                        options.error();
                        isSuccessful = false;
                        done();
                    }
                };

                caseAutomationService.getCaseAutomationInstructions(10,10,10).xhr.then(
                        function onResolve(data) {
                        },

                        function onError(errorMessage) {
                        }
                );
                assert(!isSuccessful, 'should have failed');
            });

        });

       describe('Testing successful caseInstructionCurdOperation() method', function () {
           it('should indicate success when set up to run normally', function (done) {
               var isSuccessful = false;
               $mockServerLoader.fakeInstructionCurdOperationCall("GET", 200, {}, "/caseautomation/v1/instruction");
               caseAutomationService.caseInstructionCurdOperation("GET", null, null).xhr.then(
                       function onResolve(data) {
                           isSuccessful = true;
                           done();
                       },

                       function onError(errorMessage) {
                       }
               );

               $mockServerLoader.fakeInstructionCurdOperationCall("POST", 200, {}, "/caseautomation/v1/instruction/1");
               caseAutomationService.caseInstructionCurdOperation("POST", "1", {}).xhr.then(
                       function onResolve(data) {
                           isSuccessful = true;
                           done();
                       },

                       function onError(errorMessage) {
                       }
               );

               // respond will trigger the success of getCaseAutomationInstructions call.
               mockServer.respond();
               rootScope.$apply();

               assert(isSuccessful, 'normal run should have succeeded');
           });

       });

       describe('Testing failed caseInstructionCurdOperation() arising from invalid "me" service result', function () {

           var isSuccessful = true, failedMeJSON = {};

           it('should indicate failure when set up to fail', function (done) {

               $.ajax = function (options) {
                   if (options.url.indexOf('user/me') >= 0) {
                       options.success(failedMeJSON);
                   }
                   if (options.url.indexOf('applicatonservice') >= 0) {
                       // if this part is reached, the test fails
                       isSuccessful = true;
                   }
                   else {
                       options.error();
                       isSuccessful = false;
                       done();
                   }
               };

               caseAutomationService.caseInstructionCurdOperation("GET", null, null).xhr.then(
                       function onResolve(data) {
                       },

                       function onError(errorMessage) {
                       }
               );
               assert(!isSuccessful, 'should have failed');
           });

       });
    });
});