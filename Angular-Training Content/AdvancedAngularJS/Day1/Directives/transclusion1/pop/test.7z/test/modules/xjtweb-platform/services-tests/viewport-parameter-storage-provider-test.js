define([ 'angular', 'angular-mocks', 'modules/xjtweb-platform/services/viewport-parameter-storage-provider' ], function(ng) {
    'use strict';

    /**
     * @ngdoc service
     * @name xjtweb-platform.provider:viewportParameterStorageProvider-test
     * @author Benjamin Beeman
     *
     * @description This file includes unit tests that test the $viewportParameterStorageProvider.
     *
     * Copyright (c) 2015 by General Electric Company. All rights reserved.
     *
     * The copyright to the computer software herein is the property of General Electric Company. The software may be
     * used and/or copied only with the written permission of General Electric Company or in accordance with the terms
     * and conditions stipulated in the agreement/contract under which the software has been supplied.
     */
    describe('$viewportParameterStorage Unit Test, ', function() {

        var viewportParameterStorage;

        function PortObjMock() {

        }

        beforeEach(module('viewportParameterStorage'));

        beforeEach(module(function($provide) {
            $provide.factory('$viewerModelsFactory', function() {
                return {
                    'PortObj' : PortObjMock
                }
            });
        }));

        beforeEach(inject(function($viewportParameterStorage) {
            viewportParameterStorage = $viewportParameterStorage;
        }));

        describe('Init $viewportParameterStorage:', function() {

            /**
             * @ngdoc method
             * @name Init$viewportParameterStorage_Test
             * @methodOf xjtweb-platform.provider:viewportParameterStorageProvider-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.$3DPortContentFactory port3DContentFactory} is created as an object.
             */
            it('$viewportParameterStorage should be a typeof object', function() {
                expect(typeof viewportParameterStorage).to.equal('object');
            });

            /**
             * @ngdoc method
             * @name isViewportParameterObj_ViewportParameterStorageTest
             * @methodOf xjtweb-platform.provider:viewportParameterStorageProvider-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.$viewportParameterStorage $viewportParameterStorage.isViewportParameterObj}
             *              method works properly.
             */
            it('isViewportParameterObj should return true', function() {
                expect(viewportParameterStorage.isViewportParameterObj(new viewportParameterStorage.ViewportParameterObj())).to.equal(true);
            });

            /**
             * @ngdoc method
             * @name InitViewportParameterObjTest1
             * @methodOf xjtweb-platform.provider:viewportParameterStorageProvider-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.type.ViewportParameterObj ViewportParameterObj} is created as an
             *              object.
             */
            it('new $viewportParameterStorage.ViewportParameterObj() should be a typeof object', function() {
                var vpParamObj = new viewportParameterStorage.ViewportParameterObj();
                expect(typeof vpParamObj).to.equal('object');
            });

            /**
             * @ngdoc method
             * @name InitViewportParameterObjTest2
             * @methodOf xjtweb-platform.provider:viewportParameterStorageProvider-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.type.ViewportParameterObj ViewportParameterObj} is created as an
             *              object.
             */
            it('vpParamObj.ports should be a typeof object', function() {
                var vpParamObj = new viewportParameterStorage.ViewportParameterObj();
                expect(typeof vpParamObj.ports).to.equal('object');
            });

            /**
             * @ngdoc method
             * @name InitViewportParameterObjTest3
             * @methodOf xjtweb-platform.provider:viewportParameterStorageProvider-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.type.ViewportParameterObj ViewportParameterObj} is created as an
             *              object.
             */
            it('vpParamObj.ports.length should be 4', function() {
                var vpParamObj = new viewportParameterStorage.ViewportParameterObj();
                vpParamObj.setPorts([ new PortObjMock(), new PortObjMock(), new PortObjMock(), new PortObjMock() ]);
                expect(vpParamObj.ports.length).to.equal(4);
            });

            /**
             * @ngdoc method
             * @name InitViewportParameterObjTest4
             * @methodOf xjtweb-platform.provider:viewportParameterStorageProvider-test
             *
             * @description This test method determines that we can not set more than 16 ports for the ViewportParameterObj.
             */
            it('vpParamObj.ports.length should be 0', function() {
                var vpParamObj = new viewportParameterStorage.ViewportParameterObj();
                expect(vpParamObj.ports.length).to.equal(0);
                // try to set 20 ports
                vpParamObj.setPorts([ new PortObjMock(), new PortObjMock(), new PortObjMock(), new PortObjMock(),
                    new PortObjMock(), new PortObjMock(), new PortObjMock(), new PortObjMock(),
                    new PortObjMock(), new PortObjMock(), new PortObjMock(), new PortObjMock(),
                    new PortObjMock(), new PortObjMock(), new PortObjMock(), new PortObjMock(),
                    new PortObjMock(), new PortObjMock(), new PortObjMock(), new PortObjMock() ]);
                expect(vpParamObj.ports.length).to.equal(0);
            });

            /**
             * @ngdoc method
             * @name setSeriesUid_ViewportParameterObjTest
             * @methodOf xjtweb-platform.provider:viewportParameterStorageProvider-test
             *
             * @description This tests the setSeriesUid method of the
             *              {@link xjtweb-platform.type.ViewportParameterObj ViewportParameterObj} object.
             */
            var uid = '1.2.840.113619.2.144.174778421.4233.1139390915.774';

            it('each port.seriesUid should be equal to' + uid, function() {
                var vpParamObj = new viewportParameterStorage.ViewportParameterObj();
                vpParamObj.setPorts([ new PortObjMock(), new PortObjMock(), new PortObjMock(), new PortObjMock() ]);

                vpParamObj.setSeriesUid(uid);
                vpParamObj.ports.forEach(function(port) {
                    expect(port.seriesUid).to.equal(uid);
                });
            });

            var URL = 'this/is/a/sample/url';

            /**
             * @ngdoc method
             * @name setRenderingUrl_ViewportParameterObjTest
             * @methodOf xjtweb-platform.provider:viewportParameterStorageProvider-test
             *
             * @description This tests the setRenderingUrl method of the
             *              {@link xjtweb-platform.type.ViewportParameterObj ViewportParameterObj} object.
             */
            it('vpParamObj.renderingUrl should be set rendering urls', function() {
                var vpParamObj = new viewportParameterStorage.ViewportParameterObj();
                var mprPort = new PortObjMock();
                mprPort.rendererType = 'MPR';
                var vrPort = new PortObjMock();
                vrPort.rendererType = 'VR';
                vpParamObj.setPorts([ vrPort, mprPort ]);

                var mprUrl = 'this/is/a/sample/mpr/url';
                var vrUrl = 'this/is/a/sample/vr/url';
                vpParamObj.setRenderingUrl(mprUrl, vrUrl);
                vpParamObj.ports.forEach(function(port) {
                    if (port.rendererType === 'MPR') {
                        expect(port.renderingUrl).to.equal(mprUrl);
                    } else if (port.rendererType === 'VR') {
                        expect(port.renderingUrl).to.equal(vrUrl);
                    }

                });
            });

            /**
             * @ngdoc method
             * @name setAnnotationUrl_ViewportParameterObjTest
             * @methodOf xjtweb-platform.provider:viewportParameterStorageProvider-test
             *
             * @description This tests the setAnnotationUrl method of the
             *              {@link xjtweb-platform.type.ViewportParameterObj ViewportParameterObj} object.
             */
            it('vpParamObj.annotationUrl should be equal to' + URL, function() {
                viewportParameterStorage.setAnnotationUrl(URL);
                expect(viewportParameterStorage.getAnnotationUrl()).to.equal(URL);
            });

            it('setRenderingUrls should set rendering urls', function() {
                assert.equal(typeof viewportParameterStorage.setRenderingUrls, 'function');
                assert.equal(typeof viewportParameterStorage.getRenderingUrl, 'function');
                assert.isUndefined(viewportParameterStorage.getRenderingUrl('vr'));
                assert.isUndefined(viewportParameterStorage.getRenderingUrl('mpr'));

                var urls = {
                    'vr': 'this/is/a/sample/vr/url',
                    'mpr': 'this/is/a/sample/mpr/url'
                };
                viewportParameterStorage.setRenderingUrls(urls);

                assert.equal(viewportParameterStorage.getRenderingUrl('vr'), urls.vr);
                assert.equal(viewportParameterStorage.getRenderingUrl('mpr'), urls.mpr);
            });

            it('getGroup returns a group if the id exists', function() {
                var groupId1 = {
                    groupID : 'group_id1'
                };
                var groupId2 = {
                    groupID : 'group_id2'
                };
                viewportParameterStorage.setGroups([ groupId1, groupId2 ]);
                expect(viewportParameterStorage.getGroups()).to.deep.equal([ groupId1, groupId2 ]);
                expect(viewportParameterStorage.getGroup(groupId1.groupID)).to.deep.equal(groupId1);
                expect(viewportParameterStorage.getGroup(groupId2.groupID)).to.deep.equal(groupId2);
            });

            it('getGroup returns undefined if the id does not exist', function() {
                var groupId1 = {
                    groupID : 'group_id1'
                };
                viewportParameterStorage.setGroups([ groupId1 ]);
                expect(viewportParameterStorage.getGroup('group_id2')).to.equal(undefined);
            });

            it('getGroup returns undefined if the groups are not initialized', function() {
                expect(viewportParameterStorage.getGroup('group_id2')).to.equal(undefined);
            });

            it('set2DImageModelControllerUrl, get2DImageModelControllerUrl: ', function() {
                expect(typeof viewportParameterStorage.set2DImageModelControllerUrl).to.equal('function', 'viewportParameterStorage was created without a set2DImageModelControllerUrl function');
                expect(typeof viewportParameterStorage.get2DImageModelControllerUrl).to.equal('function', 'viewportParameterStorage was created without a get2DImageModelControllerUrl function');

                var mockUrl = 'mockImageURL';
                viewportParameterStorage.set2DImageModelControllerUrl(mockUrl);
                expect(viewportParameterStorage.get2DImageModelControllerUrl()).to.equal(mockUrl, 'viewportParameterStorage.get2DImageModelControllerUrl() should have been equal to: ' + mockUrl);
            });

            it('set2DPixelStreamerUrl, get2DPixelStreamerUrl: ', function() {
                expect(typeof viewportParameterStorage.set2DPixelStreamerUrl).to.equal('function', 'viewportParameterStorage was created without a set2DPixelStreamerUrl function');
                expect(typeof viewportParameterStorage.get2DPixelStreamerUrl).to.equal('function', 'viewportParameterStorage was created without a get2DPixelStreamerUrl function');

                var mockUrl = 'mockPixelURL';
                viewportParameterStorage.set2DPixelStreamerUrl(mockUrl);
                expect(viewportParameterStorage.get2DPixelStreamerUrl()).to.equal(mockUrl, 'viewportParameterStorage.get2DPixelStreamerUrl() should have been equal to: ' + mockUrl);
            });

            it('setAnnotationUrl, getAnnotationUrl: ', function() {
                expect(typeof viewportParameterStorage.setAnnotationUrl).to.equal('function', 'viewportParameterStorage was created without a setAnnotationUrl function');
                expect(typeof viewportParameterStorage.getAnnotationUrl).to.equal('function', 'viewportParameterStorage was created without a getAnnotationUrl function');

                var mockUrl = 'mockAnnotationURL';
                viewportParameterStorage.setAnnotationUrl(mockUrl);
                expect(viewportParameterStorage.getAnnotationUrl()).to.equal(mockUrl, 'viewportParameterStorage.getAnnotationUrl() should have been equal to: ' + mockUrl);
            });

            it('getNumberOfPorts should be equal to 16', function() {
                expect(typeof viewportParameterStorage.getNumberOfPorts).to.equal('function', 'viewportParameterStorage was created without a getNumberOfPorts function');
                expect(viewportParameterStorage.getNumberOfPorts()).to.equal(16, 'viewportParameterStorage.getNumberOfPorts() should return 16');
            });

            it('getVolumes returns a saved volumes', function() {
                assert.equal(typeof viewportParameterStorage.setVolumes, 'function');
                assert.equal(typeof viewportParameterStorage.getVolumes, 'function');
                assert.equal(typeof viewportParameterStorage.getVolume, 'function');
                assert.equal(typeof viewportParameterStorage.getVolumes(), 'object');
                assert.equal(viewportParameterStorage.getVolumes().length, 0);

                var vol1 = {groupUid : '1'};
                var vol2 = {groupUid : '2'};
                viewportParameterStorage.setVolumes([vol1, vol2]);

                assert.deepEqual(viewportParameterStorage.getVolumes(), [vol1, vol2]);
                assert.deepEqual(viewportParameterStorage.getVolume('1'), vol1);
                assert.deepEqual(viewportParameterStorage.getVolume('2'), vol2);
                assert.isUndefined(viewportParameterStorage.getVolume('3'));
            });

            it('getPatientInfo returns a saved patient information', function() {
                assert.equal(typeof viewportParameterStorage.setPatientInfo, 'function');
                assert.equal(typeof viewportParameterStorage.getPatientInfo, 'function');
                assert.isNull(viewportParameterStorage.getPatientInfo());

                var patient = {};
                viewportParameterStorage.setPatientInfo(patient);

                assert.isNotNull(viewportParameterStorage.getPatientInfo());
                assert.equal(viewportParameterStorage.getPatientInfo(), patient);
            });

            it('getSaveState returns a save state if the id exists', function() {
                assert.equal(typeof viewportParameterStorage.setSaveStates, 'function');
                assert.equal(typeof viewportParameterStorage.getSaveStates, 'function');
                assert.equal(typeof viewportParameterStorage.getSaveState, 'function');

                var ss1 = {
                    volumes: [{groupUid : 'group_id1'}]
                };
                var ss2 = {
                    volumes: [{groupUid : 'group_id2'}]
                };
                viewportParameterStorage.setSaveStates([ ss1, ss2 ]);
                expect(viewportParameterStorage.getSaveStates()).to.deep.equal([ ss1, ss2 ]);
                expect(viewportParameterStorage.getSaveState('group_id1')).to.deep.equal(ss1);
                expect(viewportParameterStorage.getSaveState('group_id2')).to.deep.equal(ss2);
            });

            it('getSaveState returns undefined if the id does not exist', function() {
                var ss1 = {
                    volumes: [{groupUid : 'group_id1'}]
                };
                viewportParameterStorage.setSaveStates([ ss1 ]);
                expect(viewportParameterStorage.getSaveState('group_id2')).to.equal(undefined);
            });

            it('getSaveState returns undefined if the savestates are not initialized', function() {
                expect(viewportParameterStorage.getSaveState('group_id2')).to.equal(undefined);
            });

            it('getCurrentConfiguration returns current viewer configuration', function() {
                assert.equal(typeof viewportParameterStorage.setCurrentConfiguration, 'function');
                assert.equal(typeof viewportParameterStorage.getCurrentConfiguration, 'function');
                assert.isUndefined(viewportParameterStorage.getCurrentConfiguration());

                var config = {};
                viewportParameterStorage.setCurrentConfiguration(config);

                assert.isNotNull(viewportParameterStorage.getCurrentConfiguration());
                assert.deepEqual(viewportParameterStorage.getCurrentConfiguration(), config);
            });

            it('getStudyInfo returns saved study information', function() {
                assert.equal(typeof viewportParameterStorage.setStudyInfo, 'function');
                assert.equal(typeof viewportParameterStorage.getStudyInfo, 'function');
                assert.isNull(viewportParameterStorage.getStudyInfo());

                var study = {};
                viewportParameterStorage.setStudyInfo(study);

                assert.isNotNull(viewportParameterStorage.getStudyInfo());
                assert.deepEqual(viewportParameterStorage.getStudyInfo(), study);
            });

        });

    });
});
