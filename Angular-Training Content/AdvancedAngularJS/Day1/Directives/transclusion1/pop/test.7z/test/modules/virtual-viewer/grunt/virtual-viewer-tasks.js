/*
 *  virtual-viewer-tasks.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

module.exports = {
    copy:{
	    // Only copies the files specific to a module
        expand: true,
        //cwd: 'public/',
        dest: 'bin/',
        src: ['shell/*']
    },
    compress:{
        options: {
            archive: function () {
                return 'bin/virtual-viewer.zip';
            }
        },
		files: [{ expand: true, src: ['public/modules/virtual-viewer/*'] }]
    },
    karma:{
    	configFile: 'test/modules/virtual-viewer/karma.conf.js'
    },
    shell: {
        command: 'pwd && cd test/modules/virtual-viewer && pwd && mkdir -pv report/junit/test-report && java -jar /workspace/pfhtools_dev/sonar-karma-junit-parser1.0.0/parser.jar ./ report/junit/TESTS-xunit.xml report/junit/test-report test.js'
    }
};