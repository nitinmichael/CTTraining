/*
 * ge-dot-dot-dot-filter-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */

define([ 'angular', 'angular-mocks', 'lodash', 'modules/platform/filters/ge-dot-dot-dot-filter' ], function() {
    describe('Dot Dot Dot filter tests', function() {
        var dotDotDotFilter;

        beforeEach(module('platform.filter.ge-dot-dot-dot-filter'));
        beforeEach(inject(function(_$filter_) {
            dotDotDotFilter = _$filter_('geDotDotDot');
        }));

        it("should have a filter defined", function() {
            assert.isDefined(dotDotDotFilter, 'filter is not defined');
        });

        it("should return the original string if its length is not greater than the limit", function() {
            var string = 'existing string', result = dotDotDotFilter(string, 20);
            expect(result).to.be.equal(string);
        });

        it("should return the original string if its length is not greater than the limit", function() {
            var string = 'existing string', result = dotDotDotFilter(string, 10);
            var expected = 'existing s...';

            expect(result).to.be.equal(expected);
        });

        it("should return empty string if the input is empty string", function() {
            var string = '', result = dotDotDotFilter(string, 10);

            expect(result).to.be.equal(string);
        });

    });
});
