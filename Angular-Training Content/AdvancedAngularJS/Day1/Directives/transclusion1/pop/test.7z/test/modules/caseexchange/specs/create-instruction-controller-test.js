/*
 * create-instruction-controller-test.js
 * 
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 * 
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 * 
 * @author: Raoul Nair<raoul.nair@ge.com>
 */

define([ 'angular',
         'angular-mocks',
         'case-automation/module',
         'case-automation/controllers/create-instruction-controller',
         'mocks/fake-server',
         'mocks/case-exchange-mock-service'], function() {
    'use strict';

    var rootScope, scope, controller, caseExchangeDataService, caseAutomationDataService, getSelectedStub, postProcessingConditionMarshallerService, $mockServerLoader, mockServer, usersJSON,
        clinicalReasons, clinicalReasonsService,state, caseAutomationService, formInstCondition, instructionConditionJson, conditionKeyList, 
        conditionTypeList, conditionBooleanList, postCondition, filter;
    var MODES = {
            create: 'AUTOCREATE'
        };

    var site = {"title":null,"id":"0f1da138-563b-4d9a-8353-7c6710b604a8","content":{"name":"Site Legal Name"}};

    var instCondition = [{"boolean":"","key":"","type":"","value":""}]

    describe('Create Instruction Controller Test Suite::', function() {

        beforeEach(function () {
            
            // Load the module for the mock data first
            module('cloudav.caseExchange.mocks');
            // Load the Sinon fake server.
            module('cloudav.caseExchange.fakeServer');

            //Load state
            module('cloudav.caseExchange.createInstructionCtrl', function ($provide) {
                $provide.value('$state', {
                    transitionTo: function (url) {
                    },
                    current: {
                        params: {
                            mode: MODES.create
                        }
                    }
                });

                $provide.value('$stateParams', {
                    id: function () {
                    }
                });

                $provide.factory('configurationService', ['$q', function ($q) {
                    return {
                        getProperty: function () {
                            return $q.when({});
                        }
                    }
                }]);

            });
        });

        function fakeCaseListResolved(value) {
            return {
                promise : {
                    then : function(callback) {
                        callback("");
                    }
                }
            }
        }

        // Initialize the scope and controller variables
        beforeEach(inject(function($rootScope, $controller, $state, _CaseExchangeDataService_, _CaseAutomationDataService_, _PostProcessingConditionMarshallerService_, $MockServerLoader, CaseExchangeMocks, ClinicalReasonsService, CaseAutomationService, $filter) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            controller = $controller;
            state = $state;

            // Initialize the controller before each specs
            controller('CreateInstructionCtrl', {
                $scope : scope
            });

            caseExchangeDataService = _CaseExchangeDataService_;
            caseAutomationDataService = _CaseAutomationDataService_;
            postProcessingConditionMarshallerService = _PostProcessingConditionMarshallerService_;
            usersJSON = CaseExchangeMocks.getToUser();
            clinicalReasons = CaseExchangeMocks.getClinicalReasons();
            caseAutomationService=CaseAutomationService;
            formInstCondition = CaseExchangeMocks.getFromConditionInstJson();
            instructionConditionJson = CaseExchangeMocks.getInstructionConditionJson();
            conditionKeyList = CaseExchangeMocks.getConditionKeyList();
            conditionTypeList = CaseExchangeMocks.getConditionTypeList();
            conditionBooleanList = CaseExchangeMocks.getConditionBooleanList();
            filter=$filter;
            postCondition = CaseExchangeMocks.getPostCondition();

            getSelectedStub = sinon.stub(caseAutomationDataService, "getSelectedSite", function () { return site; });

            $mockServerLoader = $MockServerLoader;

            // Call the init to initialize the Sinon Mock Data Server.
            mockServer = $mockServerLoader.init();
            
            // Mocking the variable from parent controller as we don't have inheritance in place in unit testing.
            scope.alertTypes = {
                success: 'success',
                error: 'error'
            };

            // Mocking the method from parent controller as we don't have inheritance in place in unit testing.
            scope.showAlertMessage = function () {
            };

        }));

        it('should have a controller', function() {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it('should have a "clinicalReasons" array object', function () {
            assert.isDefined(scope.clinicalReasons, 'Controller scope doesn\'t have "clinicalReasons" array object defined');
        });

        it('should call createInstruction() method and validate for invalid instruction name field', function() {
            scope.autoCreate = {};
            scope.autoCreate.instructionName = "  ";
            scope.autoCreate.siteName = "  ";
            scope.addedRecipients.push(usersJSON.entry[0]);
            scope.autoCreate.postCondition = postCondition;
            scope.submitInstruction('AUTOCREATE');
            expect(scope.addedRecipients.length).to.equal(1);
        });

        it('should call createInstruction() method and validate for invalid instruction name and addedRecipent fields', function() {
            scope.autoCreate = {};
            scope.autoCreate.siteName = "  ";
            scope.addedRecipients = [];
            scope.autoCreate.postCondition = {
                "algorithm": "Algorithm 1",
                "modality": "MR",
                "description": "description"
            };
            scope.submitInstruction('AUTOCREATE');
            expect(scope.addedRecipients.length).to.equal(0);
        });

        it('should set modality', function() {
            scope.setModality(false);
            expect(scope.autoCreate.postCondition.modality).to.equal('');
        });

        it('should have a method "removePostProcessingCondition()" defined', function() {
            scope.removePostProcessingCondition()
            expect(scope.autoCreate.postCondition.modality).to.equal('');
        });

        it('should call not createInstruction() method as mode = AUTOUPDATE', function() {
            scope.autoCreate = {};
            scope.autoCreate.postCondition = {
                "algorithm": "Algorithm 1",
                "modality": "MR",
                "description": "description"
            };
            scope.submitInstruction('AUTOUPDATE');
            expect(scope.noImpressionAdded).to.be.false;
        });

        it('should not call createInstruction() method when recepient, clinical reasons and impression is empty and null respectively', function() {
            scope.autoCreate = {};
            scope.addedRecipients = [];
            scope.autoCreate.clinicalReason = {};
            scope.autoCreate.siteName = "  ";
            scope.autoCreate.impression = null;
            scope.autoCreate.postCondition = {
                "algorithm": "Algorithm 1",
                "modality": "MR",
                "description": "description"
            };
            scope.submitInstruction('AUTOCREATE');
            expect(scope.addedRecipients.length).to.equal(0);
            expect(scope.noImpressionAdded).to.be.true;
        });

        it('should not call createInstruction() method when impression is empty', function() {
            scope.autoCreate = {};
            scope.addedRecipients = [];
            scope.autoCreate.siteName = "  ";
            scope.autoCreate.impression = "";
            scope.autoCreate.postCondition = {
                "algorithm": "Algorithm 1",
                "modality": "MR",
                "description": "description"
            };
            scope.submitInstruction('AUTOCREATE');
            expect(scope.noImpressionAdded).to.be.true;
        });

        it('should not call createInstruction() method when impression.length >= 200', function() {
            scope.autoCreate = {};
            scope.addedRecipients = [];
            scope.autoCreate.impression = "";
            scope.autoCreate.siteName = "  ";
            scope.autoCreate.impression.length = 250;
            scope.autoCreate.postCondition = {
                "algorithm": "Algorithm 1",
                "modality": "MR",
                "description": "description"
            };
            scope.submitInstruction('AUTOCREATE');
            expect(scope.noImpressionAdded).to.be.true;
        });

        it('should test empty other clinical reason', function() {
            scope.autoCreate = {};
            scope.addedRecipients = [];
            scope.autoCreate.clinicalReason = clinicalReasons[8];
            scope.autoCreate.otherClinicalReason = "  ";
            scope.autoCreate.siteName = "  ";
            scope.autoCreate.impression = null;
            scope.autoCreate.postCondition = {
                "algorithm": "Algorithm 1",
                "modality": "MR",
                "description": "description"
            };
            scope.submitInstruction('AUTOCREATE');
            expect(scope.addedRecipients.length).to.equal(0);
            expect(scope.noImpressionAdded).to.be.true;
        });

        it('should test unique other clinical reason', function() {
            scope.autoCreate = {};
            scope.addedRecipients = [];
            scope.clinicalReasons = clinicalReasons;
            scope.autoCreate.clinicalReason = clinicalReasons[8];
            scope.autoCreate.otherClinicalReason = "Collaboration";
            scope.autoCreate.siteName = "  ";
            scope.autoCreate.impression = null;
            scope.autoCreate.postCondition = {
                "algorithm": "Algorithm 1",
                "modality": "MR",
                "description": "description"
            };
            scope.submitInstruction('AUTOCREATE');
            expect(scope.uniqueOtherClinicalReason).to.be.true;
        });

        it('should call createInstruction() method when all validations succed', function() {
            var stateSpy = sinon.spy(state, "transitionTo");
            sinon.stub(caseAutomationService, "caseInstructionCurdOperation", function () { return fakeCaseListResolved(); });
            scope.autoCreate = {};
            scope.autoCreate.instructionName = "Instruction Name1";
            scope.autoCreate.site = site;
            scope.autoCreate.siteName = "Test Site";
            scope.addedRecipients.push(usersJSON.entry[0]);
            scope.clinicalReasons = clinicalReasons;
            scope.autoCreate.clinicalReason = clinicalReasons[8];
            scope.autoCreate.otherClinicalReason = "Test Other Clinical Reasons";
            scope.autoCreate.impression= "Test Data";
            scope.autoCreate.instCondition = formInstCondition;
            scope.autoCreate.postCondition = {
                "algorithm": "Algorithm 1",
                "modality": "MR",
                "description": "description"
            };
            scope.autoCreate.postCondition.description ="description";
            scope.submitInstruction('AUTOCREATE');
            expect(scope.addedRecipients.length).to.equal(1);
            expect(scope.noImpressionAdded).to.be.false;
            expect(scope.invalidDescription).to.be.false;
        });

        it('should validate all invalid condition for modality when validateInstructionCondition() is called with invalid condition data', function() {
            scope.autoCreate = {};
            scope.autoCreate.instCondition =formInstCondition;
            scope.autoCreate.instCondition[1].boolean=null;
            scope.autoCreate.instCondition[0].value="invalid modalidty";
            scope.validateInstructionCondition();
            expect(scope.autoCreate.instCondition[0].errormsg).to.equal(filter('translate')('createInstruction.conditionModalityInvalidDicomVal'));
            
            scope.autoCreate.instCondition[0].value="";
            scope.validateInstructionCondition();
            expect(scope.autoCreate.instCondition[0].errormsg).to.equal(filter('translate')('createInstruction.conditionModalityCommaSepratedError'));
            
            scope.autoCreate.instCondition[0].value="CT*";
            scope.validateInstructionCondition();
            expect(scope.autoCreate.instCondition[0].errormsg).to.equal(filter('translate')('createInstruction.conditionSpecialCharError'));
            
            scope.autoCreate.instCondition[0].value="CT,";
            scope.validateInstructionCondition();
            expect(scope.autoCreate.instCondition[0].errormsg).to.equal(filter('translate')('createInstruction.conditionModalityCommaSepratedError'));
        });

        it('should validate all invalid condition for name criteria when validateInstructionCondition() is called with invalid condition data', function() {
            scope.autoCreate = {};
            scope.autoCreate.instCondition =formInstCondition;
            scope.autoCreate.instCondition[1].value="firstname,";
            scope.validateInstructionCondition();
            expect(scope.autoCreate.instCondition[1].errormsg).to.equal(filter('translate')('createInstruction.conditionNameCommaSepratedError'));
            
            scope.autoCreate.instCondition[1].value="firstname,firstname,firstname,firstname,";
            scope.validateInstructionCondition();
            expect(scope.autoCreate.instCondition[1].errormsg).to.equal(filter('translate')('createInstruction.conditionNameCommaSepratedError'));
            
            scope.autoCreate.instCondition[1].value="asdsamasdmsamdasasdsamasdmsamdasasdsamasdmsamdasasdsamasdmsamdasasdsamasdmsamdasasdsamasdmsamdas";
            scope.validateInstructionCondition();
            expect(scope.autoCreate.instCondition[1].errormsg).to.equal(filter('translate')('createInstruction.conditionNameMaxLengthError'));

            scope.autoCreate.instCondition[1].value="";
            scope.validateInstructionCondition();
            expect(scope.autoCreate.instCondition[1].errormsg).to.equal(filter('translate')('createInstruction.conditionNameCommaSepratedError'));
        });

        it('should call validateInstOnDicomAttr() and assign maxlength', function() {
            scope.autoCreate = {};
            scope.autoCreate.instCondition =formInstCondition;
            scope.validateInstOnDicomAttr(scope.autoCreate.instCondition[1].key,1);
            expect(scope.autoCreate.instCondition[1].maxlength).to.equal('200');
            
            scope.validateInstOnDicomAttr(scope.autoCreate.instCondition[0].key,0);
            expect(scope.autoCreate.instCondition[0].maxlength).to.equal('');
            
            scope.validateInstOnDicomAttr(null,0);
            expect(scope.autoCreate.instCondition[0].maxlength).to.equal('');
        });

        it('should call validatePostConditionDescription and check invalidDescription', function() {
            scope.autoCreate.postCondition.description = '?';
            scope.validatePostConditionDescription();
            expect(scope.invalidDescription).to.be.true;
            scope.autoCreate.postCondition.description = 'asdsamasdmsamdasasdsamasdmsamdasasdsamasdmsamdasasdsamasdmsamdasasdsamasdmsamdasasdsamasdmsamdas';
            scope.validatePostConditionDescription();
            expect(scope.invalidDescription).to.be.true;
        });

        it('should call validatePostCondition and check missing Description and invalid Algorithm', function() {
            scope.autoCreate.postCondition.description = '';
            scope.autoCreate.postCondition.modality = 'MR';
            scope.validatePostCondition();
            expect(scope.missingDescription).to.be.true;
            expect(scope.invalidAlgo).to.be.false;
            scope.autoCreate.postCondition.description = 'asdf';
            scope.autoCreate.postCondition.modality = '';
            scope.validatePostCondition();
            expect(scope.missingDescription).to.be.false;
            expect(scope.invalidAlgo).to.be.true;
        });

        it('should call addCondition() method add one more instruction', function() {
            scope.addCondition();
            expect(scope.autoCreate.instCondition.length).to.equal(2);
        });

        it('should call removeCondition() method remove one instruction', function() {
            scope.autoCreate.instCondition=[{"boolean":"","key":"","type":"","value":"","$$hashKey":"object:608"},{"boolean":"","key":"","type":"","value":"","$$hashKey":"object:640"}];
            var condition = scope.autoCreate.instCondition[0];
            scope.removeCondition(condition);
            expect(scope.autoCreate.instCondition.length).to.equal(1);
        });

        it('should call addCondition() and should allow to add more instruction if already three instruction are added', function() {
            scope.autoCreate.instCondition=[{},{},{}];
            scope.addCondition();
            expect(scope.autoCreate.instCondition.length).to.equal(3);
        });

        it('should call removeCondition() and should not allow to remove instruction if only one instruction are present', function() {
            scope.autoCreate.instCondition=[{}];
            var condition = scope.autoCreate.instCondition[0];
            scope.removeCondition(condition);
            expect(scope.autoCreate.instCondition.length).to.equal(1);
        });

        it('should call removeCondition() and should not allow to remove instruction if only more than one instruction are present', function() {
            scope.autoCreate.instCondition=[{},{}];
            var condition = scope.autoCreate.instCondition;
            scope.removeCondition(condition);
            expect(scope.autoCreate.instCondition.length).to.equal(2);
        });

        it('should have a "cancelButton" function', function () {
            var stateSpy = sinon.spy(state, "transitionTo");
            scope.cancelButton();
            assert(stateSpy.calledWith('caseexchange.caseautomation'));
        });

        // Use Sinon to replace jQuery's ajax method with a spy.
        beforeEach(function () {
            sinon.stub($, 'ajax').yieldsTo('success', {});
        });

        // Restore jQuery's ajax method to its original state
        afterEach(function () {
            $.ajax.restore();
        });

        it('should populate Clinical Reasons dropdown by making an API call', function () {
            beforeEach(function(){
                $mockServerLoader.fakeClinicalReasonsCall(200, clinicalReasons);

                mockServer.respond();
                rootScope.$apply();
            });

            scope.clinicalReasons = clinicalReasons;

            expect(scope.clinicalReasons.length).to.equal(9);
        });

    });
});