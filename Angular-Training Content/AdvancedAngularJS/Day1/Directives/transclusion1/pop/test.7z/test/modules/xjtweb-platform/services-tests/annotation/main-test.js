define([ 'angular-mocks', 'modules/xjtweb-platform/services/annotation/main' ], function() {
    describe('annotationServices main entry point tests', function() {
        var injector;

        beforeEach(module('xjtweb.platform.service.annotation'));
        beforeEach(module(function($provide) {

            var $xjtweb = {
                XJResource : {}
            };

            $provide.value('$xjtweb', $xjtweb);

        }));

        beforeEach(inject(function($injector) {
            injector = $injector;
        }));

        it('defines the annotation-related services', function() {
            injector.has('annotationCacheFactory').should.equal(true);
            injector.has('annotationService').should.equal(true);
            injector.has('annotationUIService').should.equal(true);
        })
    });
});