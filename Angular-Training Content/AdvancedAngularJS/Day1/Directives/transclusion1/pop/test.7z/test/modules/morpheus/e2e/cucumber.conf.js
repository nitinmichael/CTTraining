/*
 * Configuration file for Protractor/Cucumber based BDD testing
 */
exports.config = {
    seleniumAddress: 'http://localhost:4444/wd/hub',    // Local Web Driver, started by 'webdriver-manager start' command
    baseUrl: 'http://localhost:3000', // Base URL when running locally, started by 'node server.js' command
    framework: 'cucumber',

    specs: ['file-upload.feature'],
  
    cucumberOpts: {
        require: 'file-upload-steps.js',
	    format: 'pretty'
    },
  
    capabilities: {
        'browserName': 'chrome'
    },
  
    onPrepare: function () {
	    // Umplicit and page load timeouts
	    browser.manage().timeouts().pageLoadTimeout(40000);
	    browser.manage().timeouts().implicitlyWait(25000);

	    // For non-angular page
	    browser.ignoreSynchronization = false;
    }
};