/*
 *  toolbar-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *   Emna Turki <emna.turky@ge.com>
 */

/**
 * Spec file for Viewer > modules > mousemanagement > widgets > toolbar directive
 */

define(['angular', 'angular-mocks', 'jquery','mousemanagementModule/module',
        'mousemanagementModule/widgets/toolbar'],
    function () {
        'use strict';

        describe('toolbar Directive Test :', function () {
            var element, scope, isolatedScope;

            beforeEach(module('templates'));
            beforeEach(module('cloudav.viewerApp.mousemanagement'));

            beforeEach(module(function($provide) {
                $provide.service('translateFilter', function () {

                });
            }));

            beforeEach(
                inject(function ($compile, $rootScope) {
                    element = angular.element('<toolbar><div id="viewPortContainer"></div></toolbar>');
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$digest();
                    isolatedScope = element.isolateScope();
                })
            );

            it('should have a directive', function () {
                assert.isDefined(element, 'toolbar Directive is not defined');
            });

            it('should have an isolated scope', function () {
                assert.isDefined(isolatedScope, 'toolbar Directive does not have an isolated scope');
            });

            it('should have a toolClick function', function () {
                expect(typeof(isolatedScope.toolClick)).to.be.equal('function');

                isolatedScope.mouseModeContainer = 'viewPortContainer';
                isolatedScope.mouseMode = '';
                isolatedScope.toolClick('ZOOM');
                expect(isolatedScope.mouseMode).to.be.equal('ZOOM');

            });

            it('should have a itemClicked function', function () {
                expect(typeof(isolatedScope.itemClicked)).to.be.equal('function');

                isolatedScope.selectedIndex = 0;
                isolatedScope.itemClicked(1);
                expect(isolatedScope.selectedIndex).to.be.equal(1);
            });
        });
    });
