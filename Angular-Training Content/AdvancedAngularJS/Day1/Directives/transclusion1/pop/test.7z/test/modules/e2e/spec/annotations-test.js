describe('CloudAV annotations tests', function() {

    var openStartPage = function() {
        browser.get(browser.baseUrl);

        // since we use RequireJS + manual Angular bootstrap, we have to wait until the HTML is compiled:
        browser.driver.wait(function() {
            return browser.driver.isElementPresent(by.css('.ng-scope'));
        }, 50000);

    }

    var openCaseInbox = function() {
        // find caseInbox on start page
        element(by.xpath("//div[@name='caseInbox']")).click();

        // we have to click the item for two times
        element(by.xpath("//div[@name='caseInbox']")).click();
    }

    var clickOnCase = function(caseTooltipPart) {
        var tooltipSearch = "//div[contains(@tooltip,'" + caseTooltipPart + "')]";
        element(by.xpath(tooltipSearch)).click();
    }

    var clickOnAttachment = function() {
        var attachmentSearch = "//div[contains(@class,'attachment-container-enabled')]/div";
        element(by.xpath(attachmentSearch)).click();
    }

    it('should have a title', function() {
        openStartPage();
        expect(browser.getTitle()).toEqual('GE Health Cloud');
    });

    it('displays 3d annotations', function() {
        openStartPage();

        openCaseInbox();

        clickOnCase('MR450');

        clickOnAttachment();

        var annotationsSearch = "//*[contains(@class,'svg-canvas')]//*[contains(@class,'static-annotation') and not(contains(@class,'annot_hidden'))]";
        var visibleStaticAnnotations = element.all(by.xpath(annotationsSearch));

        expect(visibleStaticAnnotations.count()).toBeGreaterThan(0);

        // browser.driver.sleep(7000);
    });

    it('displays 2d annotations', function() {
        openStartPage();
        
        openCaseInbox();
        
        clickOnCase('Invenia ABUS 047');
        
        clickOnAttachment();
        
        var annotationsSearch = "//*[contains(@class,'svg-canvas')]//*[contains(@class,'static-annotation') and not(contains(@class,'annot_hidden'))]";
        var visibleStaticAnnotations = element.all(by.xpath(annotationsSearch));
        
        expect(visibleStaticAnnotations.count()).toBeGreaterThan(0);
        
        // browser.driver.sleep(7000);
    });
});