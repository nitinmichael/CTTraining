/*
 * my-mdt-data-service-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular', 'angular-mocks', 'mdt/modules/my-mdt/services/my-mdt-data-service'], function () {
    'use strict';

    describe("MyMdtDataService", function () {
        var MyMdtDataService, $httpBackend, rootScope, successFn;
        var ROOT_URL = 'http://localhost:8080';
        var CASE_SERVICE_URL = 'http://caseservice.ge.com';

        beforeEach(function () {
            angular.module('Services.caseExchangeDataService', []);

            module('Services.caseExchangeDataService', function($provide) {
                $provide.value('CaseExchangeDataService', {
                    getServiceURL: function() {
                        return CASE_SERVICE_URL;
                    },
                    setServiceURL: sinon.stub()
                });
            });

            module('cloudav.mdt.myMdt.services', function ($provide) {
                // add a mock $Endpoint provider - it will return ROOT_URL for any endpoint)
                $provide.value('$Endpoint', {
                    getEndpointAsync: function(query){
                        return {
                            then: function(success){

                                if(query === 'apiGatewayUrl'){
                                    var caseReaderUrl = success(CASE_SERVICE_URL);
                                    return {
                                        then: function(fn2){
                                            return fn2(caseReaderUrl);
                                        }
                                    }
                                }else{
                                    var publicAPI = success(ROOT_URL);
                                    return {
                                        then: function(fn){
                                            fn(publicAPI);
                                        }
                                    };
                                }
                            }
                        };
                    }
                });
            });

            inject(function (_MyMdtDataService_, _$httpBackend_, $rootScope) {
                $httpBackend = _$httpBackend_;
                MyMdtDataService = _MyMdtDataService_;
                rootScope = $rootScope;
            });
        });

            it("should call case headers list service", function () {
                $httpBackend.expectGET(ROOT_URL + '/views/mdt-inbox/case-exchange-proxy/v1/case?inboxtype=ALL&offset=0&limit=20&casetype=MDT').respond({name: 'test case'});
                MyMdtDataService.then(function(service) {
                    service.getCaseHeaders()
                        .success(function (data) {
                            expect(data.name).to.equal('test case');
                        })
                        .error(function () {
                            expect(true).to.be.false;
                        });
                });

                //expect(successFn).to.be.defined;
                //successFn();

                $httpBackend.flush();
            });

            it("..", function() {
                var caseId = 'abc123';
                $httpBackend.expectGET(CASE_SERVICE_URL + '/casereader/v1/case/' + caseId).respond({name: 'test case'});
                MyMdtDataService.then(function(service) {
                    service.getCase(caseId)
                        .then(function (data) {
                            expect(data.name).to.equal('test case');
                        },function () {
                            expect(true).to.be.false;
                        })
                });
                $httpBackend.flush();
            });

            afterEach(function () {
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

});
