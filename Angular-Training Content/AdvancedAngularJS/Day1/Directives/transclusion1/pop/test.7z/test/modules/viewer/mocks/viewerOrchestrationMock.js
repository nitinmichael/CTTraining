define(['viewerMockModule'], function(viewerMockModule) {
    return viewerMockModule.constant('viewerOrchestrationMock', function() {

        var group1 = {
                'groupID': '42528008526491525871317_1.2.840.113619.2.248.90584897991.8396.1348491360172.2_1.2.840.113619.2.248.90584897991.8396.1348491360172.3_1108083489',
                'description': 'Ax FSPGR 3D IR',
                'spaceID': '25300391958837055805250',
                'seriesUID': '1.2.840.113619.2.248.90584897991.8396.1348491360172.3',
                'instanceUIDs': []
            },
            group2 = {
                'groupID': '42528008526491525871317_1.2.840.113619.2.248.90584897991.8396.1348491360172.2_1.2.840.113619.2.248.90584897991.8396.1348491360172.3_1108083489',
                'description': '3D Saved State -  fery-vs4-vr',
                'spaceID': '25300391958837055805250',
                'seriesUID': '1.2.840.113619.2.248.90587482924.17180.1315478946084.6',
                'instanceUIDs': [
                    '1.2.840.113619.2.80.978640499.27815.1433850825.2'
                ]
            },
            groups = {
                data: {
                    'imageSetList': [group1, group2],
                    'studies': {
                        '1.2.840.113619.2.248.90584897991.8396.1348491360172.2': {
                            'date': '2003-11-27',
                            'description': 'CTA 83 A',
                            'instanceUID': '1.2.840.113619.2.248.90584897991.8396.1348491360172.2'
                        }
                    }
                }
            };

        groups.data.groups = {};
        groups.data.groups[group1.groupID] = group1;
        groups.data.groups[group2.groupID] = group2;

        var volumeInfo = {
            'slices': [{
                'sliceUID': '1.2.840.113619.2.248.90587482924.17180.1315478947138.279',
                'objectStoreURL': 'http://p-riakcs2.grc-apps.svc.ice.ge.com/service-instance-1f0e6f89-29c6-4b22-8369-fdf82cda4cf7/stubBucket/1.2.840.113619.2.248.90587482924.17180.1315478947138.279',
                'cacheURL': '669323ce-3aac-4ded-bfcd-b03f0978334c',
                'pixelSpacing': 0.4883,
                'intercept': 0,
                'slope': 0,
                'dirX': [-1,
                    0,
                    0
                ],
                'dirY': [
                    0, -1,
                    0
                ],
                'origin': [
                    120.237,
                    144.832,
                    70.9289
                ]
            }, {
                'sliceUID': '1.2.840.113619.2.248.90587482924.17180.1315478947135.278',
                'objectStoreURL': 'http://p-riakcs2.grc-apps.svc.ice.ge.com/service-instance-1f0e6f89-29c6-4b22-8369-fdf82cda4cf7/stubBucket/1.2.840.113619.2.248.90587482924.17180.1315478947135.278',
                'cacheURL': '1273a1d9-ac94-4a88-a54e-1def38f41e91',
                'pixelSpacing': 0.4883,
                'intercept': 0,
                'slope': 0,
                'dirX': [-1,
                    0,
                    0
                ],
                'dirY': [
                    0, -1,
                    0
                ],
                'origin': [
                    120.237,
                    144.832,
                    70.3289
                ]
            }, ],
            'studyModel': {
                'studySOPInstanceUID': '1.2.840.113619.2.248.90587482924.17180.1315478946084.5',
                'studyDate': '_',
                'studyDescription': '_'
            },
            'patientModel': {
                'patientBirthDate': '78',
                'patientName': '000Y',
                'patientSex': '_',
                'patientID': 'AW1885099666.36.1315478946'
            },
            'seriesModel': {
                'seriesSOPInstanceUID': '1.2.840.113619.2.248.90587482924.17180.1315478946084.6',
                'modality': 'MR',
                'seriesSOPclassUID': '1.2.840.10008.5.1.4.1.1.4',
                'seriesDescription': 'Ax FSPGR 3D IR'
            },
            'groupUid': '1.2.840.113619.2.248.90587482924.17180.1315478946084.6',
            'dimensions': [
                512,
                512,
                272
            ],
            'resampledOrigin': [
                120.237,
                144.832,
                70.9289
            ],
            'resampledDirX': [-1,
                0,
                0
            ],
            'resampledDirY': [
                0, -1,
                0
            ],
            'defaultWindowLevel': 6220,
            'defaultWindowWidth': 12441,
            'resampledSliceSpacing': 0.5999999999999943
        };

        var saveState = {
            'correlationID': '3be64f80-a47f-444d-810e-a27ed8665ec8',
            'senderID': 'SaveStateController UUID',
            'body': {
                'version': '0.0',
                'volumes': [{
                    'spaceid': '25300391958837055805250',
                    'seriesUid': '1.2.840.113619.2.144.174778421.4233.1139390915.774',
                    'imageUids': []
                }],
                'viewports': [{
                    'type': 'Oblique',
                    'fov': 987.903992,
                    'ww': 400,
                    'wl': 40,
                    'volumeIndex': 0,
                    'orientation': [
                        0.886117,
                        0,
                        0.463461, -0.080663,
                        0.984738,
                        0.154224, -0.456388, -0.174044,
                        0.872593
                    ]
                }, {
                    'type': 'Axial',
                    'fov': 130,
                    'ww': 400,
                    'wl': 40,
                    'volumeIndex': 0
                }, {
                    'type': 'Sagittal',
                    'fov': 987.903992,
                    'ww': 400,
                    'wl': 40,
                    'volumeIndex': 0
                }, {
                    'type': 'Coronal',
                    'fov': 987.903992,
                    'ww': 400,
                    'wl': 40,
                    'volumeIndex': 0
                }],
                'measurements': []
            },
            'header': {}
        };

        return {
            getGroups: function() {
                return {
                    then: function(fn) {
                        fn(groups);
                    }
                };
            },
            getVolumeInfo: function() {
                return {
                    then: function(fn) {
                        fn(volumeInfo);
                        return {
                            catch: function(cb) {
                                cb({
                                    config: {
                                        url: ''
                                    }
                                });
                            }
                        };
                    }
                };
            },
            getSaveState: function() {
                return {
                    then: function(fn) {
                        fn(saveState);
                    }
                };
            }
        };
    });
});
