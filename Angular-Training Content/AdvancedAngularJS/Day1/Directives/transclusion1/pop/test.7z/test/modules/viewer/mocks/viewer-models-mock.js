define(['angular'], function(angular) {
    'use strict';

    angular.module('viewerModels', []).provider('$viewerModelsFactory', function() {
        this.$get = [function() {

            return {

                'Group': function(config) {
                    this.date = (typeof config.date === 'string' ? config.date : null);
                    this.description = (typeof config.description === 'string' ? config.description : null);
                    this.groupID = (typeof config.groupID === 'string' ? config.groupID : null);
                    this.imageType = (typeof config.imageType === 'string' ? config.imageType : null);
                    this.modality = (typeof config.modality === 'string' ? config.modality : null);
                    this.saveState = (typeof config.saveState === 'boolean' ? config.saveState : false);
                    this.secondaryCapture = (typeof config.secondaryCapture === 'boolean' ? config.secondaryCapture : false);
                    this.seriesUID = (typeof config.seriesUID === 'string' ? config.seriesUID : null);
                    this.spaceID = (typeof config.spaceID === 'string' ? config.spaceID : null);
                    this.studyUID = (typeof config.studyUID === 'string' ? config.studyUID : null);
                    this.firstInstanceUID = (typeof config.instanceUIDs === 'object' ? config.instanceUIDs[0] : null);
                    this.nbImages = (typeof config.instanceUIDs === 'object' ? config.instanceUIDs.length : 0);
                    this.pixelSpacing = (typeof config.pixelSpacing === 'object' ? config.pixelSpacing : null);
                },

                'Volume': function(config) {
                    this.defaultWindowLevel = (typeof config.defaultWindowLevel === 'number' ? config.defaultWindowLevel : null);
                    this.defaultWindowWidth = (typeof config.defaultWindowWidth === 'number' ? config.defaultWindowWidth : null);
                    this.dimensions = (typeof config.dimensions === 'object' ? config.dimensions : null);
                    this.groupUid = (typeof config.groupUid === 'string' ? config.groupUid : null);
                    this.resampledDirX = (typeof config.resampledDirX === 'object' ? config.resampledDirX : null);
                    this.resampledDirY = (typeof config.resampledDirY === 'object' ? config.resampledDirY : null);
                    this.resampledOrigin = (typeof config.resampledOrigin === 'object' ? config.resampledOrigin : null);
                    this.resampledSliceSpacing = (typeof config.resampledSliceSpacing === 'number' ? config.resampledSliceSpacing : null);
                    this.slicesNumber = (typeof config.slices === 'object' ? config.slices.length : null);
                    this.pixelSpacing = (typeof config.slices === 'object' ? config.slices[0].pixelSpacing : null);
                    this.intercept = (typeof config.slices === 'object' ? config.slices[0].intercept : null);
                    this.slope = (typeof config.slices === 'object' ? config.slices[0].slope : null);
                    this.modality = (typeof config.seriesModel === 'object' ? config.seriesModel.modality : null);
                },

                'Study': function(config) {
                    this.studyDate = (typeof config.date === 'string' ? config.date : null);
                    this.studyDescription = (typeof config.description === 'string' ? config.description : null);
                    this.studyID = (typeof config.instanceUID === 'string' ? config.instanceUID : null);
                },

                'Series': function(config) {
                    this.seriesSOPInstanceUID = (typeof config.seriesSOPInstanceUID === 'string' ? config.seriesSOPInstanceUID : null);
                    this.modality = (typeof config.modality === 'string' ? config.modality : null);
                    this.seriesSOPclassUID = (typeof config.seriesSOPclassUID === 'string' ? config.seriesSOPclassUID : null);
                    this.seriesDescription = (typeof config.seriesDescription === 'string' ? config.seriesDescription : null);
                },

                'Patient': function(config) {
                    this.title = (typeof config.title === 'string' ? config.title : null);
                    this.dob = (typeof config.birthDate === 'string' ? config.birthDate : null);
                    this.age = (typeof config.age === 'string' ? config.age : null);
                    this.name = (typeof config.name === 'string' ? config.name : null);
                    this.gender = (typeof config.sex === 'string' ? config.sex : null);
                    this.id = (typeof config.id === 'string' ? config.id : null);
                },

                'SaveState': function(config) {
                    this.correlationID = (typeof config.correlationID === 'string' ? config.correlationID : null);
                    this.senderID = (typeof config.senderID === 'string' ? config.senderID : null);
                    this.volumes = (typeof config.body.volumes === 'object' ? config.body.volumes : null);
                    this.viewports = (typeof config.body.viewports === 'object' ? config.body.viewports : null);
                    this.measurements = (typeof config.body.measurements === 'object' ? config.body.measurements : null);
                    this.cursors = (typeof config.body['3dcursors'] === 'object' ? config.body['3dcursors'] : null);
                },

                'PortObj': function(config) {
                    var that = this;
                    that.portReady = false;
                    that.active2D = false;
                    that.index = config.index;
                    that.viewType = config.viewType;
                    that.rendererType = config.rendererType;
                    that.vrRenderType = config.vrRenderType;
                    that.viewPortObject = {
                        copyFromViewport: sinon.spy(),
                        setView: sinon.spy(),
                        renderEngine: {
                            setRendererBaseUrl: sinon.spy()
                        },
                        getLookPoint: sinon.spy()

                    };
                    that.updateViewportImage = sinon.spy();
                }
            };
        }];
    });
});
