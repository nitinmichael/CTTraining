define(['angular-mocks', 'postal', 'viewerMockModule', 'serviceDiscoveryMock', 'GraphicalObjectMock', 'viewerModelsMock', 'viewerModule/controllers/viewerController', 'viewerServiceMock', 'viewerOrchestrationMock', 'renderingServiceMock', 'deviceManagerServiceMock', 'imageAreaToolbarMocks', 'mousemanagementModule/module'],
    function(ngmock, postal) {
        'use strict';

        describe('Viewer Controller Test Cases', function() {

            var rootScope, scope, viewerCtrl;

            // Services
            var sceneManager, measureManager, cursorManager, renderingService, httpBackend, segmentationService, state,
                window, windowResizeService, xjtweb, logger, toastr, eventsService, stateParams, mouseModeStoreService,
                portContentFactory, orchestrationService, orchestrationServiceMock, q, http, viewportParameterStorage;

            var stubSegmentationMaskJsonUrl = './modules/viewer/modules/viewer-app/mocks/emptySegmentationMask.json';
            var saveStates, getGroupsSuccess, getGroupsError;

            var viewportParameterStorageProvider = function() {
                this.$get = function() {
                    var that = this;

                    that.currentConf = null;

                    that.studyInfo = {
                        studyDescription: 'My Study desc',
                        studyDate: '2015-11-27'
                    };

                    return {
                        ViewportParameterObj: function() {
                            var vpParmObj = this;

                            this.seriesUid = undefined;
                            this.renderingUrl = undefined;
                            this.annotationUrl = undefined;

                            this.ports = [{
                                index: 0,
                                menu: false,
                                cssLayout: 'twoByTwo',
                                usePredefinedLayout: true,
                                getId: function() {
                                    return '0';
                                }
                            }, {
                                index: 1,
                                menu: false,
                                cssLayout: 'twoByTwo',
                                usePredefinedLayout: true,
                                getId: function() {
                                    return '1';
                                }
                            }, {
                                index: 2,
                                menu: false,
                                cssLayout: 'twoByTwo',
                                usePredefinedLayout: true,
                                getId: function() {
                                    return '2';
                                }
                            }, {
                                index: 3,
                                menu: false,
                                cssLayout: 'twoByTwo',
                                usePredefinedLayout: true,
                                getId: function() {
                                    return '3';
                                }
                            }];

                            this.setSeriesUid = function(newSeriesUid) {
                                vpParmObj.seriesUid = newSeriesUid;
                            };

                            this.setRenderingUrl = function(newRenderingUrl) {
                                vpParmObj.renderingUrl = newRenderingUrl;
                            };

                            this.setAnnotationUrl = function(newAnnotationUrl) {
                                vpParmObj.annotationUrl = newAnnotationUrl;
                            };

                            this.setPorts = function(ports) {
                                vpParmObj.ports = ports;
                            };
                        },
                        isViewportParameterObj: function() {},
                        setGroups: function() {},
                        getGroup: function() {
                            return {
                                groupID: '1.23.4',
                                imageType: '3D'
                            };
                        },
                        getGroups: function() {
                            return [{
                                groupID: '1.23.4',
                                imageType: '3D'
                            }];
                        },
                        setCurrentConfiguration: function(config) {
                            that.currentConf = config;
                        },
                        getCurrentConfiguration: function() {
                            return that.currentConf;
                        },
                        setVolumes: function() {},
                        setPatientInfo: function() {},
                        setRenderingUrls: function() {},
                        setAnnotationUrl: function() {},
                        getSaveStates: function() {
                            return saveStates;
                        },
                        set2DImageModelControllerUrl: function() {},
                        set2DPixelStreamerUrl: function() {},
                        getStudyInfo: function() {
                            return that.studyInfo;
                        },
                        setStudyInfo: function() {},
                        getRenderingUrl: function() {},
                        getNumberOfPorts: function() {
                            return 16;
                        },
                        getPatientInfo: function() {},
                        reformatSaveState: function(saveStateInfo) {
                            return saveStateInfo;
                        },
                        getVolumes: function() {},
                        setSaveStates: sinon.spy()
                    };
                };
            };

            var portContentProvider = function() {
                this.$get = function() {
                    return {
                        getActivePortIndex: function() {},
                        setActivePort: function() {

                        },
                        getCurrentMouseModes: function() {

                        },
                        setGroup: function() {

                        },
                        viewport2D3DState: function() {
                            return '3D';
                        },
                        setConfig: function() {

                        },
                        cleanUp: sinon.spy()
                    };
                };
            };

            var segmentationMasksObj = {
                masks: [{
                    name: 'mask1',
                    id: '2'
                }, {
                    name: 'mask2',
                    id: '6'
                }, {
                    name: 'mask3',
                    id: '7'
                }, {
                    name: 'mask4',
                    id: '4'
                }, {
                    name: 'mask5',
                    id: '8'
                }, {
                    name: 'mask6',
                    id: '1'
                }, {
                    name: 'mask1',
                    id: '6'
                }]
            };

            beforeEach(function() {
                module('cloudav.viewerMockModule');
                module('cloudav.viewerApp.linkingviewport');
                module('xjtweb-platform');
                module('cloudav.viewerApp.services');
                module('cloudav.renderingService');
                module('deviceManagerServiceMock');
                module('viewerModels');
                module('cloudav.viewerApp.mousemanagement');
                module('viewerServiceMock');

                module('cloudav.viewerApp.controllers', function($provide, GraphicalObjectMock, viewerOrchestrationMock, renderingServiceMock) {
                    orchestrationServiceMock = viewerOrchestrationMock;

                    $provide.value('viewerUrls', {
                        servicesName: {
                            groupBuilder: 'pfh_hcimg_av_group_builder',
                            saveState: 'pfh_hcimg_av_presentationstate_provider',
                            imageController: 'pfh_hcimg_av_image_controller',
                            mprRendering: 'pfh_hcimg_av_mpr_rendering',
                            vrRendering: 'pfh_hcimg_av_vr_rendering',
                            annotationService: 'pfh-hcimg-av-annotation',
                            configManagment: 'pfh-config-configuration-store'
                        }
                    });

                    $provide.value('$stateParams', {
                        caseuuid: '25300391958837055805250', // case id used in the mock
                        studyuid: 'mock study uuid'
                    });

                    $provide.value('orchestrationService', {
                        getGroups: function(caseId) {
                            return {
                                then: function(_getGroupsSuccess_, _getGroupsError_) {
                                    getGroupsSuccess = _getGroupsSuccess_;
                                    getGroupsError = _getGroupsError_;
                                    viewerOrchestrationMock().getGroups(caseId).then(_getGroupsSuccess_, _getGroupsError_);
                                }
                            };
                        },
                        getSaveState: viewerOrchestrationMock().getSaveState,
                        getVolumeInfo: viewerOrchestrationMock().getVolumeInfo
                    });

                    $provide.value('serviceLocator', {
                        registerServices: function() {}
                    });

                    sceneManager = GraphicalObjectMock.SceneManagerMock(false, postal);
                    measureManager = GraphicalObjectMock.MeasureManagerMock(postal);
                    cursorManager = GraphicalObjectMock.CursorManagerMock(postal);
                    renderingService = renderingServiceMock.renderingServiceMock();

                    eventsService = {
                        subscribeViewerEvents: sinon.spy(),
                        destroy: sinon.spy()
                    };

                    state = {
                        go: sinon.spy()
                    };

                    windowResizeService = {
                        clearCBforOnResize: sinon.spy()
                    };

                    xjtweb = {
                        RendererFactory: {
                            destroy: sinon.spy()
                        },
                        XJTWEB: {
                            ServiceLocator: {
                                resolve: function() {
                                    return {
                                        publish: function() {}
                                    };
                                }
                            },
                            SERVICE: {
                                GMC: 'GMC'
                            },
                            GMC: {
                                CHANNEL: 'GMC_CHANNEL',
                                TOPIC: {
                                    ALL: 'GMC.*.*',
                                    VIEWPORT: {
                                        SWITCH: 'GMC.VIEWPORT.SWITCH',
                                        UPDATE: 'GMC.VIEWPORT.UPDATE',
                                        IMAGE_UPDATED: 'GMC.VIEWPORT.IMAGE_UPDATED'
                                    }
                                }
                            }
                        }
                    };

                    logger = {
                        setLogHandler: sinon.spy(),
                        log: sinon.spy(),
                        error: sinon.spy(),
                        fatal: sinon.spy()
                    };

                    toastr = {
                        show: sinon.spy(),
                        clearAll: sinon.spy()
                    };

                    mouseModeStoreService = {
                        setMouseMode: sinon.spy()
                    };

                    $provide.value('SceneManager', sceneManager);
                    $provide.value('MeasureManager', measureManager);
                    $provide.value('CursorManager', cursorManager);
                    $provide.value('renderingService', renderingService);
                    $provide.value('$windowResizeService', windowResizeService);
                    $provide.value('$state', state);
                    $provide.value('$xjtweb', xjtweb);
                    $provide.value('$logger', logger);
                    $provide.value('$toastr', toastr);
                    $provide.value('mouseModeStoreService', mouseModeStoreService);
                    $provide.value('eventsService', eventsService);
                    $provide.provider('$viewportParameterStorage', viewportParameterStorageProvider);
                    $provide.provider('portContentFactory', portContentProvider);

                    $provide.value('mousemodetoolbarFactory', {
                        success: sinon.spy()
                    });

                    $provide.value('$toolFactory', {
                        toolPanelObj: function() {},
                        toolBtnObj: function() {}
                    });
                });

                inject(function($rootScope, $controller, $httpBackend, $window, _segmentationService_, $stateParams, _portContentFactory_, _orchestrationService_, $q, $http, $viewportParameterStorage) {

                    segmentationService = _segmentationService_;
                    orchestrationService = _orchestrationService_;
                    rootScope = $rootScope;
                    scope = $rootScope.$new();
                    window = $window;
                    stateParams = $stateParams;
                    portContentFactory = _portContentFactory_;
                    q = $q;
                    httpBackend = $httpBackend;
                    http = $http;
                    viewportParameterStorage = $viewportParameterStorage;

                    scope.$bus = {
                        'subscribe': function(channel, topic, callback) {
                            postal.subscribe({
                                channel: channel,
                                topic: topic,
                                callback: callback
                            });
                        }
                    };

                    viewerCtrl = $controller('ViewerCtrl', {
                        $scope: scope
                    });

                    httpBackend.when('GET', stubSegmentationMaskJsonUrl).respond(segmentationMasksObj);
                });

                scope.$apply();
            });

            afterEach(function() {
                if (http.pendingRequests.length > 0) {
                    httpBackend.flush();
                }
                httpBackend.verifyNoOutstandingExpectation();
                httpBackend.verifyNoOutstandingRequest();
                postal.reset();
            });

            it('should initialize the segmentation masks', function() {
                scope.$apply();
                httpBackend.expectGET(stubSegmentationMaskJsonUrl);
                segmentationService.updateSegmentationMasks(scope.viewPortConfig.ports[0].groupId).then(function() {
                    var segmentationMaskUpdated = segmentationService.segmentationMasks();
                    expect(JSON.stringify(segmentationMasksObj)).to.equal(JSON.stringify(segmentationMaskUpdated));
                });

            });

            it('should have a controller', function() {
                assert.isDefined(viewerCtrl, 'Viewer Controller is not defined');
            });

            it('should have an "viewPortConfig" property', function() {
                assert.isDefined(scope.viewPortConfig, 'Viewer Controller scope doesn\'t have "viewPortConfig" property defined');
            });

            it('should have an "viewPortConfig.ports" property', function() {
                assert.isDefined(scope.viewPortConfig.ports, 'Viewer Controller scope doesn\'t have "viewPortConfig.ports" property defined');
            });

            it('should have an "selectedViewPort" property', function() {
                assert.isDefined(scope.selectedViewPort, 'Viewer Controller scope doesn\'t have "selectedViewPort" property defined');
            });

            it('should call mouseModeStoreService.setMouseMode when popstate event is fired', function() {
                window.onpopstate();
                expect(portContentFactory.cleanUp.calledOnce).to.be.true;
            });

            it('should call $toastr.clearAll when popstate event is fired', function() {
                window.onpopstate();
                expect(toastr.clearAll.calledOnce).to.be.true;
            });

            it('should call $windowResizeService.clearCBforOnResize when popstate event is fired', function() {
                window.onpopstate();
                expect(windowResizeService.clearCBforOnResize.calledOnce).to.be.true;
            });


            it('should call MeasureManager.destroy when popstate event is fired', function() {
                window.onpopstate();
                expect(measureManager.destroy.calledOnce).to.be.true;
            });


            it('should call eventsService.destroy when popstate event is fired', function() {
                window.onpopstate();
                expect(eventsService.destroy.calledOnce).to.be.true;
            });

            it('should call SceneManager.destroy when popstate event is fired', function() {
                window.onpopstate();
                expect(sceneManager.destroy.calledOnce).to.be.true;
            });

            it('should call $xjtweb.RendererFactory.destroy when popstate event is fired', function() {
                window.onpopstate();
                expect(xjtweb.RendererFactory.destroy.calledOnce).to.be.true;
            });

            it('should call renderingService.stopKeepAlive when popstate event is fired', function() {
                window.onpopstate();
                expect(renderingService.stopKeepAlive.calledOnce).to.be.true;
            });

            it('should call eventsService.subscribeViewerEvents only once', function() {
                expect(eventsService.subscribeViewerEvents).to.have.been.calledOnce;
            });

            it('should call mouseModeStoreService.setMouseMode when viewer session is closed if previousState state param was provided', function() {
                stateParams.previousState = {
                    name: '',
                    params: ''
                };
                rootScope.$broadcast('viewerSessionClosed');
                scope.$apply();
                expect(portContentFactory.cleanUp.calledOnce).to.equal(true);
            });

            it('should call $toastr.clearAll when viewer session is closed if previousState state param was provided', function() {
                stateParams.previousState = {
                    name: '',
                    params: ''
                };
                rootScope.$broadcast('viewerSessionClosed');
                scope.$apply();
                expect(toastr.clearAll.calledOnce).to.equal(true);
            });

            it('should call $windowResizeService.clearCBforOnResize when viewer session is closed if previousState state param was provided', function() {
                stateParams.previousState = {
                    name: '',
                    params: ''
                };
                rootScope.$broadcast('viewerSessionClosed');
                scope.$apply();
                expect(windowResizeService.clearCBforOnResize.calledOnce).to.equal(true);
            });


            it('should call MeasureManager.destroy when viewer session is closed if previousState state param was provided', function() {
                stateParams.previousState = {
                    name: '',
                    params: ''
                };
                rootScope.$broadcast('viewerSessionClosed');
                scope.$apply();
                expect(measureManager.destroy.calledOnce).to.equal(true);
            });

            it('should call eventsService.destroy when viewer session is closed if previousState state param was provided', function() {
                stateParams.previousState = {
                    name: '',
                    params: ''
                };
                rootScope.$broadcast('viewerSessionClosed');
                scope.$apply();
                expect(eventsService.destroy.calledOnce).to.equal(true);
            });

            it('should call SceneManager.destroy when viewer session is closed if previousState state param was provided', function() {
                stateParams.previousState = {
                    name: '',
                    params: ''
                };
                rootScope.$broadcast('viewerSessionClosed');
                scope.$apply();
                expect(sceneManager.destroy.calledOnce).to.equal(true);
            });

            it('should call $xjtweb.RendererFactory.destroy when viewer session is closed if previousState state param was provided', function() {
                stateParams.previousState = {
                    name: '',
                    params: ''
                };
                rootScope.$broadcast('viewerSessionClosed');
                scope.$apply();
                expect(xjtweb.RendererFactory.destroy.calledOnce).to.equal(true);
            });

            it('should call renderingService.stopKeepAlive when viewer session is closed if previousState state param was provided', function() {
                stateParams.previousState = {
                    name: '',
                    params: ''
                };
                rootScope.$broadcast('viewerSessionClosed');
                scope.$apply();
                expect(renderingService.stopKeepAlive.calledOnce).to.equal(true);
            });

            it('should call $state.go when viewer session is closed if previousState state param was provided', function() {
                stateParams.previousState = {
                    name: '',
                    params: ''
                };
                rootScope.$broadcast('viewerSessionClosed');
                scope.$apply();
                expect(state.go.calledOnce).to.be.true;
            });

            it('should call $window.history.back when viewer session is closed if previousState state param was not provided', function() {
                var backSpy = sinon.spy(window.history, 'back');
                rootScope.$broadcast('viewerSessionClosed');
                scope.$apply();
                expect(backSpy.calledOnce).to.be.true;
            });

            it('should define a default log handler', function() {
                expect(logger.setLogHandler.called).to.equal(true);
                logger.setLogHandler.args[0][0]();
            });

            it('should display fatal errors in a toaster', function() {
                logger.setLogHandler.args[0][0]('', 'fatal');
                expect(toastr.show.called).to.equal(true);
            });

            it('should display other errors in the browser console', function() {
                var spy = sinon.spy(console, 'log');
                logger.setLogHandler.args[0][0]();
                expect(spy.called).to.equal(true);
            });

            it('should close the viewer when a user taps on a toaster', function() {
                var spy = sinon.spy(rootScope, '$broadcast');
                logger.setLogHandler.args[0][0]('', 'fatal');
                toastr.show.args[0][0].onTap();
                expect(spy.called).to.equal(true);
            });

            it('should not be able to load a save state', function() {
                // TODO When SS returns into the project's scope, the viewerController unit test should be refactored
                // that the ViewerCtrl service creation should be removed from beforeEach(), in order to be able to set
                // up the mocks as needed for each test. Also it is strange the viewerServiceMock defines
                // the 'viewerService' service instead of 'viewerServiceMock' -- compare with viewerOrchestrationMock.

                expect(viewportParameterStorage.setSaveStates.called).to.equal(false);
            });

            it('should log the errors if the controller cannot get the groups', function() {
                var errorCount = logger.error.callCount,
                    fatalCount = logger.fatal.callCount;

                getGroupsError({
                    data: null
                });

                getGroupsError({
                    data: {
                        message: 'message'
                    }
                });

                expect(logger.error.callCount).to.equal(errorCount + 3);
                expect(logger.fatal.callCount).to.equal(fatalCount + 2);
            });

            it('should log the errors if the orchestration service does not send the right group', function() {
                var errorCount = logger.error.callCount,
                    fatalCount = logger.fatal.callCount,
                    res = {
                        data: {
                            groups: {
                                test: {}
                            }
                        }
                    };

                getGroupsSuccess(res);
                expect(logger.error.callCount).to.equal(errorCount + 1);
                getGroupsSuccess(res);
                getGroupsSuccess(res);
                getGroupsSuccess(res);
                getGroupsSuccess(res);
                getGroupsSuccess(res);
                expect(logger.fatal.callCount).to.equal(fatalCount + 1);
            });
        });
    });
