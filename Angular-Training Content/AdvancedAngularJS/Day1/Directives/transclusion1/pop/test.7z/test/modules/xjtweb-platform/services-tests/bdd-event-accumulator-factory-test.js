define([ 'angular', 'angular-mocks', 'modules/xjtweb-platform/services/bdd-event-accumulator-factory' ], function() {
    'use strict';

    describe('BDD Event Accumulator Factory', function() {
        var BddEventAccumulator = null;
        var $window = {
            BDD_MODE: false
        };

        beforeEach(module('bdd-event-accumulator'));
        beforeEach(module(function($provide) {
            $provide.value('$window', $window);
        }));
        beforeEach(inject(function(_BddEventAccumulator_) {
            BddEventAccumulator = _BddEventAccumulator_;
        }));

        it('should create a new factory with valid methods', function() {
            expect(typeof BddEventAccumulator.appendEvent === 'function').to.equal(true);
            expect(typeof BddEventAccumulator.getEventsAsJson === 'function').to.equal(true);
        });

        it('should not accumulate events in production', function() {
            BddEventAccumulator.appendEvent({});
            expect(BddEventAccumulator.getEventsAsJson()).to.equal("[]");
        });

        it('should accumulate events in BDD mode', function() {
            $window.BDD_MODE = true;
            BddEventAccumulator.appendEvent({});
            expect(BddEventAccumulator.getEventsAsJson()).to.equal("[{}]");
        });
    });

});
