
var home = 'modules/xjtweb-platform/services/';

define([ 'angular', 'angular-mocks','xjtweb', home + 'xjtweb-provider' ], function(ng, mock) {
    'use strict';

    /**
     * @ngdoc service
     * @name xjtweb-platform.provider:xjtwebProvider-test
     * @author Benjamin Beeman
     *
     * @description This is the unit-test suite for the {@link xjtweb-platform.$xjtweb $xjtweb} factory and its
     *              supporting {@link xjtweb-platform.provider:xjtwebProvider provider} .
     *
     * Copyright (c) 2015 by General Electric Company. All rights reserved.
     *
     * The copyright to the computer software herein is the property of General Electric Company. The software may be
     * used and/or copied only with the written permission of General Electric Company or in accordance with the terms
     * and conditions stipulated in the agreement/contract under which the software has been supplied.
     */
    describe('$xjtweb factory service tests, ', function() {

        var xjtweb;
        var cameraFactroy, rendererFactory;
        var mockURL = 'mockedHomeUrl';

        beforeEach(module('xjtwebProvider'));
        beforeEach(function() {
            module(function($xjtwebProvider) {
                $xjtwebProvider.setModuleHome(mockURL);
            });
        });

        beforeEach(inject(function($xjtweb) {
            xjtweb = $xjtweb;
            cameraFactroy = $xjtweb.CameraFactory;
            rendererFactory = $xjtweb.RendererFactory;
        }));

        describe('Init the $xjtweb factory service:', function() {

            /**
             * @ngdoc method
             * @name InitViewportContentFactoryTest
             * @methodOf xjtweb-platform.provider:xjtwebProvider
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.$viewportContentFactory $viewportContentFactory} is created as an
             *              object.
             */
            it('$xjtweb should be a typeof object', function() {
                expect(typeof xjtweb).to.equal('object');
            });

            it('$xjtweb.XJTWEB should return the mocked XJTWEB', function() {
                expect(typeof xjtweb.XJTWEB).to.equal('object');
            });

            it('$xjtweb.setWebGLRendererSize should be a typeof function.', function() {
                expect(typeof xjtweb.setWebGLRendererSize).to.equal('function');
            });

            it('$xjtweb.setWebGLRendererSize.', function() {

                xjtweb.setWebGLRendererSize();
                var node = document.createElement("canvas");
                node.id = 'webgl';

                document.body.appendChild(node);
                var webGLContext = {
                    renderer : {
                        setSize : function() {
                        }
                    }

                };
                var vp_rect = {
                    left : 5,
                    top : 5,
                    width : 100,
                    height : 100
                };
                xjtweb.setWebGLRendererSize(webGLContext, vp_rect);

                expect(webGLContext.viewportSize.x).to.equal(-3, 'x should be -3');
                expect(webGLContext.viewportSize.y).to.equal(-3, 'y should be -3');
                expect(webGLContext.viewportSize.width).to.equal(vp_rect.width, 'width should equal vp_rect width');
                expect(webGLContext.viewportSize.height).to.equal(vp_rect.height, 'height should equal vp_rect height');
            });

            /**
             * @ngdoc method
             * @name CameraFactory_Init_Test
             * @methodOf xjtweb-platform.provider:xjtwebProvider
             *
             * @description This test method determines that the CameraFactory is created as a instanceof CameraFactory
             *              from XJTWEB.
             */
            it('CameraFactory should be an instanceof xjtwebMockCameraFactory', function() {
                expect(cameraFactroy instanceof xjtwebMockCameraFactory).to.equal(true);
            });

            /**
             * @ngdoc method
             * @name RendererFactory_Init_Test
             * @methodOf xjtweb-platform.provider:xjtwebProvider
             *
             * @description This test method determines that the CameraFactory is created as a instanceof CameraFactory
             *              from XJTWEB.
             */
            it('RendererFactory should be an instanceof MockConstructor', function() {
                expect(rendererFactory instanceof MockConstructor).to.equal(true);
            });

            /**
             * @ngdoc method
             * @name getModuleHome_Test
             * @methodOf xjtweb-platform.provider:xjtwebProvider
             *
             * @description This test method determines that the getModuleHome returns the value set in the provider
             *              function.
             */
            it('getModuleHome should have been ' + mockURL, function() {
                expect(xjtweb.getModuleHome()).to.equal(mockURL);
            });

        });

    });
});
