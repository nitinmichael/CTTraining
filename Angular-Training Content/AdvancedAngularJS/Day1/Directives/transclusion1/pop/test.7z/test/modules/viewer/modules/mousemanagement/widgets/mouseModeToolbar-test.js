/*
 * mouseModeToolbar-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 *
 * @author: Emna Turki <emna.turky@ge.com>
 */

/**
 * Spec file for Viewer > modules > mousemanagement > widgets > mouseModeToolbar directive
 */

define(['angular', 'angular-mocks', 'jquery', 'deviceManagerServiceMock', 'mousemanagementModule/module', 'mousemanagementModule/widgets/mouseModeToolbar', 'lodash'], function(angular) {
    'use strict';

    describe('mouseModeToolbar Directive Test :', function() {
        var element, scope, compile, isolatedScope;
        var mouseModeService, setMouseModeWatch, pagingInvalidOnActivePortMock, rotateInvalidOnActivePortMock, windowResizeCallback, onClickCallback, window, oldUserAgent;
        var portContentFactory, mouseMode;

        var mockData = {
            title: 'mockTitle',
            type: 'mockType',
            buttons: [{
                id: 'rotate_mode',
                panel: true
            }, {
                id: 'paging_mode',
                title: 'mousemanagement.paging',
                Name: 'PAGING',
                groupPanel: true
            }]
        };

        beforeEach(module('deviceManagerServiceMock'));
        beforeEach(module('cloudav.viewerApp.mousemanagement'));

        beforeEach(module(function($provide) {

            $provide.value('$toolFactory', {

                toolBtnObj: function(config) {
                    this.title = config.title;
                    this.id = config.id;
                    this.isDisabled = config.isDisabled;
                    this.type = config.type;
                    this.onclick = config.onclick;

                    if (config.id === 'paging_mode') {
                        onClickCallback = this.onclick;
                    }
                },

                toolBoxObj: function(config) {
                    this.title = config.title;
                    this.type = config.type;
                    this.buttons = config.buttons;
                },

                defaultToolBoxObj: function() {},

                toolModalObj: function() {},

                toolPanelObj: function() {},

                Icon: function() {}
            });

            $provide.service('$windowResizeService', function() {
                this.addCBforOnResize = function(callback) {
                    windowResizeCallback = callback;
                };
            });

            mouseModeService = {
                setMouseMode: function(mm) {
                    setMouseModeWatch = mm;
                }
            };

            $provide.value('mouseModeStoreService', mouseModeService);

            $provide.factory('portContentFactory', function() {
                return {
                    pagingInvalidOnActivePort: function() {
                        return pagingInvalidOnActivePortMock;
                    },
                    rotateInvalidOnActivePort: function() {
                        return rotateInvalidOnActivePortMock;
                    },
                    setMouseMode: sinon.spy(),
                    getSelectedMouseModeForActivePort: function() {
                        return mouseMode;
                    },
                    resetMouseMode: sinon.spy()
                };
            });

            $provide.factory('mousemodetoolbarFactory', function() {
                return {
                    success: function(cb) {
                        cb();
                        cb(mockData);
                    }
                };
            });
        }));

        beforeEach(inject(function($compile, $rootScope, $window, _portContentFactory_) {
            scope = $rootScope.$new();
            compile = $compile;
            window = $window;
            portContentFactory = _portContentFactory_;

            oldUserAgent = window.navigator.userAgent;
        }));

        afterEach(function() {
            // Reset the user agent
            window.navigator = {
                userAgent: oldUserAgent
            };
        });

        var createMouseModeDirective = function() {
            var mmEl;

            element = angular.element('<mouse-mode-toolbar></mouse-mode-toolbar>');

            mmEl = compile(element)(scope);
            scope.$digest();
            isolatedScope = element.scope();

            return mmEl;
        };

        it('should not add resize callback on mobile devices', function() {
            window.navigator = {
                userAgent: 'Mozilla/5.0 (iPad; CPU OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53'
            };
            createMouseModeDirective();
            expect(windowResizeCallback).to.equal(undefined);
        });

        it('should have a directive', function() {
            var mmEl = createMouseModeDirective();
            assert.isDefined(mmEl, 'mouse Mode toolbar Directive is not defined');
        });

        it('should have an isolated scope', function() {
            createMouseModeDirective();
            assert.isDefined(isolatedScope, 'mouse Mode toolbar Directive does not have an isolated scope');
        });

        it('should have mouseModeBoxModel', function() {
            assert.isDefined(isolatedScope.mouseModeBoxModel, 'mouse Mode toolbar Directive does not have mouseModeBoxModel');
        });

        it('should have title', function() {
            assert.equal(isolatedScope.mouseModeBoxModel.title, mockData.title, 'Mouse Mode toolbar Directive has incorrect title');
        });

        it('should have type', function() {
            assert.equal(isolatedScope.mouseModeBoxModel.type, mockData.type, 'mouse Mode toolbar Directive has incorrect type');
        });

        it('should have default buttons', function() {
            assert.isArray(isolatedScope.mouseModeBoxModel.buttons);
            assert.equal(isolatedScope.mouseModeBoxModel.buttons.length, mockData.buttons.length, 'mouse Mode toolbar Directive has incorrect number of buttons');
            expect(isolatedScope.mouseModeBoxModel.buttons[0].id).to.equal('rotate_mode');

            expect(isolatedScope.mouseModeBoxModel.buttons[1].id).to.equal('paging_mode');
        });

        it('should have a toolBtnClick function defined in scope', function() {
            createMouseModeDirective();
            expect(typeof(isolatedScope.toolBtnClick)).to.equal('function');
        });

        it('should change the mouse mode orientation when the destkop version of the viewer is resized', function() {
            try {
                windowResizeCallback();
            } catch (e) {}

            expect(isolatedScope.mouseModeBoxModel.orientation).to.equal('horizontal');

            window.innerWidth = 600;

            try {
                windowResizeCallback();
            } catch (e) {}

            expect(isolatedScope.mouseModeBoxModel.orientation).to.equal('vertical');
        });

        it('default mouse mode should be highlighted', function() {
            isolatedScope.activeToolMode = null;
            mouseMode = 'PAGING';
            isolatedScope.$apply();
            expect(isolatedScope.activeToolMode).to.equal('mousemanagement.paging');
        });

        it('click on a mouse mode button should change the mouse mode on desktop', function() {
            createMouseModeDirective();

            var spy = sinon.spy(isolatedScope, 'toolBtnClick');

            isolatedScope.activeToolMode = null;
            onClickCallback();
            expect(spy.calledWith('PAGING')).to.equal(true);
            expect(portContentFactory.setMouseMode.calledWith('PAGING')).to.equal(true);

            isolatedScope.activeToolMode = 'mousemanagement.paging';
            onClickCallback();
            expect(spy.callCount).to.equal(1);

            spy.restore();
        });

        it('click on a mouse mode button should change or reset the mouse mode on tablet', function() {
            window.navigator = {
                userAgent: 'Mozilla/5.0 (iPad; CPU OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53'
            };

            createMouseModeDirective();

            var spy = sinon.spy(isolatedScope, 'toolBtnClick');

            isolatedScope.activeToolMode = null;
            onClickCallback();
            expect(spy.calledWith('PAGING')).to.equal(true);
            expect(portContentFactory.setMouseMode.calledWith('PAGING')).to.equal(true);

            isolatedScope.activeToolMode = 'mousemanagement.paging';
            onClickCallback();
            expect(spy.calledWith()).to.equal(true);
            expect(portContentFactory.resetMouseMode.called).to.equal(true);
        });
    });
});
