/*
 * normalization-controller.js
 * 
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 * 
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 * 
 * @author: Raoul Nair<raoul.nair@ge.com>
 */

define([ 'angular', 'angular-mocks', 'case-automation/module', 'case-automation/controllers/case-automation-controller', 'case-automation/services/case-automation-service','mocks/case-exchange-mock-service', 'mocks/fake-server', 'case-exchange/services/case-exchange-data-service'], function() {
    'use strict';
    
    var rootScope, scope, controller, caseAutomationService, getSitesServices, caseAutomationDataService, getSelectedStub, modal, filter, state, mockServer, $mockServerLoader, stateParams, caseExchangeDataService, caseDataService, patientJson, adminJson;
    var MODES = {
            create: 'AUTOCREATE'
        };

    var site = {"title":null,"id":"0f1da138-563b-4d9a-8353-7c6710b604a8","content":{"name":"Site Legal Name"}};

    describe('Case Automation Controller Test Suite::', function() {
        var caseInstListResponse,
            instructionConditionJson,
            conditionKeyList,
            conditionTypeList,
            conditionBooleanList;

        beforeEach(function () {
            module('cloudav.caseExchange.mocks');
            // Load the Sinon fake server.
            module('cloudav.caseExchange.fakeServer');
            
            module('cloudav.caseExchange.caseAutomationCtrl', function ($provide) {

                $provide.value('$state', {
                    transitionTo: function (url) {
                    },
                    current: {
                        params: {
                            mode: MODES.create
                        }
                    }
                });

                $provide.value('$stateParams', {
                    id: function () {
                    },
                    selectedSite:{id:"1234"}
                });

            });
        });

        function fakeCaseListResolved(value) {
            return {
                promise : {
                    then : function(callback) {
                        callback("");
                    }
                }
            }
        }

        function fakeGetSiteResolved(value) {
            return {
                then : function(callback) {
                    callback("");
                }
            }
        }

        beforeEach(module('cloudav.caseExchange.caseAutomationCtrl', function($provide) {}));

        // Initialize the scope and controller variables
        beforeEach(inject(function($rootScope, $controller, CaseAutomationService, $filter, $state, $stateParams, GetSitesServices, CaseAutomationDataService, $modal, $MockServerLoader, CaseExchangeDataService, CaseExchangeMocks) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            controller = $controller;

            // Initialize the controller before each specs
            controller('CaseAutomationCtrl', {
                $scope : scope
            });
            
            caseAutomationService=CaseAutomationService;
            getSitesServices=GetSitesServices;
            caseAutomationDataService = CaseAutomationDataService;
            caseExchangeDataService = CaseExchangeDataService;
            adminJson = CaseExchangeMocks.getAdminJson();
            patientJson = CaseExchangeMocks.getPatientJson();
            caseInstListResponse = CaseExchangeMocks.getCaseInstListResponse();
            instructionConditionJson=CaseExchangeMocks.getInstructionConditionJson();
            conditionKeyList=CaseExchangeMocks.getConditionKeyList();
            conditionTypeList=CaseExchangeMocks.getConditionTypeList();
            conditionBooleanList=CaseExchangeMocks.getConditionBooleanList();
            modal = $modal;
            filter = $filter;
            state = $state;
            stateParams=$stateParams;
            getSelectedStub = sinon.stub(caseAutomationDataService, "getSelectedSite", function () { return site; });
            scope.modalInstance =  {
                "dismiss":function(){}
            }
            
            $mockServerLoader = $MockServerLoader;
            // Call the init to initialize the Sinon Mock Data Server.
            mockServer = $mockServerLoader.init();

            // Mocking the variable from parent controller as we don't have inheritance in place in unit testing.
            scope.alertTypes = {
                success: 'success',
                error: 'error'
            };

            // Mocking the method from parent controller as we don't have inheritance in place in unit testing.
            scope.showAlertMessage = function () {
            };
        }));

        it('should have a controller', function() {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it('should fetch next set of instruction and display in the case automation page', function() {
            scope.isFetchingInstList=false;
            scope.selectedSite=JSON.stringify(site);
            sinon.stub(caseAutomationService, "getCaseAutomationInstructions", function () { return fakeCaseListResolved("value"); });
            scope.getPendingCaseInstList();
            expect(scope.showCaseListSpinner).to.be.false;
            expect(scope.isFetchingInstList).to.be.false;
        });

        it('should fetch instruction on selection of sites', function() {
            scope.selectedSite=JSON.stringify(site);
            sinon.stub(caseAutomationService, "getCaseAutomationInstructions", function () { return fakeCaseListResolved("value"); });
            scope.showInstructionList(); 
            expect(scope.showCaseListSpinner).to.be.false;
            expect(scope.isFetchingInstList).to.be.false;
        });

        it('should fetch sites list', function() {
            sinon.stub(getSitesServices, "getSiteList", function () { return fakeGetSiteResolved("value"); });
            scope.getSiteDetails();
            expect(scope.showsiteListSpinner).to.be.false;
        });

        it('should reset the site srop down list', function() {
           scope.siteList=[{id:"1234"}];
           scope.resetSiteInstList();
           expect(scope.selectedSite).to.equal(scope.siteList[0]);
        });

        it('should not reset the site srop down list', function() {
            scope.siteList=[{id:"12345"}];
            scope.resetSiteInstList();
            expect(scope.selectedSite).to.not.equal(scope.siteList[0]);
         });

        it('should open modal with appropriate case status',function(){
            var instruction={
                    name:'Test case 1',
                    status: 'ACTIVE'
                },
                params={
                    templateUrl : './modules/caseexchange/modules/case-automation/views/case-activate-suspend-popup.html',
                    scope : scope
                },
                callback = sinon.spy(modal,'open');
                
            modal.open(params,callback);

            scope.openActivateSuspendPopup(instruction);

            callback.calledWith(params);
            expect(scope.statusOfInstruction).to.equal(filter('translate')('caseAutoInstrList.suspend'));

            instruction.status='SUSPEND';
            scope.openActivateSuspendPopup(instruction);
            expect(scope.statusOfInstruction).to.equal(filter('translate')('caseAutoInstrList.activate'));

        });

        it('should close activate/suspend modal',function(){            
            var modalInstance=scope.modalInstance,
                callback = sinon.spy(modalInstance,'dismiss');
                
            modalInstance.dismiss(callback);
            scope.close();
            callback.calledOnce;            
        });

        it('should call saveInstructionState and succesfully activate instruction',function(){
            scope.instruction={id:"1234",status:"SUSPENDED"};
            sinon.stub(caseAutomationService, "caseInstructionCurdOperation", function () { return fakeCaseListResolved("value"); });
            scope.saveInstructionState();
            expect(scope.instruction.status).to.equal("ACTIVE");
        });

        it('should call saveInstructionState and succesfully suspend instruction',function(){
            scope.instruction={id:"1234",status:"ACTIVE"};
            sinon.stub(caseAutomationService, "caseInstructionCurdOperation", function () { return fakeCaseListResolved("value"); });
            scope.saveInstructionState();
            expect(scope.instruction.status).to.equal("SUSPENDED");
        });

        it('should open create instruction screen',function(){
            var stateSpy = sinon.spy(state, "transitionTo");
            scope.openCreateInstruction();
            assert(stateSpy.calledWith('caseexchange.createinstruction'));
        });

        it('should call getCaseInstList() with error in ajax call',function(){
            $mockServerLoader.fakeInstructionListCall(500, {});
            scope.selectedSite=JSON.stringify(site);
            scope.getCaseInstList();
            mockServer.respond();
            rootScope.$apply();
            expect(scope.showCaseListSpinner).to.be.false;
            expect(scope.isFetchingInstList).to.be.false;
        });

        it('should call getSiteDetails() with error in ajax call', function() {
            $mockServerLoader.fakeGetSiteListCall(500, {});
            scope.getSiteDetails();
            mockServer.respond();
            rootScope.$apply();
            expect(scope.showsiteListSpinner).to.be.false;
        });
        
        it('should not call getCaseInstList() when no site is selected and populate case list array',function(){
            scope.showInstructionList();
            scope.getPendingCaseInstList();
            expect(scope.showInstructionList.length).to.equal(0);
        });
        
        it('should display failure message on error in ajax call while updating status of a instruction',function(){
            var showMessageSpy = sinon.spy(scope,'showAlertMessage');
            scope.instruction={id:"1234",status:"SUSPENDED"};
            $mockServerLoader.fakeInstructionCurdOperationCall("PATCH", 500, {}, "/caseautomation/v1/instruction/1");
            scope.saveInstructionState();
            mockServer.respond();
            rootScope.$apply();
            assert(showMessageSpy.calledWith(filter('translate')('common.genericError'), scope.alertTypes.error));
        });
        
        it('should create description based on condition saved on call of getCaseInstDescription()',function(){
            var data = instructionConditionJson;
            scope.conditionKeyList=conditionKeyList;
            scope.ConditionTypeList=conditionTypeList;
            scope.conditionBooleanList=conditionBooleanList;
            var newCondition = scope.getCaseInstDescription(data);
            expect(newCondition[0].description).to.equal(filter('translate')('createInstruction.instDescription'));
        });

        it('Administrator should have access for case automation', function() {
            var data = adminJson,
                getSiteDetailsCallback = sinon.spy(scope,'getSiteDetails'),
                getDicomConditionCallback = sinon.spy(scope, 'getDicomCondition');

            caseExchangeDataService.setCurrentUser(data);
            scope.init();

            assert(getSiteDetailsCallback.calledOnce);
            assert(getDicomConditionCallback.calledOnce);
        });

        it('Users other than administrator should not have access to case automation', function() {
            var data = patientJson,
                callback = sinon.spy(state, "transitionTo");

            caseExchangeDataService.setCurrentUser(data);
            scope.init();

            assert(callback.calledOnce);
        });

        it('If no user is present, then get users from service call, check for success callback', function() {
            var data = adminJson,
                getSiteDetailsCallback = sinon.spy(scope,'getSiteDetails'),
                getDicomConditionCallback = sinon.spy(scope, 'getDicomCondition');

            caseExchangeDataService.setCurrentUser(null);
            //success
            $mockServerLoader.fakeQueryCurrentUserCall(200, data);
            scope.init();
            mockServer.respond();
            rootScope.$apply();

            assert(getSiteDetailsCallback.calledOnce);
            assert(getDicomConditionCallback.calledOnce);
        });

        it('If no user is present, then get users from service call, check for error callback', function() {
            var callback = sinon.spy(state, "transitionTo");

            caseExchangeDataService.setCurrentUser(null);
            //success
            $mockServerLoader.fakeQueryCurrentUserCall(200, {});
            scope.init();
            mockServer.respond();
            rootScope.$apply();

            assert(callback.calledOnce);
        });

        it('If no user is present, then get users from service call, service is giving error while fetching current user', function() {
            var showMessageSpy = sinon.spy(scope,'showAlertMessage');

            caseExchangeDataService.setCurrentUser(null);
            //error
            $mockServerLoader.fakeQueryCurrentUserCall(500, null);
            scope.init();
            mockServer.respond();
            rootScope.$apply();

            assert(showMessageSpy.calledOnce);

            assert(showMessageSpy.calledWith(filter('translate')('common.accessDenied'), scope.alertTypes.error));
        });
    });
});