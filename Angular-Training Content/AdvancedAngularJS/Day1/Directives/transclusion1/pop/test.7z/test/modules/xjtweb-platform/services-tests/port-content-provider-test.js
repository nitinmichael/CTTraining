var home = 'modules/xjtweb-platform/services/';

define(['angular', 'angular-mocks', home + 'port-content-provider'], function() {
    'use strict';

    /**
     * @ngdoc service
     * @name xjtweb-platform.provider:portContentFactory-test
     * @author Benjamin Beeman
     *
     * @description TODO
     *
     * Copyright (c) 2015 by General Electric Company. All rights reserved.
     *
     * The copyright to the computer software herein is the property of General Electric Company. The software may be
     * used and/or copied only with the written permission of General Electric Company or in accordance with the terms
     * and conditions stipulated in the agreement/contract under which the software has been supplied.
     */
    describe('port-content-provider Unit Test, ', function() {

        var portContentFactory;
        var errorMsg, warnMsg;
        var setUp2DPortCallCount, setUp3DPortCallCount;
        var paint2DCallCount;
        var setWebGLRendererSizeCallParams = {};
        var set2DGroupOnPortParams, set3DGroupOnPortParams;
        var NUMBER_OF_PORTS = 16;
        var addCBforOnResizeMock;
        var setMouseModeMock, get2DEventModesMock, get3DEventModesMock, $xjtweb, port2DContentFactory, port3DContentFactory;

        var adaptPortNumber = function(ports) {
            if (ports.length < NUMBER_OF_PORTS) {
                var i;
                for (i = ports.length; i < NUMBER_OF_PORTS; i++) {
                    ports.push(ports[ports.length - 1]);
                }
            }
        };

        var portMocks = [{
            index: 0,
            rendererType: 'MPR',
            viewType: 'LEFT'
        }, {
            index: 1,
            rendererType: 'MPR',
            viewType: 'LEFT'
        }, {
            index: 2,
            rendererType: 'MPR',
            viewType: 'LEFT'
        }, {
            index: 3,
            rendererType: 'MPR',
            viewType: 'LEFT'
        }];

        adaptPortNumber(portMocks);

        var viewerModelsFactory = {
            PortObj: function(config) {
                var that = this;
                that.portReady = false;
                that.active2D = false;
                that.index = config.index;
                that.viewType = config.viewType;
                that.rendererType = config.rendererType;

            },
            Group: function() {}
        };

        beforeEach(function() {
            module('portContent');

            module(function($provide) {

                $provide.factory('$xjtweb', function() {
                    return {
                        'setWebGLRendererSize': function(webGLContext, vp_rect) {
                            setWebGLRendererSizeCallParams.webGLContext = webGLContext;
                            setWebGLRendererSizeCallParams.vp_rect = vp_rect;

                        },
                        'XJTWEB': {
                            MouseModeStore: {
                                STARTING_MODE_NAME: "PAGING_MODE"
                            }
                        }
                    };
                });

                $provide.factory('$logger', function() {
                    return {
                        'error': function(msg) {
                            errorMsg = msg;
                        },
                        'warn': function(msg) {
                            warnMsg = msg;
                        }
                    };
                });

                $provide.factory('$viewportParameterStorage', function() {
                    return {
                        getNumberOfPorts: function() {
                            return 16;
                        }
                    };
                });

                $provide.factory('$windowResizeService', function() {
                    return {
                        'addCBforOnResize': function(fn) {
                            addCBforOnResizeMock = fn;
                        }
                    };
                });

                $provide.factory('port3DContentFactory', function() {
                    return {
                        'setUp3DPort': function(port) {
                            setUp3DPortCallCount++;
                            port.viewPortObject = {
                                getViewHeight: function() {
                                    return 2;
                                },
                                getAspectRatio: function() {
                                    return 3;
                                }
                            }
                        },
                        'set3DGroupOnPort': function(port, groupCfg) {
                            set3DGroupOnPortParams.port = port;
                            set3DGroupOnPortParams.groupCfg = groupCfg;
                        },
                        'getEventModes': function() {
                            return get3DEventModesMock;
                        },
                        'set2DGroupOnPort': function() {

                        },
                        'setMouseMode': function(mode) {
                            setMouseModeMock = mode;
                        },
                        'pagingInvalidOnPort': sinon.stub(),
                        'rotateInvalidOnPort': sinon.stub()
                    };
                });

                $provide.factory('port2DContentFactory', function() {
                    return {
                        'setUp2DPort': function(port) {
                            setUp2DPortCallCount++;
                            port.xp2DImageViewport = {
                                'paint': function() {
                                    paint2DCallCount++;
                                }
                            };
                        },
                        'set2DGroupOnPort': function(port, groupCfg) {
                            set2DGroupOnPortParams.port = port;
                            set2DGroupOnPortParams.groupCfg = groupCfg;
                        },
                        'getEventModes': function() {
                            return get2DEventModesMock;
                        },
                        'getSlicesNumber': function() {},
                        'setMouseMode': function(mode) {
                            setMouseModeMock = mode;
                        },
                        'pagingInvalidOnPort': sinon.stub(),
                        'rotateInvalidOnPort': sinon.stub()
                    };
                });

                $provide.factory('$viewerModelsFactory', viewerModelsFactory);
            });

            inject(function(_$xjtweb_, _portContentFactory_, _port2DContentFactory_, _port3DContentFactory_) {
                portContentFactory = _portContentFactory_;
                port2DContentFactory = _port2DContentFactory_;
                port3DContentFactory = _port3DContentFactory_;
                $xjtweb = _$xjtweb_;
            });
        });

        describe('Init portContentFactory:', function() {

            /**
             * @ngdoc method
             * @name InitPortContentFactoryTest
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.portContentFactory portContentFactory} is created as an object.
             */
            it('portContentFactory should be a typeof object', function() {
                expect(typeof portContentFactory).to.equal('object');
            });

            /**
             * @ngdoc method
             * @name InitPortContentFactory_getActivePortIndex_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.portContentFactory portContentFactory} is created with a
             *              getActivePortIndex function.
             */
            it('portContentFactory getActivePortIndex should be a typeof function', function() {
                expect(typeof portContentFactory.getActivePortIndex).to.equal('function');
            });

            /**
             * @ngdoc method
             * @name set_getActivePortIndex_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test sets an active port to null and verifies that it then getActivePortIndex returns a
             *              default value
             */
            it('portContentFactory getActivePortIndex should return a default value if the active port is not initialized', function() {
                var portIndex = portContentFactory.getActivePortIndex();
                expect(portIndex).to.equal(0);
            });

            /**
             * @ngdoc method
             * @name set_getActivePortIndex_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test sets an active port and verifies that it then getActivePortIndex returns the
             *              index.
             */
            it('portContentFactory getActivePortIndex should return the index of the active port', function() {
                portContentFactory.setActivePort({
                    'index': 3
                });
                var portIndex = portContentFactory.getActivePortIndex();
                expect(portIndex).to.equal("3");
            });

            /**
             * @ngdoc method
             * @name set_getActivePortIndex_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test sets an active port to null and verifies that it then getActivePort returns null
             */
            it('portContentFactory getActivePortIndex should return a default value if the active port is not initialized', function() {
                var port = portContentFactory.getActivePort();
                expect(port).to.equal(null);
            });

            /**
             * @ngdoc method
             * @name set_getActivePortIndex_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test sets an active port and verifies that it then getActivePort returns the active
             *              port
             */
            it('portContentFactory getActivePortIndex should return the index of the active port', function() {
                var port = {
                    'index': 3
                };
                portContentFactory.setActivePort(port);
                var result = portContentFactory.getActivePort();
                expect(result).to.deep.equal(port);
            });

            /**
             * @ngdoc method
             * @name InitPortContentFactory_setActivePort_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.portContentFactory portContentFactory} is created with a
             *              setActivePort function.
             */
            it('portContentFactory setActivePort should be a typeof function', function() {
                expect(typeof portContentFactory.setActivePort).to.equal('function');
            });

            /**
             * @ngdoc method
             * @name PortContentFactory_resetMouseMode_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.portContentFactory portContentFactory} is created with a
             *              resetMouseMode function.
             */
            it(' resetMouseMode, ', function() {
                expect(typeof portContentFactory.resetMouseMode).to.equal('function');

                portContentFactory.resetMouseMode();
                expect(setMouseModeMock).to.equal($xjtweb.XJTWEB.MouseModeStore.STARTING_MODE_NAME, 'If there is no Mouse Mode the Mouse mode should have been set to PAGING and it was not.');

            });

            /**
             * @ngdoc method
             * @name PortContentFactory_pagingOnSlider_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test method do paging on 2D and 3D(MPR) viewport
             *              {@link xjtweb-platform.portContentFactory portContentFactory} is created with a
             *              pagingOnSlider function.
             */
            it('portContentFactory.pagingOnSlider should be a typeof function', function() {
                expect(typeof portContentFactory.pagingOnSlider).to.equal('function');
                portContentFactory.setActivePort({
                    'index': 0,
                    'active2D': false,
                    'rendererType': 'VR'
                });
                portContentFactory.pagingOnSlider(2, 4);

            });

            /**
             * @ngdoc method
             * @name PortContentFactory_getSlicesNumber_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test method return the volume slices number
             *              {@link xjtweb-platform.portContentFactory portContentFactory} is created with a
             *              getSlicesNumber function.
             */
            it('portContentFactory.getSlicesNumber should be a typeof function', function() {
                expect(typeof portContentFactory.getSlicesNumber).to.equal('function');
                portContentFactory.setActivePort({
                    'index': 1,
                    'active2D': true,
                });
                portContentFactory.getSlicesNumber();

            });

            /**
             * @ngdoc method
             * @name PortContentFactory_getSliceIndex_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test method return the volume current slice index
             *              {@link xjtweb-platform.portContentFactory portContentFactory} is created with a
             *              getSliceIndex function.
             */
            it('portContentFactory.getSliceIndex should be a typeof function', function() {
                expect(typeof portContentFactory.getSliceIndex).to.equal('function');
                portContentFactory.setActivePort({
                    'index': 0,
                    'active2D': false,
                    'rendererType': 'VR'
                });
                portContentFactory.getSliceIndex();

            });

            /**
             * @ngdoc method
             * @name PortContentFactory_pagingValidOnActivePort_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.portContentFactory portContentFactory} is created with a
             *              pagingValidOnActivePort function.
             */
            it(' pagingValidOnActivePort, ', function() {
                expect(typeof portContentFactory.pagingInvalidOnActivePort).to.equal('function');

                portContentFactory.setActivePort({
                    'index': 0,
                    'active2D': true
                });
                port2DContentFactory.pagingInvalidOnPort.returns(false);
                expect(portContentFactory.pagingInvalidOnActivePort()).to.equal(false, 'Paging should have been valid on a 2D port.');

                portContentFactory.setActivePort({
                    'index': 0,
                    'active2D': false,
                    'rendererType': 'MPR'
                });
                port3DContentFactory.pagingInvalidOnPort.returns(false);
                expect(portContentFactory.pagingInvalidOnActivePort()).to.equal(false, 'Paging should have been valid on a 3D port with a rendertype of MPR.');

                portContentFactory.setActivePort({
                    'index': 0,
                    'active2D': false,
                    'rendererType': 'VR'
                });
                port3DContentFactory.pagingInvalidOnPort.returns(true);
                expect(portContentFactory.pagingInvalidOnActivePort()).to.equal(true, 'Paging should have not been valid on a 3D port with a rendertype of MPR.');

            });

            /**
             * @ngdoc method
             * @name PortContentFactory_getEventModes_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.portContentFactory portContentFactory} is created with a
             *              getEventModes function.
             */
            it(' getEventModes, ', function() {
                expect(typeof portContentFactory.getEventModes).to.equal('function');

                var mockPort = {
                    'active2D': true
                };
                get2DEventModesMock = 'Mocked2dEventMode';
                expect(portContentFactory.getEventModes(mockPort)).to.equal(get2DEventModesMock, 'getEventModes should have returned ' + get2DEventModesMock + " and did not.");

                mockPort = {
                    'active2D': false
                };
                get3DEventModesMock = 'Mocked3dEventMode';
                expect(portContentFactory.getEventModes(mockPort)).to.equal(get3DEventModesMock, 'getEventModes should have returned ' + get3DEventModesMock + " and did not.");

            });

            /**
             * @ngdoc method
             * @name setActivePort_PortErrorNotObject_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This object validates an error case when calling the setActivePort function with an invalid
             *              object.
             */
            it('portContentFactory setActivePort input parameter should be a typeof object', function() {

                portContentFactory.setActivePort();
                expect(errorMsg).to.equal('Invalid active port set. Port is not an object.');

            });

            /**
             * @ngdoc method
             * @name setActivePort_PortObjectWithoutIndexError_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This object validates an error case when calling the setActivePort function with an object
             *              that does not have an index.
             */
            it('portContentFactory setActivePort input paramether error without a valid index.', function() {

                portContentFactory.setActivePort({});
                expect(errorMsg).to.equal('Active port set without a valid index.');

            });

            /**
             * @ngdoc method
             * @name InitPortContentFactory_setConfig_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.portContentFactory portContentFactory} is created with a setConfig
             *              function.
             */
            it('portContentFactory setConfig should be a typeof function', function() {
                expect(typeof portContentFactory.setConfig).to.equal('function');
            });

            /**
             * @ngdoc method
             * @name setConfig_InvalidInputError_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This object validates an error case when calling the setConfig function without a valid
             *              input parameter object.
             */
            it('portContentFactory setPorts should be a typeof object', function() {

                portContentFactory.setConfig("Invalid Input");
                expect(errorMsg).to.equal('Input config is not a valid object.');

                portContentFactory.setConfig({});
                expect(errorMsg).to.equal('Input ports have an invalid number of ports or is not a valid object.');

            });

            /**
             * @ngdoc method
             * @name InitPortContentFactory_setGroup_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.portContentFactory portContentFactory} is created with a setGroup
             *              function.
             */
            it('portContentFactory setGroup should be a typeof function', function() {
                expect(typeof portContentFactory.setGroup).to.equal('function');
            });

            /**
             * @ngdoc method
             * @name InitPortContentFactory_setGroup_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.portContentFactory portContentFactory} is created with a setGroup
             *              function.
             */
            it('portContentFactory setGroup should be a typeof function', function() {
                expect(typeof portContentFactory.setGroup).to.equal('function');
            });

            var get2DPorts = function() {
                var newPortMocks = [
                    new viewerModelsFactory.PortObj(portMocks[0]),
                    new viewerModelsFactory.PortObj(portMocks[1]),
                    new viewerModelsFactory.PortObj(portMocks[2]),
                    new viewerModelsFactory.PortObj(portMocks[3])
                ];

                adaptPortNumber(newPortMocks);

                newPortMocks.forEach(function(port) {
                    port.active2D = true;
                });
                portContentFactory.setActivePort(newPortMocks[0]);

                portContentFactory.setConfig({
                    ports: newPortMocks
                });

                return newPortMocks;
            };

            /**
             * @ngdoc method
             * @name setGroup_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description These are tests for the setGroup function.
             */
            it('setGroup error case one: ', function() {

                var newPortMocks = [
                    new viewerModelsFactory.PortObj(portMocks[0]),
                    new viewerModelsFactory.PortObj(portMocks[1]),
                    new viewerModelsFactory.PortObj(portMocks[2]),
                    new viewerModelsFactory.PortObj(portMocks[3])
                ];

                portContentFactory.setConfig({
                    ports: newPortMocks
                });

                errorMsg = '';

                get2DPorts();

                portContentFactory.setGroup();
                expect(errorMsg).to.equal('groupCfg is not an object! It is not supported to call setGroup without a groupCfg object.', 'error should have been logged and was not.');

                var mockGroup = {
                    'imageType': 'unsupportedType'
                };
                portContentFactory.setGroup(mockGroup);
                expect(errorMsg).to.equal('groupCfg.imageType unsupportedType is not supported.');

                mockGroup = {
                    'imageType': '2D'
                };
                set2DGroupOnPortParams = {};
                portContentFactory.setActivePort({});
                portContentFactory.setGroup(mockGroup);

                mockGroup = {
                    'imageType': '3D'
                };
                set3DGroupOnPortParams = {};
                portContentFactory.setActivePort({});
                portContentFactory.setGroup(mockGroup, 1);
            });

            /**
             * @ngdoc method
             * @name synchronizeWindowing_setGroup_Test
             * @methodOf xjtweb-platform.provider:portContentFactory-test
             *
             * @description This test method determines if the synchronizeWindowing works correctly.
             */
            it('synchronizeWindowing should synchronize the windowing of the port regarding a reference one', function() {

                var newPortMocks = [
                    new viewerModelsFactory.PortObj(portMocks[0]),
                    new viewerModelsFactory.PortObj(portMocks[1])
                ];

                adaptPortNumber(newPortMocks);

                portContentFactory.setConfig({
                    ports: newPortMocks
                });
                portContentFactory.synchronizeWindowing(0);

                newPortMocks[0].viewPortObject = {};
                portContentFactory.setConfig({
                    ports: newPortMocks
                });
                portContentFactory.synchronizeWindowing(0);

                newPortMocks[0].groupId = 'groupId';
                portContentFactory.setConfig({
                    ports: newPortMocks
                });
                portContentFactory.synchronizeWindowing(0);

                newPortMocks[0].viewPortObject = {
                    renderEngine: {
                        getWindowLevel: sinon.spy(),
                        getWindowWidth: sinon.spy()
                    },
                    setWindowing: sinon.spy()
                };
                portContentFactory.setConfig({
                    ports: newPortMocks
                });
                portContentFactory.synchronizeWindowing(0);

                expect(newPortMocks[0].viewPortObject.renderEngine.getWindowLevel.called).to.equal(true);
                expect(newPortMocks[0].viewPortObject.renderEngine.getWindowWidth.called).to.equal(true);
                expect(newPortMocks[0].viewPortObject.setWindowing.called).to.equal(true);
            });
        });
    });
});
