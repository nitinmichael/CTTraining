/*
 *  message-field-directive-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jignesh Parekh<jignesh.parekh@ge.com>
 *  Monique Shotande<moniqueshotande@ge.com>
 */

/**
 * Spec file for Case Exchange > widgets > ge-control-group directive
 */
'use strict';

define(['angular', 'angular-mocks',
        'widgets/ge-control-group/ge-control-group-directive',
        'widgets/ge-form-submitted/ge-form-submitted-directive'],
    function () {
    'use strict';
    describe('GE Control Directive Test Suite::', function () {

        beforeEach(function () {
            // Load actual module
            module('Directives.geControlGroup');

            module('Directives.geFormSubmitted');

            // Load Templates
            module('templates');
        });

        describe('Directive fields', function() {
            var element, $compile, rootScope, scope, isolateScope, spy;

            beforeEach(
                inject(function (_$compile_, $rootScope) {

                    element = angular.element(
                        '<form name="exampleForm" ge-form-submitted>' +
                        '   <div>' +
                        '       <ge-control-group label="Example Field"' +
                        '           error-on-dirty="true"' +
                        '           success-on-dirty="true"' +
                        '           error-on-submit="true"' +
                        '           success-on-submit="true"' +
                        '           hide-validation="false"' +
                        '           tooltip-msg="Example Message">' +
                        '           <input control-group' +
                        '               id       ="example"' +
                        '               name     ="example"' +
                        '               type     ="text"' +
                        '               ng-model ="formData.example"' +
                        '               required>' +
                        '       </ge-control-group>' +
                        '   </div>' +
                        '</form>');


                    rootScope = $rootScope;
                    scope = $rootScope.$new();
                    $compile = _$compile_;

                    $compile(element)(scope);
                    var scopeToWatch = scope.$parent;
                    spy = sinon.spy(scopeToWatch, "$watch");
                    // fire all the watches, so the scope expressions will be evaluated
                    scope.$digest();
                    element.triggerHandler("submit");
                    isolateScope = element.find('div').eq(1).isolateScope();

                })
            );

            it('should have a directive', function () {
                assert.isDefined(element, 'Directive is not defined');
            });

            it('should have "scope" object', function () {
                assert.isDefined(isolateScope, 'directive scope doesn\'t exist');
            });

            // affirm all the scope variables are defined
            it('should have "label" object', function () {
                assert.isDefined(isolateScope.label, 'directive scope doesn\'t have "label" object defined');
            });

            it('should have "tooltipMsg" object', function () {
                assert.isDefined(isolateScope.tooltipMsg, 'directive scope doesn\'t have "tooltipMsg" object defined');
            });

            it('should have "errorOnSubmit" object', function () {
                assert.isDefined(isolateScope.errorOnSubmit, 'directive scope doesn\'t have "errorOnSubmit" object defined');
            });

            it('should have a "errorOnDirty" variable', function () {
                assert.isDefined(isolateScope.errorOnDirty, 'Directive scope doesn\'t have "errorOnDirty" variable defined');
            });

            it('should have "successOnDirty" object', function () {
                assert.isDefined(isolateScope.successOnDirty, 'directive scope doesn\'t have "successOnDirty" object defined');
            });

            it('should have "successOnSubmit" object', function () {
                assert.isDefined(isolateScope.successOnSubmit, 'directive scope doesn\'t have "successOnSubmit" object defined');
            });

            it('should have "hideValidation" object', function () {
                assert.isDefined(isolateScope.hideValidation, 'directive scope doesn\'t have "hideValidation" object defined');
            });

        });

        describe('Compiled directive', function() {
            var element, scope, isolateScope;

            beforeEach(
                inject(function ($compile, $rootScope) {

                    element = angular.element(
                        '<form name="exampleForm">' +
                        '   <div>' +
                        '       <ge-control-group label="Example Field"' +
                        '           error-on-dirty="false"' +
                        '           success-on-dirty="false"' +
                        '           error-on-submit="false"' +
                        '           success-on-submit="false"' +
                        '           hide-validation="false"' +
                        '           tooltip-msg="Example Message">' +
                        '           <input control-group' +
                        '               id       ="example"' +
                        '               name     ="example"' +
                        '               type     ="text"' +
                        '               ng-model ="formData.example"' +
                        '               required>' +
                        '       </ge-control-group>' +
                        '   </div>' +
                        '</form>');



                    scope = $rootScope.$new();

                    $compile(element)(scope);
                    // fire all the watches, so the scope expressions will be evaluated
                    scope.$digest();
                    isolateScope = element.find('div').eq(1).isolateScope();

                })
            );
        });
    });

});
