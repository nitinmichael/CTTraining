define(['angular'], function(angular) {
    angular.module('imagingToolbarFactoryMock', []).factory('imagingToolbarFactory', function() {
        var json = {
            "title": "Imaging toolbar",
            "type": "simple-bar",
            "buttons": [{
                "id": "invert_button",
                "Name": "SET_MOUSEMODE_INVERT",
                "title": "mousemanagement.invert",
                "icon": {
                    "url": "./modules/viewer/modules/mousemanagement/images/icons/ViewerIcons_icon_Invert.svg"
                },
                "class": "right-toolbar-btn",
                "groupPanel": {
                    "id": "invert_button-group-panel",
                    "url": "./modules/platform/directives/toolBox/collapsed-btns-template.html",
                    "title": "Collapsed buttons popover",
                    "type": "popover",
                    "alignment": "vertical"
                }
            }, {
                "id": "multiplanar_button",
                "Name": "MILTIPLANAR",
                "title": "mousemanagement.multiplanar",
                "icon": {
                    "url": "./modules/viewer/modules/mousemanagement/images/icons/ViewerIcons_icon_Curs.svg"
                },
                "class": "right-toolbar-btn"
            }, {
                "id": "measuredistance_button",
                "Name": "MEASUREDISTANCE",
                "title": "mousemanagement.measuredistance",
                "icon": {
                    "url": "./modules/viewer/modules/mousemanagement/images/icons/ViewerIcons_icon_Meas.svg"
                },
                "class": "right-toolbar-btn"
            }, {
                "id": "cut_button",
                "Name": "CUT",
                "title": "mousemanagement.cut",
                "icon": {
                    "url": "./modules/viewer/modules/mousemanagement/images/icons/ViewerIcons_icon_CutPlane.svg"
                },
                "panel": {
                    "id": "imaging-tools-cutPlanes-panel",
                    "url": "./modules/viewer/modules/mousemanagement/widgets/templates/cutPlanesPanel.html",
                    "title": "Cut Planes Popover",
                    "type": "popover",
                    "alignment": "vertical"
                },
                "class": "right-toolbar-btn",
                "parentId": "invert_button"
            }, {
                "id": "color_button",
                "name": "COLOR",
                "title": "mousemanagement.color",
                "icon": {
                    "url": "./modules/viewer/modules/mousemanagement/images/icons/ViewerIcons_icon_Color.svg"
                },
                "panel": {
                    "id": "imaging-tools-color-panel",
                    "url": "./modules/viewer/modules/mousemanagement/widgets/templates/colorMapPanel.html",
                    "title": "Color Map Popover",
                    "type": "popover",
                    "alignment": "vertical"
                },
                "class": "right-toolbar-btn",
                "parentId": "invert_button"
            }, {
                "id": "eye_button",
                "name": "EYE",
                "title": "Volume renderer view",
                "icon": {
                    "url": "./modules/viewer/modules/mousemanagement/images/icons/ViewerIcons_icon_EyeActive.svg"
                },
                "panel": {
                    "id": "imaging-tools-eye-panel",
                    "url": "./modules/viewer/modules/mousemanagement/widgets/templates/eyeMapPanel.html",
                    "title": "Eye Map Popover",
                    "type": "popover",
                    "alignment": "vertical"
                },
                "class": "right-toolbar-btn",
                "parentId": "invert_button"
            }]

        };
        return {
            success: function(callback) {
                callback(json);
            }
        };
    });
});
