/*
 * mdt-session-presentation-details-controller-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/**
 * Created by 212408578 on 2015.11.17..
 */

define(['angular', 'angular-mocks', 'ng-sortable', 'mdt/modules/mdt-session-management/controllers/mdt-session-details-controller'], function () {
    'use strict';

    describe('MDT Session Presentation test cases ::', function () {
        var scope, stateParams, state, controller, MdtSessionPresentationService, MdtSessionDataService, NotificationService, successHandler, errorHandler, rootScope,
            broadcastCallbacks = {},
            getCaseSuccess, getCaseError,
            reviewedSuccess, reviewedError;

        beforeEach(function () {
            module('Mdt.Module.MdtSessionPresentationController', function ($provide) {
                $provide.value('MdtSessionPresentationService', {
                    then: function(fn){
                        fn({
                            getDetails: function (id, success, error) {
                                successHandler = success;
                                errorHandler   = error;
                                return {caseList : []};
                            },
                            getCaseDetails: function(sessionid, caseid, success, error){
                                getCaseSuccess = success;
                                getCaseError   = error;
                                return {};
                            },
                            markCaseAsReviewed: function(sessionId, caseID, caseComment, success, error){
                                reviewedSuccess = success;
                                reviewedError   = error;
                            }
                        });
                    }
                });
                $provide.value('NotificationService', {
                    addErrorMessage: sinon.spy()
                });
            });
        });

         describe('Presentation details controller', function(){
            beforeEach(function(){
                module('Mdt.Module.MdtSessionDataService');
                inject(function ($rootScope, $controller, _MdtSessionPresentationService_,_MdtSessionDataService_, _NotificationService_) {
                    var state, stateParams, MdtSessionPresentationService, MdtSessionDataService;
                    scope = $rootScope.$new();
                    state = {
                        transitionTo: sinon.spy(),
                        go: sinon.spy()
                    };
                    stateParams = { sessionId: 6677, caseId: 3344 };
                    MdtSessionPresentationService = _MdtSessionPresentationService_;
                    MdtSessionDataService = _MdtSessionDataService_;
                    NotificationService = _NotificationService_;
                    var session = {
                        meetingId: 6677,
                        cases: [
                            {id: 1122,
                                outcome: 'outcome1122'},
                            {id: 3344,
                                outcome: 'outcome3344'}
                        ]
                    };
                    MdtSessionDataService.updateItemList(session.cases);
                    MdtSessionDataService.retrieveSelectedItem(3344);
                    state = {
                        transitionTo: sinon.spy()
                    };
                    rootScope = {
                        $broadcast: sinon.spy(),
                        $on: function(name, fn){
                            broadcastCallbacks[name] = fn;
                        }
                    };
                    //Initialize the controller
                    controller =
                        $controller('MdtSessionPresentationDetailsController', {
                            $scope: scope,
                            $state: state,
                            $stateParams: stateParams,
                            $rootScope: rootScope,
                            MdtSessionPresentationService: MdtSessionPresentationService,
                            MdtSessionDataService: MdtSessionDataService,
                            NotificationService: NotificationService
                        });
                });
            });

            it("should be defined", function () {
                assert.isDefined(controller, 'List controller is not defined');
            });

            it('should handle received case details', function(){
                var result = {
                    data: {
                        id: 3344,
                        status: 'IN_REVIEW',
                        ceCase: {}
                    }
                };

                expect(scope.fetchingCaseDetails).to.be.true;

                getCaseSuccess(result);

                expect(scope.fetchingCaseDetails).to.be.false;
                expect(scope.case.ceCase).to.be.equal(result.data.ceCase);
            });

            it('should handle received case details error', function(){

                expect(scope.fetchingCaseDetails).to.be.true;

                getCaseError();

                expect(scope.fetchingCaseDetails).to.be.false;
                expect(NotificationService.addErrorMessage.calledWith("Could not access Case details, please try again.")).to.be.true;
            });

            it('should handle marking case reviewed', function(){
                console.log('should handle marking case reviewed');
                expect(scope.markingCaseAsReviewed).to.be.false;

                scope.case = {outcome: 'outcome'};
                scope.markReviewed();

                expect(scope.markingCaseAsReviewed).to.be.true;

                reviewedSuccess();
                expect(scope.case.status).to.equal('CLOSED');
            });

            it('should handle marking case reviewed error', function(){
                expect(scope.markingCaseAsReviewed).to.be.false;

                scope.case = {outcome: 'outcome'};
                scope.markReviewed();

                expect(scope.markingCaseAsReviewed).to.be.true;

                reviewedError();
                expect(scope.markingCaseAsReviewed).to.be.false;
                expect(NotificationService.addErrorMessage.calledWith("Could not mark case as reviewed, please try again.")).to.be.true;
            });

            it('should create a dummy patient', function() {
                var dummyPatient = scope.prepareDummyPatient();
                expect(dummyPatient).to.exist;
                expect(dummyPatient.name).to.be.equal("");

                var subject = "SOS case";
                scope.case = {
                    ceCase: {
                        subject: subject
                    }
                };
                dummyPatient = scope.prepareDummyPatient();
                expect(dummyPatient).to.exist;
                expect(dummyPatient.name).to.be.equal(subject);
            })
        });
    });
});
