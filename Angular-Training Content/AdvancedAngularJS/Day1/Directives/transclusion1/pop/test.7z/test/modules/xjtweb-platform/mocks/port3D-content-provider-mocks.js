angular.module('port3DContent-test-mocks', []).constant('TestMocks', {

    $xjtwebMock: function() {

        return {
            XJTWEB: {
                volumeRenderEngine: function() {},
                T3DViewport: function() {},
                RmVolume: {
                    create: function() {}
                },
                ServiceLocator: {
                    resolve: function() {
                        return {
                            publish : function() {}
                        };
                    }
                },
                SERVICE: {
                    GMC: 'GMC' // Global Messaging Channel
                },
                GMC: {
                    CHANNEL: 'GMC_CHANNEL',
                    TOPIC: {
                        ALL: 'GMC.*.*',
                        VIEWPORT: {
                            SWITCH: "GMC.VIEWPORT.SWITCH",
                            UPDATE: 'GMC.VIEWPORT.UPDATE',
                            IMAGE_UPDATED: 'GMC.VIEWPORT.IMAGE_UPDATED'
                        }
                    }
                }
            },

            CameraFactory: {
                createOrthographicCamera: function() {}
            }
        };
    },

    $windowResizeServiceMock: function() {

        return {

        };
    },

    PortContentMock: function() {

        return {

        };
    },

    SceneManagerMock: function() {

        return {
            requestRender: sinon.spy()
        };
    },

    annotStateServiceMock: function() {

        return {

        };
    },

    MeasureManagerMock: function() {

        return {

        };
    },

    linkingManagerMock: function() {

        return {

        };
    },
    renderingServiceMock: function() {

        return {

        };
    },
    CursorManagerMock: function() {

        return {

        };
    }

});
