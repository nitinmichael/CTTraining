define(['angular',
        'angular-mocks',
        'orgMgmnt/features/organization/organizationDetail/orgDetailModule'
    ],
    function(ng) {
        'use strict';

        describe('Test OrgDetailModule file', function(){
            var _rootScope, _stateProvider;

            beforeEach(function() {
                module('Orgmanagement.Features.Organization.OrganizationDetail.OrgDetailModule'),function($stateProvider) {
                    _stateProvider = $stateProvider;
                }
            });

            it('should load the page.', inject(function($state){
                chai.expect($state).to.exist;
            }));
        });
    }
);