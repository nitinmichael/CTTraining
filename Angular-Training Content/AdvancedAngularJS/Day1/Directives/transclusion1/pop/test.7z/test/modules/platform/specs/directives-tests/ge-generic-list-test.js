/*
 * ge-generic-list-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define([
    'jquery',
    'angular-mocks', 
    'modules/platform/directives/ge-generic-list/ge-generic-list-directive'
], function(jQuery) {
    'use strict';

    describe('Generic list controller', function () {
        var scope, $controller, controller;

        beforeEach(module('Platform.Directive.GenericList'));
        beforeEach(function () {
            inject(function ($rootScope, _$controller_) {
                scope = $rootScope.$new();
                $controller = _$controller_;
                controller = _$controller_('geGenericListController', {
                    $scope: scope
                });
            });
        });

        it("should have a controller defined", function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it('should check if there is invalid data loaded', function(){
            expect(scope.hasInvalidData).is.not.undefined;
            expect(scope.hasInvalidData()).to.be.true;
            scope.loadingInProgress = true;
            expect(scope.hasInvalidData()).to.be.false;
            scope.loadingInProgress = false;
            scope.data = [];
            expect(scope.hasInvalidData()).to.be.true;
        });

        it('should handles click event', function(){
            expect(scope.selectedItemId).to.be.undefined;
            expect(scope.selectedItem).to.be.undefined;
            var testObject = {test: "object"};
            scope.itemClicked(123, testObject);
            expect(scope.selectedItemId).to.be.equal(123);
            expect(scope.selectedItem).to.be.equal(testObject);
            expect(scope.selectedItemObj).to.be.undefined;
            scope.selectedItemObj = {
                value: 0,
                selectedItem: null
            };
            var testObject2 = {test: "object2"};
            scope.itemClicked(321, testObject2);
            expect(scope.selectedItemId).to.be.equal(321);
            expect(scope.selectedItem).to.be.equal(testObject2);
            expect(scope.selectedItemObj.value).to.be.equal(321);
            expect(scope.selectedItemObj.selectedItem).to.be.equal(testObject2);
        });

        it('should watches external selected item obj', function(){
            scope.selectedItemObj = {
                value: 0,
                selectedItem: null
            };

            controller = $controller('geGenericListController', {
                $scope: scope
            });

            var testObject = {test: "object"};
            var testObject2 = {test: "object2"};
            scope.data = [testObject, testObject2];
            scope.selectedItemObj.value = 1;
            scope.$digest();
            expect(scope.selectedItemId).to.be.equal(1);
            expect(scope.selectedItem).to.be.equal(testObject2);
        });

    });

    describe('Generic list directive', function() {
        var $compile;
        var $rootScope;

        var scope;
        var element;

        beforeEach(module('templates'));
        beforeEach(module('Platform.Directive.GenericList', function ($provide) {
            ['translateFilter'].forEach(function(f){
                $provide.value(f, function(val){
                    return val;
                });
            });
        }));

        beforeEach(inject(function(_$compile_, _$rootScope_) {
            $compile = _$compile_;
            $rootScope = _$rootScope_;

            scope = $rootScope.$new();
            element = $compile("<ge-generic-list></ge-generic-list>")(scope);
            $rootScope.$digest();
        }));

        it('should be defined', function() {
            var html = element.html();
            expect(html).to.have.length.of.at.least(1);
        });

        it('should expose an API', function () {
            expect(element.isolateScope().api).to.be.instanceof(Object);
        });

        it('should define the resetScroll API method', function () {
            expect(element.isolateScope().api.resetScroll).to.be.instanceof(Function);
            var findSpy = sinon.spy(jQuery.fn, 'find');
            var scrollTopSpy = sinon.spy(jQuery.fn, 'scrollTop');
            
            element.isolateScope().api.resetScroll();

            expect(findSpy.calledWith('.ge-generic-list-container')).to.be.true;
            expect(scrollTopSpy.calledWith(0)).to.be.true;

            jQuery.fn.find.restore();
            jQuery.fn.scrollTop.restore();
        });

        it('should define the scrollTo API method', function () {
            expect(element.isolateScope().api.scrollTo).to.be.instanceof(Function);
            var findSpy = sinon.spy(jQuery.fn, 'find');
            var scrollTopSpy = sinon.spy(jQuery.fn, 'scrollTop');
            var stub = sinon.stub(jQuery.fn, 'offset');
            
            element.isolateScope().api.scrollTo();

            expect(findSpy.called).to.be.false;
            expect(scrollTopSpy.called).to.be.false;

            stub.onFirstCall().returns({ top: 400 }).onSecondCall().returns({ top: 300 });

            element.isolateScope().api.scrollTo(2);

            expect(findSpy.calledWith('.ge-generic-list-container')).to.be.true;
            expect(findSpy.calledWith('.ge-generic-list-item:nth-child(' + 3 + ')')).to.be.true;

            expect(scrollTopSpy.calledTwice).to.be.true;
            expect(scrollTopSpy.calledWith(100)).to.be.true;

            jQuery.fn.find.restore();
            jQuery.fn.scrollTop.restore();
            stub.restore();
        });
    });
});
