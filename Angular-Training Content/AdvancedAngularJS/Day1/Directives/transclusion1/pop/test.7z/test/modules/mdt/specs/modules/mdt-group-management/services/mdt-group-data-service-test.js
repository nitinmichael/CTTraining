/*
 * mdt-group-data-service-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/**
 * Created by 212408578 on 2015.11.03..
 */

define(['angular', 'angular-mocks', 'mdt/services/mdt-group-data-service', 'mdt/services/mdt-list-details-service'], function () {
    'use strict';
    describe("MdtGroupDataService ", function () {
        var MdtGroupDataService;

        beforeEach(function () {
            module('Mdt.Module.MdtGroupDataService');

            inject(function (_MdtGroupDataService_) {
                MdtGroupDataService = _MdtGroupDataService_;
            });
        });

        it("should return empty object when retrieveSelectedItem called with groupId = null", function () {
            var selectedGroup = MdtGroupDataService.retrieveSelectedItem(null);
            expect(selectedGroup).to.be.empty;
        });

        it("MDT Group List should be empty in the beginning - query for certain groups should return empty", function () {
            var GROUP_ID_1 = "groupdId 1";
            var selectedGroup = MdtGroupDataService.retrieveSelectedItem(GROUP_ID_1);
            expect(selectedGroup).to.be.empty;
        });

        it("should return the given MDT Group List when updateItemList is called", function () {
            var GROUP_ID_2 = "groupdId 2";
            var TEST_DATA = "test data";
            var newGroupList = [{groupId: "groupdId 1"},
                {groupId: GROUP_ID_2,
                    testData: TEST_DATA},
                {groupId: "groupdId 3"}];
            var returnedGrupList = MdtGroupDataService.updateItemList(newGroupList);
            expect(returnedGrupList).to.be.equal(newGroupList);
        });

        it("should update MDT Group List with the given list so that I can retrieve a certain group by groupId", function () {
            var GROUP_ID_2 = "groupdId 2";
            var TEST_DATA = "test data";
            var newGroupList = [{groupId: "groupdId 1"},
                {groupId: GROUP_ID_2,
                    testData: TEST_DATA},
                {groupId: "groupdId 3"}];
            MdtGroupDataService.updateItemList(newGroupList);
            var selectedGroup = MdtGroupDataService.retrieveSelectedItem(GROUP_ID_2);
            expect(selectedGroup.testData).to.be.equal(TEST_DATA);
        });

        it("should return null object when getSelectedItemObj called before initialization", function () {
            var selectedItemObj = MdtGroupDataService.getSelectedItemObj();
            expect(selectedItemObj.selectedItem).to.be.null;
            expect(selectedItemObj.value).to.be.null;
        });

        it("should return the ordinal of the last selected item after updating MDT Group List and retrieving a certain object", function () {
            var GROUP_ID_2 = "groupdId 2";
            var TEST_DATA = "test data";
            var newGroupList = [{groupId: "groupdId 1"},
                {groupId: GROUP_ID_2,
                 testData: TEST_DATA},
                {groupId: "groupdId 3"}];
            var ordinalOfGroup2 = 1; //group 1 has ordinal 0, etc...
            MdtGroupDataService.updateItemList(newGroupList);
            var retrieved = MdtGroupDataService.retrieveSelectedItem(GROUP_ID_2);
            var selectedItemObj = MdtGroupDataService.getSelectedItemObj();
            expect(selectedItemObj.value).to.be.equal(ordinalOfGroup2);
        });

        it("should return null after updating MDT Group List and retrieving null", function () {
            var GROUP_ID_2 = "groupdId 2";
            var TEST_DATA = "test data";
            var newGroupList = [{groupId: "groupdId 1"},
                {groupId: GROUP_ID_2,
                    testData: TEST_DATA},
                {groupId: "groupdId 3"}];
            MdtGroupDataService.updateItemList(newGroupList);
            var retrieved = MdtGroupDataService.retrieveSelectedItem(null);
            var selectedItemObj = MdtGroupDataService.getSelectedItemObj();
            expect(selectedItemObj.value).to.be.null;
            expect(selectedItemObj.selectedItem).to.be.null;
        });

        it("should override selected group object after updateItemDetails called", function () {
            var GROUP_ID_2 = "groupdId 2";
            var TEST_DATA = "test data";
            var newGroupList = [{groupId: "groupdId 1"},
                {groupId: GROUP_ID_2,
                    testData: TEST_DATA},
                {groupId: "groupdId 3"}];
            MdtGroupDataService.updateItemList(newGroupList);
            MdtGroupDataService.retrieveSelectedItem(GROUP_ID_2);
            var GROUP_ID_4 = "groupdId 4";
            var TEST_DATA_2 = "test data 2";
            var newGroupDetails = {
                groupId: GROUP_ID_4,
                testData: TEST_DATA_2
            };
            MdtGroupDataService.updateItemDetails(newGroupDetails);
            var retrieved = MdtGroupDataService.retrieveSelectedItem(GROUP_ID_4);
            expect(retrieved.testData).to.be.equal(TEST_DATA_2);
        });

        it("should return empty object after updateItemDetails called with null object", function () {
            var GROUP_ID_2 = "groupdId 2";
            var TEST_DATA = "test data";
            var newGroupList = [{groupId: "groupdId 1"},
                {groupId: GROUP_ID_2,
                    testData: TEST_DATA},
                {groupId: "groupdId 3"}];
            MdtGroupDataService.updateItemList(newGroupList);
            var retrieved = MdtGroupDataService.retrieveSelectedItem(null);
            expect(retrieved).to.be.empty;
        });
    });
});
