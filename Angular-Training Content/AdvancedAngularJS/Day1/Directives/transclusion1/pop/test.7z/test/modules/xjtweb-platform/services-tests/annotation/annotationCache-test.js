define([ 'angular-mocks', 'modules/xjtweb-platform/services/annotation/annotationCache' ], function() {
    describe('annotationCache tests', function() {
        var annotationCacheFactory;

        beforeEach(module('xjtweb.platform.service.annotationCache'));

        beforeEach(inject(function(_annotationCacheFactory_) {
            annotationCacheFactory = _annotationCacheFactory_;
        }));

        it('has a factory', function() {
            expect(annotationCacheFactory).to.exist;
        })

        it('works with size=2', function() {
            var objects = {
                a : 'A',
                b : 'B',
                c : 'C'
            };

            var createCallback = function(strKey, objKey, doneCB) {
                doneCB(null, objects[strKey]);
            }
            var spiedCB = sinon.spy(createCallback);

            var cache = annotationCacheFactory.create(2, spiedCB);

            var getCB = sinon.spy();

            cache.get('a', {}, getCB);
            getCB.lastCall.args[0].should.equal('A');
            spiedCB.callCount.should.equal(1);

            cache.get('b', {}, getCB);
            getCB.lastCall.args[0].should.equal('B');
            spiedCB.callCount.should.equal(2);

            cache.get('a', {}, getCB);
            getCB.lastCall.args[0].should.equal('A');
            // A is already cached
            spiedCB.callCount.should.equal(2);

            cache.get('c', {}, getCB);
            getCB.lastCall.args[0].should.equal('C');
            spiedCB.callCount.should.equal(3);

            cache.get('a', {}, getCB);
            getCB.lastCall.args[0].should.equal('A');
            // A was expelled, now it had to be loaded again
            spiedCB.callCount.should.equal(4);

            cache.get('a', {}, getCB);
            getCB.lastCall.args[0].should.equal('A');
            // A is cached again
            spiedCB.callCount.should.equal(4);
        });

        it('works with size=0', function() {
            var objects = {
                a : 'A',
                b : 'B',
                c : 'C'
            };

            var createCallback = function(strKey, objKey, doneCB) {
                doneCB(null, objects[strKey]);
            }
            var spiedCB = sinon.spy(createCallback);

            var cache = annotationCacheFactory.create(0, spiedCB);

            var getCB = sinon.spy();

            cache.get('a', {}, getCB);
            getCB.lastCall.args[0].should.equal('A');
            spiedCB.callCount.should.equal(1);

            cache.get('a', {}, getCB);
            getCB.lastCall.args[0].should.equal('A');
            // cache is off:
            spiedCB.callCount.should.equal(2);
        });

        it('can be cleared', function() {
            var objects = {
                a : 'A',
                b : 'B',
                c : 'C'
            };

            var createCallback = function(strKey, objKey, doneCB) {
                doneCB(null, objects[strKey]);
            }
            var spiedCB = sinon.spy(createCallback);

            var cache = annotationCacheFactory.create(25, spiedCB);

            var getCB = sinon.spy();

            cache.get('a', {}, getCB);
            getCB.lastCall.args[0].should.equal('A');
            spiedCB.callCount.should.equal(1);

            cache.get('a', {}, getCB);
            getCB.lastCall.args[0].should.equal('A');
            spiedCB.callCount.should.equal(1);

            cache.clear();

            cache.get('a', {}, getCB);
            getCB.lastCall.args[0].should.equal('A');
            spiedCB.callCount.should.equal(2);

            cache.get('a', {}, getCB);
            getCB.lastCall.args[0].should.equal('A');
            spiedCB.callCount.should.equal(2);
        });

        it('handles undefined values', function() {
            var objects = {
                a : 'A',
                b : 'B',
                c : 'C'
            };

            var createCallback = function(strKey, objKey, doneCB) {
                doneCB(null, objects[strKey]);
            }
            var spiedCB = sinon.spy(createCallback);

            var cache = annotationCacheFactory.create(2, spiedCB);

            var getCB = sinon.spy();

            cache.get('x', {}, getCB);
            expect(getCB.lastCall.args[0]).to.not.exist;
            spiedCB.callCount.should.equal(1);
        });

        it('does not cache error fallback value', function() {

            var createCallback = function(strKey, objKey, doneCB) {
                var errorFallback = 'X';
                doneCB({value:errorFallback}, null);
            }
            var spiedCB = sinon.spy(createCallback);
            var cache = annotationCacheFactory.create(2, spiedCB);

            var getCB = sinon.spy();

            cache.get('a', {}, getCB);
            getCB.lastCall.args[0].should.equal('X');
            spiedCB.callCount.should.equal(1);

            cache.get('a', {}, getCB);
            getCB.lastCall.args[0].should.equal('X');
            // cache is off:
            spiedCB.callCount.should.equal(2);

        });

        it('aggregates pending requests', function() {

            var createCallback = sinon.spy();
            var cache = annotationCacheFactory.create(2, createCallback);

            var getCB = sinon.spy();

            cache.get('a', {}, getCB);
            createCallback.callCount.should.equal(1); // creation was attempted
            getCB.callCount.should.equal(0); // the create callback did not do anything

            cache.get('a', {}, getCB);
            createCallback.callCount.should.equal(1); // no change, i.e. the get request was aggregated
            getCB.callCount.should.equal(0); // the create callback still did not do anything

            var creationDoneCB = createCallback.lastCall.args[2];
            creationDoneCB(null, 'A');

            getCB.callCount.should.equal(2); // the callbacks did fire
            getCB.args[0][0].should.equal('A');
            getCB.args[1][0].should.equal('A');

            //the request is discarded
            Object.keys(cache.pendingCreateRequests).length.should.equal(0);

        });

    });
});