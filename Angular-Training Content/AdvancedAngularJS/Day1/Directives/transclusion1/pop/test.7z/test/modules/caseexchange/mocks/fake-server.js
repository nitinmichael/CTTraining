/*  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jignesh Parekh<jignesh.parekh@ge.com>
 */


define(['angular'], function(angular){
    /**
     * Module to initialize & configure the Sinon fake server
     */
    var mod = angular.module('cloudav.caseExchange.fakeServer', []);

    /**
     * Provider for Sinon Mock Server.
     * It also contains the methods to fake the server response
     */
    mod.provider('$MockServerLoader', function(){
        var mockLoader, mockServer;

        /**
         * Initilization function.
         * This will initialize the Sinon server.
         */
        this.init = function () {
            // Creating a fake server
            mockServer = sinon.fakeServer.create();
            return mockServer;
        };
        /**
         * Function to fake the CaseExchangeDataService > queryCurrentUser call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  data: Mock data to be returned in service response
         */
        this.fakeQueryCurrentUserCall = function(responseStatus, data){
            mockServer.respondWith('GET', '/userregistry/v1/user/me?level.value=2', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || {})]);
        };
        /**
         * Function to fake the CaseDataService > getCaseDetails call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  mockData: Mock data to be returned in service response
         */
        this.fakeCaseDetailsCall = function(responseStatus, data){
            mockServer.respondWith('GET', '/casereader/v1/case/1', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data)]);
        };

        /**
         * Function to fake the CreateCaseService > createTransaction call.
         * @params:
         *  caseId: Selected case ID. This will be appended in URL.
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  data: Mock data to be returned in service response
         */
        this.fakeCreateTransactionCall = function(caseId, responseStatus, data){
            mockServer.respondWith('POST', '/casewriter/v1/case/'+ caseId +'/transaction', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || {})]);
        };

        /**
         * Function to fake the CreateCaseService > createCase call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  data: Mock data to be returned in service response
         */
        this.fakeCreateCaseCall = function(responseStatus, data){
            mockServer.respondWith('POST', '/casewriter/v1/case', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || {})]);
        };

        /**
         * Function to fake the Download to Premise > downloadCaseAttachment call.
         * @params:
         *  caseId: Selected case ID. This will be appended in URL.
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  data: Mock data to be returned in service response
         */
        this.fakeDownloadCaseAttachment = function(caseId, responseStatus, data){
            mockServer.respondWith('POST', '/caseattachment/v1/case/'+ caseId +'/attachment/store', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || {})]);
        };
	
	/**
         * Function to fake the CreateCaseService > patchAttachment call.
         * @params:
         *  caseId: Selected case ID. This will be appended in URL.
         *  attachmentId: Selected attachment ID. This will be appended in URL.
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  mockData: Mock data to be returned in service response
         */
        this.fakePatchAttachmentCall = function(caseId, attachmentId, responseStatus, data){
            mockServer.respondWith('PATCH', '/casewriter/v1/case/' + caseId + "/attachment/" + attachmentId, [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || {})]);
        };

        /**
         * Function to fake the CreateCaseService > uploadCaseAttachment call.
         * @params:
         *  caseId: Selected case ID. This will be appended in URL.
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  data: Mock data to be returned in service response
         */
        this.fakeUploadCaseAttachmentCall = function(caseId, responseStatus, data){
            mockServer.respondWith('POST', '/caseattachment/v1/case/'+ caseId + '/attachment/retrieve', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || {})]);
        };

        /**
         * Function to fake the GetPacsService > getPacsDevices call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  data: Mock data to be returned in service response
         */
        this.fakeGetPacsDevicesCall = function(responseStatus, data){
            mockServer.respondWith('GET', '/v1/user/me/applicationservice?level.value=1', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || {})]);
        };

        /**
         * Function to fake the ClinicalReasonsService > getClinicalReasons call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  mockData: Mock data to be returned in service response
         */
        this.fakeClinicalReasonsCall = function(responseStatus, data){
            mockServer.respondWith('GET', '/casereader/v1/case/clinicalreasons', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data)]);
        };

        /**
         * Function to fake the GetBillingOrganizationsService > getOrganizationsForLoggedInUser call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  mockData: Mock data to be returned in service response
         */
        this.fakeGetBillingOrganizationsCall = function(responseStatus, data){
            mockServer.respondWith('GET', '/v1/user/me/organization', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data)]);
        };

        /**
         * Function to fake the PacsSearchService > pacsSearch call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  mockData: Mock data to be returned in service response
         */
        this.fakePacsSearchCall = function(responseStatus, data){
            mockServer.respondWith('POST', '/patientstudyquery/v1/patient/search', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || null)]);
        };

        /**
         * Function to fake the NormalizationService > normalizeSave call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  mockData: Mock data to be returned in service response
         */
        this.fakeNormalizeSaveCall = function(responseStatus, data){
            mockServer.respondWith('POST', '/caseattachment/v1/case/0/attachment/store', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || null)]);
        };

        /**
         * Function to fake the StudyListService > studyList call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  mockData: Mock data to be returned in service response
         */
        this.fakeStudyListCall = function(responseStatus, data){
            mockServer.respondWith('POST', '/patientstudyquery/v1/study/search', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || null)]);
        };

        /**
         * Function to fake the /me call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  mockData: Mock data to be returned in service response
         */
        this.fakeMeServiceCall = function(responseStatus, data){
            mockServer.respondWith('GET', '/userregistry/v1/user/me?level.value=2', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || null)]);
        };

        /**
         * Function to fake the GetSitesServices > getSiteList call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  data: Mock data to be returned in service response
         */
        this.fakeGetSiteListCall = function(responseStatus, data){
            mockServer.respondWith('GET', '/v1/user/me/site?role=administrator&level.value=2', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || {})]);
        };

        /**
         * Function to fake the CaseAutomationService > getCaseAutomationInstructions call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  data: Mock data to be returned in service response
         */
        this.fakeInstructionListCall = function(responseStatus, data){
            mockServer.respondWith('GET', '/caseautomation/v1/instruction?limit=10&offset=10&siteId=10', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || {})]);
        };

        /**
         * Function to fake the CaseAutomationService > caseInstructionCurdOperation call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  data: Mock data to be returned in service response
         */
        this.fakeInstructionCurdOperationCall = function(operation, responseStatus, data, url){
            mockServer.respondWith(operation, url, [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || {})]);
        };

        /**
         * Function to fake the GetInstructionConditionsService > getConditionKeyList call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  data: Mock data to be returned in service response
         */
        this.fakeGetConditionKeyListCall = function(responseStatus, data){
            mockServer.respondWith('GET', '/caseautomation/v1/instruction/dicomattributes', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data || {})]);
        };

        /**
         * Override method for AngularJS Provider
         * @returns:
         *  mockLoader: Mock provider.
         */
        this.$get = function(){
            if(!mockLoader){
                mockLoader = this;
            }
            return mockLoader;
        };
    });
});
