define(['angular',
    'angular-mocks',
    'orgMgmnt/features/organization/viewOrganization/controllers/viewOrganizationController',
    'orgMgmnt/dataModels/organizationDataModel',
    'orgMgmnt/services/organizationService',
    'orgMgmnt/widgets/ge-exception-handler/geExceptionHandler',
    'orgMgmnt/services/userService'
], function(ng){
    'use strict';

    describe('Test View Organization Controller ', function(){
        var ViewOrganizationCtrl, scope, _log, _q, multipleOrgDetailsDeferred,loggedInUserDetailsDeffered, _orgDataModel, _orgMgmtService,
            getAllOrg, _rootScope, _state,_messageObj,_$timeout,_userService, loggedInUserResult, orgListDeffered,
            siteListDeffered, getAllSite, getMultipleOrgDetails, orgList, findOrgDeferred;

        beforeEach(function () {

            module('Orgmanagement.Features.Organization.ViewOrganization.ViewOrganizationController');
            module('Orgmanagement.DataModel.OrgDataModel');
            module('Orgmanagement.Services.OrganizationService');
            module('ui.router');
            module('geExceptionHandlerModule');
            module('Orgmanagement.Services.UserService');
            module('Orgmanagement.Utilities.MasterData');
        });

        beforeEach(function(){
            getAllOrg=JSON.parse(JSON.stringify({"resourceType": "Bundle","title": " List of Organizaitons for user Id : e8c93e28-72fc-4d0b-98b5-dd0d13bdff2d","id": null,"entry": [{"title": null,"id": "f9e2dfa7-e6e0-485a-947b-7110a6acba96","content": {"resourceType": "Organization","identifier": [{"system": "urn:hc.ge.com/pfh/platform/identifier","value": "b6ae9922-21c1-4e89-a3b2-9b056a640047"},{"_id": "f9e2dfa7-e6e0-485a-947b-7110a6acba96","system": "urn:hc.ge.com/pfh/platform/orgtype"}],"name": "TestEmail","type": {"coding": [{"system": "urn:hc.ge.com/pfh/platform/orgtype","code": "ORG","display": "Organization"}]},"telecom": [{"system": "phone","value": "1325412"}],"address": [{"line": ["TestEmail","TestEmail"],"city": "TestEmail","state": "AZ","zip": "123546","country": "US"}],"contact": [{"name": {"text": "TestEmail"},"telecom": [{"system": "phone","value": "1234565"},{"system": "email","value": "TestEmail@g"}]}]}},{"title": null,"id": "7828fed5-fc42-4ba0-934b-8947a4811862","content": {"resourceType": "Organization","identifier": [{"system": "urn:hc.ge.com/pfh/platform/identifier","value": "b6ae9922-21c1-4e89-a3b2-9b056a640047"},{"_id": "7828fed5-fc42-4ba0-934b-8947a4811862","system": "urn:hc.ge.com/pfh/platform/orgtype"}],"name": "Org_Ketan","type": {"coding": [{"system": "urn:hc.ge.com/pfh/platform/orgtype","code": "ORG","display": "Organization"}]},"telecom": [{"system": "phone","value": "1234567"}],"address": [{"line": ["Mumbai"],"city": "Mumbai","state": "AL","zip": "23424","country": "US"}],"contact": [{"name": {"text": "Ketan"},"telecom": [{"system": "phone","value": "5646566"},{"system": "email","value": "ketan@ge.com"}]}]}},{"title": null,"id": "28f53f0b-8abe-4b0a-9459-29eb4775dd98","content": {"resourceType": "Organization","identifier": [{"system": "urn:hc.ge.com/pfh/platform/identifier","value": "b6ae9922-21c1-4e89-a3b2-9b056a640047"},{"_id": "28f53f0b-8abe-4b0a-9459-29eb4775dd98","system": "urn:hc.ge.com/pfh/platform/orgtype"}],"name": "Test123","type": {"coding": [{"system": "urn:hc.ge.com/pfh/platform/orgtype","code": "ORG","display": "Organization"}]},"telecom": [{"system": "phone","value": "1234567"}],"address": [{"line": ["Test","Test"],"city": "Test","state": "AK","zip": "132465","country": "US"}],"contact": [{"name": {"text": "Test"},"telecom": [{"system": "phone","value": "123456-1234568"},{"system": "email","value": "Test@f"}]}]}}]}));
            loggedInUserResult = { "resourceType": "ResourcesUser", "name": {"use": "official","family": ["Chalmers"],"given": ["Peter","James"]},"role": [{"scopingOrganization": {"reference": "organization/74553d9a-7d1b-4f93-929c-72b6318a6178"},"status": "active"}],"externalId": [{"system": "IDM","value": "b9f2b0f9-03ab-4d94-bd33-f40b495fc4d5"},{"system": "UOM","value": "034e2e9b-60b0-4856-85a7-c43779a11746"}],"address": [{"line": ["3300 Washtenaw Avenue, Suite 227"],"city": "Ann Arbor","state": "MI","zip": "48104","country": "USA"}],"telecom": [{"system": "phone","value": "(+1) 734-677-7777"},{"system": "email","value": "peterjames98@ge.com"}],"preferredLanguage": "English","type": "Human","status": "active","comment": "This is an Hospital Practioner 1","principalName": "peterjames98@ge.com","gender": {"coding": [{"system": "http://hl7.org/fhir/v3/AdministrativeGender","code": "M","display": "Male"}]},"acceptedAgreement": [{"agreementUri": "http://goodcare.org/devices/id","accepted": false}]};
            getAllSite = {"resourceType": "Bundle","title": "Title ","id": null,"entry": [{"title": null,"id": null,"content": {"resourceType": "ResourcesUser","role": [{"code": [{"system": "urn:hc.ge.com/pfh/platform/user-role:V1","code": "administrator","display": "administrator"}],"scopingOrganization": {"reference": "site/93c562aa-c560-46b9-98ee-17417dedb738","display": "site"},"status": "active"}, {"code": [{"system": "urn:hc.ge.com/pfh/platform/user-role:V1","code": "administrator","display": "administrator"}],"scopingOrganization": {"reference": "site/3c2955cb-87de-489b-8adc-dfc40e850009","display": "Rname"},"status": "active"}, {"code": [{"system": "urn:hc.ge.com/pfh/platform/user-role:V1","code": "administrator","display": "administrator"}],"scopingOrganization": {"reference": "site/1cd60a36-654d-4d9b-b2bc-984e49ee5bca","display": "vnb"},"status": "active"}, {"code": [{"system": "urn:hc.ge.com/pfh/platform/user-role:V1","code": "administrator","display": "administrator"}],"scopingOrganization": {"reference": "site/d40df3b8-028d-4d35-8d95-77f93b173e8b","display": "S2"},"status": "active"}]}}, {"title": null,"id": "93c562aa-c560-46b9-98ee-17417dedb738","content": {"resourceType": "Organization","text": {"status": "generated","div": "<div>502538594</div>"},"name": "site","type": {"coding": [{"system": "urn:hc.ge.com/pfh/platform/orgtype","code": "SITE","display": "site"}]},"partOf": {"reference": "organization/15848068-aa11-4548-a23c-48a2a0568e06"}}}, {"title": null,"id": "3c2955cb-87de-489b-8adc-dfc40e850009","content": {"resourceType": "Organization","text": {"status": "generated","div": "<div>Rdesc</div>"},"name": "Rname","type": {"coding": [{"system": "urn:hc.ge.com/pfh/platform/orgtype","code": "SITE","display": "site"}]},"partOf": {}}},{"title": null,"id": "3c2955cb-87de-489b-8adc-dfc40e850009","content": {"resourceType": "Organization","text": {"status": "generated","div": "<div>Rdesc</div>"},"name": "Rname","type": {"coding": [{"system": "urn:hc.ge.com/pfh/platform/orgtype","code": "SITE","display": "site"}]},"partOf": {"reference": "organization/f9e2dfa7-e6e0-485a-947b-7110a6acba96"}}}]};
            getMultipleOrgDetails=JSON.parse(JSON.stringify([{"resourceType": "organization","name": "Manipl","identifier": "123","address": "Airport Road"},{"resourceType": "organization","name": "Apollo","identifier": "234","address": "Jayanagar Road"},{"resourceType": "organization","name": "CColumbia Asia","identifier": "345","address": "Hebbal"}]));
            orgList = JSON.parse(JSON.stringify({"data":{"entry":[{"content":{"name":"test"}},{"content":{"name":"test1"}}]}, status: 2000}));
        });

        beforeEach(inject(function($controller, $rootScope, orgDataModel, orgMgmtService ,$q, $log, $state,messageObj,$timeout,userMgmtService){
            scope = $rootScope.$new();
            _rootScope = $rootScope;
            _orgDataModel = orgDataModel;
            _orgMgmtService = orgMgmtService;


            _q = $q;
            _log = $log;
            _state = $state;
            multipleOrgDetailsDeferred = _q.defer();

            _$timeout=$timeout;
            sinon.stub(_log, 'info');
            _state.transitionTo = sinon.stub();
            _state.params= {errList:null};
           _messageObj= messageObj;
            loggedInUserDetailsDeffered = _q.defer();
            orgListDeffered = _q.defer();
            siteListDeffered = _q.defer();
            _userService = userMgmtService;
            sinon.stub(_userService, 'getLoggedInUserDetails').returns(loggedInUserDetailsDeffered.promise);
            sinon.stub(_userService, 'listOfOrganizationForLoggedInUser').returns(orgListDeffered.promise);
            sinon.stub(_userService, 'listOfSiteForLoggedInUser').returns(siteListDeffered.promise);
            sinon.stub(_orgMgmtService, 'getMultipleOrganizationDetails').returns(multipleOrgDetailsDeferred.promise);
            findOrgDeferred = _q.defer();
            sinon.stub(_orgMgmtService, 'findOrganization').returns(findOrgDeferred.promise);
            ViewOrganizationCtrl = $controller('ViewOrganizationCtrl', {$scope: scope,$log:_log,orgMgmtService: _orgMgmtService,$rootScope:_rootScope,$state:_state,messageObj:_messageObj,$timeout:_$timeout});

        }));

        it('should test the controller is defined', function(){
            chai.assert.isDefined(ViewOrganizationCtrl, 'Controller not defined');
        });

        it('should test the transition to create org when Create Organization is clicked ', function(){
            scope.changePage();
            chai.expect(_state.transitionTo).to
                .have.been.calledOnce
                .and.calledWith('orgmanagement.organizationCreate');
        });

        it('should test when organization is selected from the list', function(){
            var orgObject = {
                content: {
                    resourceType: "Organization",
                    _id: "c528ab77-7ab3-42f4-b96e-5a2e8a11840a",
                    name: "GE Healthcare",
                    address: [
                        {
                            line: [
                                "3300 Washtenaw Avenue, Suite 227",
                                "second line"
                            ],
                            city: "Ann Arbor",
                            state: "MI",
                            zip: "48104",
                            country: "USA"
                        }
                    ]
                }
            };
            scope.selectOrg(orgObject);
            chai.expect(_state.transitionTo).to
                .have.been.calledOnce
                .and.calledWith('orgmanagement.organizationDetail.organizationOtherDetails');
        });

        describe('When page is loaded ', function(){
            it('should test that the getAllOrganization service is called successfully', function(done){

                scope.init();
                orgListDeffered.resolve(getAllOrg);
                scope.$root.$digest();

                chai.expect(scope.orgList).to.have.length(3);
                done();
            });

            it('should test that the getAllOrganization service is not called successfully', function(done){

                scope.init();
                orgListDeffered.reject(getAllOrg);
                scope.$root.$digest();

                chai.expect(scope.orgList).to.have.length(0);
                done();
            });

            it('should test that if page has error from createOrganization screen', function(done){
                var sp = sinon.spy(_messageObj,"setErrorCode");
                _state.params= {errList:{data:"",status:404}};
                scope.init();
                orgListDeffered.resolve(getAllOrg);
                _$timeout.flush();
                scope.$root.$digest();
                chai.assert(sp.called);
                done();
            });

            it('should test that if page has success message from createOrganization screen', function(done){
                var sp = sinon.spy(_messageObj,"setSuccessCode");
                _state.params= {succList: "ORG_CREATE_SUCCESS"};
                scope.init();
                orgListDeffered.resolve(getAllOrg);
                _$timeout.flush();
                scope.$root.$digest();
                chai.assert(sp.called);
                done();
            });
        });

        it('should test loggedInUserDetails, success scenario', function(done){
            scope.init();
            loggedInUserDetailsDeffered.resolve(JSON.parse(JSON.stringify(loggedInUserResult)));
            scope.$root.$digest();
            done();
        });

        it('should test loggedInUserDetails, failure scenario', function(done){
            scope.init();
            loggedInUserDetailsDeffered.reject();
            scope.$root.$digest();
            done();
        });

        it('should test the "displayPhoneNumber" method & return phone number from telecom object', function(){
            var telecomObj = [{
                "system": "phone",
                "value": "(+1) 734-677-7777"
            }];
            var phoneNumber = scope.displayPhoneNumber(telecomObj);
            chai.expect(phoneNumber).to.be.equal("(+1) 734-677-7777");
        });

        it('should test the "displayPhoneNumber" method, if telecom object is empty', function(){
            var telecomObj;
            var phoneNumber = scope.displayPhoneNumber(telecomObj);
            chai.expect(phoneNumber).to.be.equal("--");
        });

        it('should test the "displayPhoneNumber" method, if telecom object does not contain phone number', function(){
            var telecomObj = [{
                "system": "email",
                "value": "james@ge.com"
            }];
            var phoneNumber = scope.displayPhoneNumber(telecomObj);
            chai.expect(phoneNumber).to.be.equal("--");
        });

        it('should test getAllSitesForLoggedInUser , success scenario', function(done){
            orgListDeffered.resolve(getAllOrg);
            scope.$root.$digest();
            siteListDeffered.resolve(JSON.parse(JSON.stringify(getAllSite)));
            scope.$root.$digest();
            done();
        });

        it('should test getAllSitesForLoggedInUser , success scenario, else condition if org is already in the list (no need to add again)', function(done){
            sinon.stub(_orgMgmtService, 'getLoggedInUserOrgIds').returns(['f9e2dfa7-e6e0-485a-947b-7110a6acba96']);
            orgListDeffered.resolve(getAllOrg);
            scope.$root.$digest();
            siteListDeffered.resolve(JSON.parse(JSON.stringify(getAllSite)));
            scope.$root.$digest();
            done();
        });

        it('should test getAllSitesForLoggedInUser , success scenario, with gettting multiple org details successfully', function(done){
            orgListDeffered.resolve(getAllOrg);
            scope.$root.$digest();
            done();
            siteListDeffered.resolve(JSON.parse(JSON.stringify(getAllSite)));
            scope.$root.$digest();
            done();
            multipleOrgDetailsDeferred.resolve(JSON.parse(JSON.stringify(getMultipleOrgDetails)));
            scope.$root.$digest();
            done();
        });

        it('should test getAllSitesForLoggedInUser , success scenario, with gettting multiple org details not successfully', function(done){
            orgListDeffered.resolve(getAllOrg);
            scope.$root.$digest();
            done();
            siteListDeffered.resolve(JSON.parse(JSON.stringify(getAllSite)));
            scope.$root.$digest();
            done();
            multipleOrgDetailsDeferred.reject();
            scope.$root.$digest();
            done();
        });

        it('should test getAllSitesForLoggedInUser , failure scenario', function(done){
            orgListDeffered.resolve(getAllOrg);
            scope.$root.$digest();
            done();
            siteListDeffered.reject();
            scope.$root.$digest();
            done();
        });

        it('should filter organization list from server after 3 characters typed', function(done){
            var text = 'test';
            scope.textToBeSearched = '';
            scope.searchedSuperSetData = [];

            scope.searchOrganization(text);
            findOrgDeferred.resolve(orgList);
            scope.$root.$digest();

            chai.expect(scope.textToBeSearched).to.equal('tes');
            chai.expect(scope.orgList).to.have.length(2);
            done();
        });

        it('should not open organization list after 3 characters typed not found', function(done){
            var text = 'test2';
            scope.textToBeSearched = '';
            scope.searchedSuperSetData = orgList.data.entry;

            scope.searchOrganization(text);
            findOrgDeferred.reject();
            scope.$root.$digest();

            chai.expect(scope.textToBeSearched).to.equal('tes');
            chai.expect(scope.orgList).to.have.length(0);
            done();
        });

        it('should filter organization list at clientside if 3 characters match superSetData', function(done){
            var text = 'test1';
            scope.textToBeSearched = 'tes';
            scope.searchedSuperSetData = orgList.data.entry;

            scope.searchOrganization(text);
            findOrgDeferred.resolve(orgList);
            scope.$root.$digest();

            chai.expect(scope.orgList).to.have.length(1);
            done();
        });

        it('should not open organization list at clientside if 3 characters not found', function(done){
            var text = 'test2';
            scope.textToBeSearched = 'tes';
            scope.searchedSuperSetData = orgList.data.entry;

            scope.searchOrganization(text);
            findOrgDeferred.reject();
            scope.$root.$digest();

            chai.expect(scope.orgList).to.have.length(0);
            done();
        });

        describe('Test typeAhead Search for negative paths', function() {
            beforeEach(function() {
                scope.searcTriggered=true;
                orgListDeffered.resolve(getAllOrg);
                scope.$root.$digest();
            });
            it('checks getAllOrganization call incase search was already triggered', function (done) {
                chai.expect(scope.fullOrganizationList.length>0).to.be.true;
                done();
            });
            it('should test getAllSitesForLoggedInUser , success scenario, with gettting multiple org details successfully', function(done){
                siteListDeffered.resolve(JSON.parse(JSON.stringify(getAllSite)));
                scope.$root.$digest();
                done();
                multipleOrgDetailsDeferred.resolve(JSON.parse(JSON.stringify(getMultipleOrgDetails)));
                scope.$root.$digest();
                chai.expect(scope.fullOrganizationList.length>0).to.be.true;
                done();
            });
            it('checks searchOrganization for less than 3 characters', function (done) {
                scope.searchOrganization('ab');
                chai.expect(scope.fullOrganizationList.length===scope.orgList.length).to.be.true;
                done();
            });
        });
    });
});