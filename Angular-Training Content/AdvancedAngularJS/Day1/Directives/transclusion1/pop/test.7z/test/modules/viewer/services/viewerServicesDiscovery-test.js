define(['angular', 'angular-mocks', 'viewerServices/constants', 'viewerMockModule', 'viewerServices/viewerServicesDiscovery', 'endpointConfigMock'], function(ng, mocks) {
    'use strict';

    describe('Test serviceDiscovery', function() {
        var serviceDisco, rootScope, header, consoleLogSpy, consoleErrorSpy;

        beforeEach(module('cloudav.constants'));
        beforeEach(module('cloudav.viewerMockModule'));

        //beforeEach(module('uaf.appshell.endpoint'));
        beforeEach(function() {
            consoleLogSpy = sinon.spy(console, 'log');
            consoleErrorSpy = sinon.spy(console, 'error');

            module('cloudav.serviceDiscovery', function($provide, $Endpoint) {
                $provide.factory('$Endpoint', $Endpoint);
            });
        });

        beforeEach(module(function($provide) {
            var defaultEnvJsonAppdetails = {
                "app_name": "healthcloud", "scm_version": "1483197", "deployment_date": "Thu Oct 22 09:32:15 CEST 2015"
            };

            var headerNull = function() {
                return null;
            };

            $provide.value('$http', {
                get : function () {
                    return {
                        success: function(fn) {
                            fn(defaultEnvJsonAppdetails, 200, header);
                        }
                    };
                }
            })
        }));

        beforeEach(inject(function(_serviceDiscovery_, _$rootScope_) {
            serviceDisco = _serviceDiscovery_;
            rootScope = _$rootScope_;
        }));

        afterEach(function() {
            consoleLogSpy.restore();
            consoleErrorSpy.restore();
        });

        it('serviceDiscovery can be defined', function() {
            assert.isDefined(serviceDisco);
        });
        it('serviceDiscovery can locate savestate service', function() {
            serviceDisco.getServiceUrl('savestate-rest').then(function(value) {
                expect((value.indexOf('savestate-rest') > -1)).to.equals(true);
            });
            // this forces promises to be called
            rootScope.$digest();
        });
        it('serviceDiscovery can locate Configuration store service', function() {
            serviceDisco.getServiceUrl('pfh-config-configuration-store').then(function(value) {
                expect((value.indexOf('configuration') > -1)).to.equals(true);
            });
            // this forces promises to be called
            rootScope.$digest();
        });
        it('serviceDiscovery call EndpointConfig to', function() {
            serviceDisco.getServiceUrl('endpointMock').then(function(value) {
                console.log(value);
                expect(value).to.equals("");
            });
            // this forces promises to be called
            rootScope.$digest();
        });
        it('serviceDiscovery can give the Application version', function() {
            header = function headersGetter() {
                return '1483197';
            };

            try {
                serviceDisco.getApplicationVersion();
            } catch (err) {}

            expect(consoleErrorSpy).to.have.not.been.called;
            expect(consoleLogSpy).to.have.been.calledWithMatch('SCM Version');
        });
        it('serviceDiscovery log an error when cannot give the Application version', function() {
            header = function headersGetter() {
                return null;
            };

            try {
                serviceDisco.getApplicationVersion();
            } catch (err) {}

            expect(consoleErrorSpy).to.have.been.calledWith('Unable to set application details. Missing X-Version header.');
            expect(consoleLogSpy).to.have.been.calledWithMatch('SCM Version: undefined');
        });
    });
});
