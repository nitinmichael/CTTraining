/*
 *createGroupController-test.js
 * This test file is used to cover the unit test cases for Create MDT or Generic Group controller(createGroupController.js)
 */
define(['angular', 'angular-mocks',
        'orgMgmnt/features/group/createGroup/controllers/createGroupController',
        'orgMgmnt/services/groupService',
        'angular-ui',
        'orgMgmnt/services/userService'
    ],
    function () {
        'use strict';

        describe('Test the CreateGroupController', function () {
            var createGroupController, scope, event, templateHtml, formElem, form, state,
                templateGroupAdminsHtml, formGroupAdminsElem, searchUserResult, searchUserResultStub,
                q, deferred, createResponse, rootScope, loggedInUserResult, getLoggedUserDeferred,
                groupService, validGroupNameDeferred, filter,_userService;
            before(function () {
                searchUserResult =
                {
                    "resourceType": "Bundle",
                    "title": "List of all groups for user",
                    "id": null,
                    "data": {
                        "entry": [
                            {
                                "title": "ResourcesUser",
                                "id": "ff54d5c2-973a-4162-b457-877b5d0b49ca",
                                "content": {
                                    "resourceType": "ResourcesUser",
                                    "name": {
                                        "use": "official",
                                        "family": [
                                            "Chalmers"
                                        ],
                                        "given": [
                                            "Nandro",
                                            "Kollar"
                                        ]
                                    },
                                    "telecom": [
                                        {
                                            "system": "phone",
                                            "value": "(+1) 734-677-7777"
                                        },
                                        {
                                            "system": "email",
                                            "value": "nandro@ge.com"
                                        }
                                    ],
                                    "preferredLanguage": "English",
                                    "type": "Human",
                                    "status": "active",
                                    "comment": "This is an Hospital Practioner 1",
                                    "principalName": "nandro@ge.com",
                                    "gender": {
                                        "coding": [
                                            {
                                                "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                                "code": "M",
                                                "display": "Male"
                                            }
                                        ]
                                    },
                                    "acceptedAgreement": [
                                        {
                                            "agreementUri": "http://goodcare.org/devices/id",
                                            "accepted": false
                                        }
                                    ]
                                }
                            }]
                    }
                };
                loggedInUserResult = {
                    "resourceType": "ResourcesUser",
                    "name": {
                        "use": "official",
                        "family": [
                            "Chalmers"
                        ],
                        "given": [
                            "Peter",
                            "James"
                        ]
                    },
                    "role": [
                        {
                            "scopingOrganization": {
                                "reference": "organization/74553d9a-7d1b-4f93-929c-72b6318a6178"
                            },
                            "status": "active"
                        }
                    ],
                    "externalId": [
                        {
                            "system": "IDM",
                            "value": "b9f2b0f9-03ab-4d94-bd33-f40b495fc4d5"
                        },
                        {
                            "system": "UOM",
                            "value": "034e2e9b-60b0-4856-85a7-c43779a11746"
                        }
                    ],
                    "address": [
                        {
                            "line": [
                                "3300 Washtenaw Avenue, Suite 227"
                            ],
                            "city": "Ann Arbor",
                            "state": "MI",
                            "zip": "48104",
                            "country": "USA"
                        }
                    ],
                    "telecom": [
                        {
                            "system": "phone",
                            "value": "(+1) 734-677-7777"
                        },
                        {
                            "system": "email",
                            "value": "peterjames98@ge.com"
                        }
                    ],
                    "preferredLanguage": "English",
                    "type": "Human",
                    "status": "active",
                    "comment": "This is an Hospital Practioner 1",
                    "principalName": "peterjames98@ge.com",
                    "gender": {
                        "coding": [
                            {
                                "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                "code": "M",
                                "display": "Male"
                            }
                        ]
                    },
                    "acceptedAgreement": [
                        {
                            "agreementUri": "http://goodcare.org/devices/id",
                            "accepted": false
                        }
                    ]
                };
            });
            beforeEach(function () {
                module('Orgmanagement.Features.Group.CreateGroup.CreateGroupController');
                module('geExceptionHandlerModule');
                module('Orgmanagement.Utilities.MasterData');
                module('Orgmanagement.Services.UserService');
            });

            beforeEach(module('Orgmanagement.Features.Group.CreateGroup.CreateGroupController', function ($provide) {
                $provide.value('$state', {
                    transitionTo: function () {
                    },
                    go: function(){
                    },
                    params: {
                        groupType: "generic"
                    }
                });
                $provide.value('$stateParams', {
                    id: function () {
                    }
                });
            }));

            beforeEach(inject(function ($controller, $rootScope, $compile, $state, groupMgmtService, $q, $filter,userMgmtService) {
                scope = $rootScope.$new();
                rootScope = $rootScope;
                rootScope.selectedOrg = {content: {_id: "656565"}};
                rootScope.orgObject = {content: {_name: "TestOrg"}};
                rootScope.selectedSite = {content: {_id: "123456"}};
                rootScope.selectedSite.content.name = 'TestSite';
                groupService = groupMgmtService;
                _userService=userMgmtService;
                state = $state;
                q = $q;
                getLoggedUserDeferred = $q.defer();
                sinon.stub(_userService, 'getLoggedInUserDetails').returns(getLoggedUserDeferred.promise);
                createGroupController = $controller('CreateGroupCtrl', {
                    $scope: scope,
                    $state: state,
                    groupMgmtService: groupMgmtService,
                    $rootScope: rootScope
                });
                event = {
                    stopPropagation: sinon.spy(),
                    preventDefault: sinon.spy()
                };
                templateHtml = '<form id="createGroupMainFormGroupInfoFieldsDiv" name="parentGroupForm.groupForm"  class="form-horizontal" novalidate> <input name="groupName" type="text" maxlength="255" ng-change="removeUniqueGroupNameExistMessage()" ng-model="formGroupInfo.groupName"  class="input controls form-control error-icon-style" id="createGroupMainFormGroupInfoGroupNameInput" ng-model="formGroupInfo.groupName" required/> <textarea rows="3" style="resize:none;" name="groupDescription" class="input controls form-control error-icon-style" id="createGroupMainFormGroupDescriptionInfoInput" ng-model="formGroupInfo.groupDescription"></textarea><input name="mainContactName" type="text" class="input controls form-control error-icon-style" id="createGroupMainFormGroupInfoMainContactNameInput" ng-model="formGroupInfo.mainContactName" required/><input name="mainContactEmail" type="email" class="input controls form-control error-icon-style" id="createGroupMainFormMainContactEmailInfoInput" ng-model="formGroupInfo.mainContactEmail" required/><input name="mainContactPhone" type="text" maxlength="10" pattern="^[0-9]{10}$" class="input controls form-control error-icon-style" id="createGroupMainFormMainContactPhoneInfoInput" ng-model="formGroupInfo.mainContactPhone" required/></form>';
                formElem = angular.element("<div>" + templateHtml + "</div>");
                scope.formGroupInfo = {
                    groupName: 'GEHCGrp',
                    mainContactName: "mainContactName ",
                    mainContactEmail: "a@ge.com",
                    mainContactPhone: "1111111111"
                };
                $compile(formElem)(scope);
                scope.$apply();
                templateGroupAdminsHtml = '<form id="createGroupMainFormCreateGroupAdminParticipantFieldsDiv" name="parentGroupForm.groupAdminsForm"  class="form-horizontal" novalidate><input id="administratorSelector" class="form-control input-sm admin-typeahead" ng-model="selectedAdmin" type="text" typeahead-on-select="selectAdministrator($item)" typeahead="user as user.name for user in searchUserForAdmin($viewValue)"></form>';
                formGroupAdminsElem = angular.element("<div>" + templateGroupAdminsHtml + "</div>");
                $compile(formGroupAdminsElem)(scope);
                scope.$apply();
                form = scope.parentGroupForm.groupForm;
                scope.createGroupDetailsTab = "createGroupDetailsTab";
                scope.createGroupAdminsTab = "createGroupAdminsTab";
                scope.createGroupConfirmationTab = "createGroupConfirmationTab";
                scope.tabGroup = scope.createGroupDetailsTab;
                q = $q;
                deferred = q.defer();
                validGroupNameDeferred = q.defer();
                sinon.stub(groupMgmtService, 'createGroup').returns(deferred.promise);
                searchUserResultStub = sinon.stub(_userService, 'findUser').returns(deferred.promise);
                sinon.stub(groupMgmtService, 'isValidGroupName').returns(validGroupNameDeferred.promise);
                filter = $filter;
            }));

            beforeEach(function (done) {
                getLoggedUserDeferred.resolve(JSON.parse(JSON.stringify(loggedInUserResult)));
                scope.$digest();
                done();
            });

            it('checks required field "groupName" is valid with default entry', function () {
                chai.expect(scope.hasGroupError("groupName")).to.be.false;
            });

            it('checks required field "mainContactName" is valid with default entry', function () {
                chai.expect(scope.hasGroupError("mainContactName")).to.be.false;
            });

            it('checks required field "mainContactEmail" is valid with default entry', function () {
                chai.expect(scope.hasGroupError("mainContactEmail")).to.be.false;
            });

            it('checks required field "mainContactPhone" is valid with default entry', function () {
                chai.expect(scope.hasGroupError("mainContactPhone")).to.be.false;
            });

            it('should go to group list on click of cancel button when group creation failed', function () {
                var stateSpy = sinon.spy(state, "go");
                scope.cancelGroupClicked();
                chai.expect(stateSpy.calledWith('orgmanagement.site.allGroups'));
            });

            it('should go to group list on click of finish button when group creation successful', function () {
                var stateSpy = sinon.spy(state, "go");
                scope.finishGroupClicked();
                chai.expect(stateSpy.calledWith('orgmanagement.site.allGroups'));
            });

            it('groupName uniqueness check, Required field is not blank', function (done) {
                scope.validateGroupName();
                validGroupNameDeferred.reject();
                scope.$digest();
                done();
                scope.groupOwner = searchUserResult.data.entry[0];
                scope.formGroupInfo.groupName = 'Diabetes';
                scope.$apply();
                scope.nextGroupScreen(event);
                chai.expect(scope.hasGroupError("groupName")).to.be.true;
            });

            it('groupName uniqueness check, Does exist?', function (done) {
                scope.validateGroupName();
                validGroupNameDeferred.reject();
                scope.$digest();
                done();
                scope.groupOwner = searchUserResult.data.entry[0];
                scope.formGroupInfo.groupName = 'Diabetes';
                scope.$apply();
                scope.nextGroupScreen(event);
                chai.expect(form["groupName"].$error.exist).to.be.true;
            });

            it('groupName uniqueness check, Remove unique error message if field is left blank', function () {
                scope.groupOwner = searchUserResult.data.entry[0];
                scope.formGroupInfo.groupName = 'Diabetes';
                scope.$apply();
                scope.nextGroupScreen(event);
                scope.formGroupInfo.groupName = '';
                scope.$apply();
                scope.removeUniqueGroupNameExistMessage();
                scope.nextGroupScreen(event);
                chai.expect(form.$valid).to.be.false;
            });

            it('Checking for unique conditions and left over paths, Set form entries to valid,remove groupNameUniqueness error and check form to be valid', function () {
                scope.groupOwner = searchUserResult.data.entry[0];
                scope.formGroupInfo.groupName = 'GEHCGrp';
                scope.$apply();
                scope.removeUniqueGroupNameExistMessage();
                chai.expect(form.$valid).to.be.true;
            });

            it('Checking for unique conditions and left over paths, Let form have groupname uniqueness error and try to go to next screen', function (done) {
                scope.validateGroupName();
                validGroupNameDeferred.reject();
                scope.$digest();
                done();
                scope.groupOwner = searchUserResult.data.entry[0];
                scope.formGroupInfo.groupName = 'Diabetes';
                scope.$apply();
                //--This sets exists error on groupName--
                scope.nextGroupScreen(event);
                //-Calling nextGroupScreen with an invalid form-
                scope.nextGroupScreen(event);
                chai.expect(form.$valid).to.be.false;
            });

            it('Checking for unique conditions and left over paths, Initial case Valid -Pristine nonSubmitted form with unique group name - Removes groupName exist error', function () {
                scope.groupOwner = searchUserResult.data.entry[0];
                scope.nextGroupScreen(event);
                chai.expect(form.$valid).to.be.true;
            });

            it('Checking for unique conditions and left over paths, Initial case Valid -Pristine nonSubmitted form with unique group name-', function (done) {
                scope.validateGroupName();
                validGroupNameDeferred.reject();
                scope.$digest();
                done();
                scope.groupOwner = searchUserResult.data.entry[0];
                scope.formGroupInfo.groupName = "Diabetes";
                scope.nextGroupScreen(event);
                chai.expect(form.$valid).to.be.false;
            });

            it('Previous Button will be disappeared on "MDT or Generic Group Details" screen ', function () {
                scope.tabGroup = scope.createGroupDetailsTab;
                scope.previousGroupScreen(event);
                chai.expect(scope.tabGroup).to.equal(scope.createGroupDetailsTab);
            });

            it('Go to previous screen (MDT or Generic Group Details) from MDT or Generic Group Admin Screen', function () {
                scope.tabGroup = scope.createGroupAdminsTab;
                scope.previousGroupScreen(event);
                chai.expect(scope.tabGroup).to.equal(scope.createGroupDetailsTab);
            });

            it('Go to previous screen (MDT or Generic Group Admins) from MDT or Generic Group Confirmation Screen', function () {
                scope.tabGroup = scope.createGroupConfirmationTab;
                scope.previousGroupScreen();
                chai.expect(scope.tabGroup).to.equal(scope.createGroupAdminsTab);
            });

            it('On click of "CreateGroupDetails" stops propagation, as it is disabled"', function () {
                scope.onCreateGroupDetailsTabClick(event);
                chai.expect(event.stopPropagation).to.be.called;
            });

            it('On click of "CreateGroupAdminsParticipants" stops propagation, as it is disabled"', function () {
                scope.onCreateGroupAdminsParticipantsTabClick(event);
                chai.expect(event.stopPropagation).to.be.called;
            });

            it('On click of "CreateGroupConfirmation" stops propagation, as it is disabled"', function () {
                scope.onCreateGroupConfirmationTabClick(event);
                chai.expect(event.stopPropagation).to.be.called;
            });

            it('On click of cross button of error alert box at "CreateGroupDetails" tab, disappears alert box', function () {
                scope.formGroupInfo.groupName = '';
                scope.$apply();
                scope.nextGroupScreen(event);
                scope.closeAlert();
                chai.expect(scope.parentGroupForm.groupForm.$submitted).to.be.false;
            });

            it('On click of cross button of error alert box at "CreateGroupAdmins" tab, disappears alert box', function () {
                scope.tabGroup = scope.createGroupAdminsTab;
                scope.closeAlert();
                chai.expect(scope.parentGroupForm.groupAdminsForm.$submitted).to.be.false;
            });

            it('On click of cross button of error alert box at "CreateGroupConfirmation" tab, disappears success alert box', function () {
                scope.tabGroup = scope.createGroupConfirmationTab;
                scope.nextGroupScreen(event);
                scope.closeAlert();
                chai.expect(scope.parentGroupForm.success).to.be.false;
            });

            it('On click of cross button of error alert box at "CreateGroupConfirmation" tab, disappears error alert box', function () {
                scope.tabGroup = scope.createGroupConfirmationTab;
                scope.nextGroupScreen(event);
                scope.closeAlert();
                chai.expect(scope.parentGroupForm.error).to.be.false;
            });

            it('Invoking "closeAlert" function with no tabGroup selected', function () {
                scope.tabGroup = "";
                scope.nextGroupScreen(event);
                scope.closeAlert();
                chai.expect(scope.parentGroupForm.success).to.be.false;
            });

            it('Checks success value on click of create button for Generic Group, success should be true', function (done) {
                scope.groupOwner = searchUserResult.data.entry[0];
                scope.nextGroupScreen(event);
                var responseData = {data:{id:'12s3-ag4'}};
                var user = searchUserResult.data.entry[0];
                scope.selectAdministrator(user);
                scope.selectParticipant(user);
                scope.createGroupClicked(event);
                deferred.resolve(responseData);
                scope.$digest();
                chai.expect(scope.parentGroupForm.success).to.be.true;
                done();
            });

            it('Checks success value on click of create button for MDT Group, success should be true', function (done) {
                scope.groupOwner = searchUserResult.data.entry[0];
                scope.nextGroupScreen(event);
                var responseData = {data:{id:'12s3-ag4'}};
                var user = searchUserResult.data.entry[0];
                scope.selectAdministrator(user);
                scope.selectParticipant(user);
                scope.groupType = "mdt";
                scope.createGroupClicked(event);
                deferred.resolve(responseData);
                scope.$digest();
                chai.expect(scope.parentGroupForm.success).to.be.true;
                done();
            });

            it('Checks reject value on click of create button, error should be true', function (done) {
                scope.groupOwner = searchUserResult.data.entry[0];
                scope.nextGroupScreen(event);
                var user = searchUserResult.data.entry[0];
                scope.selectAdministrator(user);
                scope.selectParticipant(user);
                scope.createGroupClicked(event);
                createResponse = {data: "dump", status: 404};
                deferred.reject(createResponse);
                scope.$digest();
                chai.expect(scope.parentGroupForm.error).to.be.true;
                done();
            });

            it('On click of create button, it must show error with no admin selected', function (done) {
                loggedInUserResult.id = "034e2e9b-60b0-4856-85a7-c43779a11746";
                scope.removeAdministrator(loggedInUserResult);
                scope.createGroupClicked(event);
                scope.validateCreateGroupAdminsParticipantsTab(event);
                chai.expect(scope.isValidGroupAdmins).to.be.false;
                done();
            });

            it('Searching user for selecting as admin', function (done) {
                scope.searchUserForAdmin("a");
                deferred.resolve(searchUserResult);
                scope.$digest();
                done();
                chai.expect(scope.searchingUsersForAdmin).to.be.false;
            });

            it('Selecting user after searching as admin', function () {
                var user = searchUserResult.data.entry[0];
                scope.selectAdministrator(user);
                chai.expect(scope.groupDetails.administrators.length).to.equal(2);
            });

            it('Try to selecting again selected user after searching as admin, it will not add again as particular user is already selected', function () {
                var user = searchUserResult.data.entry[0];
                scope.selectAdministrator(user);
                scope.selectAdministrator(user);
                chai.expect(scope.groupDetails.administrators.length).to.equal(2);
            });

            it('Remove selected user from selected admins', function () {
                var user = searchUserResult.data.entry[0];
                scope.selectAdministrator(user);
                scope.removeAdministrator(user);
                chai.expect(scope.groupDetails.administrators.length).to.equal(1);
            });

            it('Validating Group Admin form, No user selected', function () {
                loggedInUserResult.id = "034e2e9b-60b0-4856-85a7-c43779a11746";
                scope.removeAdministrator(loggedInUserResult);
                scope.tabGroup = scope.createGroupAdminsTab;
                scope.validateCreateGroupAdminsParticipantsTab(event);
                chai.expect(scope.isValidGroupAdmins).to.be.false;
            });

            it('Validating Group Admin form, No user selected & disappearing green tick', function () {
                loggedInUserResult.id = "034e2e9b-60b0-4856-85a7-c43779a11746";
                scope.removeAdministrator(loggedInUserResult);
                scope.tabGroup = scope.createGroupAdminsTab;
                scope.validateCreateGroupAdminsParticipantsTab(event);
                var user = searchUserResult.data.entry[0];
                scope.selectAdministrator(user);
                scope.removeAdministrator(user);
                scope.validateCreateGroupAdminsParticipantsTab(event);
                chai.expect(scope.isValidGroupAdmins).to.be.false;
            });

            it('Validating Group Admin form, one user selected', function () {
                scope.tabGroup = scope.createGroupAdminsTab;
                var user = searchUserResult.data.entry[0];
                scope.selectAdministrator(user);
                scope.validateCreateGroupAdminsParticipantsTab(event);
                chai.expect(scope.isValidGroupAdmins).to.be.true;
            });


            it('After selecting any user as admin, display it with name & email', function () {

                var user = searchUserResult.data.entry[0].content;
                user.display = user.name.given[0] +' '+user.name.given[1];
                var expectedOutput = user.display + ' ('+ scope.getUserEmailForDisplay(user)  + ')';
                var output = scope.getUserForDisplay(user);
                chai.expect(output).to.equal(expectedOutput);
            });

            it('Check getUserEmailForDisplay function, object is not empty', function () {
                var expectedResult = "nandro@ge.com";
                var user = searchUserResult.data.entry[0].content;
                var userEmail = scope.getUserEmailForDisplay(user);
                chai.expect(userEmail).to.equal(expectedResult);
            });

            it('Check getUserEmailForDisplay function, object is empty', function () {
                var userEmail = scope.getUserEmailForDisplay({});
                chai.expect(userEmail).to.be.empty;
            });

            it('After selecting any user as admin, display it with name & email, if email does not exist', function () {
                var user = searchUserResult.data.entry[0].content;
                user.display = user.name.given[0] +' '+user.name.given[1];
                var expectedOutput = user.display;
                user.principalName = "";
                var output = scope.getUserForDisplay(user);
                chai.expect(output).to.equal(expectedOutput);
            });

            it('Check selectMainContact function', function () {
                var expectedOutput = "Nandro Kollar";
                scope.selectMainContact(searchUserResult.data.entry[0]);
                chai.expect(scope.groupOwner.display).to.equal(expectedOutput);
            });

            it('Check removeMainContact function', function () {
                scope.removeMainContact(searchUserResult.data.entry[0]);
                chai.expect(Object.keys(scope.groupOwner).length).to.equal(0);
            });

            it('Check getUserObject function', function () {
                var userObject = scope.getUserObject(searchUserResult.data.entry[0]);
                chai.expect(userObject.id).to.equal(searchUserResult.data.entry[0].id);
            });

            it('Check searchUserForMainContact function, success', function (done) {
                scope.searchUserForMainContact("a");
                deferred.resolve(searchUserResult);
                scope.$root.$digest();
                done();
                chai.expect(scope.searchingUsersForMainContact).to.be.false;
            });

            it('Check searchUserForMainContact function, reject', function (done) {
                scope.searchUserForMainContact("abc");
                deferred.reject();
                scope.$root.$digest();
                done();
                chai.expect(scope.noResultsForMainContact).to.be.true;
            });

            it('Check searchUserForAdmin function, reject', function (done) {
                scope.searchUserForAdmin("abc");
                deferred.reject();
                scope.$root.$digest();
                done();
                chai.expect(scope.noResultsForAdmin).to.be.true;
            });

            it('Check getUserPhoneForDisplay function, object is not empty', function () {
                var expectedResult = "(+1) 734-677-7777";
                var userPhone = scope.getUserPhoneForDisplay(searchUserResult.data.entry[0].content);
                chai.expect(userPhone).to.equal(expectedResult);
            });

            it('Check getUserPhoneForDisplay function, object is empty', function () {
                var userPhone = scope.getUserPhoneForDisplay({});
                chai.expect(userPhone).to.be.empty;
            });

            it('Check getUserNameForDisplay function, object is not empty', function () {
                var expectedOutput = "Nandro Kollar";
                var userName = scope.getUserNameForDisplay(searchUserResult.data.entry[0].content);
                chai.expect(userName).to.equal(expectedOutput);
            });

            it('Check getUserNameForDisplay  function, object is empty', function () {
                var userName = scope.getUserNameForDisplay({});
                chai.expect(userName).to.be.empty;
            });

            describe('Test if XSS event has been taken care of when', function(){
                it('user tries to enter the script in input box it must show error on blur', function(){
                    scope.groupDetails.mainContactName = '<script>';
                    scope.$digest();
                    var object = {message: "There is an attempt to insert script."};
                    scope.$emit("SHOW_FAILURE_MESSAGE_NO_TIMEOUT",object.message);
                    chai.expect(scope.closeAlertPressed).to.be.equal(0);
                });

                it('to close the XSS error message box, click on x button', function(){
                    scope.closeXSSAlert();
                    chai.expect(scope.closeAlertPressed).to.be.equal(1);
                });
            });

            it('Searching user for selecting as participant', function (done) {
                scope.searchUserForParticipant("a");
                deferred.resolve(searchUserResult);
                scope.$digest();
                done();
                chai.expect(scope.searchingUsersForParticipant).to.be.false;
            });

            it('Check searchUserForParticipant function, reject', function (done) {
                scope.searchUserForParticipant("abc");
                deferred.reject();
                scope.$root.$digest();
                done();
                chai.expect(scope.noResultsForParticipant).to.be.true;
            });

            it('Selecting user after searching as Participant', function () {
                var user = searchUserResult.data.entry[0];
                scope.selectParticipant(user);
                chai.expect(scope.participants.length).to.equal(1);
            });

            it('Try to selecting again selected user after searching as Participant, it will not add again as particular user is already selected', function () {
                var user = searchUserResult.data.entry[0];
                scope.selectParticipant(user);
                scope.selectParticipant(user);
                chai.expect(scope.participants.length).to.equal(1);
            });

            it('Remove selected user from selected Participants', function () {
                var user = searchUserResult.data.entry[0];
                scope.selectParticipant(user);
                scope.removeParticipant(user);
                chai.expect(scope.participants.length).to.equal(0);
            });

            it('groupName uniqueness check, Check "validateGroupName" function, success', function (done) {
                scope.validateGroupName();
                validGroupNameDeferred.resolve();
                scope.$digest();
                done();
                chai.expect(scope.isGrNameExists).to.be.false;
            });

            it('Check "validateGroupName" function, groupName field is blank with reject', function (done) {
                scope.validateGroupName();
                validGroupNameDeferred.reject();
                scope.$digest();
                done();
                scope.formGroupInfo.groupName = '';
                scope.$apply();
                scope.validateGroupName();
                chai.expect(scope.parentGroupForm.groupForm.$submitted).to.be.true;
            });

            it('Check "getLoggedUserDeferred" function to get the loggedinuser details, success but empty object',function (done) {
                getLoggedUserDeferred.resolve({});
                scope.$digest();
                done();
            });

            it('Check "validateCreateGroupOwner" function, empty owner object', function () {
                scope.groupOwner = {};
                scope.$apply();
                scope.validateCreateGroupOwner();
                chai.expect(scope.isValidGroupOwner).to.be.true;
            });

            it('Check "goToPage" function, moves navigation to specific page', function () {
                scope.goToPage(2);
                chai.expect(scope.currentPage).to.equal(2);
            });

            it('Check "goToPreviousPage " function, disabled on first page, navigation does not happen', function () {
                scope.goToPreviousPage(event);
                chai.expect(event.preventDefault).to.be.called;
            });

            it('Check "goToPreviousPage " function, moves navigation to previous page', function () {
                scope.currentPage = 1;
                scope.goToPreviousPage(event);
                chai.expect(scope.currentPage).to.equal(0);
            });

            it('Check "goToNextPage " function, moves navigation to next page', function () {
                scope.participants.length = 10;
                scope.goToNextPage(event);
                chai.expect(scope.currentPage).to.equal(1);
            });

            it('Check "goToNextPage " function, disabled on last page, navigation does not happen', function () {
                scope.participants.length = 5;
                scope.goToNextPage(event);
                chai.expect(event.preventDefault).to.be.called;
            });

            it('Check "startFrom" filter', function () {
                scope.currentPage = 1;
                scope.participants.length = 10;
                var result = filter('startFrom')(scope.participants, scope.currentPage * scope.pageSize);
                chai.expect(result.length).to.equal(5);
            });

            it('Checking validateCreateGroupDetailsTab if validate group name service is already in progress', function () {
                scope.validateGroupNameLoader = true;
                scope.nextGroupScreen(event);
                chai.expect(scope.tabGroup).to.equal(scope.createGroupDetailsTab);
            });

            it('checks if modal instance is not undefined', function () {
                scope.formGroupInfo.groupName = 'Trauma';
                scope.loopBreaker = true;
                scope.canTransitionToOtherScreens = false;
                state.transitionTo('Organization');
                rootScope.$broadcast('$stateChangeStart');
                chai.expect(scope.modalInstance).to.not.be.undefined;
            });

            it('checks if modal instance is undefined', function () {
                scope.formGroupInfo.groupName = 'Trauma';
                scope.loopBreaker = false;
                scope.canTransitionToOtherScreens = false;
                state.transitionTo('Organization');
                rootScope.$broadcast('$stateChangeStart');
                chai.expect(scope.modalInstance).to.be.undefined;
            });

            it('checks for relaseStateChangeHandler', function () {
                var relStateSpy = sinon.spy(scope, 'relaseStateChangeHandler');
                state.transitionTo('Organization');
                scope.$emit('$destroy');
                chai.expect(relStateSpy.called).to.be.true;
            });


            it('Check searchUserForMainContact function success, filtering in search result ', function (done) {
                scope.searchUserForMainContact("nan");
                deferred.resolve(searchUserResult);
                scope.$root.$digest();
                done();
                var userResult = scope.searchUserForMainContact("nand");
                chai.expect(userResult).to.not.be.empty;
            });

            it('Check searchUserForParticipant function success, filtering in search result ', function (done) {
                scope.searchUserForParticipant("nan");
                deferred.resolve(searchUserResult);
                scope.$root.$digest();
                done();
                var userResult = scope.searchUserForParticipant("nand");
                chai.expect(userResult).to.not.be.empty;
            });

            it('Check searchUserForAdmin function success, filtering in search result ', function (done) {
                scope.searchUserForAdmin("nan");
                deferred.resolve(searchUserResult);
                scope.$root.$digest();
                done();
                var userResult = scope.searchUserForAdmin("nand");
                chai.expect(userResult).to.not.be.empty;
            });
        });

        describe('Test the modal instance conroller', function() {
            var scope,modal,filter,ModalInstanceCtrl3,
                    transitionParams = {},
                    modalInstance = { close: function() {}, dismiss: function() {}};
            beforeEach( function(){
                module('Orgmanagement.Features.Group.CreateGroup.CreateGroupController');
            });
            beforeEach(inject(function($controller,$rootScope, $modal, $filter) {
                scope = $rootScope.$new();
                modal = $modal;
                filter = $filter;
                ModalInstanceCtrl3 = $controller('ModalInstanceCtrl3',{
                    $scope: scope,
                    $modalInstance: modalInstance,
                    groupObj: {},
                    transitionParams: transitionParams
                });
                scope.$apply();
            }));

            it('should have a controller', function () {
                assert.isDefined(ModalInstanceCtrl3, 'Controller is not defined');
            });
        });
    });
