/*
 * ge-contact-information-popover-directive-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['jquery', 'angular',
        'angular-mocks','rich-popover',
        'modules/platform/filters/ge-na-filter'
        ],
    function () {
        'use strict';
        var $rootScope, scope, isolatedScope, $compile;

        describe('GE Contact Information Directive Test Suite::', function () {
            beforeEach(function () {
                if (!$.fn.richPopover) throw new Error('geContactInformationPopover requires rich-popover.js');
                module('Directive.geContactInformationPopover', function ($provide, $translateProvider) {
                    // This will provide the mock translation to $translate provider
                    $translateProvider.translations('en', {});
                    $provide.value('MdtUserService', {});
                    $provide.value('NotificationService', {});
                });

                module('platform.filter.ge-na-filter');
                //Load Templates
                module('templates');

                //Create new scope
                inject(function (_$compile_, _$rootScope_) {
                    $rootScope = _$rootScope_;
                    $compile = _$compile_;
                    scope = $rootScope.$new();
                });
            });


            beforeEach(function () {

                scope.member="member";

                scope.memberList = [
                {
                    id: "1",
                    name: "Nandro Kollar",
                    title: "Oncology Coordinator",
                    phone: "+1-555-123-456-78",
                    email: "nandro@ge.com"
                }];

                var html = '<span ge-contact-information-popover user="memberList[0]"></span>';

                var element = $compile(html)(scope);
                scope.$digest();
                isolatedScope = element.isolateScope();
             });

            it('check user visible in the directive', function () {
                expect(isolatedScope.user).to.be.eql(scope.memberList[0]);
            });

        });
    });
