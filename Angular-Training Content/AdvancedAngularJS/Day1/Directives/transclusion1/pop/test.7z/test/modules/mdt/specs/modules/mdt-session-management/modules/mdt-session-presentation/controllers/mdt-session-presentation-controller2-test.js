/*
 * mdt-session-presentation-controller-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular', 'angular-mocks', 'ng-sortable', 'mdt/modules/mdt-session-management/controllers/mdt-session-details-controller'], function () {
    'use strict';

    describe('MDT Session Presentation test cases ::', function () {
        var scope, stateParams, state, controller, MdtSessionPresentationService, MdtCaseDataService, NotificationService, successHandler, errorHandler, rootScope,
            broadcastCallbacks = {},
            getCaseSuccess, getCaseError,
            reviewedSuccess, reviewedError;

        beforeEach(function () {
            module('Mdt.Module.MdtSessionPresentationController', function ($provide) {
                $provide.value('MdtSessionPresentationService', {
                    then: function(fn){
                        fn({
                            getDetails: function (id, success, error) {
                                successHandler = success;
                                errorHandler   = error;
                                return {caseList : []};
                            },
                            getCaseDetails: function(sessionid, caseid, success, error){
                                getCaseSuccess = success;
                                getCaseError   = error;
                                return {};
                            },
                            markCaseAsReviewed: function(sessionId, caseID, caseComment, success, error){
                                reviewedSuccess = success;
                                reviewedError   = error;
                            }
                        });
                    }
                });
                $provide.value('NotificationService', {
                    addErrorMessage: sinon.spy()
                });
            });
        });

        describe('Presentation list controller', function(){
            beforeEach(function(){
                module('Mdt.Module.MdtCaseDataService');
                inject(function ($rootScope, $controller, _MdtSessionPresentationService_, _NotificationService_, _MdtCaseDataService_) {
                    scope = $rootScope.$new();
                    stateParams = {sessionId: '6677'};
                    NotificationService = _NotificationService_;
                    MdtSessionPresentationService = _MdtSessionPresentationService_;
                    MdtCaseDataService = _MdtCaseDataService_;
                    MdtCaseDataService.setLoadingSessionDetailsValue = sinon.spy();
                    rootScope = {
                        $broadcast: sinon.spy(),
                        $on: function(name, fn){
                            broadcastCallbacks[name] = fn;
                        }
                    };
                    var session = {
                        meetingId: '6677',
                        cases: [
                            {id: '1122',
                                outcome: 'outcome1122'},
                            {id: '3344',
                                outcome: 'outcome3344'}
                        ]
                    };
                    state = {
                        transitionTo: sinon.spy(),
                        go: sinon.spy()
                    };
                    scope.mdtCaseList = MdtCaseDataService.updateItemList(session.cases);
                    scope.case = MdtCaseDataService.retrieveSelectedItem('3344');

                    //Initialize the controller
                    controller =
                        $controller('MdtSessionPresentationListController', {
                            $scope: scope,
                            $state: state,
                            $stateParams: stateParams,
                            $rootScope: rootScope,
                            MdtCaseDataService: MdtCaseDataService,
                            MdtSessionPresentationService: MdtSessionPresentationService,
                            NotificationService: NotificationService
                        });
                });
            });

            it("should be defined", function () {
                assert.isDefined(controller, 'List controller is not defined');
            });

            it('should handle received headers', function(){

                expect(MdtCaseDataService.setLoadingSessionDetailsValue.calledOnce).to.be.true;

                var result = {
                    data:{
                        name: 'Lorem Pista'
                    }
                };
                successHandler(result);

                expect(scope.sessionDetails.name).to.be.equal(result.data.name);
            });

            it('should handle selected case id - deep copy', function(){
                var caseId = '3141592';

                var result = {
                    data:{
                        name: 'Lorem Pista',
                        cases: [{
                            id: caseId + '10',
                            status: 'NOTCLOSED'
                        }, {
                            id: caseId,
                            status: 'NOTCLOSED'
                        }]
                    }
                };

                successHandler(result);

                expect(scope.sessionDetails.cases[1].status).to.be.equal('NOTCLOSED');
            });

            it('should handle session details fetching error', function(){
                MdtCaseDataService.setLoadingSessionDetailsValue = sinon.spy();

                errorHandler();

                expect(MdtCaseDataService.setLoadingSessionDetailsValue.calledOnce).to.be.true;
            });

            it('should generate a state transition', function() {
                scope.$digest();
                console.log("****************************** " +scope.selectedCaseObj.value)
                if( scope.selectedCaseObj.value===0  ) {
                    scope.selectedCaseObj.value = 1;
                } else {
                    scope.selectedCaseObj.value = 0;
                }
                scope.$digest();

                expect(state.go).calledOnce;
            });
        });
    });
});
