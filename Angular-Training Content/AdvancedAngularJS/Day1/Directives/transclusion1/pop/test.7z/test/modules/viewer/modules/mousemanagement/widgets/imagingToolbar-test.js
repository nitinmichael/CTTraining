/*
 *  imagingToolbar-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *   Emna Turki <emna.turky@ge.com>
 */

/**
 * Spec file for Viewer > modules > mousemanagement > widgets > imagingToolbar directive
 */

define(['angular', 'angular-mocks', 'jquery', 'deviceManagerServiceMock', 'mousemanagementModule/module', 'platformMock', 'imagingToolbarMocks',
        'mousemanagementModule/widgets/imagingToolbar', 'modules/viewer/modules/viewer-app/module'],
    function () {
        'use strict';
        var segmentationService
        ,   portContentFactory
        ,   mockActivePort;
        var eyeButtonIndex = 5;

        describe('imagingToolbar Directive Test :', function () {
            var element, scope, isolatedScope;

            beforeEach(module('deviceManagerServiceMock'));
            beforeEach(module('platform'));
            beforeEach(module('templates'));
            beforeEach(module('cloudav.viewerApp.mousemanagement'));
            beforeEach(module('imagingToolbarFactoryMock'));

            beforeEach(module('cloudav.viewerApp.services', function($provide) {
                var mockSegmentationMasks =  {
                                                'masks': []
                                             };
                segmentationService = {
                        segmentationMasks: sinon.stub().returns(mockSegmentationMasks)
                };
                $provide.value('segmentationService', segmentationService);
            }));
            beforeEach(module(function($provide) {
                mockActivePort = {
                        rendererType:'VR'
                    };
                portContentFactory = {
                    getActivePort : function(){
                        return mockActivePort
                    }
                };
                $provide.value('portContentFactory', portContentFactory);
            }));
            beforeEach(
                inject(function ($compile, $rootScope) {
                    element = angular.element('<imaging-toolbar />');
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$digest();
                    isolatedScope = element.isolateScope();
                })
            );

            it('should have a directive', function () {
                assert.isDefined(element, 'imaging toolbar Directive is not defined');
            });

            it('should have an isolated scope', function () {
                assert.isDefined(isolatedScope, 'Imaging toolbar Directive does not have an isolated scope');
            });

            it('should have imagingBoxModel', function () {
                assert.isDefined(isolatedScope.imagingBoxModel, 'Imaging toolbar Directive does not have imagingBoxModel');
            });

            it('should have title', function () {
                assert.equal(isolatedScope.imagingBoxModel.title, 'Imaging toolbar', 'Imaging toolbar Directive has incorrect title');
            });

            it('should have type', function () {
                assert.equal(isolatedScope.imagingBoxModel.type, 'simple-bar', 'Imaging toolbar Directive has incorrect type');
            });

            it('should have default buttons', function () {
                assert.isArray(isolatedScope.imagingBoxModel.buttons);
                assert.equal(isolatedScope.imagingBoxModel.buttons.length, 6, 'Imaging toolbar Directive has incorrect number of buttons');
            });

            it('should have onclick function on a button', function () {
                var clickType = typeof(isolatedScope.imagingBoxModel.buttons[0].onclick);
                expect(clickType).to.be.equal('function', 'The button ' + isolatedScope.imagingBoxModel.buttons[0].title + ' do not have a onclick function');
                isolatedScope.imagingBoxModel.buttons[0].onclick();
            });

            it('should disable the eye button icon (because the there is not masks of segmentation) ', function () {
                var expected = typeof(isolatedScope.imagingBoxModel.buttons[eyeButtonIndex].isDisabled);
                expect(expected).to.equal('function');
            });
        });

        describe('imagingToolbar resize > 560 test :', function () {
            var element, scope, isolatedScope, resizeCallBack;

            beforeEach(module('deviceManagerServiceMock'));
            beforeEach(module('platform'));
            beforeEach(module('templates'));
            beforeEach(module('cloudav.viewerApp.mousemanagement'));
            beforeEach(module('imagingToolbarFactoryMock'));

            beforeEach(module(function($provide) {
                $provide.value('$toolFactory', {
                    toolBtnObj: function (config) {
                        this.title = config.title;
                        this.type = config.type;
                        this.onclick = config.onclick;
                    },
                    toolBoxObj: function (config) {
                        this.title = config.title;
                        this.type = config.type;
                        this.buttons = config.buttons;
                        this.resizeToolbox = function () {};
                    },
                    defaultToolBoxObj: function () {},
                    toolModalObj: function () {},
                    toolPanelObj: function () {},
                    Icon: function () {}
                });

                $provide.value('$window', {
                    innerHeight: 600,
                    innerWidth: 600
                });

                $provide.service('$windowResizeService', function () {
                    this.addCBforOnResize = function (fn) {
                        resizeCallBack = fn;
                    };
                });
            }));

            beforeEach(module('cloudav.viewerApp.services', function($provide) {
                $provide.value('segmentationService', segmentationService);
            }));
            beforeEach(module('cloudav.viewerApp.services', function($provide) {
                $provide.value('segmentationService', segmentationService);
            }));
            beforeEach(module(function($provide) {
                mockActivePort = {
                        rendererType:'VR'
                    };
                portContentFactory = {
                    getActivePort : function(){
                        return mockActivePort
                    }
                };
                $provide.value('portContentFactory', portContentFactory);
            }));
            beforeEach(
                inject(function ($compile, $rootScope) {
                    element = angular.element('<imaging-toolbar />');
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$digest();
                    isolatedScope = element.isolateScope();
                    resizeCallBack();
                })
            );

            it('should have callback on window resizing', function () {
                expect(isolatedScope.imagingBoxModel.orientation).to.be.equal('vertical', 'The isolatedScope.imagingBoxModel.orientation value should be vertical when the window have an innerWidth <= 560');
            });
        });

        describe('imagingToolbar resize < 560 test:', function () {
            var element, scope, isolatedScope, resizeCallBack;

            beforeEach(module('deviceManagerServiceMock'));
            beforeEach(module('platform'));
            beforeEach(module('templates'));
            beforeEach(module('cloudav.viewerApp.mousemanagement'));
            beforeEach(module('imagingToolbarFactoryMock'));

            beforeEach(module('cloudav.viewerApp.services', function($provide) {
                $provide.value('segmentationService', segmentationService);
            }));

            beforeEach(module(function($provide) {
                $provide.value('$toolFactory', {
                    toolBtnObj: function (config) {
                        this.title = config.title;
                        this.type = config.type;
                        this.onclick = config.onclick;
                    },
                    toolBoxObj: function (config) {
                        this.title = config.title;
                        this.type = config.type;
                        this.buttons = config.buttons;
                        this.resizeToolbox = function () {};
                    },
                    defaultToolBoxObj: function () {},
                    toolModalObj: function () {},
                    toolPanelObj: function () {},
                    Icon: function () {}
                });

                $provide.value('$window', {
                    innerHeight: 500,
                    innerWidth: 500
                });

                $provide.service('$windowResizeService', function () {
                    this.addCBforOnResize = function (fn) {
                        resizeCallBack = fn;
                    };
                });
            }));
            beforeEach(module(function($provide) {
                mockActivePort = {
                        rendererType:'VR'
                    };
                portContentFactory = {
                    getActivePort : function(){
                        return mockActivePort
                    }
                };
                $provide.value('portContentFactory', portContentFactory);
            }));

            beforeEach(
                inject(function ($compile, $rootScope) {
                    element = angular.element('<imaging-toolbar />');
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$digest();
                    isolatedScope = element.isolateScope();
                    resizeCallBack();
                })
            );

            it('should have callback on window resizing', function () {
                expect(isolatedScope.imagingBoxModel.orientation).to.be.equal('horizontal', 'The isolatedScope.imagingBoxModel.orientation value should be horizontal when the window have an innerWidth <= 560');
            });
        });
    });
