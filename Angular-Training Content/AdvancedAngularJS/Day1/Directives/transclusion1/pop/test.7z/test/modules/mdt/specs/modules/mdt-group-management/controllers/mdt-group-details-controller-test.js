/*
 * mdt-group-details-controller-test.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

define(['angular', 'angular-mocks', 'mdt/module', 'mdt/modules/mdt-group-management/controllers/mdt-group-details-controller', 'mdt/services/mdt-user-service'], function () {
    'use strict';

    describe('MDT Group Details controller', function () {
        var scope, state, stateParams, controller, MdtGroupService, MdtUserService, NotificationService, MdtGroupDataService;

        beforeEach(function () {
            angular.module('Platform.Services.NotificationService',[])
                    .service('NotificationService', [function(){
                        return {
                            addErrorMessage: sinon.stub()
                        }
                    }]);

            MdtGroupService = {
                getGroupDetails: sinon.stub(),
                update: sinon.stub()
            };

            MdtUserService = {
                searchUser: sinon.stub(),
                getContactInformationWithId: sinon.stub()
            };

            module('Mdt.Module.MdtGroupDetailsController', 'Mdt.MdtUserService', function ($provide) {
                $provide.value('MdtGroupService', {
                    then: function(fn){
                        fn(MdtGroupService);
                    }
                });
                $provide.value('MdtUserService', {
                    then: function(fn){
                        fn(MdtUserService);
                    }
                });

                // add a mock $Endpoint provider - it will return "" for any endpoint)
                $provide.value('$Endpoint', {
                    getEndpoint: function () {
                        return "";
                    },
                    getEndpointAsync: function(){
                        return {
                            then: function(fn){
                                fn();
                            }
                        }
                    }
                });
            });

            module('Mdt.Module.MdtGroupDataService');

            inject(function ($rootScope, $controller, _$log_, _MdtGroupService_, _MdtUserService_, _MdtGroupDataService_) {
                scope = $rootScope.$new();
                state = {go: sinon.stub()};
                stateParams = {groupId: 1};
                MdtGroupDataService = _MdtGroupDataService_;
                NotificationService = {
                    addErrorMessage: sinon.spy()
                };
                //Initialize the controller
                controller =
                        $controller('MdtGroupDetailsController', {
                            $scope: scope,
                            $state: state,
                            $log: _$log_,
                            $stateParams: stateParams,
                            MdtGroupService: _MdtGroupService_,
                            MdtUserService: _MdtUserService_,
                            NotificationService: NotificationService,
                            MdtGroupDataService: MdtGroupDataService
                        });
            });
        });

        it("should have a controller defined", function () {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it("should call update on MdtGroupService", function () {
            scope.groupDetails = {
                "groupId": "2",
                "groupName": "MDT Suicide 2",
                "admins": null,
                "members": null,
                "scheduling": null,
                "description": null,
                "reminder": null,
                "reminderDisabled": false,
                "caseLimitPerMeeting": 0,
                "caseLimitPerMeetingDisabled": false,
                "freezeWindowMillis": 0,
                "freezeWindowMillisDisabled": false,
                "reportTemplateId": null
            };

            scope.mdtGroupDetailsForm = {
                $valid : true
            };

            scope.update();

            expect(MdtGroupService.update.calledWith(scope.groupDetails)).to.equal(true);
        });

        it("should call user search web service", function() {
            var searchText = "searchPattern";

            scope.searchUser(searchText);

            expect(MdtUserService.searchUser.calledWith(searchText)).to.equal(true);
        });

        it("should handle error when searching for user with error notification", function() {
            var pattern = "ABC123",
                errorResponse = {
                    data: {
                        issue: [{
                            details: 'MOCK_ERROR'
                        }]
                    }
                };

            MdtUserService.searchUser = function(pattern, error){
                return error(errorResponse);
            };

            var result = scope.searchUser(pattern);

            expect(scope.isAdministratorSearchLoading).to.be.false;
            expect(scope.isMemberSearchLoading).to.be.false;
            expect(NotificationService.addErrorMessage.calledOnce).to.be.true;
            expect(result).to.be.empty;
        });

        it("should handle error when searching for user but do not display error notification when no records found", function() {
            var pattern = "ABC123",
                errorResponse = {
                    data: {
                        issue: [{
                            details: 'NO_MATCHING_RECORDS_FOUND'
                        }]
                    }
                };

            MdtUserService.searchUser = function(pattern, error){
                return error(errorResponse);
            };

            var result = scope.searchUser(pattern);

            expect(scope.isAdministratorSearchLoading).to.be.false;
            expect(scope.isMemberSearchLoading).to.be.false;
            expect(NotificationService.addErrorMessage.calledOnce).to.be.false;
            expect(result).to.be.empty;
        });

        it("should add member to group as first member", function() {
            var memberToAdd = {
                id: "memberId",
                content: {
                    name: {
                        family: ["mock"],
                        given: ["user"]
                    }
                }
            };

            scope.groupDetails = {};

            MdtUserService.getContactInformationWithId.returns(memberToAdd);

            scope.selectMember(memberToAdd);

            expect(scope.groupDetails.members[0].id).to.equal(memberToAdd.id);
        });

        it("should handle occurence selector validation", function() {
            scope.groupDetails = true;
            scope.occurrenceSelector(true);
            expect(scope.occurrenceSelectorIsValid).to.be.true;

            scope.groupDetails = true;
            scope.occurrenceSelector(false);
            expect(scope.occurrenceSelectorIsValid).to.be.false;

            scope.groupDetails = false;
            scope.occurrenceSelector(true);
            expect(scope.occurrenceSelectorIsValid).to.be.false;

            scope.groupDetails = true;
            scope.occurrenceSelectorIsValid = "asd";
            scope.occurrenceSelector(undefined);
            expect(scope.occurrenceSelectorIsValid).to.be.equals("asd");
        });

        it("should add member to group as a second member", function() {
            var memberToAdd = {
                id: "memberId",
                content: {
                    name: {
                        family: ["mock"],
                        given: ["user"]
                    }
                }
            };
            scope.groupDetails = {
                "members": [{id : "firstMemberId"}]
            };

            MdtUserService.getContactInformationWithId.returns(memberToAdd);

            scope.selectMember(memberToAdd);

            expect(scope.groupDetails.members[1].id).to.equal(memberToAdd.id);
        });

        it("should add administrator to group as first administrator", function() {
            var adminToAdd =  {
                id: "memberId",
                content: {
                    name: {
                        family: ["mock"],
                        given: ["user"]
                    }
                }
            };
            scope.groupDetails = {};

            MdtUserService.getContactInformationWithId.returns(adminToAdd);

            scope.selectAdministrator(adminToAdd);

            expect(scope.groupDetails.admins[0].id).to.equal(adminToAdd.id);
        });

        it("should add administrator to group as second administrator", function() {
            var adminToAdd =  {
                id: "memberId",
                content: {
                    name: {
                        family: ["mock"],
                        given: ["user"]
                    }
                }
            };
            scope.groupDetails = {
                "admins": [{id : "firstAdministratorId"}]
            };

            MdtUserService.getContactInformationWithId.returns(adminToAdd);

            scope.selectAdministrator(adminToAdd);

            expect(scope.groupDetails.admins[1].id).to.equal(adminToAdd.id);
        });

        it("should retrieve group details from web service when reset", function() {
            scope.reset();

            expect(MdtGroupService.getGroupDetails.called).to.equal(true);
        });

        it("should remove an administrator", function() {
            var administrator1 = {id : "administratorId1"};
            var administrator2 = {id : "administratorId2"};
            scope.groupDetails = {
                "admins": [administrator1, administrator2]
            };

            scope.removeAdministrator(administrator1);

            expect(scope.groupDetails.admins.length).to.equal(1);
        });

        it("should remove a member", function() {
            var member = {id : "memberId"};
            scope.groupDetails = {
                "members": [member]
            };

            scope.removeMember(member);

            expect(scope.groupDetails.members.length).to.equal(0);
        });

        it("should insert an admin and a member", function(){
            var item = {
                "title": "ResourcesUser",
                "id": "33576c66-f54f-419a-ace7-ae0e17b76cbb",
                "content": {
                    "resourceType": "ResourcesUser",
                    "name": {
                        "use": "official",
                        "family": [
                            "Smith"
                        ],
                        "given": [
                            "John",
                            "Albert"
                        ]
                    },
                    "managingOrganization": {
                        "organization": {
                            "reference": "organization/1"
                        },
                        "department": {
                            "reference": "organization/3"
                        },
                        "division": {
                            "reference": "organization/2"
                        },
                        "manager": {
                            "reference": "user/1"
                        },
                        "jobTitle": {
                            "coding": [
                                {
                                    "system": "http://hl7.org/fhir/v3/AdministrativeUser",
                                    "version": "1",
                                    "code": "Manager",
                                    "primary": true
                                }
                            ],
                            "text": "Manager"
                        },
                        "costCenter": "oxz123456",
                        "employeeNumber": "ID_123445"
                    },
                    "role": [
                        {
                            "code": [
                                {
                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                    "code": "practitioner",
                                    "display": "practitioner"
                                }
                            ],
                            "scopingOrganization": {
                                "reference": "organization/5"
                            },
                            "status": "active"
                        },
                        {
                            "code": [
                                {
                                    "system": "urn:hc.ge.com/pfh/platform/user-role:V1",
                                    "code": "practitioner",
                                    "display": "practitioner"
                                }
                            ],
                            "scopingOrganization": {
                                "reference": "organization/6"
                            },
                            "status": "active"
                        }
                    ],
                    "address": [
                        {
                            "line": [
                                "3300 Washtenaw Avenue, Suite 227"
                            ],
                            "city": "Ann Arbor",
                            "state": "MI",
                            "zip": "48104",
                            "country": "USA"
                        }
                    ],
                    "telecom": [
                        {
                            "system": "phone",
                            "value": "(+1) 734-677-7777"
                        },
                        {
                            "system": "email",
                            "value": "john@ge.com"
                        }
                    ],
                    "preferredLanguage": "English",
                    "type": "Human",
                    "status": "active",
                    "comment": "This is an Hospital Practioner 1",
                    "principalName": "username1@ge.com",
                    "gender": {
                        "coding": [
                            {
                                "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                "code": "M",
                                "display": "Male"
                            }
                        ]
                    },
                    "acceptedAgreement": [
                        {
                            "agreementUri": "http://goodcare.org/devices/id",
                            "accepted": false
                        }
                    ]
                }
            };
            scope.groupDetails = {
                "admins": []
            };

            MdtUserService.getContactInformationWithId.returns({
                display: 'John Albert Smith',
                title: 'Manager',
                email: 'john@ge.com',
                phone: '(+1) 734-677-7777'
            });

            scope.selectAdministrator(item);
            expect(scope.groupDetails.admins.length).to.equal(1);
            expect(scope.groupDetails.admins[0].display).to.equal('John Albert Smith');
            expect(scope.groupDetails.admins[0].title).to.equal('Manager');
            expect(scope.groupDetails.admins[0].email).to.equal('john@ge.com');
            expect(scope.groupDetails.admins[0].phone).to.equal('(+1) 734-677-7777');
            scope.groupDetails = {
                "admins": []
            };

            scope.groupDetails = {
                "members": []
            };
            scope.selectMember(item);
            expect(scope.groupDetails.members.length).to.equal(1);
            expect(scope.groupDetails.members[0].display).to.equal('John Albert Smith');
            expect(scope.groupDetails.members[0].title).to.equal('Manager');
            expect(scope.groupDetails.members[0].email).to.equal('john@ge.com');
            expect(scope.groupDetails.members[0].phone).to.equal('(+1) 734-677-7777');
        })
    });

    describe('MDT Group Details controller test getGroupDetails success handler', function () {
        var scope, state, stateParams, controller, MdtGroupService, NotificationService, MdtUserService;

        beforeEach(function () {
            angular.module('Platform.Services.NotificationService', []);

            MdtGroupService = {
                getGroupDetails: function (groupId, successHandler) {
                    successHandler({data: {}});
                },
                update: sinon.stub(),
                searchUser: sinon.stub()
            };

            MdtUserService = {
                searchUser: sinon.stub()
            };

            module('Mdt.Module.MdtGroupDetailsController', function ($provide) {
                $provide.value('MdtGroupService', {
                    then: function(fn){
                        fn(MdtGroupService);
                    }
                });
                $provide.value('MdtUserService', {
                    then: function(fn){
                        fn(MdtUserService);
                    }
                });

            });
            module('Mdt.Module.MdtGroupDataService');

            inject(function ($rootScope, $controller, _$log_, _MdtGroupService_, _MdtUserService_) {
                scope = $rootScope.$new();
                state = {};
                stateParams = {groupId: 1};
                //MdtGroupService = _MdtGroupService_;
                //MdtUserService = _MdtUserService_;
                controller = $controller;
                NotificationService = {
                    addErrorMessage: sinon.spy()
                };

                //Initialize the controller
                controller('MdtGroupDetailsController', {
                    $scope: scope,
                    $state: state,
                    $log: _$log_,
                    $stateParams: stateParams,
                    MdtGroupService: _MdtGroupService_,
                    MdtUserService: _MdtUserService_,
                    NotificationService: NotificationService
                });
            });
        });

        it("should call getGroupDetails success handler which does the initialization", function() {
            scope.getGroupDetails();

            var expectedValueAfterInitialization = {
                "reminder": {"offsetUnit": "HOURS"},
                "reminderDisabled": true,
                "caseLimitPerMeetingDisabled": true,
                "freezeWindowMillisDisabled": true
            };

            expect(scope.fetchingGroupDetails).to.equal(false);
            expect(JSON.stringify(scope.groupDetails)).to.equal(JSON.stringify(expectedValueAfterInitialization));

        });

    });

    describe('MDT Group Details controller test getGroupDetails, update failure handlers', function () {
        var scope, state, stateParams, controller, MdtGroupService, NotificationService, MdtUserService, MdtGroupDataService;

        beforeEach(function () {
            angular.module('Platform.Services.NotificationService', []);

            MdtGroupService = {
                getGroupDetails: function (groupId, successHandler, failureHandler) {
                    failureHandler({status: 'response status'});
                },
                update: function (group, successHandler, failureHandler) {
                    failureHandler({status: 'response status'});
                }
            };

            MdtUserService = {};

            module('Mdt.Module.MdtGroupDetailsController', function ($provide) {
                $provide.value('MdtGroupService', {
                    then: function(fn){
                        fn(MdtGroupService);
                    }
                });
                $provide.value('MdtUserService', {
                    then: function(fn){
                        fn(MdtUserService);
                    }
                });

            });

            module('Mdt.Module.MdtGroupDataService');

            inject(function ($rootScope, $controller, _$log_, _MdtGroupService_, _MdtUserService_, _MdtGroupDataService_) {
                scope = $rootScope.$new();
                scope.showAlertMessage = sinon.stub();
                scope.mdtGroupDetailsForm = {
                    $valid: true
                };
                state = {};
                stateParams = {groupId: 1};
                //MdtGroupService = _MdtGroupService_;
                NotificationService = {
                    addErrorMessage: sinon.spy()
                };
                //MdtUserService = _MdtUserService_;
                MdtGroupDataService = _MdtGroupDataService_;
                //Initialize the controller
                controller = $controller('MdtGroupDetailsController', {
                    $scope: scope,
                    $state: state,
                    $log: _$log_,
                    $stateParams: stateParams,
                    MdtGroupService: _MdtGroupService_,
                    NotificationService: NotificationService,
                    MdtUserService: _MdtUserService_,
                    MdtGroupDataService: MdtGroupDataService
                });
            });
        });


        it("should call getGroupDetails failure handler", function() {
            NotificationService.addErrorMessage.reset();

            scope.getGroupDetails();

            expect(scope.fetchingGroupDetails).to.equal(false);
            expect(scope.groupDetails).to.be.an('object').and.be.empty;
            expect(NotificationService.addErrorMessage.calledOnce).to.be.true;

            var fn = MdtGroupDataService.getSelectedItemId;
            MdtGroupDataService.getSelectedItemId = sinon.stub();
            MdtGroupDataService.getSelectedItemId.returns(undefined);
            scope.groupDetails = undefined;
            scope.getGroupDetails();
            expect(scope.groupDetails).to.be.undefined;

            scope.groupDetails = {};
            MdtGroupDataService.getSelectedItemId = fn;
        });

        it("should call update failure handler", function() {
            NotificationService.addErrorMessage.reset();

            scope.update();

            expect(scope.fetchingGroupDetails).to.equal(false);
            expect(NotificationService.addErrorMessage.calledOnce).to.be.true;
        });

    });

    describe('MDT Group Details controller test, getter setter tests ', function () {
        var scope, state, stateParams, controller, NotificationService;

        beforeEach(function () {
            angular.module('Platform.Services.NotificationService', []);

            module('Mdt.Module.MdtGroupDetailsController', function ($provide) {
                $provide.value('MdtGroupService', {
                    then: function(){}
                });
                $provide.value('MdtUserService', {
                    then: function(){}
                });
            });
            module('Mdt.Module.MdtGroupDataService');

            inject(function ($rootScope, $controller, _$log_) {
                scope = $rootScope.$new();
                state = {};
                stateParams = {groupId: 1};
                NotificationService = {
                    addErrorMessage: sinon.spy()
                };
                //Initialize the controller
                controller = $controller('MdtGroupDetailsController', {
                    $scope: scope,
                    $state: state,
                    $log: _$log_,
                    $stateParams: stateParams,
                    NotificationService: NotificationService
                });
                scope.mdtGroupDetailsForm = {
                    reminderOffsetValue: {
                        $setViewValue: sinon.stub(),
                        $render: sinon.stub()
                    },
                    reminderOffsetUnit: {
                        $setViewValue: sinon.stub(),
                        $render: sinon.stub()
                    },
                    caseLimitPerMeeting: {
                        $setViewValue: sinon.stub(),
                        $render: sinon.stub()
                    },
                    freezeWindowMillis: {
                        $setViewValue: sinon.stub(),
                        $render: sinon.stub()
                    }
                };
            });
        });

        it("should disable reminders", function() {
            scope.groupDetails = {};
            scope.reminderDisabled(true);

            expect(scope.groupDetails.reminderDisabled).to.equal(true);
            expect(scope.mdtGroupDetailsForm.reminderOffsetValue.$setViewValue.calledWith(undefined)).to.equal(true);
            expect(scope.mdtGroupDetailsForm.reminderOffsetValue.$render.called).to.equal(true);
            expect(scope.mdtGroupDetailsForm.reminderOffsetUnit.$setViewValue.calledWith(undefined)).to.equal(true);
            expect(scope.mdtGroupDetailsForm.reminderOffsetUnit.$render.called).to.equal(true);
        });

        it("should switch case limit ", function() {
            scope.groupDetails = {};
            scope.caseLimitPerMeetingDisabled(true);

            expect(scope.groupDetails.caseLimitPerMeetingDisabled).to.equal(true);
            expect(scope.mdtGroupDetailsForm.caseLimitPerMeeting.$setViewValue.calledWith(undefined)).to.equal(true);
            expect(scope.mdtGroupDetailsForm.caseLimitPerMeeting.$render.called).to.equal(true);

            scope.caseLimitPerMeetingDisabled(false);

            expect(scope.groupDetails.caseLimitPerMeetingDisabled).to.equal(false);
            expect(scope.mdtGroupDetailsForm.caseLimitPerMeeting.$setViewValue.calledWith(undefined)).to.equal(true);
            expect(scope.mdtGroupDetailsForm.caseLimitPerMeeting.$render.called).to.equal(true);

            scope.caseLimitPerMeetingDisabled(undefined);

            expect(scope.groupDetails.caseLimitPerMeetingDisabled).to.equal(false);

            scope.groupDetails = null;
            scope.caseLimitPerMeetingDisabled(true);
            scope.groupDetails = {};
        });

        it("should switch window", function() {
            scope.groupDetails = {};
            scope.freezeWindowMillisDisabled(true);

            expect(scope.groupDetails.freezeWindowMillisDisabled).to.equal(true);
            expect(scope.mdtGroupDetailsForm.freezeWindowMillis.$setViewValue.calledWith(undefined)).to.equal(true);
            expect(scope.mdtGroupDetailsForm.freezeWindowMillis.$render.called).to.equal(true);

            scope.freezeWindowMillisDisabled(false);

            expect(scope.groupDetails.freezeWindowMillisDisabled).to.equal(false);
            expect(scope.mdtGroupDetailsForm.freezeWindowMillis.$setViewValue.calledWith(undefined)).to.equal(true);
            expect(scope.mdtGroupDetailsForm.freezeWindowMillis.$render.called).to.equal(true);

            scope.freezeWindowMillisDisabled(undefined);

            expect(scope.groupDetails.freezeWindowMillisDisabled).to.equal(false);

            scope.groupDetails = null;
            scope.freezeWindowMillisDisabled(true);
            scope.groupDetails = {};
        });

    });
 });
