angular.module('xjtweb-platform').constant('annotStateService', {});
