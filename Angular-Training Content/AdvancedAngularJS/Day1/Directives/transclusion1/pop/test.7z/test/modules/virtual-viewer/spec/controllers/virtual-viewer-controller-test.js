define(['angular-mocks', 'virtual-viewer/controllers/virtualViewerController'], function () {
    'use strict';

    describe('Virtual viewer controller test cases', function () {
        var scope, controller, state, stateParams, endPoint, caseDataService, translate, sce, accessToken, window;
        
        var endpoints = {
            documentViewerUrl: 'http://docviewer.com/endpoint'
        };
        
        beforeEach(function () {
            module('cloudav.virtualViewer.Controllers', function ($provide) {
                $provide.value('$stateParams', {
                    attachmentName: 'attachmentName',
                    caseId: 'caseId',
                    attachmentId: 'docId'
                });
                
                $provide.value('$Endpoint', {
                    getEndpoint: function(key) {
                        return endpoints[key];
                    }
                });

                $provide.value('AccessToken', {
                    token: {
                        token_type: 'bearer',
                        access_token: 'access_token'
                    }
                });

                $provide.value('$sce', {
                    trustAsResourceUrl: function(url) {
                        return url;
                    }
                });
                
                $provide.value('CaseDataService', {
                    getCaseDetails: function(stateId) {
                        return {
                            then: function(callback) {
                                callback({
                                    patient: 'patient_name'
                                });
                            }
                        };
                    }
                });
                
                $provide.value('$translate', {});
                
                $provide.value('$state', {
                    destination: null,
                    params: {
                        previousState: null
                    },
                    config: null,
                    go: function(destination, params, config) {
                        this.destination = destination;
                        this.params = params;
                        this.config = config;
                    }
                });
            });

            inject(function ($rootScope, $controller, $stateParams, $Endpoint, CaseDataService, $translate, $sce, AccessToken, $window) {
                scope = $rootScope.$new();
                controller = $controller;
                stateParams = $stateParams;
                endPoint = $Endpoint;
                caseDataService = CaseDataService;
                translate = $translate;
                sce = $sce;
                accessToken = AccessToken;
                window = $window;

                //Initialize the controller
                controller('cloudav.virtualViewerController', {$scope: scope, $stateParams: stateParams, CaseDataService: caseDataService, $translate: translate , $EndPoint: endPoint, AccessToken: accessToken});
            });
        });

        it("should initialize scope's attachment name", function () {
            expect(scope.attachmentName).to.equal('attachmentName');
        });

        it("should convert patient DOB into date format", function () {
            var dob = "20001211";
            var dateInDateFormat = scope.convertToDate(dob).toDateString();
            var expectedDate = new Date('12/11/2000').toDateString();

            expect(dateInDateFormat).to.equal(expectedDate);
        });

        it("should calculate patient's age from patient's DOB", function () {
            var dob = "20001211";
            var age = scope.calculatePatientAge(dob);

            expect(age).to.be.at.least(14);
        });
        
        it('should retrive patient data', function() {
            expect(scope.patient).to.equal('patient_name');
        });
        
        it('should set uri to document viewer', function() {
            expect(scope.docUri).to.equal('http://docviewer.com/endpoint?documentId=caseId/object/docId');
        });

        it('should navigate back to the original module', function() {
            var windowHistoryBackSpy = sinon.spy(window.history, 'back');
            scope.navigateBack();
            expect(windowHistoryBackSpy).to.have.been.called;
        });
    });
});