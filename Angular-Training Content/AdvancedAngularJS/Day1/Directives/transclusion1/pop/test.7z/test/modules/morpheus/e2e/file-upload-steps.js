var chai = require('chai');
var chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
var expect = chai.expect;
config = require('./cucumber.conf.js').config;

var pageLoadWrapper = function () {
    'use strict';

    this.Given(/^I open the case creation site$/, function (callback) {
        browser.get("/").then(function () {
            element(by.id('caseinbox_switch_to')).click();
            element(by.id('createCasesButton')).click();
            expect(element(by.id("createCaseTitle")).getText()).to.eventually.equal('Create a Case').and.notify(callback);
        });
    });

    this.Then(/^the the attachment file list should not be rendered$/, function (callback) {
        expect((element.all(by.binding('file.name')).count())).to.eventually.equal(0).and.notify(callback);
    });

    this.Then(/^the the size of the attachments should be (\d+)$/, function (arg1, callback) {
        expect(element(by.binding("fileList.length")).getText()).to.eventually.equal('0').and.notify(callback);
    });

};

module.exports = pageLoadWrapper;