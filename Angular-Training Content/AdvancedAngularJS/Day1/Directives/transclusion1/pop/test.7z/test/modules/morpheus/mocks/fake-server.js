/*  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Saravana Velusamy<saravana.velusamy@ge.com>
 */


define(['angular'], function(angular){
    /**
     * Module to initialize & configure the Sinon fake server
     */
    var mod = angular.module('cloudav.caseExchange.fakeServer', []);

    /**
     * Provider for Sinon Mock Server.
     * It also contains the methods to fake the server response
     */
    mod.provider('$MockServerLoader', function(){
        var mockLoader, mockServer;

        /**
         * Initilization function.
         * This will initialize the Sinon server.
         */
        this.init = function () {
            // Creating a fake server
            mockServer = sinon.fakeServer.create();
            return mockServer;
        };

        /**
         * Function to fake the CaseDataService > getCaseDetails call.
         * @params:
         *  responseStatus: Ajax response status. For example: 200 - Success, 500 - Failure
         *  mockData: Mock data to be returned in service response
         */
        this.fakeGetUrlCall = function(responseStatus, data){
            mockServer.respondWith('GET', 'http://morpheussso.grc-apps.svc.ice.ge.com/v1/dashboardurl', [responseStatus, {"Content-Type": "application/json"}, JSON.stringify(data)]);
        };

        /**
         * Override method for AngularJS Provider
         * @returns:
         *  mockLoader: Mock provider.
         */
        this.$get = function(){
            if(!mockLoader){
                mockLoader = this;
            }
            return mockLoader;
        };
    });
});
