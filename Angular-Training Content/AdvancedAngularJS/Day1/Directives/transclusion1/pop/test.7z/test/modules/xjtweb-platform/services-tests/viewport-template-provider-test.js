define([ 'angular', 'angular-mocks', 'modules/xjtweb-platform/services/viewport-template-provider', 'mocks/viewport-template-provider-test-mocks', 'deviceManagerServiceMock' ], function(ng, mocks) {
    'use strict';

    /**
     * @ngdoc service
     * @name xjtweb-platform.provider:viewportTemplateFactoryProvider-test
     * @author Benjamin Beeman
     * 
     * @description This is the test suite for the
     *              {@link xjtweb-platform.$viewportTemplateFactory $viewportTemplateFactory} and its supporting
     *              {@link xjtweb-platform.provider:viewportTemplateFactoryProvider provider} .
     * 
     * Copyright (c) 2015 by General Electric Company. All rights reserved.
     * 
     * The copyright to the computer software herein is the property of General Electric Company. The software may be
     * used and/or copied only with the written permission of General Electric Company or in accordance with the terms
     * and conditions stipulated in the agreement/contract under which the software has been supplied.
     */
    describe('Viewport Template Factory, ', function() {

        var viewportTemplateFactory;
        var deviceManagerService;

        beforeEach(module('deviceManagerServiceMock'));
        beforeEach(module('viewport-template-provider'));
        beforeEach(module('viewport-template-provider-test-mocks'));

        beforeEach(module(function($provide, VpTemplateProvTestMocks) {
            $provide.factory('$xjtweb', VpTemplateProvTestMocks.xjtweb);
        }));

        beforeEach(inject(function($viewportTemplateFactory, $deviceManagerService) {
            viewportTemplateFactory = $viewportTemplateFactory;
            deviceManagerService = $deviceManagerService;
        }));
        
        /**
         * @ngdoc method
         * @name InitViewportTemplateFactoryTest
         * @methodOf xjtweb-platform.provider:viewportTemplateFactoryProvider-test
         * 
         * @description This test method determines that the
         *              {@link xjtweb-platform.$viewportTemplateFactory $viewportTemplateFactory} is created as an
         *              object.
         */
        describe('Init viewportTemplateFactory:', function() {

            it('$viewportTemplateFactory should be a typeof object', function() {
                expect(typeof viewportTemplateFactory).to.equal('object');
            });

        });

        /**
         * @ngdoc method
         * @name getViewportTemplateTest
         * @methodOf xjtweb-platform.provider:viewportTemplateFactoryProvider-test
         * 
         * @description This tests the
         *              {@link xjtweb-platform.$viewportTemplateFactory#getViewportTemplate getViewportTemplate}
         *              function.
         */
        describe('Test getViewportTemplate function:', function() {

            var testUrlString = 'modules/xjtweb-platform/directives/viewport/viewport-template.html';

            it('Should return \'' + testUrlString + '\'', function() {
                expect(viewportTemplateFactory.getViewportTemplate()).to.equal(testUrlString);
            });

        });

    });
});
