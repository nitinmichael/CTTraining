define(['angular', 'angular-mocks', 'lodash', 'linkingMocks', 'linkingModule/services/linkingmanager', 'linkingModule/services/linkingsettings'], function(ng, mocks) {

    'use strict';

    // TODO: move this one to xjtweb_dev stream
    xdescribe('linking manager test', function() {

        var linkingManagerFactory;
        var rootScope;

        beforeEach(module('cloudav.viewerApp.linkingviewport'));

        beforeEach(module(function($provide, linkingMocks, linkingSettings) {
            $provide.factory('linkingFilter', linkingMocks.linkingFilterMock);
            $provide.value('linkingSettings', linkingSettings);
        }));

        beforeEach(inject(function($rootScope, linkingManager) {
            rootScope = $rootScope;
            linkingManagerFactory = linkingManager;
            linkingManagerFactory.viewEventEmitter = 'viewport1';

        }));

        it('should link a view without error ', function() {
            expect(linkingManagerFactory.isLinked('ViewId')).to.equal(false);
            linkingManagerFactory.link('ViewId');
            expect(linkingManagerFactory.isLinked('ViewId')).to.equal(true);
        });

        it('should unlink a view without error ', function() {
            expect(linkingManagerFactory.isLinked('ViewId')).to.equal(false);
            linkingManagerFactory.link('ViewId');
            expect(linkingManagerFactory.isLinked('ViewId')).to.equal(true);
            linkingManagerFactory.unlink('ViewId');
            expect(linkingManagerFactory.isLinked('ViewId')).to.equal(false);
        });

        it('should unlink an existing view without error ', function() {
            expect(linkingManagerFactory.isLinked('ViewId')).to.equal(false);
            linkingManagerFactory.unlink('ViewId');
            expect(linkingManagerFactory.isLinked('ViewId')).to.equal(false);
        });

        it('publish throw error if view Event Emitter is null or undefined', function() {
            expect(function() {
                linkingManagerFactory.publish('event',undefined, {});
            }).to.throw(Error, 'View Event Emitter should not be null');

            expect(function() {
                linkingManagerFactory.publish('event', null,{});
            }).to.throw(Error, 'View Event Emitter should not be null');
        });


        it('publish data should be an object', function() {
            expect(function() {
                linkingManagerFactory.publish('event', "0", null);
            }).to.throw(TypeError);
            expect(function() {
                linkingManagerFactory.publish('event', "0", 'string');
            }).to.throw(TypeError);
            expect(function() {
                linkingManagerFactory.publish('event', "0", {});
            }).to.not.throw(TypeError);
        });

        it('should not call callback if is not the emitter and is not linked ', function() {
            var res;
            var data = {
                zoom: 10,
                viewEventEmitter: 'viewport1'
            };
            var callback = function(event, data) {
                res = data;
            };

            expect(linkingManagerFactory.isLinked('viewport1')).to.equal(false);
            expect(linkingManagerFactory.isLinked('viewport2')).to.equal(false);

            var listenerCallback = linkingManagerFactory.createListenerCallback('zoom', 'viewport2', callback);
            expect(listenerCallback).to.be.function;
            listenerCallback(data, null);
            expect(res).to.equal(undefined);
        });

        it('should check filters and call callback if it is the emitter', function() {
            var res;
            var data = {
                zoom: 10,
                viewEventEmitter: 'viewport1'
            };
            var callback = function(data, enveloppe) {
                res = data;
            };

            expect(linkingManagerFactory.isLinked('viewport1')).to.equal(false);

            var listenerCallback = linkingManagerFactory.createListenerCallback('zoom', 'viewport1', callback);
            expect(listenerCallback).to.be.function;

            listenerCallback(data, null);
            rootScope.$apply();

            expect(res).to.equal(data);
        });

        it('should check filters and call callback if view ports are linked', function() {
            var res;
            var data = {
                zoom: 10,
                viewEventEmitter: 'viewport1'
            };
            var callback = function(data, enveloppe) {
                res = data;
            };

            linkingManagerFactory.link('viewport1');
            linkingManagerFactory.link('viewport2');
            expect(linkingManagerFactory.isLinked('viewport1')).to.equal(true);
            expect(linkingManagerFactory.isLinked('viewport2')).to.equal(true);


            var listenerCallback = linkingManagerFactory.createListenerCallback('zoom', 'viewport2', callback);
            expect(listenerCallback).to.be.function;

            listenerCallback(data, null);

            rootScope.$apply();
            expect(res).to.equal(data);
        });

        it('should call callbacks if it is the emitter when publish events', function() {
            var res;

            var data = {
                zoom: 10
            };

            var callback = function(data) {
                res = data;
            };

            expect(linkingManagerFactory.isLinked('viewport1')).to.equal(false);

            linkingManagerFactory.subscribe('zoom', 'viewport1', callback);
            linkingManagerFactory.publish('zoom', 'viewport1', data);

            rootScope.$apply();
            expect(res).to.equal(data);
        });


        it('should call callbacks if viewports are linked when publish events', function() {
            var res;

            var data = {
                zoom: 10
            };

            var callback = function(data) {
                res = data;
            };

            linkingManagerFactory.link('viewport1');
            linkingManagerFactory.link('viewport2');
            expect(linkingManagerFactory.isLinked('viewport1')).to.equal(true);
            expect(linkingManagerFactory.isLinked('viewport2')).to.equal(true);

            linkingManagerFactory.subscribe('zoom', 'viewport1', callback);
            linkingManagerFactory.publish('zoom','viewport2', data);

            rootScope.$apply();
            expect(res).to.equal(data);
        });

        it('should not call callbacks if viewports are not linked when publish events', function() {
            var res;

            var data = {
                zoom: 10
            };

            var callback = function(data) {
                res = data;
            };

            expect(linkingManagerFactory.isLinked('viewport1')).to.equal(false);
            expect(linkingManagerFactory.isLinked('viewport2')).to.equal(false);

            linkingManagerFactory.publish('zoom', 'viewport1', data);
            linkingManagerFactory.subscribe('zoom', 'viewport2', callback);

            rootScope.$apply();
            expect(res).to.equal(undefined);
        });

        it('should not call callbacks if filters are not checked when publish events', function() {
            var res;

            var data = {
                zoom: 10
            };

            var callback = function(data) {
                res = data;
            };

            linkingManagerFactory.link('viewport1');
            linkingManagerFactory.link('viewport2');
            expect(linkingManagerFactory.isLinked('viewport1')).to.equal(true);
            expect(linkingManagerFactory.isLinked('viewport2')).to.equal(true);

            linkingManagerFactory.publish('zoom2', 'viewport1', data);
            linkingManagerFactory.subscribe('zoom2', 'viewport2', callback);

            rootScope.$apply();
            expect(res).to.be.equal(undefined);
        });

        it('should unsubscribe from events', function() {
            var res;
            var i = 0;
            var array = [];

            var data = {
                zoom: 10
            };

            var callback = function(data) {
                res = data;
                i++;
            };

            linkingManagerFactory.link('viewport1');
            linkingManagerFactory.link('viewport2');
            expect(linkingManagerFactory.isLinked('viewport1')).to.equal(true);
            expect(linkingManagerFactory.isLinked('viewport2')).to.equal(true);

            var subObj = linkingManagerFactory.subscribe('zoom_un', 'viewport2', callback);
            array.push(subObj);
            linkingManagerFactory.publish('zoom_un','viewport1', data);

            rootScope.$apply();
            expect(res).to.be.equal(data);
            expect(i).to.be.equal(1);

            // unsubscribe
            res = undefined;
            linkingManagerFactory.unsubscribe(array);
            linkingManagerFactory.publish('zoom_un','viewport1', data);

            rootScope.$apply();
            expect(res).to.be.equal(undefined);
            expect(i).to.be.equal(1);

        });
    });
});
