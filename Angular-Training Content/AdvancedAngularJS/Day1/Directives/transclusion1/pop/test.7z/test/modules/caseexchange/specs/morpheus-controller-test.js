/*
 *  Morpheus-controller-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jyothi Jayaraman<Jyothi.Jayaraman@ge.com>
 */

/**
 * Test specs for Morpheus Controller
 */

define(['angular', 'angular-mocks',
        'modules/caseexchange/modules/morpheus/controllers/morpheus-controller',
        'mocks/fake-server',
        'mocks/case-exchange-mock-service',
        'modules/caseexchange/modules/morpheus/services/get-morpheus-service'], function () {
    'use strict';

    var MODES = {
            create: 'AUTOCREATE'
        };

    //mock data with no admin role
    var loggedInUserDetailsWithNoAdmin = {
        role: [ { id: 1, code: [{ code: 'practitioner'}] },
                { id: 2, code: [{ code: 'user'}] } ]
        };

    //mock data with admin role
    var loggedInUserDetailsWithAdmin = {
        role: [ { id: 1, code: [{ code: 'administrator'}] },
                { id: 2, code: [{ code: 'user'}]}]
        };


    var rootScope, scope, state, controller, morpheusService, caseExchangeDataService,  CreateTarget,
        morpheusServiceStubWithAdminData, mockServer, $mockServerLoader, adminJson, patientJson, practitionerJson;

    describe('Morpheus Controller Test Suite::', function() {

        beforeEach(function() {
            // Load the Sinon fake server.
            module('cloudav.caseExchange.fakeServer');
            // Load the module for the mock data first
            module('cloudav.caseExchange.mocks');
            module('cloudav.caseExchange.morpheusCtrl');
        });

        beforeEach(function () {
            module('cloudav.caseExchange.morpheusCtrl', function ($provide) {
                $provide.value('$state', {
                    transitionTo: function (url) {
                    },
                    current: {
                        params: {
                            mode: MODES.create
                        },
                        name: 'test'
                    }
                });

                $provide.value('$stateParams', {
                    id: function () {
                    }
                });
            });

        });

        // Initialize the scope and controller variables
        beforeEach(inject(function($rootScope, $state, $controller,  _MorpheusServices_, _CaseExchangeDataService_,
                                   CaseExchangeMocks, $MockServerLoader) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            state = $state;

            controller = $controller;
            morpheusService = _MorpheusServices_;
            caseExchangeDataService = _CaseExchangeDataService_;
            $mockServerLoader = $MockServerLoader;
            // Call the init to initialize the Sinon Mock Data Server.
            mockServer = $mockServerLoader.init();

            adminJson = CaseExchangeMocks.getAdminJson();
            patientJson = CaseExchangeMocks.getPatientJson();
            practitionerJson = CaseExchangeMocks.getPractitionerJson();

            // Initialize the controller before each specs
            CreateTarget = function() {
                controller('MorpheusCtrl', {
                    $scope : scope,
                    $rootScope : rootScope
                });
            }
        }));

        it('should have a controller', function() {
            assert.isDefined(controller, 'Controller is not defined');
        });

        it('Scope should have error on load', function() {
            controller = CreateTarget();
            var stateTransitionToSpy = sinon.spy(state, 'transitionTo');
            rootScope.$broadcast('error');
            assert(stateTransitionToSpy.withArgs('caseexchange.caseinbox').calledOnce);
        });

        it('should call $state.transitionTo caseexchange.morpheusAdmin', function() {
            var callback = sinon.spy(state, "transitionTo");
            controller = CreateTarget();
            $mockServerLoader.fakeQueryCurrentUserCall(200, adminJson);
                mockServer.respond();
                rootScope.$apply();
            assert(callback.calledOnce);
            assert(callback.calledWith('caseexchange.morpheus.morpheusAdmin'));
        });

        it('should call $state.transitionTo caseexchange.morpheusUser', function() {
            var callback = sinon.spy(state, "transitionTo");
            controller = CreateTarget();
            $mockServerLoader.fakeQueryCurrentUserCall(200, patientJson);
            mockServer.respond();
            rootScope.$apply();
            assert(callback.calledOnce);
            assert(callback.calledWith('caseexchange.caseinbox'));
        });

        it('should call $state.transitionTo caseexchange.morpheusPractitioner', function() {
            var callback = sinon.spy(state, "transitionTo");
            controller = CreateTarget();
            $mockServerLoader.fakeQueryCurrentUserCall(200, practitionerJson);
            mockServer.respond();
            rootScope.$apply();
            assert(callback.calledOnce);
            assert(callback.calledWith('caseexchange.morpheus.morpheusUser'));
        });

        it('should call $state.transitionTo current page', function() {
            rootScope.onLoad = false;
            var callback = sinon.spy(state, "transitionTo");
            controller = CreateTarget();
            $mockServerLoader.fakeQueryCurrentUserCall(200, patientJson);
            mockServer.respond();
            rootScope.$apply();
            assert(callback.calledOnce);
        });
    });
});