/*
 *  post-processing-condition-marshaller-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 */

/**
 * Spec file for Get Instruction Conditions Service Test module
 */

define([
  'angular',
  'angular-mocks',
  'modules/caseexchange/modules/case-automation/services/post-processing-condition-marshaller-service',
  'mocks/case-exchange-mock-service',
  'mocks/fake-server'
], function() {
  'use strict';

  describe('Test Get Instruction Conditions Details', function() {
    var postProcessingConditionMarshallerService, rootScope, originalAjax, $mockServerLoader, marshalConditionJson,unmarshalConditionJson, mockServer;

    beforeEach(function() {
      // Load the module for the mock data first
      module('cloudav.caseExchange.mocks');
      // Load the Sinon fake server.
      module('cloudav.caseExchange.fakeServer');

      // store original $.ajax
      originalAjax = $.ajax;
      // provide mock services for postProcessingConditionMarshallerService
      module('Services.postProcessingConditionMarshallerService', function($provide) {
        $provide.factory('configurationService', ['$q',
          function($q) {
            return {
              getProperty: function() {
                return $q.when({});
              }
            }
          }
        ]);
      });
      // inject dependencies for GetInstructionConditionsService
      inject(function(_PostProcessingConditionMarshallerService_, _CaseExchangeDataService_, $rootScope, CaseExchangeMocks, $MockServerLoader) {
        postProcessingConditionMarshallerService = _PostProcessingConditionMarshallerService_;
        rootScope = $rootScope;
        $mockServerLoader = $MockServerLoader;
        marshalConditionJson = CaseExchangeMocks.marshalConditionJson();
        unmarshalConditionJson = CaseExchangeMocks.unmarshalConditionJson();
        mockServer = $mockServerLoader.init();
      });
    });

    // restore $.ajax for use by other test suites
    afterEach(function() {
      $.ajax = originalAjax;
    });

    it('should define a service', function() {
      assert.isDefined(postProcessingConditionMarshallerService, 'GetInstructionConditionsService is defined');
    });

    describe('This service will do the desired operations on jsons, like marshalling, unmarshalling.', function() {
      it('should marshal json into desired format', function() {

        var conditionJson = marshalConditionJson,
          expectedModality = "MR",
          expectedDescription = "description",
          expectedAlgo = "Algorithm 1",
          marshalCondition = postProcessingConditionMarshallerService.marshalCondition(conditionJson),
          marshalJson = marshalCondition.conditionOne;

        expect(expectedModality).to.equal(marshalJson.conditionOne.value);
        expect(expectedDescription).to.equal(marshalJson.conditionTwo.value);
        expect(expectedAlgo).to.equal(marshalCondition.conditionTwo.value);
      });

      it('should unmarshal json into desired format', function() {
        var conditionJson = unmarshalConditionJson,
          conditionOneJson = conditionJson.conditionOne,
          unmarshalCondition = postProcessingConditionMarshallerService.unmarshalCondition(conditionJson);

        expect(unmarshalCondition.modality).to.equal(conditionOneJson.conditionOne.value);
        expect(unmarshalCondition.description).to.equal(conditionOneJson.conditionTwo.value);
        expect(unmarshalCondition.algorithm).to.equal(conditionJson.conditionTwo.value);
      });
    });
  });
});