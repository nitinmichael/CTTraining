/*
 *  test-main.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Saravana Velusamy<saravana.velusamy@ge.com>
 */

/**
 * Karma-RequireJS configuration file for Case Exchange module
 */
var tests = [];
for (var file in window.__karma__.files) {
  if (window.__karma__.files.hasOwnProperty(file)) {
    if (/-test\.js$/.test(file)) {
      tests.push(file);
    }
  }
}
console.log(tests);
require.config({
    // Karma serves files under /base, which is the basePath from your config file
    baseUrl: '/base/public',
    paths: {
        'jquery': 'uaf/hdx/components/3rdparty/jquery/jquery',
        'angular': 'uaf/3rdparty/angular/angular',
        'angular-mocks': 'uaf/3rdparty/angular/angular-mocks',
        'angularTranslate': 'uaf/3rdparty/angular-translate/dist/angular-translate',
        'angularTranslatePartialLoader': 'uaf/3rdparty/angular-translate/dist/angular-translate-loader-partial/angular-translate-loader-partial',
        'lodash': 'uaf/3rdparty/lodash',
        'postal': 'uaf/3rdparty/postal/lib/postal',
        'angular-ui': 'uaf/hdx/components/3rdparty/angular-ui/ui-bootstrap-tpls-0.12.1',
        'angularRoute'    : './uaf/3rdparty/angular-route/angular-route',
        'morpheus': './modules/morpheus',
        'widgets': './modules/morpheus/directives',
        'uiRouter': 'uaf/3rdparty/angular-ui-router/build/angular-ui-router',
        'mocks': '../test/modules/morpheus/mocks'
    },
    shim: {
        'angular': { deps: ['jquery'], 'exports': 'angular' },
        'angular-mocks': {
            deps: ['angular'],
            'exports': 'angular.mock'
        },
        'angular-ui': {
            deps: ['angular']
        },
        'uiRouter': { deps: ['angular'] },
        'angularTranslate': { deps: ['angular'] },
        'angularTranslatePartialLoader': { deps: ['angularTranslate'] }
    },
    // dynamically load all test files
    deps: tests,
    // start running the tests, once Require.js is done
    callback: window.__karma__.start
});
