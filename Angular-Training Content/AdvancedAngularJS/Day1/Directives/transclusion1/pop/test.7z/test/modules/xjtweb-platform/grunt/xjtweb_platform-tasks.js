/**
 * @ngdoc object
 * @name xjtweb-platform.object:xjtweb-tasks
 * @author Benjamin Beeman
 * 
 * @description This is the grunt task configuration file for the {@link xjtweb-platform} module.
 */
module.exports = {

    /**
     * @ngdoc property
     * @name copy
     * @propertyOf xjtweb-platform.object:xjtweb-tasks
     * 
     * @description Sets up the xjtweb-platform module grunt copy command.
     */
    copy : {
        // Only copies the files specific to a module
        expand : true,
        // cwd: 'public/',
        dest : 'bin/',
        src : [ 'shell/*' ]
    },

    /**
     * @ngdoc property
     * @name compress
     * @propertyOf xjtweb-platform.object:xjtweb-tasks
     * 
     * @description Sets up the xjtweb-platform module grunt compress command.
     */
    compress : {
        options : {
            archive : function() {
                return 'bin/xjtweb-platform.zip';
            }
        },
        files : [ {
            expand : true,
            src : [ 'public/modules/xjtweb-platform/*' ]
        } ]
    },

    /**
     * @ngdoc property
     * @name karma
     * @propertyOf xjtweb-platform.object:xjtweb-tasks
     * 
     * @description Sets up the path to the karma.confi.js file for the xjtweb-platform module unit tests.
     */
    karma : {
        configFile : 'test/modules/xjtweb-platform/karma.conf.js'
    },
    
    clean : ['test/modules/xjtweb-platform/report/'],

    /**
     * @ngdoc property
     * @name shell
     * @propertyOf xjtweb-platform.object:xjtweb-tasks
     * 
     * @description Sets up the xjtweb-platform module grunt shell command.
     */
    shell : {
        command : 'pwd && cd test/modules/xjtweb-platform && pwd && mkdir -pv report/junit/test-report && java -jar /workspace/pfhtools_dev/sonar-karma-junit-parser1.0.0/parser.jar ./ report/junit/TESTS-xunit.xml report/junit/test-report test.js'
    }
};
