module.exports = {
    copy:{
	    // Only copies the files specific to a module
        expand: true,
        //cwd: 'public/',
        dest: 'bin/',
        src: ['shell/*']
    },
    compress:{
        options: {
            archive: function () {
                return 'bin/patient-view.zip';
            }
        },
		files: [{ expand: true, src: ['public/modules/patient-view/*'] }]
    },
    karma:{
    	configFile: 'test/modules/patient-view/karma.conf.js'
    },
    shell: {
        command: 'pwd && cd test/modules/patient-view && pwd && mkdir -pv report/junit/test-report && java -jar /workspace/pfhtools_dev/sonar-karma-junit-parser1.0.0/parser.jar specs report/junit/TESTS-xunit.xml report/junit/test-report test.js'
    }
};