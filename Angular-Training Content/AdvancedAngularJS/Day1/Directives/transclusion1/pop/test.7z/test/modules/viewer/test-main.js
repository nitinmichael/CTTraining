var tests = [];
for (var file in window.__karma__.files) {
    if (window.__karma__.files.hasOwnProperty(file)) {
        if (/-test\.js$/.test(file)) {
            tests.push(file);
        }
    }
}

require.config({
    // Karma serves files under /base, which is the basePath from your config file
    baseUrl: '/base/public',

    map: {
        '*': {

            // override the xjtweb module: for tests we use a mock:
            'xjtweb': '../test/modules/viewer/mocks/xjtwebPlatformMock',

            // The mappings below are optional, they only function as shortcuts for long module paths.
            // The modules can be also referenced using their long path (e.g. is valid to have
            // 'modules/viewer/modules/linking/module' as a requireJS dependency in a test or mock module.)
            'linkingModule': 'modules/viewer/modules/linking',
            'mousemanagementModule': 'modules/viewer/modules/mousemanagement',
            'viewerModule': 'modules/viewer/modules/viewer-app',
            'viewerServices': 'modules/viewer/services',

            // these are less optional, as they lie outside baseUrl
            'deviceManagerServiceMock': '../test/modules/viewer/mocks/deviceManagerServiceMock',
            'viewerModelsMock': '../test/modules/viewer/mocks/viewer-models-mock',
            'endpointConfigMock': '../test/modules/viewer/mocks/endpointConfigMock',
            'imageAreaToolbarMocks': '../test/modules/viewer/mocks/imageAreaToolbarMocks',
            'imagingToolbarMocks': '../test/modules/viewer/mocks/imagingToolbarMocks',
            'linkingMocks': '../test/modules/viewer/mocks/linkingmocks',
            'mouseModeToolbarMocks': '../test/modules/viewer/mocks/mouseModeToolbarMocks',
            'platformMock': '../test/modules/viewer/mocks/platformMock',
            'serviceDiscoveryMock': '../test/modules/viewer/mocks/serviceDiscoveryMock',
            'settingsAreaToolbarTestMocks': '../test/modules/viewer/mocks/settingsAreaToolbarTestMocks',
            'viewerMockModule': '../test/modules/viewer/mocks/viewerMockModule',
            'viewerOrchestrationMock': '../test/modules/viewer/mocks/viewerOrchestrationMock',
            'viewerServicesMock': '../test/modules/viewer/mocks/viewerServicesMock',
            'portContentFactoryMock': '../test/modules/viewer/mocks/portcontentFactoryMock',
            'viewportParameterStorageMock': '../test/modules/viewer/mocks/viewportParameterStorageMock',
            'viewerServiceMock': '../test/modules/viewer/mocks/viewerServiceMock',
        }
    },
    paths: {
        // Is this loaded at all? why giving it a junk name did not cause complain?
        'angular': 'uaf/3rdparty/angular/angular',
        'angular-mocks': 'uaf/3rdparty/angular/angular-mocks',
        'angular-ui': 'uaf/3rdparty/angular-ui/ui-bootstrap-tpls-0.12.1',
        'angularRoute': 'uaf/3rdparty/angular-route/angular-route',
        'uiRouter': 'uaf/3rdparty/angular-ui-router/build/angular-ui-router',
        'angularTranslate': 'uaf/3rdparty/angular-translate/dist/angular-translate',
        'angularTranslatePartialLoader': 'uaf/3rdparty/angular-translate/dist/angular-translate-loader-partial/angular-translate-loader-partial',
        'lodash': 'uaf/3rdparty/lodash',
        'postal': 'uaf/3rdparty/postal/lib/postal',
        'hdx': 'uaf/hdx/js/hdx',
        'hdx-bootstrap': 'uaf/hdx/components/hdx-bootstrap/js/hdx-bootstrap',
        'jquery': 'uaf/hdx/components/3rdparty/jquery/dist/jquery',
        'bootstrap': 'uaf/hdx/components/3rdparty/bootstrap/js',
        'prettify': "uaf/hdx/components/3rdparty/prettify/prettify",
        'directive': "uaf/hdx/components/3rdparty/angular-ui/ui-bootstrap-tpls-0.12.1",

        // non-AMD resources from xjtweb-platform:
        'jsjami': '3rdparty/xjtweb/1.0.0/jsjami',
        'GraphicalObjectMock': '../test/modules/xjtweb-platform/mocks/graphicalobjectmock',
        'renderingServiceMock': '../test/modules/xjtweb-platform/mocks/renderingServiceMock',

        // only paths pointing to JS files without a define() call should be added here.
        // JS files with a define() call (AMD files) should be placed to the 'map' above.

    },
    shim: {
        'angular': {
            'exports': 'angular'
        },
        'angular-mocks': {
            deps: ['angular'],
            'exports': 'angular.mock'
        },
        'uiRoute': {
            deps: ['angular'],
        },
        'angularTranslatePartialLoader': {
            deps: ['angular', 'angularTranslate'],
            'exports': 'angularTranslatePartialLoader'
        },
        'renderingServiceMock': {
            deps: ['angular'],
        },
        GraphicalObjectMock: ['xjtweb']
    },

    // dynamically load all test files
    // commented out because of tracing:
    // deps : tests,

    // start running the tests, once Require.js is done
    // commented out because of tracing:
    // callback : window.__karma__.start
});

// xjtwebConstants should do this, not us:
var XJTWEB = XJTWEB ? XJTWEB : {};

// Phantom JS does not support bind functionnality mock it here.
Function.prototype.bind = Function.prototype.bind || function(thisp) {
    var fn = this;
    return function() {
        return fn.apply(thisp, arguments);
    };
};

// RequireJS/AngularJS tracing configured below:
(function() {

    // intercept RequireJS module loading:
    window.rtree.interceptRJSmoduleLoading();

    // intercept angular.module function calls:
    window.ngTracing.interceptNgModuleFunction();

    // angular-mocks is not added statically to the host page (as opposed to angular):
    require(['angular-mocks'], function() {

        window.ngMockTracing.interceptModuleFunction();

        // we load the tests now, after we intercepted angular.mock.module:
        require(tests, function() {
            window.rtree.printModuleInfo();

            window.__karma__.start();

            window.ngTracing.checkModuleRefs();
            window.ngMockTracing.checkMockModuleCalls();

        });
    });

})();
