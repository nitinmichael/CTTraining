define(['angular', 'jsjami'], function(angular){

    angular.module('xjtweb-platform', []);

    XJTWEB.ServiceLocator = {
        register: function() {},
        resolve: function() {}
    };
});
