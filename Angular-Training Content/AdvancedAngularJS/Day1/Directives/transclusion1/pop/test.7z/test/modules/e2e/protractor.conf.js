//Why cannot we pass this information from e2e-tasks?
var serverOptions = require('../../../grunt/options/connect').server.options;
var appUrl = serverOptions.protocol + '://localhost:' + serverOptions.port;

exports.config = {
  baseUrl: appUrl,
//  seleniumAddress: 'http://localhost:4444/wd/hub',
  directConnect: true,
  capabilities: {
    'browserName': 'chrome'
  },
  specs: ['spec/**/*.js'],
  jasmineNodeOpts: {
    showColors: true, // Use colors in the command line report.
    includeStackTrace: true
  }
};