/*
 *  viewtypeswitch-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Stéphane Breton <stephane.bretone@ge.com>
 */

/**
 * Spec file for Viewer > modules > viewer-app > widgets > view-type-switch directive
 */
//

define(['angular', 'angular-mocks', 'viewerModule/widgets/hangingprotocol'], function () {
    'use strict';

    describe('hangingProtocol Directive Test :', function () {
        var element, scope;

        beforeEach(module('cloudav.viewerApp.widgets'));
        beforeEach(module('templates'));

        beforeEach(
            inject(function ($compile, $rootScope) {
                scope   = $rootScope.$new();
                element = $compile('<hanging-protocol />')(scope);
                scope.$digest();
            })
        );

        describe('defined directive', function () {
            it('should have a directive', function () {
                assert.isDefined(element, 'hanging-protocol Directive is not defined');
            });
        });
    });
});
