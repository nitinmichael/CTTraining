/*
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular',
    'create-case/module',
    'mocks/fake-server'], function () {
    'use strict';

    describe('Create Case Service Test Suite::', function () {
        var CreateCaseService, $mockServerLoader, caseExchangeDataService, stub, mockServer, rootScope, sampleResponse;
        beforeEach(function() {
            // Load the Sinon fake server.
            module('cloudav.caseExchange.fakeServer');

            module('Services.createCaseService', function($provide){
                $provide.factory('configurationService', ['$q', function($q){
                    return {
                        getProperty: function(){
                            return $q.when({});
                        }
                    }
                }]);
            });

            inject(function ($MockServerLoader, _CreateCaseService_, _CaseExchangeDataService_, $rootScope){
                CreateCaseService = _CreateCaseService_;
                $mockServerLoader = $MockServerLoader;
                caseExchangeDataService = _CaseExchangeDataService_;
                rootScope = $rootScope;
                sampleResponse = {id: 1};

                mockServer = $mockServerLoader.init();
            });
        });

        describe('createCase() function', function(){

            it('should reject promise on invalid input', function(){
                CreateCaseService.createCase("").then(function(){
                    assert(false, "Error should have been thrown");
                }, function(){
                });
            });

            it('should reject promise on http error', function(){
                $mockServerLoader.fakeCreateCaseCall(500, null);
                CreateCaseService.createCase({}).then(function(){
                    assert(false, "Error should have been thrown");
                }, function(error){
                    expect(error.status).to.equal(500);
                });
                mockServer.respond();
                rootScope.$apply();
            });

            it('should return response on valid input', function(){
                $mockServerLoader.fakeCreateCaseCall(200, sampleResponse);
                CreateCaseService.createCase({}).then(function(data){
                    expect(data.id).to.equal(sampleResponse.id);
                }, function(){
                    assert(false, "Error should not have been thrown");
                });
                mockServer.respond();
                rootScope.$apply();
            });

        });

        describe('createTransaction() function', function(){

            it('should reject promise on invalid input', function(){
                CreateCaseService.createTransaction("", 0).then(function(){
                    assert(false, "Error should have been thrown");
                }, function(){
                });
            });

            it('should reject promise on http error', function(){
                $mockServerLoader.fakeCreateTransactionCall(0, 500, null);
                CreateCaseService.createTransaction({}, 0).then(function(){
                    assert(false, "Error should have been thrown");
                }, function(error){
                    expect(error.status).to.equal(500);
                });
                mockServer.respond();
                rootScope.$apply();
            });

            it('should return response on valid input', function(){
                $mockServerLoader.fakeCreateTransactionCall(0, 200, sampleResponse);
                CreateCaseService.createTransaction({}, 0).then(function(data){
                    expect(data.id).to.equal(sampleResponse.id);
                }, function(){
                    assert(false, "Error should not have been thrown");
                });
                mockServer.respond();
                rootScope.$apply();
            });

        });

        describe('uploadCaseAttachment() function', function(){

            it('should reject promise on invalid input data', function(){
                CreateCaseService.uploadCaseAttachment("", 1).then(function(){
                    assert(false, "Error should have been thrown");
                }, function(){
                });
            });

            it('should reject promise on invalid input caseId', function(){
                CreateCaseService.uploadCaseAttachment({}, 0).then(function(){
                    assert(false, "Error should have been thrown");
                }, function(){
                });
            });

            it('should reject promise on http error', function(){
                $mockServerLoader.fakeUploadCaseAttachmentCall(1, 500, null);
                CreateCaseService.uploadCaseAttachment({}, 1).then(function(){
                    assert(false, "Error should have been thrown");
                }, function(error){
                    expect(error.status).to.equal(500);
                });
                mockServer.respond();
                rootScope.$apply();
            });

            it('should return response on valid input', function(){
                $mockServerLoader.fakeUploadCaseAttachmentCall(1, 200, sampleResponse);
                CreateCaseService.uploadCaseAttachment({}, 1).then(function(data){
                    if(!angular.isObject(data)) {
                        data = JSON.parse(data);
                    }
                    expect(data.id).to.equal(sampleResponse.id);
                }, function(){
                    assert(false, "Error should not have been thrown");
                });
                mockServer.respond();
                rootScope.$apply();
            });

        });

    });

});
