define([ 'angular-mocks', 'modules/xjtweb-platform/services/annotation/annotationUIService' ], function() {
    describe('annotationUIService tests', function() {
        var annotationUIService;
        var testElement;

        beforeEach(function() {
            testElement = createDiv(document.body);

            createDiv(testElement, 'static-annotation');
            createDiv(testElement, 'static-annotation-shadow');

            createDiv(testElement, 'annotation-full-noshow');
            createDiv(testElement, 'annotation-partial-noshow');
        });

        afterEach(function() {
            testElement.parentElement.removeChild(testElement);
        });

        function createDiv(parent, classListItem) {
            var div = document.createElement('div');
            if (classListItem) {
                div.classList.add(classListItem);
            }
            parent.appendChild(div);
            return div;
        }

        beforeEach(module('xjtweb.platform.service.annotationUIService'));

        beforeEach(inject(function(_annotationUIService_) {
            annotationUIService = _annotationUIService_;
        }));

        it('handles invalid input ', function() {
            annotationUIService.setAnnotationVisibility('anything');
            $.each(testElement.children, function(index, e) {
                assert.isTrue(e.style.visibility === undefined || e.style.visibility === '');
            });
        })

        it('can set "full" annotation state', function() {
            annotationUIService.setAnnotationVisibility('full');

            $(".static-annotation")[0].style.visibility.should.equal("visible");
            $(".static-annotation-shadow")[0].style.visibility.should.equal("visible");

            $(".annotation-full-noshow")[0].style.visibility.should.equal("hidden");
            $(".annotation-partial-noshow")[0].style.visibility.should.equal("visible");
        });

        it('can set "partial" annotation state', function() {
            annotationUIService.setAnnotationVisibility('partial');

            $(".static-annotation")[0].style.visibility.should.equal("visible");
            $(".static-annotation-shadow")[0].style.visibility.should.equal("visible");

            $(".annotation-full-noshow")[0].style.visibility.should.equal("visible");
            $(".annotation-partial-noshow")[0].style.visibility.should.equal("hidden");
        });

        it('can set "hidden" annotation state', function() {
            annotationUIService.setAnnotationVisibility('hidden');

            $(".static-annotation")[0].style.visibility.should.equal("hidden");
            $(".static-annotation-shadow")[0].style.visibility.should.equal("hidden");

        });

        it('can can display 3D annotations', function() {
            var transformation = [];
            var image = {
                slice : {
                    imageToRas : []
                }
            };
            var ira = {};

            var viewport3d = {
                getImage : sinon.stub(),
                getDisplay2Image : sinon.stub(),
                getGroupId : sinon.stub(),
                annot : {
                    displayAnnotation : sinon.spy()
                }
            };
            viewport3d.getImage.returns(image);
            viewport3d.getDisplay2Image.returns(transformation);
            viewport3d.getGroupId.returns('groupID');

            var renderEngine = {
                getImageRenderAttributes : sinon.stub()
            };
            renderEngine.getImageRenderAttributes.returns(ira);

            annotationUIService.showAnnotations(viewport3d, renderEngine);

            viewport3d.annot.displayAnnotation.called.should.equal(true);
        });

    });
});