define(['angular'], function(angular){
angular.module('cloudav.viewerApp')
    .constant('viewerMock', {
            viewerSettings: {
                data: {
                    'renderingGatewayUrl': 'http://localhost:9000/image',
                    'mprJson': {},
                    'vrJson': {}
                }
            },
            serviceLocator: function() {
                this.registerServices = function() {
                    XJTWEB.ServiceLocator.register(XJTWEB.SERVICE.LINKING_MANAGER, {
                        publish: function() {}
                    });
                    XJTWEB.ServiceLocator.register(XJTWEB.SERVICE.SCENE_MANAGER, function() {});
                };
            }
        });
});