define(['angular', 'postal', 'angular-mocks', 'jquery', 'modules/xjtweb-platform/directives/viewport/viewport', 'mocks/viewport-test-mocks', 'linkingMocks'], function(angular, postal) {
    'use strict';

    /**
     * @ngdoc service
     * @name xjtweb-platform.provider:viewport-test
     * @author Benjamin Beeman
     *
     * @description This is the test suite for the {@link xjtweb-platform.directive:viewPort viewPort}.
     *
     * Copyright (c) 2015 by General Electric Company. All rights reserved.
     *
     * The copyright to the computer software herein is the property of General Electric Company. The software may be
     * used and/or copied only with the written permission of General Electric Company or in accordance with the terms
     * and conditions stipulated in the agreement/contract under which the software has been supplied.
     */
    describe('Viewport Directive Test :', function() {

        var $compile, $logger, $scope, $timeout, element, parentScope;

        var linkingFilter, mouseModeService, portContentFactory, RendererFactory;

        var addCBforOnResize, currentConf, getViewportTemplate, isViewportParameterObjReturnVal,
            isViewportParameterObjSpy, portObjCfgMock, setPortsMockResults;

        var portSp = {
            id: 'wh'
        };

        var viewportParameterStorage = function() {
            this.$get = function() {
                var that = this;
                that.currentConf = null;
                that.studyInfo = {
                    studyDescription: 'My Study desc',
                    studyDate: '2015-11-27'
                };
                return {
                    ViewportParameterObj: function() {
                        var vpParmObj = this;
                        vpParmObj.seriesUid = undefined;
                        vpParmObj.renderingUrl = undefined;
                        vpParmObj.annotationUrl = undefined;
                        vpParmObj.ports = [{
                            index: 0,
                            menu: false,
                            cssLayout: 'twoByTwo',
                            usePredefinedLayout: true,
                            getId: function() {
                                return '0';
                            },
                            visible: true,
                            viewType: '3D',
                            volumeInfo: {
                                modality: ''
                            }
                        }, {
                            index: 1,
                            menu: false,
                            cssLayout: 'twoByTwo',
                            usePredefinedLayout: true,
                            getId: function() {
                                return '1';
                            },
                            visible: true,
                            viewType: 'MR',
                            volumeInfo: {
                                modality: ''
                            }
                        }, {
                            index: 2,
                            menu: false,
                            cssLayout: 'twoByTwo',
                            usePredefinedLayout: true,
                            getId: function() {
                                return '2';
                            },
                            visible: true,
                            viewType: 'MR',
                            volumeInfo: {
                                modality: ''
                            }
                        }, {
                            index: 3,
                            menu: false,
                            cssLayout: 'twoByTwo',
                            usePredefinedLayout: true,
                            getId: function() {
                                return '3';
                            },
                            visible: true,
                            viewType: 'MR',
                            volumeInfo: {
                                modality: ''
                            }
                        }];
                        this.setSeriesUid = function(newSeriesUid) {
                            vpParmObj.seriesUid = newSeriesUid;
                        };
                        this.setRenderingUrl = function(newRenderingUrl) {
                            vpParmObj.renderingUrl = newRenderingUrl;
                        };
                        this.setAnnotationUrl = function(newAnnotationUrl) {
                            vpParmObj.annotationUrl = newAnnotationUrl;
                        };
                        this.setPorts = function(ports) {
                            vpParmObj.ports = ports;
                        };

                        return vpParmObj;

                    },
                    isViewportParameterObj: function() {
                        return isViewportParameterObjReturnVal;
                    },
                    setGroups: sinon.spy(),
                    getGroups: function() {
                        return [{
                            groupID: '1.23.4',
                            imageType: '3D'
                        }];
                    },
                    setCurrentConfiguration: function(config) {
                        that.currentConf = config;
                    },
                    getCurrentConfiguration: function() {
                        return that.currentConf;
                    },
                    setVolumes: sinon.spy(),
                    setPatientInfo: sinon.spy(),
                    setRenderingUrls: sinon.spy(),
                    setAnnotationUrl: sinon.spy(),
                    getSaveStates: sinon.spy(),
                    set2DImageModelControllerUrl: sinon.spy(),
                    set2DPixelStreamerUrl: sinon.spy(),
                    getStudyInfo: function() {
                        return that.studyInfo;
                    },
                    setStudyInfo: sinon.spy(),
                    getRenderingUrl: sinon.spy(),
                    getNumberOfPorts: function() {
                        return 16;
                    },
                    getPatientInfo: sinon.spy()
                };
            };
        };

        beforeEach(function() {
            module('viewport');
            // Load Templates
            module('templates');
            module('viewport-test-mocks');
            module('cloudav.viewerApp.linkingviewport');

            module(function($provide, $compileProvider, VpTestMocks, linkingMocks) {

                $provide.factory('$viewportTemplateFactory', VpTestMocks.viewportTemplateFactory);

                $provide.factory('$windowResizeService', VpTestMocks.windowResizeService);

                $provide.factory('segmentationService', VpTestMocks.segmentationService);

                $provide.provider('$viewportParameterStorage', viewportParameterStorage);

                $provide.factory('portContentFactory', function() {
                    return {
                        setActivePort: function(port) {
                            portSp = port;
                        },
                        setConfig: function(cfg) {
                            setPortsMockResults = cfg.ports[0].mockTest;
                        },
                        renderTypeState: sinon.stub().returns('MPR'),
                        resetMouseMode: sinon.spy(),
                        getActivePort: function() {
                            return portSp;
                        },
                        getSlicesNumber: sinon.spy(),
                        getSliceIndex: sinon.spy(),
                        synchronizeWindowing: sinon.spy()
                    };
                });

                $provide.factory('sliderManager', function() {
                    return {
                        getSliderMin: sinon.spy()
                    };
                });

                $provide.factory('$logger', function() {
                    return {
                        error: sinon.spy()
                    };
                });

                $provide.factory('$popupCloserService', function() {
                    return {
                        closePopup: sinon.spy()
                    };
                });

                RendererFactory = {
                    clearAll: sinon.spy()
                };

                $provide.value('$xjtweb', {
                    RendererFactory: RendererFactory,
                });

                mouseModeService = {
                    setMouseMode: sinon.spy(),
                    getCurrentMouseMode: sinon.spy()
                };

                $provide.value('mouseModeStoreService', mouseModeService);

                linkingFilter = linkingMocks.linkingFilterTestCallbackMocks();

                $provide.value('linkingFilter', linkingFilter);

                $provide.value('linkingSettings', linkingMocks.linkingSettingsMock);
            });

            inject(function(_$compile_, _$logger_, _$timeout_, _portContentFactory_, $rootScope, $viewportTemplateFactory, $viewportParameterStorage, $windowResizeService) {

                $compile = _$compile_;
                $logger = _$logger_;
                $timeout = _$timeout_;
                portContentFactory = _portContentFactory_;

                parentScope = $rootScope.$new();
                getViewportTemplate = sinon.spy($viewportTemplateFactory, 'getViewportTemplate');
                isViewportParameterObjSpy = sinon.spy($viewportParameterStorage, 'isViewportParameterObj');
                addCBforOnResize = sinon.spy($windowResizeService, 'addCBforOnResize');
                $viewportParameterStorage.setCurrentConfiguration($viewportParameterStorage.ViewportParameterObj());
                currentConf = $viewportParameterStorage.ViewportParameterObj();
            });
        });

        var createVP = function() {
            var vpEl;
            element = angular.element('<view-port config="paramConfig"></view-port>');
            parentScope.paramConfig = portObjCfgMock;
            vpEl = $compile(element)(parentScope);
            parentScope.$digest();
            $scope = parentScope.$$childTail;
            return vpEl;
        };

        describe('Viewport, ', function() {

            /**
             * @ngdoc property
             * @name Viewport Define TEST,
             * @propertyOf xjtweb-platform.provider:viewport-test
             *
             * @description This test determines that the {@link xjtweb-platform.directive:viewPort viewPort} directive
             *              was initiated when complied.
             */
            it('should have a directive', function() {
                var vpEle = createVP();
                assert.isDefined(vpEle, 'Directive is not defined');
            });

            it('should be called Once a directive', function() {
                createVP();
                chai.expect(addCBforOnResize.called).to.equal(true);
            });

            /**
             * @ngdoc property
             * @name Viewport getViewportTemplate call-back TEST
             * @propertyOf xjtweb-platform.provider:viewport-test
             *
             * @description This test determines that the {@link xjtweb-platform.directive:viewPort viewPort} directive
             *              calls {@link xjtweb-platform.$viewportTemplateFactory#getViewportTemplate
             *              $viewportTemplateFactory.getViewportTemplate} to get the URL to its template when it is
             *              initiated.
             *
             * It also determines that $viewportParameterStorage.isViewportParameterObj is called to test that the input
             * config is an instance of {@link xjtweb-platform.type.ViewportParameterObj ViewportParameterObj}.
             *
             * The $viewportParameterStorage.isViewportParameterObj is mocked to return false. This test also checks
             * that a $logger.error message is called since the return is false.
             *
             */
            it('$viewportTemplateFactory.getViewportTemplate should have been called.', function() {
                createVP();
                chai.expect(getViewportTemplate.called).to.equal(true);
            });

            it('$viewportParameterStorage.isViewportParameterObj should have been called.', function() {
                createVP();
                chai.expect(isViewportParameterObjSpy.called).to.equal(true);
            });

            it('$logger.error should have been called since we have mocked the $viewportParameterStorage.isViewportParameterObj to return false.', function() {
                isViewportParameterObjReturnVal = false;
                createVP();
                chai.expect($logger.error.called).to.equal(true);
            });

            /**
             * @ngdoc property
             * @name Viewport_clickViewPort_init,
             * @propertyOf xjtweb-platform.provider:viewport-test
             *
             * @description This test determines that the clickViewPort function is present in the inner scope of the
             *              viewport directive when it is initialized.
             */
            it('Initial scope should have a clickViewPort function.', function() {
                createVP();
                expect(typeof $scope.clickViewPort).to.equal('function');
            });

            /**
             * @ngdoc property
             * @name Viewport_clickViewPort_portContent
             * @propertyOf xjtweb-platform.provider:viewport-test
             *
             * @description This test determines that when the clickViewPort function is executed it calls setActivePort
             *              on the portContentFactory.
             */
            it('Initial scope should have a clickViewPort function.', function() {
                createVP();
                var id = 'My Test Port';
                var port = {
                    id: id,
                    groupId: '13513.561'
                };
                $scope.selectedViewport = {
                    groupId: 'fakeGroupUid'
                };
                $scope.clickViewPort(port);
                expect(portSp.id).to.equal(id);
            });

            /**
             * @ngdoc property
             * @name Viewport_clickViewPort_selectedViewport
             * @propertyOf xjtweb-platform.provider:viewport-test
             *
             * @description This test determines that when the clickViewPort function is executed it sets the
             *              selectedViewport scope variable with the input port.
             */
            it('Initial scope should have a clickViewPort function.', function() {
                createVP();
                var id = 'My Test Port';
                var port = {
                    id: id,
                    groupId: '13513.561'
                };
                $scope.selectedViewport = {
                    groupId: 'fakeGroupUid'
                };
                $scope.clickViewPort(port);
                $scope.$apply();
                expect($scope.selectedViewport.id).to.equal(id);
            });

            /**
             * @ngdoc property
             * @name Viewport_callSetConfig
             * @propertyOf xjtweb-platform.provider:viewport-test
             *
             * @description This test determines that when the viewport has a valid config object that the ports are set
             *              on the portContentFactory.
             */
            it('With a valid config object, ports should by set by calling setPorts on the portContentFactory.', function() {
                var mockedPort = 'myMockedPort';
                isViewportParameterObjReturnVal = true;
                portObjCfgMock = {
                    ports: [{
                        cssLayout: 'twoByTwo',
                        index: 0,
                        usePredefinedLayout: true,
                        mockTest: mockedPort
                    }]
                };
                createVP();
                expect(setPortsMockResults).to.equal(mockedPort);
            });

            /**
             * @ngdoc property
             * @name Viewport_callviewportLayoutChange
             * @propertyOf xjtweb-platform.provider:viewport-test
             *
             * @description This test determines that the viewportLayoutChange callback is properly called when a
             *              'viewerLayoutChange' event is broadcasted in the scope
             */
            it('testing the Viewport Layout Change Callback ', function() {
                // Just testing the callback no need to test if Angular is able to call it
                var event;
                var VISIBLE_PORTS = 2;
                var args = {
                    visiblePorts: VISIBLE_PORTS,
                    cssLayout: 'twoByOne',
                    usePredefinedLayout: true,
                    visible: false
                };

                expect(function() {
                    $scope.$$listeners.viewerLayoutChange[0](event, args);
                }).not.to.throw();

                expect($scope.visiblePorts).to.equal(2);
                expect($scope.config.ports[0].cssLayout).to.equal('twoByOne');
                expect($scope.config.ports[0].usePredefinedLayout).to.equal(true);
                expect($scope.config.ports[0].visible).to.equal(true);

                args = {};
                expect(function() {
                    $scope.$$listeners.viewerLayoutChange[0](event, args);
                }).to.throw(RangeError);

                args = {
                    visiblePorts: 'String'
                };
                expect(function() {
                    $scope.$$listeners.viewerLayoutChange[0](event, args);
                }).to.throw(TypeError);
            });

            /**
             * @ngdoc property
             * @name Viewport_callviewportLayoutChange
             * @propertyOf xjtweb-platform.provider:viewport-test
             *
             * @description This test determines that the viewportLayoutChange callback is properly called when a
             *              'viewerLayoutChange' event is broadcasted in the scope
             */
            it('should not process the change layout if this is the same as already selected', function() {
                var event;
                var VISIBLE_PORTS = 2;
                var args = {
                    visiblePorts: VISIBLE_PORTS,
                    cssLayout: 'twoByOne',
                    usePredefinedLayout: true,
                    visible: false
                };

                $scope.$$listeners.viewerLayoutChange[0](event, args);
                args.visiblePorts = 3;
                $scope.$$listeners.viewerLayoutChange[0](event, args);
                expect($scope.visiblePorts).to.equal(2);
            });

            it('test sameType Filter filter returns false if 2 viewTypes are different (example VR and MR)', function() {
                createVP();
                // View Event Emmiter 1 has type MR 0 has type VR
                var data = {
                    viewEventEmitter: 1
                };
                var result = linkingFilter.filters.SAME_TYPE_FILTER(0, data);
                expect(result).to.equal(false);
            });

            it('test sameType Filter filter returns true if 2 viewTypes are the same (example VR and VR)', function() {
                createVP();
                // View Event Emmiter 1 has type MR 0 has type VR
                var data = {
                    viewEventEmitter: 0
                };

                expect(linkingFilter.filters.SAME_TYPE_FILTER(0, data)).to.equal(true);
            });

            it('test sameType Filter filter returns false if the viewport is not visible', function() {
                createVP();
                // View Event Emmiter 1 has type MR 0 has type VR
                var data = {
                    viewEventEmitter: 0
                };
                currentConf.ports[0].visible = false;
                expect(linkingFilter.filters.SAME_TYPE_FILTER(0, data)).to.equal(false);
            });

            it('test not VR view receiver filter returns true if VR view is not the receiver', function() {
                createVP();
                // View Event Emmiter 1 has type MR
                var data = {
                    viewEventEmitter: 1
                };

                expect(linkingFilter.filters.NOT_VR_VIEW_RECEIVER(1, data)).to.equal(true);
            });

            it('test not VR view receiver filter returns false if the viewport is not visible', function() {
                createVP();
                // View Event Emmiter 1 has type MR
                var data = {
                    viewEventEmitter: 1
                };
                currentConf.ports[1].visible = false;
                expect(linkingFilter.filters.NOT_VR_VIEW_RECEIVER(1, data)).to.equal(false);
            });

            it('test not VR view receiver filter returns false if VR view is the receiver', function() {
                createVP();
                // View Event Emmiter 1 has type MR
                var data = {
                    viewEventEmitter: 1
                };
                currentConf.ports[0].visible = true;
                expect(linkingFilter.filters.NOT_VR_VIEW_RECEIVER(0, data)).to.equal(false);
            });

            it('test Same Viewtype renderer filter returns true if 3D view have same renderer type', function() {
                createVP();
                postal.channel(XJTWEB.VIEWPORT_UPDATE.CHANNEL).publish(XJTWEB.VIEWPORT_UPDATE.TOPIC.SWITCH_TYPE, {
                    index: 1,
                    viewTypeTarget: '3D',
                    rendererType: 'VR',
                    vrRenderType: 'VR',
                });
                var data = {
                    viewEventEmitter: 1
                };
                currentConf.ports[0].visible = true;
                expect(linkingFilter.filters.SAME_RENDERER_TYPE_FILTER(0, data)).to.equal(true);
            });

            it('test Same Viewtype renderer filter returns false if the viewport is not visible', function() {
                createVP();

                postal.channel(XJTWEB.VIEWPORT_UPDATE.CHANNEL).publish(XJTWEB.VIEWPORT_UPDATE.TOPIC.SWITCH_TYPE, {
                    index: 1,
                    viewTypeTarget: '3D',
                    rendererType: 'VR',
                    vrRenderType: 'VOLUMIC',
                });
                $scope.$apply();
                var data = {
                    viewEventEmitter: 1
                };

                currentConf.ports[0].visible = false;
                expect(linkingFilter.filters.SAME_RENDERER_TYPE_FILTER(0, data)).to.equal(false);
            });

            it('test Same Viewtype renderer filter returns false if 3D views have not the same renderer type', function() {
                createVP();

                postal.channel(XJTWEB.VIEWPORT_UPDATE.CHANNEL).publish(XJTWEB.VIEWPORT_UPDATE.TOPIC.SWITCH_TYPE, {
                    index: 3,
                    viewTypeTarget: '3D',
                    rendererType: 'VR',
                    vrRenderType: 'Max',
                });

                var data = {
                    viewEventEmitter: 3
                };

                expect(linkingFilter.filters.SAME_RENDERER_TYPE_FILTER(0, data)).to.equal(true);
            });

            it('should call linkingFilter.destroy when viewer session is closed if previousState state param was provided', function() {
                createVP();
                $scope.$destroy();
                expect(linkingFilter.destroy.calledOnce).to.equal(true);
            });

            it('windowing should be synhcronized when the layout changes', function() {

                portObjCfgMock = {
                    ports: [{
                        cssLayout: 'twoByOne',
                        index: 0,
                        usePredefinedLayout: true
                    }]
                };

                createVP();

                var args = {
                    visiblePorts: 0,
                    cssLayout: 'twoByTwo',
                    usePredefinedLayout: true
                };

                $scope.$$listeners.viewerLayoutChange[0](event, args);

                expect($scope.visiblePorts).to.equal(0);

                args = {
                    visiblePorts: 1,
                    cssLayout: 'twoByOne',
                    usePredefinedLayout: true
                };
                var port = $scope.config.ports[0];
                port.refresh = sinon.spy();
                port.portReady = true;

                $scope.$$listeners.viewerLayoutChange[0](event, args);
                $timeout.flush();
                expect(portContentFactory.synchronizeWindowing.calledWith(0)).to.equal(true);
                expect(port.refresh.calledOnce).to.equal(true);

                args = {
                    visiblePorts: 1,
                    cssLayout: 'twoByTwo',
                    usePredefinedLayout: true
                };
                port.portReady = false;
                port.cbForOnReady = null;

                $scope.$$listeners.viewerLayoutChange[0](event, args);
                expect(Array.isArray(port.cbForOnReady)).to.equal(true);
                expect(port.cbForOnReady.length).to.equal(1);
                expect(typeof port.cbForOnReady[0]).to.equal('function');

                args = {
                    visiblePorts: 1,
                    cssLayout: 'twoByOne',
                    usePredefinedLayout: true
                };
                var synchronizeWindowingCount = portContentFactory.synchronizeWindowing.callCount,
                    refreshCount = port.refresh.callCount;
                port.cbForOnReady = [];

                $scope.$$listeners.viewerLayoutChange[0](event, args);
                port.cbForOnReady[0]();
                $timeout.flush();
                expect(portContentFactory.synchronizeWindowing.callCount).to.equal(synchronizeWindowingCount + 1);
                expect(port.refresh.callCount).to.equal(refreshCount + 1);
            });
        });
    });
});
