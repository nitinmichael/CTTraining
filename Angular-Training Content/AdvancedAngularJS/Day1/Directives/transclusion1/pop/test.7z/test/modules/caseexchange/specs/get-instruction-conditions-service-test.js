/*
 *  get-instruction-conditions-service-test.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 */

/**
 * Spec file for Get Instruction Conditions Service Test module
 */

define([
  'angular',
  'angular-mocks',
  'modules/caseexchange/modules/case-automation/services/get-instruction-conditions-service',
  'mocks/case-exchange-mock-service',
  'mocks/fake-server'
], function() {
  'use strict';

  describe('Test Get Instruction Conditions Details', function() {
    var getInstructionConditionsService, rootScope, originalAjax, $mockServerLoader, mockServer;

    beforeEach(function() {
      // Load the module for the mock data first
      module('cloudav.caseExchange.mocks');
      // Load the Sinon fake server.
      module('cloudav.caseExchange.fakeServer');

      // store original $.ajax
      originalAjax = $.ajax;
      // provide mock services for getInstructionConditionsService
      module('Services.getInstructionConditionsService', function($provide) {
        $provide.factory('configurationService', ['$q',
          function($q) {
            return {
              getProperty: function() {
                return $q.when({});
              }
            }
          }
        ]);
      });
      // inject dependencies for GetInstructionConditionsService
      inject(function(_GetInstructionConditionsService_, _CaseExchangeDataService_, $rootScope, $MockServerLoader) {
        getInstructionConditionsService = _GetInstructionConditionsService_;
        rootScope = $rootScope;
        $mockServerLoader = $MockServerLoader;
        mockServer = $mockServerLoader.init();
      });
    });

    // restore $.ajax for use by other test suites
    afterEach(function() {
      $.ajax = originalAjax;
    });

    it('should define a service', function() {
      assert.isDefined(getInstructionConditionsService, 'GetInstructionConditionsService is defined');
    });

    describe('Testing successful getConditionKeyList() method', function() {
      it('should indicate success when set up to run normally', function(done) {
        var isSuccessful = false;
        $mockServerLoader.fakeGetConditionKeyListCall(200, {});
        getInstructionConditionsService.getConditionKeyList().xhr.then(
          function onResolve(data) {
            isSuccessful = true;
            done();
          },

          function onError(errorMessage) {
          }
        );

        // respond will trigger the success of getConditionKeyList call.
        mockServer.respond();
        rootScope.$apply();

        assert(isSuccessful, 'normal run should have succeeded');
      });
    });

    describe('Testing failed getConditionKeyList() arising from invalid "me" service result', function() {

      var isSuccessful = true,
        failedMeJSON = {};

      it('should indicate failure when set up to fail', function(done) {

        $.ajax = function(options) {
          if (options.url.indexOf('user/me') >= 0) {
            options.success(failedMeJSON);
          }
          if (options.url.indexOf('applicatonservice') >= 0) {
            // if this part is reached, the test fails
            isSuccessful = true;
          } else {
            options.error();
            isSuccessful = false;
            done();
          }
        };

        getInstructionConditionsService.getConditionKeyList().xhr.then(
          function onResolve(data) {},

          function onError(errorMessage) {}
        );
        assert(!isSuccessful, 'should have failed');
      });

    });

  });
});