/*
 *  verifyUserIdentityController-test.js
 *
 *  Copyright (c) 2016 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 */
/***
 * Specs for verify user identity controller module
 */
define(['angular', 'angular-mocks',
        'caseExchange/widgets/ge-control-group/ge-control-group-directive',
        'orgMgmnt/features/user/selfRegistration/controllers/verifyUserIdentityController'], function(){
    'use strict';
    describe('Test suite for Verify User Identity Controller::', function(){
        var scope, controller, selfRegistrationService;
        beforeEach(function(){
            module('Orgmanagement.Features.User.SelfRegistration.VerifyUserIdentityController', function($provide){
                $provide.value('$stateParams', {
                    id: '1234'
                });

                $provide.factory('selfRegistrationService', ['$q',function($q){
                    return {
                        getUserInformation: function (identifier) {
                            return $q.when({id: identifier, email: 'CT_Clinician.ge@gmail.com'});
                        }
                    }
                }]);
            });

            inject(function($rootScope, $controller, _selfRegistrationService_){
                scope = $rootScope.$new();
                controller = $controller;
                selfRegistrationService = _selfRegistrationService_;
                controller('verifyUserIdentityController', {$scope: scope});
            });
        });

        describe('Variable declaration test suite::', function(){
            it('should have a formData object defined', function(){
                assert.isDefined(scope.formData, 'Controller scope doesn\'t have "formData" object defined');
            });
        });

        describe('Controller init functionality test suite::', function(){
            it('should call service method to get user information on init', function(){
                var getUserInformationSpy = sinon.spy(selfRegistrationService, 'getUserInformation');
                //Re-initializing the controller to invoke service call
                controller('verifyUserIdentityController', {$scope: scope});
                assert(getUserInformationSpy.calledOnce);
            });
        });

    });
});


