/*
 * groupDetailController-test.js
 * This test file is used to cover the unit test cases for Edit MDT or Generic Group controller(groupDetailController.js)
 */
define(['angular', 'angular-mocks',
        'orgMgmnt/features/group/groupDetail/controllers/groupDetailController',
        'orgMgmnt/services/groupService',
        'orgMgmnt/dataModels/groupDataModel',
        'orgMgmnt/services/userService'
    ],
    function () {
        'use strict';

        describe('Test the GroupDetailController', function () {
            var groupDetailController, scope, state, searchUserResult, groupInfo, q, deferred,
                createResponse, groupResultObject, templateHtml, formElem, userResultObject, deferredUserResult,
                deferredSearchUserResult, deferredUpdateGroupAdmins, deferredUpdateGroupDetails, compile,
                deferredGetMultipleUsersDetails, event, filter, groupService, loggedInUserResult, getLoggedUserDeferred,_log,_rootscope,modal,_userService;
            before(function () {
                searchUserResult =
                {
                    "resourceType": "Bundle",
                    "title": "List of all groups for user",
                    "id": null,
                    "data": {
                        "entry": [
                            {
                                "title": "ResourcesUser",
                                "id": "ba3cb2ce-e299-4149-be07-06e4c9517b78",
                                "content": {
                                    "resourceType": "ResourcesUser",
                                    "name": {
                                        "use": "official",
                                        "family": [
                                            "Chalmers"
                                        ],
                                        "given": [
                                            "Nandro",
                                            "Kollar"
                                        ]
                                    },
                                    "telecom": [
                                        {
                                            "system": "phone",
                                            "value": "(+1) 734-677-7777"
                                        },
                                        {
                                            "system": "email",
                                            "value": "nandro@ge.com"
                                        }
                                    ],
                                    "preferredLanguage": "English",
                                    "type": "Human",
                                    "status": "active",
                                    "comment": "This is an Hospital Practioner 1",
                                    "principalName": "nandro@ge.com",
                                    "gender": {
                                        "coding": [
                                            {
                                                "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                                "code": "M",
                                                "display": "Male"
                                            }
                                        ]
                                    },
                                    "acceptedAgreement": [
                                        {
                                            "agreementUri": "http://goodcare.org/devices/id",
                                            "accepted": false
                                        }
                                    ]
                                }
                            }]
                    }
                };
                groupInfo = {
                    "title": "UserGroup Resource",
                    "id": "240529c1-8c60-43cc-bbbb-3516ed4c2e72",
                    "content": {
                        "resourceType": "ResourcesUserGroup",
                        "member": [
                            {
                                "user": {
                                    "reference": "user/891a1d75-79cf-49d6-902f-3ccab357e22f",
                                    "display": "Peter James"
                                },
                                "role": "owner"
                            },
                            {
                                "user": {
                                    "reference": "user/3cc1f86d-4c81-46a4-a7f2-76c60a2c84b1",
                                    "display": "Bradley Casper"
                                },
                                "role": "administrator"
                            },
                            {
                                "user": {
                                    "reference": "user/3cc1f86d-4c81-46a4-a7f2-76c60a2c84b1",
                                    "display": "Bradley Casper"
                                },
                                "role": "member"
                            }
                        ],
                        "managingOrganization": {
                            "reference": "orgization/3",
                            "display": "CJW groups"
                        },
                        "name": "This is my Group",
                        "quantity": 2,
                        "identifier": {
                            "system": "urn:hc.ge.com/pfh/platform/identifier",
                            "value": "4515"
                        },
                        "type": "mdt",
                        "accessType": "private",
                        "active": true,
                        "description": "Blood pressure related diagnosis"
                    }
                };
                groupResultObject = {
                    "data": {
                        "resourceType": "ResourcesUserGroup",
                        "member": [
                            {
                                "user": {
                                    "reference": "user/a39a5e23-4cf6-427a-aec6-fc081b69b6a9",
                                    "display": "sameer James"
                                },
                                "role": "owner"
                            },
                            {
                                "user": {
                                    "reference": "user/a39a5e23-4cf6-427a-aec6-fc081b69b6a9",
                                    "display": "sameer James"
                                },
                                "role": "administrator"
                            },
                            {
                                "user": {
                                    "reference": "user/a39a5e23-4cf6-427a-aec6-fc081b69b6a9",
                                    "display": "sameer James"
                                },
                                "role": "member"
                            }
                        ],
                        "managingOrganization": {
                            "reference": "organization/04b38adf-861b-4633-b59c-85cf830b85f9",
                            "display": "CT-ORG"
                        },
                        "partOf": {
                            "reference": "site/47fcbcc5-47b0-48d4-9637-06d1c693655c",
                            "display": "CT-Site"
                        },
                        "name": "IFFF1",
                        "quantity": 4,
                        "identifier": {
                            "_id": "240529c1-8c60-43cc-bbbb-3516ed4c2e72",
                            "system": "urn:hc.ge.com/pfh/platform/groupType"
                        },
                        "type": "mdt",
                        "accessType": "private",
                        "active": true,
                        "description": "RRRRRRRRRRRRRRR77444"
                    },
                    "status": 200,
                    "statusText": "OK"
                };
                userResultObject = {
                    "data": {
                        "resourceType": "ResourcesUser",
                        "name": {
                            "use": "official",
                            "family": [
                                "Chalmers"
                            ],
                            "given": [
                                "sameer",
                                "James"
                            ]
                        },
                        "role": [
                            {
                                "scopingOrganization": {
                                    "reference": "organization/74553d9a-7d1b-4f93-929c-72b6318a6178"
                                },
                                "status": "active"
                            }
                        ],
                        "address": [
                            {
                                "line": [
                                    "3300 Washtenaw Avenue, Suite 227"
                                ],
                                "city": "Ann Arbor",
                                "state": "MI",
                                "zip": "48104",
                                "country": "USA"
                            }
                        ],
                        "telecom": [
                            {
                                "system": "phone",
                                "value": "(+1) 734-677-7777"
                            },
                            {
                                "system": "email",
                                "value": "peter9@ge.com"
                            }
                        ],
                        "preferredLanguage": "English",
                        "type": "Human",
                        "status": "active",
                        "comment": "This is an Hospital Practioner 1",
                        "principalName": "peter9@ge.com",
                        "gender": {
                            "coding": [
                                {
                                    "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                    "code": "M",
                                    "display": "Male"
                                }
                            ]
                        },
                        "acceptedAgreement": [
                            {
                                "agreementUri": "http://goodcare.org/devices/id",
                                "accepted": false
                            }
                        ]
                    }
                };
                loggedInUserResult = {
                    "resourceType": "ResourcesUser",
                    "name": {
                        "use": "official",
                        "family": [
                            "Chalmers"
                        ],
                        "given": [
                            "Peter",
                            "James"
                        ]
                    },
                    "role": [
                        {
                            "scopingOrganization": {
                                "reference": "organization/74553d9a-7d1b-4f93-929c-72b6318a6178"
                            },
                            "status": "active"
                        }
                    ],
                    "address": [
                        {
                            "line": [
                                "3300 Washtenaw Avenue, Suite 227"
                            ],
                            "city": "Ann Arbor",
                            "state": "MI",
                            "zip": "48104",
                            "country": "USA"
                        }
                    ],
                    "telecom": [
                        {
                            "system": "phone",
                            "value": "(+1) 734-677-7777"
                        },
                        {
                            "system": "email",
                            "value": "peterjames98@ge.com"
                        }
                    ],
                    "preferredLanguage": "English",
                    "type": "Human",
                    "status": "active",
                    "comment": "This is an Hospital Practioner 1",
                    "principalName": "peterjames98@ge.com",
                    "gender": {
                        "coding": [
                            {
                                "system": "http://hl7.org/fhir/v3/AdministrativeGender",
                                "code": "M",
                                "display": "Male"
                            }
                        ]
                    },
                    "acceptedAgreement": [
                        {
                            "agreementUri": "http://goodcare.org/devices/id",
                            "accepted": false
                        }
                    ]
                };
            });
            beforeEach(function () {
                module('Orgmanagement.Features.Group.GroupDetail.GroupDetailController');
                module('Orgmanagement.Utilities.MasterData');
                module('Orgmanagement.Services.UserService');
            });

            beforeEach(module('Orgmanagement.Features.Group.GroupDetail.GroupDetailController', function ($provide) {
                $provide.value('$state', {
                    transitionTo: function () {
                    },
                    params: {
                        groupInfo: groupInfo,
                        from: null
                    }
                });
                $provide.value('$stateParams', {
                    id: function () {
                    }
                });
            }));

            beforeEach(inject(function ($controller, $rootScope, $compile, $state, groupMgmtService, $q, groupDataModel, $filter, $log, $modal,userMgmtService) {
                _rootscope=$rootScope;
                scope = $rootScope.$new();
                state = $state;
                groupService = groupMgmtService;
                _userService=userMgmtService;
                compile = $compile;
                q = $q,
                modal=$modal,
                _log=$log;
                deferred = q.defer();
                deferredUserResult = q.defer();
                deferredSearchUserResult = q.defer();
                deferredUpdateGroupAdmins = q.defer();
                deferredUpdateGroupDetails = q.defer();
                deferredGetMultipleUsersDetails = q.defer();
                getLoggedUserDeferred = $q.defer();
                sinon.stub(groupMgmtService, 'getGroupDetails').returns(deferred.promise);
                sinon.stub(groupMgmtService, 'getUserDetails').returns(deferredUserResult.promise);
                sinon.stub(_userService, 'findUser').returns(deferredSearchUserResult.promise);
                sinon.stub(groupMgmtService, 'updateGroupMembers').returns(deferredUpdateGroupAdmins.promise);
                sinon.stub(groupMgmtService, 'updateGroupDetails').returns(deferredUpdateGroupDetails.promise);
                sinon.stub(groupMgmtService, 'getMultipleUsersDetails').returns(deferredGetMultipleUsersDetails.promise);
                sinon.stub(_userService, 'getLoggedInUserDetails').returns(getLoggedUserDeferred.promise);
                event = {
                    preventDefault: sinon.spy()
                };
                groupDetailController = $controller('GroupDetailCtrl', {
                    $scope: scope,
                    $state: state,
                    groupMgmtService: groupMgmtService,
                    groupDataModel: groupDataModel,
                    $rootScope: $rootScope,
                    $log:_log
                });
                templateHtml = '<form id="groupDetailMainFormGroupInfoFieldsDiv" name="parentGroupForm.groupForm"  class="form-horizontal" novalidate><textarea rows="3" name="groupDescription" class="input controls form-control error-icon-style text-area-resize" id="groupDetailMainFormGroupDescriptionInfoInput" ng-model="groupDetailsForEdit.description"></textarea><input name="mainContactName" type="text" ng-model="groupDetails.mainContactName" id="groupDetailMainFormGroupInfoMainContactNameInput" class="form-control input-sm error-icon-style admin-typeahead" typeahead-on-select="selectMainContact($item);" typeahead="user for user in searchUserForMainContact($viewValue)" typeahead-loading="searchingUsersForMainContact" typeahead-no-results="noResultsForMainContact" typeahead-template-url="./modules/orgmanagement/features/group/createGroup/views/displaySearchUserResults.html" required></form>';
                formElem = angular.element("<div>" + templateHtml + "</div>");
                scope.groupDetails.mainContactName = searchUserResult.data.entry[0];
                $compile(formElem)(scope);
                scope.$apply();
                filter = $filter;
            }));
            describe('Checks sucess/resolved senarios', function () {
                beforeEach(function (done) {
                    deferred.resolve(groupResultObject);
                    scope.$root.$digest();
                    done();
                });
                beforeEach(function (done) {
                    deferredUserResult.resolve(userResultObject);
                    scope.$root.$digest();
                    done();
                });

                beforeEach(function (done) {
                    getLoggedUserDeferred.resolve(loggedInUserResult);
                    scope.$digest();
                    done();
                });
                it('should have a controller', function () {
                    assert.isDefined(groupDetailController, 'Controller is not defined');
                });

                it('Check selectMainContact function', function () {
                    var expectedOutput = "Nandro Kollar";
                    scope.selectMainContact(searchUserResult.data.entry[0]);
                    chai.expect(scope.groupOwner.display).to.equal(expectedOutput);
                });

                it('Check removeMainContact function', function () {
                    scope.removeMainContact(searchUserResult.data.entry[0]);
                    chai.expect(scope.groupOwner).to.be.empty;
                });

                it('Check getUserObject function', function () {
                    var userObject = scope.getUserObject(searchUserResult.data.entry[0]);
                    chai.expect(userObject.id).to.equal(searchUserResult.data.entry[0].id);
                });

                it('Check getUserEmailForDisplay function, object is not empty', function () {
                    var expectedResult = "nandro@ge.com";
                    var userEmail = scope.getUserEmailForDisplay(searchUserResult.data.entry[0].content);
                    chai.expect(userEmail).to.equal(expectedResult);
                });

                it('Check getUserEmailForDisplay function, object is empty', function () {
                    var userEmail = scope.getUserEmailForDisplay({});
                    chai.expect(userEmail).to.be.empty;
                });

                it('Check getUserPhoneForDisplay function, object is not empty', function () {
                    var expectedResult = "(+1) 734-677-7777";
                    var userPhone = scope.getUserPhoneForDisplay(searchUserResult.data.entry[0].content);
                    chai.expect(userPhone).to.equal(expectedResult);
                });

                it('Check getUserPhoneForDisplay function, object is empty', function () {
                    var userPhone = scope.getUserPhoneForDisplay({});
                    chai.expect(userPhone).to.be.empty;
                });

                it('Check getUserNameForDisplay function, object is not empty', function () {
                    var expectedOutput = "Nandro Kollar";
                    var userName = scope.getUserNameForDisplay(searchUserResult.data.entry[0].content);
                    chai.expect(userName).to.equal(expectedOutput);
                });

                it('Check getUserNameForDisplay  function, object is empty', function () {
                    var userName = scope.getUserNameForDisplay({});
                    chai.expect(userName).to.be.empty;
                });

                it('Check searchUserForMainContact function, success', function (done) {
                    scope.searchUserForMainContact("a");
                    deferredSearchUserResult.resolve(searchUserResult);
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.searchingUsersForMainContact).to.be.false;
                });

                it('Check searchUserForMainContact function, reject', function (done) {
                    scope.searchUserForMainContact("abc");
                    deferredSearchUserResult.reject();
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.noResultsForMainContact).to.be.true;
                });

                it('Check searchUserForAdmin function, Searching user for selecting as admin', function (done) {
                    scope.searchUserForAdmin("a");
                    deferredSearchUserResult.resolve(searchUserResult);
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.noResultsForAdmin).to.be.false;
                });

                it('Check searchUserForAdmin function, reject', function (done) {
                    scope.searchUserForAdmin("abc");
                    deferredSearchUserResult.reject();
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.noResultsForAdmin).to.be.true;
                });

                it('Selecting user after searching as admin', function () {
                    var user = searchUserResult.data.entry[0];
                    scope.selectAdministrator(user);
                    chai.expect(scope.groupDetails.administrators.length).to.equal(2);
                });

                it('Try to selecting again selected user after searching as admin, it will not add again as particular user is already selected', function () {
                    var user = searchUserResult.data.entry[0];
                    scope.selectAdministrator(user);
                    scope.selectAdministrator(user);
                    chai.expect(scope.groupDetails.administrators.length).to.equal(2);
                });

                it('Remove selected user from selected admins', function () {
                    var user = searchUserResult.data.entry[0];
                    scope.selectAdministrator(user);
                    scope.removeAdministrator(user);
                    chai.expect(scope.groupDetails.administrators.length).to.equal(1);
                });

                it('On click of edit button of group admin section, shows admins as editable after invoking "onEditGroupAdminsClick" method', function () {
                    scope.groupDetailViewMode = false;
                    scope.groupOwnerTemp={display:"name23"};
                    scope.onEditGroupAdminsClick();
                    chai.expect(scope.groupDetailAdminsViewMode).to.be.false;
                });

                it('On click of cancel button of group admin section in edit mode, moves back to previous view state for admins', function () {
                    scope.onCancelGroupAdminsClick();
                    chai.expect(scope.groupDetailAdminsViewMode).to.be.true;
                });

                it('After selecting any user as admin, display it with name & email', function () {
                    var user = searchUserResult.data.entry[0].content;
                    var expectedOutput = user.display + '(' + scope.getUserEmailForDisplay(user) + ')';
                    var output = scope.getUserForDisplay(user);
                    chai.expect(output).to.equal(expectedOutput);
                });

                it('After selecting any user as admin, display it with name & email, if email does not exist', function () {
                    var expectedOutput = "Nandro Kollar";
                    var user = angular.copy(searchUserResult.data.entry[0].content);
                    user.principalName = "";
                    var output = scope.getUserForDisplay(user);
                    chai.expect(output).to.equal(expectedOutput);
                });

                it('Validate MDT or Generic Group Admins On Edit, on click of save button', function (done) {
                    scope.groupDetails.administrators = [];
                    var responseData = {};
                    scope.onSaveGroupAdminsClick();
                    deferredUpdateGroupAdmins.resolve(responseData);
                    scope.$digest();
                    done();
                    chai.expect(scope.groupDetailAdminsViewMode).to.be.true;
                });

                it('update group admins is a success ', function (done) {
                    scope.onEditGroupAdminsClick();
                    var user = searchUserResult.data.entry[0];
                    scope.selectAdministrator(user);
                    var responseData = {};
                    scope.onSaveGroupAdminsClick();
                    deferredUpdateGroupAdmins.resolve(responseData);
                    scope.$digest();
                    done();
                    chai.expect(scope.groupDetailAdminsViewMode).to.be.true;
                });

                it('Update group admins is rejected ', function (done) {
                    scope.onEditGroupAdminsClick();
                    var user = searchUserResult.data.entry[0];
                    scope.selectAdministrator(user);
                    scope.onSaveGroupAdminsClick();
                    createResponse = "a233vg-678dfdf-dfsdfsdfsdf-sdfsd";
                    deferredUpdateGroupAdmins.reject({data: createResponse, status: 402});
                    scope.$digest();
                    done();
                    chai.expect(scope.groupDetailAdminsViewMode).to.be.false;
                });

                it('Validate MDT or Generic Group Admins On Edit', function () {
                    scope.groupDetails.administrators = [];
                    scope.validateGroupAdminsOnEdit();
                    chai.expect(scope.isValidGroupAdmins).to.be.false;
                });

                it('Validate MDT or Generic Group Admins On Edit, close alert box', function () {
                    scope.groupDetails.administrators = [];
                    scope.validateGroupAdminsOnEdit();
                    scope.closeAlert();
                    chai.expect(scope.isValidGroupAdmins).to.be.true;
                });

                it('checks required field "mainContactName" is valid with default entry', function () {
                    chai.expect(scope.hasGroupDetailsError("mainContactName")).to.be.false;
                });

                it('checks required field "mainContactName" is valid with blank entry without submitted ', function () {
                    scope.groupDetails.mainContactName = "";
                    scope.parentGroupForm.groupForm.$submitted = true;
                    scope.$apply();
                    chai.expect(scope.hasGroupDetailsError("mainContactName")).to.be.true;
                });

                it('checks required field "mainContactName" is invalid with blank entry', function () {
                    var field = "mainContactName";
                    scope.groupDetails.mainContactName = "";
                    scope.parentGroupForm.groupForm[field].$pristine = false;
                    scope.$apply();
                    chai.expect(scope.hasGroupDetailsError("mainContactName")).to.be.true;
                });

                it('On click of edit button of group details section, shows group details as editable after invoking "onEditGroupDetailsClick" method', function () {
                    scope.groupDetailAdminsViewMode = false;
                    scope.onEditGroupDetailsClick();
                    chai.expect(scope.groupDetailViewMode).to.be.false;
                });

                it('On click of cancel button of group details section in edit mode, moves back to previous view state for group details', function () {
                    scope.groupOwnerTemp={display:"name23"};
                    scope.onCancelGroupDetailsClick();
                    chai.expect(scope.groupDetailViewMode).to.be.true;
                });

                it('Validate MDT or Generic Group Details On Edit, valid case', function () {
                    scope.groupOwner = searchUserResult.data.entry[0];
                    scope.validateGroupDetailsEditMode();
                    chai.expect(scope.isValidGroupDetails).to.be.true;
                });

                it('Validate MDT or Generic Group Details On Edit, invalid case', function () {
                    scope.groupDetails.mainContactName = "";
                    scope.$apply();
                    scope.validateGroupDetailsEditMode();
                    chai.expect(scope.isValidGroupDetails).to.be.false;
                });

                it('Validate MDT or Generic Group Details On Edit, invalid case, close alert box', function () {
                    scope.groupDetails.mainContactName = "";
                    scope.$apply();
                    scope.validateGroupDetailsEditMode();
                    scope.closeAlert();
                    chai.expect(scope.parentGroupForm.groupForm.$submitted).to.be.false;
                });

                it('update group Details is a success ', function (done) {
                    scope.groupOwner = searchUserResult.data.entry[0];
                    scope.onEditGroupDetailsClick();
                    scope.groupDetailsForEdit.description = "New Description";
                    var responseData = {};
                    scope.onSaveGroupDetailsClick();
                    deferredUpdateGroupDetails.resolve({data: responseData, status: 200});
                    scope.$digest();
                    done();
                    chai.expect(scope.groupDetailAdminsViewMode).to.be.true;
                });

                it('update group Details is a success ', function (done) {
                    scope.groupOwner = searchUserResult.data.entry[0];
                    var responseData = {};
                    scope.onSaveGroupDetailsClick();
                    deferredUpdateGroupDetails.resolve({data: responseData, status: 200});
                    scope.$digest();
                    done();
                    chai.expect(scope.groupDetailAdminsViewMode).to.be.true;
                });

                it('update group Details is a success, validation fails ', function () {
                    scope.groupOwner = searchUserResult.data.entry[0];
                    scope.onEditGroupDetailsClick();
                    scope.groupDetails.mainContactName = "";
                    scope.$apply();
                    scope.onSaveGroupDetailsClick();
                    chai.expect(scope.isValidGroupDetails).to.be.false;
                });

                it('Update group Details is rejected ', function (done) {
                    scope.groupOwner = searchUserResult.data.entry[0];
                    scope.onEditGroupDetailsClick();
                    scope.onSaveGroupDetailsClick();
                    deferredUpdateGroupDetails.reject({data: "", status: 404});
                    scope.$digest();
                    done();
                    chai.expect(scope.groupDetailViewMode).to.be.false;
                });

                it('Check get Group Owner Details service result, error for getting group owner details service condition', function (done) {
                    deferredUserResult.reject({data: "", status: 404});
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.loadingGroupDetailsGet).to.be.false;
                });

                describe('Test if XSS event has been taken care of when', function () {
                    it('user tries to enter the script in input box it must show error on blur', function () {
                        scope.groupDetails.mainContactName = '<script>';
                        scope.$digest();
                        var object = {message: "There is an attempt to insert script."};
                        scope.$emit("SHOW_FAILURE_MESSAGE_NO_TIMEOUT", object.message);
                        chai.expect(scope.closeAlertPressed).to.be.equal(0);
                    });

                    it('to close the XSS error message box, click on x button', function () {
                        scope.closeXSSAlert();
                        chai.expect(scope.closeAlertPressed).to.be.equal(1);
                    });
                });

                it('Searching user for selecting as participant', function (done) {
                    scope.searchUserForParticipant("a");
                    deferredSearchUserResult.resolve(searchUserResult);
                    scope.$digest();
                    done();
                    chai.expect(scope.searchingUsersForParticipant).to.be.false;
                });

                it('Check searchUserForParticipant function, reject', function (done) {
                    scope.searchUserForParticipant("abc");
                    deferredSearchUserResult.reject();
                    scope.$root.$digest();
                    done();
                    chai.expect(scope.noResultsForParticipant).to.be.true;
                });

                it('Selecting user after searching as Participant', function () {
                    var user = searchUserResult.data.entry[0];
                    scope.selectParticipant(user);
                    chai.expect(scope.participants.length).to.equal(2);
                });

                it('Try to selecting again selected user after searching as Participant, it will not add again as particular user is already selected', function () {
                    var user = searchUserResult.data.entry[0];
                    scope.selectParticipant(user);
                    scope.selectParticipant(user);
                    chai.expect(scope.participants.length).to.equal(2);
                });

                it('Remove selected user from selected Participants', function () {
                    var user = searchUserResult.data.entry[0];
                    scope.selectParticipant(user);
                    scope.removeParticipant(user);
                    chai.expect(scope.participants.length).to.equal(1);
                });

                it('On click of edit button of group admin section shows admins as editable and shows other section like group participant as view mode if open in edit mode', function () {
                    scope.groupDetailParticipantsViewMode = false;
                    scope.onEditGroupAdminsClick();
                    chai.expect(scope.groupDetailAdminsViewMode).to.be.false;
                });

                it('On click of edit button of group details section shows group details as editable and shows other section like group participant as view mode if open in edit mode', function () {
                    scope.groupDetailParticipantsViewMode = false;
                    scope.onEditGroupDetailsClick();
                    chai.expect(scope.groupDetailViewMode).to.be.false;
                });

                it('On click of edit button of group participant section shows group participant as editable and shows other section like group details as view mode if open in edit mode', function () {
                    scope.groupDetailViewMode = false;
                    scope.groupOwnerTemp={display:"name23"};
                    scope.onEditGroupParticipantsClick();
                    chai.expect(scope.groupDetailParticipantsViewMode).to.be.false;
                });

                it('On click of edit button of group participant section shows group participant as editable and shows other section like group admin as view mode if open in edit mode', function () {
                    scope.groupDetailAdminsViewMode = false;
                    scope.onEditGroupParticipantsClick();
                    chai.expect(scope.groupDetailParticipantsViewMode).to.be.false;
                });

                it('update group participants is a success ', function (done) {
                    scope.onEditGroupParticipantsClick();
                    var user = searchUserResult.data.entry[0];
                    scope.selectParticipant(user);
                    var responseData = {};
                    scope.onSaveGroupParticipantsClick();
                    deferredUpdateGroupAdmins.resolve(responseData);
                    scope.$digest();
                    done();
                    chai.expect(scope.groupDetailParticipantsViewMode).to.be.true;
                });

                it('Update group participants is rejected ', function (done) {
                    scope.onEditGroupParticipantsClick();
                    var user = searchUserResult.data.entry[0];
                    scope.selectParticipant(user);
                    scope.onSaveGroupParticipantsClick();
                    createResponse = "a233vg-678dfdf-dfsdfsdfsdf-sdfsd";
                    deferredUpdateGroupAdmins.reject({data: createResponse, status: 402});
                    scope.$digest();
                    done();
                    chai.expect(scope.groupDetailParticipantsViewMode).to.be.false;
                });

                it('Check "getMultipleUsersDetails" is success', function (done) {
                    var responseArray = [];
                    var response = {};
                    response.data = searchUserResult.data.entry[0].content;
                    responseArray.push(response);
                    deferredGetMultipleUsersDetails.resolve(responseArray);
                    scope.$digest();
                    done();
                    var user = scope.groupDetails.administrators[0];
                    var expectedOutput = user.display + '(' + scope.getUserEmailForDisplay(user) + ')';
                    var output = scope.getUserForDisplay(user);
                    chai.expect(output).to.equal(expectedOutput);
                });

                it('Check "getMultipleUsersDetails" is reject, administrator', function (done) {
                    var responseArray = [];
                    deferredGetMultipleUsersDetails.reject(responseArray);
                    scope.$digest();
                    done();
                    chai.expect(scope.loadingGroupUpdateAdmins).to.be.false;
                });

                it('Check "getMultipleUsersDetails" is reject, in case of participants', function (done) {
                    var responseArray = [];
                    deferredGetMultipleUsersDetails.reject(responseArray);
                    scope.$digest();
                    done();
                    chai.expect(scope.loadingGroupUpdateParticipants).to.be.false;
                });

                it('Check "validateCreateGroupOwner" function, empty owner object', function () {
                    scope.groupOwner = {};
                    scope.$apply();
                    scope.validateGroupDetailsEditMode();
                    chai.expect(scope.isValidGroupOwner).to.be.true;
                });

                it('Check "goToPage" function, moves navigation to specific page', function () {
                    scope.goToPage(2);
                    chai.expect(scope.currentPage).to.equal(2);
                });

                it('Check "goToPreviousPage " function, disabled on first page, navigation does not happen', function () {
                    scope.goToPreviousPage(event);
                    chai.expect(event.preventDefault).to.be.called;
                });

                it('Check "goToPreviousPage " function, moves navigation to previous page', function () {
                    scope.currentPage = 1;
                    scope.goToPreviousPage(event);
                    chai.expect(scope.currentPage).to.equal(0);
                });

                it('Check "goToNextPage " function, moves navigation to next page', function () {
                    scope.participants.length = 10;
                    scope.goToNextPage(event);
                    chai.expect(scope.currentPage).to.equal(1);
                });

                it('Check "goToNextPage " function, disabled on last page, navigation does not happen', function () {
                    scope.participants.length = 5;
                    scope.goToNextPage(event);
                    chai.expect(event.preventDefault).to.be.called;
                });

                it('Check "startFrom" filter', function () {
                    scope.currentPage = 1;
                    scope.participants.length = 10;
                    var result = filter('startFrom')(scope.participants, scope.currentPage * scope.pageSize);
                    chai.expect(result.length).to.equal(5);
                });

                it('Check "getLoggedUserDeferred" function to get the loggedinuser details, success but empty object', function (done) {
                    loggedInUserResult = {};
                    scope.$apply();
                    getLoggedUserDeferred.resolve({});
                    scope.$root.$digest();
                    done();
                });

                it('checks unsavedChanges popUp', function (done) {
                    sinon.stub(scope, 'compareInitAndFinalModals');
                    scope.initialModel=JSON.parse(JSON.stringify({"admins":[{"reference":"user/034e2e9b-60b0-4856-85a7-c43779a11746","display":"Tushar K","id":"034e2e9b-60b0-4856-85a7-c43779a11746"},{"reference":"user/null","display":"Saganlal L","id":"null"}],"participants":[],"groupDetails":{"resourceType":"ResourcesUserGroup","member":[{"user":{"reference":"user/034e2e9b-60b0-4856-85a7-c43779a11746","display":"Tushar K"},"role":"owner"},{"user":{"reference":"user/034e2e9b-60b0-4856-85a7-c43779a11746","display":"Tushar K"},"role":"administrator"},{"user":{"reference":"user/null","display":"Saganlal L"},"role":"administrator"}],"managingOrganization":{},"partOf":{},"name":"Cancer Group MDT","quantity":3,"type":"mdt","accessType":"public","active":true,"description":"Cancer Group Desc1"},"groupOwner":{"resourceType":"ResourcesUser","name":{"use":"official","family":["Tari"],"given":["Tushar","K"]},"externalId":[{"system":"IDM","value":"b9f2b0f9-03ab-4d94-bd33-f40b495fc4d5"},{"system":"UOM","value":"034e2e9b-60b0-4856-85a7-c43779a11746"},{"_id":"tushar.tari@ge.com","system":"urn:hc.ge.com/pfh/platform/useremail"}],"role":[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"practitioner"}],"scopingOrganization":{"reference":"organization/5"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"practitioner"}],"scopingOrganization":{"reference":"organization/6"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"organization/7ef47dcc-c08c-4034-ae05-1a3a4283671d","display":"CTLegalName_338PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"site/607f631a-7e2e-4fcf-b572-47695c5b04a3","display":"CTSiteName_530PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"site/81698887-1768-4caf-b66f-ac8b31a8dd70","display":"CTSiteName_530PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"site/83de340b-83aa-4140-814b-13fc1ed04a6d","display":"CTSiteName_611PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"organization/fd1bf210-9939-4909-a3cf-e302dda7a667","display":"CTSiteName_622PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"site/b566c0ab-78a8-44ba-b760-8aeaa2e0d107","display":"CTSiteName_751PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/18cdd815-2b1d-419d-b923-f27c6408d4ab","display":"CTLegalName_1005514PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ce1294b3-3724-422e-a52b-c70d2a082df2","display":"CTSiteLegalName_1005547PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/6f8bc721-fec3-46e5-b4a8-bf7f53cb0260","display":"CTSiteLegalName_1005614PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/b7b102f9-0225-41ba-93f1-e466a34d48ae","display":"CTLegalName_743PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/3f72d20a-862a-4a31-973c-367c7c230fd7","display":"CT105B"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/ab17c8f7-429c-4ee9-b0f8-56f427e0c56e","display":"TestFinal"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/abf6c228-a248-48e5-833a-a0942601a38a","display":"CTLegalName_10061218PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/0f0d4b1d-ab9a-4e3f-8c06-894cb658025a","display":"CTLegalName_10061246PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/220cfee3-0fba-4b4e-b9bb-bdd146ee2c17","display":"Automation Test New Org Demo"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/f98e510c-dd03-46c6-9daf-feb259368f27","display":"AutomationNewOrg06_Oct_12-52-59_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/7f4f0629-36b6-4dc7-b840-23c3ac58993a","display":"AutomationNewOrg06_Oct_12-57-19_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/a42bd2c9-b3b9-43e0-8d49-4d6e90bad8f6","display":"AutomationNewOrg06_Oct_12-57-45_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/4ac948c4-2d84-4d58-b839-ee787a8512ab","display":"AutomationNewOrg06_Oct_01-06-42_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/10324cf2-3e57-4147-ade1-baf9879cb720","display":"AutomationNewOrg06_Oct_01-08-13_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/bdeacd30-893a-4499-be7b-8992d014aa84","display":"fyfgu"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/5dd6f31e-846b-455c-88af-c7f0a1a9b306","display":"fjhkhjl"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/92d38f96-f122-4465-a4b2-c90c843fda68","display":"CTSTest106"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/b74a0743-36d4-411d-b224-f8a7a7b81953","display":"AutomationNewOrg06_Oct_01-48-38_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/8b76f276-7c53-434a-ad9f-3805f8962abd","display":"AutomationNewOrg06_Oct_01-56-23_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/7587ed6e-a0dc-4f3b-97a8-ac01253b55c1","display":"AutomationNewOrg06_Oct_02-00-23_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/adaddc26-1381-4f1c-beec-a2a85d3b14a5","display":"AutomationNewOrg06_Oct_02-03-03_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/e5392a1c-1e8c-4f44-bb36-e951cf5097bb","display":"AutomationNewOrg06_Oct_02-06-59_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a044cb20-1690-47a0-bba0-716a677fb951","display":"CTSite_2016PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/ecca52c3-0746-48a4-9212-75d34b8aad26","display":"AutomationNewOrg06_Oct_02-09-29_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/7e55613a-da98-456c-92a1-1b1ae714fb46","display":"S9"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/587a698b-75b1-4d8b-b33d-4f7691b2c95b","display":"AutomationNewOrg06_Oct_02-17-17_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/4f3d0ddf-ad2b-45e0-9999-4b1e21f45191","display":"AutomationNewOrg06_Oct_02-17-47_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/848a21e8-d0e8-40d0-afba-720a97fcd156","display":"dfv"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/5ad1fd86-6daa-484e-99a6-0ff892a4bd78","display":"sdfv"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ec80e48d-e331-41a4-ab27-95ca2f6e5c29","display":"fdghj"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/014c7601-db5a-4b58-958f-4a7c3de1aa21","display":"TestFinal5"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/c1ca3cb6-1ecb-4953-864d-67e362ceb166","display":"CTSiteLegalName_1006301PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ca4d3a75-d926-40f4-ab36-2b13f7224d0f","display":"site07"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/b6362a2e-7878-42e2-8b1d-2bdb078abce7","display":"CTLegalName_1006308PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/655bc685-06fd-4dc8-bba7-fdfdfee1b086","display":"AutomationNewOrg06_Oct_03-17-58_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/f91bbf69-da51-485f-bc67-2701738b2eb2","display":"AutomationNewOrg06_Oct_03-18-33_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/b746c4af-6cd1-4ed7-ae4a-94cbeab4c4da","display":"uy"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/f0856d5b-0221-440d-910a-062a7b2e967a","display":"finaltest0914"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/c9f150c1-b208-4a36-bce1-06547ae60aae","display":"site4"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a1b63b75-aff4-4a9d-b500-e6802b823ea9","display":"site100"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/8b4e7b40-915d-4b16-9483-81b448495e2a","display":"s9"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/e1634ae9-ede8-4a86-817b-3fa6c944f305","display":"fgkg"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/600407a9-713b-4b0a-815e-0e550906f3eb","display":"site102"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/60e159c0-cc5b-4242-b0a9-15a58c103b03","display":"fsdfsdf"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/e8c25a32-f1bf-4463-ab5b-8e46f504aceb","display":"CTSData"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/c98fbec9-b136-4931-9137-d6d6bcb9bb13","display":"AutomationNewOrg06_Oct_04-57-33_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/a22efe8b-c32c-4847-a339-1b954842062e","display":"AutomationNewOrg06_Oct_04-58-03_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/2f77ef63-0f07-480f-bc70-7e0c9f630dcb","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/69191400-4ce2-4823-9f03-4d2298972901","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/cca11de3-afef-496f-8981-41377eec2321","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/0c75f95a-ca3f-4778-a59f-810b94bd8b34","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/d1886ae1-3760-434d-b21a-8a06496bacff","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/41cb5d8f-e919-4d79-9c5c-246f76ff771d","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/a089d5fc-d1a6-49cb-9304-f167c18966d3","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/1cbfb3d5-6a1c-47c8-950a-1ffd077fd52c","display":"AutomationNewSite06_Oct_12-11-59_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/9321a28a-8fac-45f2-a39a-3e7b0f2cf6c8","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/f635da16-4682-48a8-a3c2-ea208c3ca22f","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/f734293e-8dd8-4932-bab5-b449175604a3","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/d271fcbb-5edc-4689-bc66-aeb235af34de","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a1286fa2-c7aa-4dcf-bbe6-148cbd1cbbce","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/cc72df2f-c179-47f4-9655-746f95a73ed1","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/6264bde9-19ad-4628-af4d-2affd28776ac","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/09e1aba2-1f44-4793-b5be-cc72ba0d6627","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/fbf2b365-d15a-4484-87b3-83b4435751fc","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/ba89b1a1-1058-4441-b856-046e31100958","display":"AutomationNewOrg06_Oct_05-45-17_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/ac1cc773-1ef1-4c7c-a6ae-9f03221e9add","display":"AutomationNewOrg06_Oct_05-45-50_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/48de4de7-2e9f-4d37-90cc-eda8f75ac06b","display":"test2"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/32bffa8d-2d92-4fc7-bab4-a8f96f40f705","display":"autosite101"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/d5df9110-7191-4510-8608-e740c5fc174c","display":"Site"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ef57cabf-5594-4bf3-aebe-70affc7caa14","display":"newSite"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ff90837c-1895-495d-8ff9-55d7b2ad9bb6","display":"CTSite_20167PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/65751894-45b5-43be-b2a4-eb4bd1009a55","display":"Site07Oct"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/90d6c42f-64b9-4617-bfde-ea306fdc92db","display":"CTSite_20167PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/de666138-3549-4ea7-83d3-81750526bb8d","display":"vnvbn"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/c96b9f7a-36ea-4b0d-bcec-3097c0602d00","display":"site210"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/4e8efed1-0bac-4ada-acd5-5f9cf44789f5","display":"SiteName_543PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/190ddf23-1336-482a-8ca2-223b302c0f3a","display":"LegalName"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/0cf5e367-1b12-4057-a148-c1562b25bdcf","display":"Site Legal Name*"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/1f5c10ed-cd25-417f-93b9-1dca7aeca836","display":"Site Legal Name*-RequiredFeild"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/e26c3f9b-aaa9-4271-ac03-767b7e85b562","display":"Site Legal Name*"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/86e9cc4f-39c3-4162-bdf3-7db61ee8904a","display":"Site Legal Name*3"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/8eb46eea-1626-4511-bc8a-d9d902617075","display":"site08oct01"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/6ef488b2-ebd7-4f44-813f-0651579a92ea","display":"CTSSite"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/7da2578f-23d0-4906-afb0-3fc60465705f","display":"CTSSite1"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/2dee0e97-febf-430d-a811-ca9663939c4c","display":"CTSSite2"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/6d8ce210-9492-4649-b917-ca4ca128ffed","display":"CTSSite4"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/e78696a0-a705-4881-808b-5c96dbc4bf12","display":"ghsdfgh"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/955b6344-d51d-4903-badf-9368139a07c6","display":"CTSite5"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a8bb02a0-299b-42f2-a093-e35483f071c9","display":"CTSite6"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/bfa5c481-25ab-4b2d-923b-c172b1fded7f","display":"CTSSite7"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/661a4767-24f0-4e7a-a8aa-207d0408b2b1","display":"CTSite8"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/aae3628b-bdfc-4e31-86a3-c5a172b9469f","display":"CTSSIte9"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/5031ec9f-f713-4586-a604-b117a23911eb","display":"R3J"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/455603f5-03d9-40ac-8af6-b13a54ebc087","display":"ctsit10"},"status":"active"}],"address":[{"line":["3300 Washtenaw Avenue, Suite 227"],"city":"Ann Arbor","state":"MI","zip":"48104","country":"USA"}],"telecom":[{"system":"phone","value":"(+1) 734-677-7777"},{"system":"email","value":"tushar.tari@ge.com"}],"preferredLanguage":"English","type":"Human","status":"active","comment":"This is an Hospital Practioner 1","principalName":"tushar.tari@ge.com","gender":{"coding":[{"system":"http://hl7.org/fhir/v3/AdministrativeGender","code":"M","display":"Male"}]},"acceptedAgreement":[{"agreementUri":"http://goodcare.org/devices/id","accepted":false}],"id":"034e2e9b-60b0-4856-85a7-c43779a11746","display":"Tushar K"}}));
                    _rootscope.$broadcast('$stateChangeStart');
                    chai.expect(scope.compareInitAndFinalModals).to.be.calledOnce;
                    done();
                });
                it('checks unsavedChanges popUp when loopBreaker is false', function (done) {
                    sinon.stub(scope, 'compareInitAndFinalModals');
                    scope.initialModel=JSON.parse(JSON.stringify({"admins":[{"reference":"user/034e2e9b-60b0-4856-85a7-c43779a11746","display":"Tushar K","id":"034e2e9b-60b0-4856-85a7-c43779a11746"},{"reference":"user/null","display":"Saganlal L","id":"null"}],"participants":[],"groupDetails":{"resourceType":"ResourcesUserGroup","member":[{"user":{"reference":"user/034e2e9b-60b0-4856-85a7-c43779a11746","display":"Tushar K"},"role":"owner"},{"user":{"reference":"user/034e2e9b-60b0-4856-85a7-c43779a11746","display":"Tushar K"},"role":"administrator"},{"user":{"reference":"user/null","display":"Saganlal L"},"role":"administrator"}],"managingOrganization":{},"partOf":{},"name":"Cancer Group MDT","quantity":3,"type":"mdt","accessType":"public","active":true,"description":"Cancer Group Desc1"},"groupOwner":{"resourceType":"ResourcesUser","name":{"use":"official","family":["Tari"],"given":["Tushar","K"]},"externalId":[{"system":"IDM","value":"b9f2b0f9-03ab-4d94-bd33-f40b495fc4d5"},{"system":"UOM","value":"034e2e9b-60b0-4856-85a7-c43779a11746"},{"_id":"tushar.tari@ge.com","system":"urn:hc.ge.com/pfh/platform/useremail"}],"role":[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"practitioner"}],"scopingOrganization":{"reference":"organization/5"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"practitioner"}],"scopingOrganization":{"reference":"organization/6"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"organization/7ef47dcc-c08c-4034-ae05-1a3a4283671d","display":"CTLegalName_338PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"site/607f631a-7e2e-4fcf-b572-47695c5b04a3","display":"CTSiteName_530PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"site/81698887-1768-4caf-b66f-ac8b31a8dd70","display":"CTSiteName_530PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"site/83de340b-83aa-4140-814b-13fc1ed04a6d","display":"CTSiteName_611PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"organization/fd1bf210-9939-4909-a3cf-e302dda7a667","display":"CTSiteName_622PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"site/b566c0ab-78a8-44ba-b760-8aeaa2e0d107","display":"CTSiteName_751PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/18cdd815-2b1d-419d-b923-f27c6408d4ab","display":"CTLegalName_1005514PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ce1294b3-3724-422e-a52b-c70d2a082df2","display":"CTSiteLegalName_1005547PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/6f8bc721-fec3-46e5-b4a8-bf7f53cb0260","display":"CTSiteLegalName_1005614PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/b7b102f9-0225-41ba-93f1-e466a34d48ae","display":"CTLegalName_743PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/3f72d20a-862a-4a31-973c-367c7c230fd7","display":"CT105B"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/ab17c8f7-429c-4ee9-b0f8-56f427e0c56e","display":"TestFinal"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/abf6c228-a248-48e5-833a-a0942601a38a","display":"CTLegalName_10061218PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/0f0d4b1d-ab9a-4e3f-8c06-894cb658025a","display":"CTLegalName_10061246PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/220cfee3-0fba-4b4e-b9bb-bdd146ee2c17","display":"Automation Test New Org Demo"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/f98e510c-dd03-46c6-9daf-feb259368f27","display":"AutomationNewOrg06_Oct_12-52-59_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/7f4f0629-36b6-4dc7-b840-23c3ac58993a","display":"AutomationNewOrg06_Oct_12-57-19_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/a42bd2c9-b3b9-43e0-8d49-4d6e90bad8f6","display":"AutomationNewOrg06_Oct_12-57-45_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/4ac948c4-2d84-4d58-b839-ee787a8512ab","display":"AutomationNewOrg06_Oct_01-06-42_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/10324cf2-3e57-4147-ade1-baf9879cb720","display":"AutomationNewOrg06_Oct_01-08-13_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/bdeacd30-893a-4499-be7b-8992d014aa84","display":"fyfgu"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/5dd6f31e-846b-455c-88af-c7f0a1a9b306","display":"fjhkhjl"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/92d38f96-f122-4465-a4b2-c90c843fda68","display":"CTSTest106"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/b74a0743-36d4-411d-b224-f8a7a7b81953","display":"AutomationNewOrg06_Oct_01-48-38_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/8b76f276-7c53-434a-ad9f-3805f8962abd","display":"AutomationNewOrg06_Oct_01-56-23_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/7587ed6e-a0dc-4f3b-97a8-ac01253b55c1","display":"AutomationNewOrg06_Oct_02-00-23_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/adaddc26-1381-4f1c-beec-a2a85d3b14a5","display":"AutomationNewOrg06_Oct_02-03-03_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/e5392a1c-1e8c-4f44-bb36-e951cf5097bb","display":"AutomationNewOrg06_Oct_02-06-59_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a044cb20-1690-47a0-bba0-716a677fb951","display":"CTSite_2016PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/ecca52c3-0746-48a4-9212-75d34b8aad26","display":"AutomationNewOrg06_Oct_02-09-29_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/7e55613a-da98-456c-92a1-1b1ae714fb46","display":"S9"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/587a698b-75b1-4d8b-b33d-4f7691b2c95b","display":"AutomationNewOrg06_Oct_02-17-17_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/4f3d0ddf-ad2b-45e0-9999-4b1e21f45191","display":"AutomationNewOrg06_Oct_02-17-47_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/848a21e8-d0e8-40d0-afba-720a97fcd156","display":"dfv"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/5ad1fd86-6daa-484e-99a6-0ff892a4bd78","display":"sdfv"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ec80e48d-e331-41a4-ab27-95ca2f6e5c29","display":"fdghj"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/014c7601-db5a-4b58-958f-4a7c3de1aa21","display":"TestFinal5"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/c1ca3cb6-1ecb-4953-864d-67e362ceb166","display":"CTSiteLegalName_1006301PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ca4d3a75-d926-40f4-ab36-2b13f7224d0f","display":"site07"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/b6362a2e-7878-42e2-8b1d-2bdb078abce7","display":"CTLegalName_1006308PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/655bc685-06fd-4dc8-bba7-fdfdfee1b086","display":"AutomationNewOrg06_Oct_03-17-58_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/f91bbf69-da51-485f-bc67-2701738b2eb2","display":"AutomationNewOrg06_Oct_03-18-33_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/b746c4af-6cd1-4ed7-ae4a-94cbeab4c4da","display":"uy"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/f0856d5b-0221-440d-910a-062a7b2e967a","display":"finaltest0914"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/c9f150c1-b208-4a36-bce1-06547ae60aae","display":"site4"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a1b63b75-aff4-4a9d-b500-e6802b823ea9","display":"site100"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/8b4e7b40-915d-4b16-9483-81b448495e2a","display":"s9"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/e1634ae9-ede8-4a86-817b-3fa6c944f305","display":"fgkg"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/600407a9-713b-4b0a-815e-0e550906f3eb","display":"site102"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/60e159c0-cc5b-4242-b0a9-15a58c103b03","display":"fsdfsdf"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/e8c25a32-f1bf-4463-ab5b-8e46f504aceb","display":"CTSData"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/c98fbec9-b136-4931-9137-d6d6bcb9bb13","display":"AutomationNewOrg06_Oct_04-57-33_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/a22efe8b-c32c-4847-a339-1b954842062e","display":"AutomationNewOrg06_Oct_04-58-03_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/2f77ef63-0f07-480f-bc70-7e0c9f630dcb","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/69191400-4ce2-4823-9f03-4d2298972901","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/cca11de3-afef-496f-8981-41377eec2321","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/0c75f95a-ca3f-4778-a59f-810b94bd8b34","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/d1886ae1-3760-434d-b21a-8a06496bacff","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/41cb5d8f-e919-4d79-9c5c-246f76ff771d","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/a089d5fc-d1a6-49cb-9304-f167c18966d3","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/1cbfb3d5-6a1c-47c8-950a-1ffd077fd52c","display":"AutomationNewSite06_Oct_12-11-59_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/9321a28a-8fac-45f2-a39a-3e7b0f2cf6c8","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/f635da16-4682-48a8-a3c2-ea208c3ca22f","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/f734293e-8dd8-4932-bab5-b449175604a3","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/d271fcbb-5edc-4689-bc66-aeb235af34de","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a1286fa2-c7aa-4dcf-bbe6-148cbd1cbbce","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/cc72df2f-c179-47f4-9655-746f95a73ed1","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/6264bde9-19ad-4628-af4d-2affd28776ac","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/09e1aba2-1f44-4793-b5be-cc72ba0d6627","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/fbf2b365-d15a-4484-87b3-83b4435751fc","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/ba89b1a1-1058-4441-b856-046e31100958","display":"AutomationNewOrg06_Oct_05-45-17_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/ac1cc773-1ef1-4c7c-a6ae-9f03221e9add","display":"AutomationNewOrg06_Oct_05-45-50_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/48de4de7-2e9f-4d37-90cc-eda8f75ac06b","display":"test2"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/32bffa8d-2d92-4fc7-bab4-a8f96f40f705","display":"autosite101"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/d5df9110-7191-4510-8608-e740c5fc174c","display":"Site"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ef57cabf-5594-4bf3-aebe-70affc7caa14","display":"newSite"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ff90837c-1895-495d-8ff9-55d7b2ad9bb6","display":"CTSite_20167PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/65751894-45b5-43be-b2a4-eb4bd1009a55","display":"Site07Oct"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/90d6c42f-64b9-4617-bfde-ea306fdc92db","display":"CTSite_20167PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/de666138-3549-4ea7-83d3-81750526bb8d","display":"vnvbn"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/c96b9f7a-36ea-4b0d-bcec-3097c0602d00","display":"site210"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/4e8efed1-0bac-4ada-acd5-5f9cf44789f5","display":"SiteName_543PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/190ddf23-1336-482a-8ca2-223b302c0f3a","display":"LegalName"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/0cf5e367-1b12-4057-a148-c1562b25bdcf","display":"Site Legal Name*"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/1f5c10ed-cd25-417f-93b9-1dca7aeca836","display":"Site Legal Name*-RequiredFeild"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/e26c3f9b-aaa9-4271-ac03-767b7e85b562","display":"Site Legal Name*"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/86e9cc4f-39c3-4162-bdf3-7db61ee8904a","display":"Site Legal Name*3"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/8eb46eea-1626-4511-bc8a-d9d902617075","display":"site08oct01"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/6ef488b2-ebd7-4f44-813f-0651579a92ea","display":"CTSSite"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/7da2578f-23d0-4906-afb0-3fc60465705f","display":"CTSSite1"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/2dee0e97-febf-430d-a811-ca9663939c4c","display":"CTSSite2"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/6d8ce210-9492-4649-b917-ca4ca128ffed","display":"CTSSite4"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/e78696a0-a705-4881-808b-5c96dbc4bf12","display":"ghsdfgh"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/955b6344-d51d-4903-badf-9368139a07c6","display":"CTSite5"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a8bb02a0-299b-42f2-a093-e35483f071c9","display":"CTSite6"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/bfa5c481-25ab-4b2d-923b-c172b1fded7f","display":"CTSSite7"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/661a4767-24f0-4e7a-a8aa-207d0408b2b1","display":"CTSite8"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/aae3628b-bdfc-4e31-86a3-c5a172b9469f","display":"CTSSIte9"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/5031ec9f-f713-4586-a604-b117a23911eb","display":"R3J"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/455603f5-03d9-40ac-8af6-b13a54ebc087","display":"ctsit10"},"status":"active"}],"address":[{"line":["3300 Washtenaw Avenue, Suite 227"],"city":"Ann Arbor","state":"MI","zip":"48104","country":"USA"}],"telecom":[{"system":"phone","value":"(+1) 734-677-7777"},{"system":"email","value":"tushar.tari@ge.com"}],"preferredLanguage":"English","type":"Human","status":"active","comment":"This is an Hospital Practioner 1","principalName":"tushar.tari@ge.com","gender":{"coding":[{"system":"http://hl7.org/fhir/v3/AdministrativeGender","code":"M","display":"Male"}]},"acceptedAgreement":[{"agreementUri":"http://goodcare.org/devices/id","accepted":false}],"id":"034e2e9b-60b0-4856-85a7-c43779a11746","display":"Tushar K"}}));
                    scope.loopBreaker=false;
                    _rootscope.$broadcast('$stateChangeStart');
                    chai.expect(scope.compareInitAndFinalModals).not.to.be.calledOnce;
                    done();
                });
                it('checks unsavedChanges popUp when a popup is already open', function (done) {
                    sinon.stub(modal, 'open');
                    scope.modalInstance={};
                    scope.initialModel=JSON.parse(JSON.stringify({"admins":[{"reference":"user/034e2e9b-60b0-4856-85a7-c43779a11746","display":"Tushar K","id":"034e2e9b-60b0-4856-85a7-c43779a11746"},{"reference":"user/null","display":"Saganlal L","id":"null"}],"participants":[],"groupDetails":{"resourceType":"ResourcesUserGroup","member":[{"user":{"reference":"user/034e2e9b-60b0-4856-85a7-c43779a11746","display":"Tushar K"},"role":"owner"},{"user":{"reference":"user/034e2e9b-60b0-4856-85a7-c43779a11746","display":"Tushar K"},"role":"administrator"},{"user":{"reference":"user/null","display":"Saganlal L"},"role":"administrator"}],"managingOrganization":{},"partOf":{},"name":"Cancer Group MDT","quantity":3,"type":"mdt","accessType":"public","active":true,"description":"Cancer Group Desc1"},"groupOwner":{"resourceType":"ResourcesUser","name":{"use":"official","family":["Tari"],"given":["Tushar","K"]},"externalId":[{"system":"IDM","value":"b9f2b0f9-03ab-4d94-bd33-f40b495fc4d5"},{"system":"UOM","value":"034e2e9b-60b0-4856-85a7-c43779a11746"},{"_id":"tushar.tari@ge.com","system":"urn:hc.ge.com/pfh/platform/useremail"}],"role":[{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"practitioner"}],"scopingOrganization":{"reference":"organization/5"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"practitioner","display":"practitioner"}],"scopingOrganization":{"reference":"organization/6"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"organization/7ef47dcc-c08c-4034-ae05-1a3a4283671d","display":"CTLegalName_338PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"site/607f631a-7e2e-4fcf-b572-47695c5b04a3","display":"CTSiteName_530PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"site/81698887-1768-4caf-b66f-ac8b31a8dd70","display":"CTSiteName_530PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"site/83de340b-83aa-4140-814b-13fc1ed04a6d","display":"CTSiteName_611PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"organization/fd1bf210-9939-4909-a3cf-e302dda7a667","display":"CTSiteName_622PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"ADMIN","display":"ADMIN"}],"scopingOrganization":{"reference":"site/b566c0ab-78a8-44ba-b760-8aeaa2e0d107","display":"CTSiteName_751PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/18cdd815-2b1d-419d-b923-f27c6408d4ab","display":"CTLegalName_1005514PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ce1294b3-3724-422e-a52b-c70d2a082df2","display":"CTSiteLegalName_1005547PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/6f8bc721-fec3-46e5-b4a8-bf7f53cb0260","display":"CTSiteLegalName_1005614PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/b7b102f9-0225-41ba-93f1-e466a34d48ae","display":"CTLegalName_743PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/3f72d20a-862a-4a31-973c-367c7c230fd7","display":"CT105B"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/ab17c8f7-429c-4ee9-b0f8-56f427e0c56e","display":"TestFinal"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/abf6c228-a248-48e5-833a-a0942601a38a","display":"CTLegalName_10061218PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/0f0d4b1d-ab9a-4e3f-8c06-894cb658025a","display":"CTLegalName_10061246PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/220cfee3-0fba-4b4e-b9bb-bdd146ee2c17","display":"Automation Test New Org Demo"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/f98e510c-dd03-46c6-9daf-feb259368f27","display":"AutomationNewOrg06_Oct_12-52-59_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/7f4f0629-36b6-4dc7-b840-23c3ac58993a","display":"AutomationNewOrg06_Oct_12-57-19_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/a42bd2c9-b3b9-43e0-8d49-4d6e90bad8f6","display":"AutomationNewOrg06_Oct_12-57-45_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/4ac948c4-2d84-4d58-b839-ee787a8512ab","display":"AutomationNewOrg06_Oct_01-06-42_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/10324cf2-3e57-4147-ade1-baf9879cb720","display":"AutomationNewOrg06_Oct_01-08-13_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/bdeacd30-893a-4499-be7b-8992d014aa84","display":"fyfgu"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/5dd6f31e-846b-455c-88af-c7f0a1a9b306","display":"fjhkhjl"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/92d38f96-f122-4465-a4b2-c90c843fda68","display":"CTSTest106"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/b74a0743-36d4-411d-b224-f8a7a7b81953","display":"AutomationNewOrg06_Oct_01-48-38_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/8b76f276-7c53-434a-ad9f-3805f8962abd","display":"AutomationNewOrg06_Oct_01-56-23_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/7587ed6e-a0dc-4f3b-97a8-ac01253b55c1","display":"AutomationNewOrg06_Oct_02-00-23_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/adaddc26-1381-4f1c-beec-a2a85d3b14a5","display":"AutomationNewOrg06_Oct_02-03-03_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/e5392a1c-1e8c-4f44-bb36-e951cf5097bb","display":"AutomationNewOrg06_Oct_02-06-59_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a044cb20-1690-47a0-bba0-716a677fb951","display":"CTSite_2016PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/ecca52c3-0746-48a4-9212-75d34b8aad26","display":"AutomationNewOrg06_Oct_02-09-29_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/7e55613a-da98-456c-92a1-1b1ae714fb46","display":"S9"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/587a698b-75b1-4d8b-b33d-4f7691b2c95b","display":"AutomationNewOrg06_Oct_02-17-17_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/4f3d0ddf-ad2b-45e0-9999-4b1e21f45191","display":"AutomationNewOrg06_Oct_02-17-47_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/848a21e8-d0e8-40d0-afba-720a97fcd156","display":"dfv"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/5ad1fd86-6daa-484e-99a6-0ff892a4bd78","display":"sdfv"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ec80e48d-e331-41a4-ab27-95ca2f6e5c29","display":"fdghj"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/014c7601-db5a-4b58-958f-4a7c3de1aa21","display":"TestFinal5"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/c1ca3cb6-1ecb-4953-864d-67e362ceb166","display":"CTSiteLegalName_1006301PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ca4d3a75-d926-40f4-ab36-2b13f7224d0f","display":"site07"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/b6362a2e-7878-42e2-8b1d-2bdb078abce7","display":"CTLegalName_1006308PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/655bc685-06fd-4dc8-bba7-fdfdfee1b086","display":"AutomationNewOrg06_Oct_03-17-58_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/f91bbf69-da51-485f-bc67-2701738b2eb2","display":"AutomationNewOrg06_Oct_03-18-33_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/b746c4af-6cd1-4ed7-ae4a-94cbeab4c4da","display":"uy"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/f0856d5b-0221-440d-910a-062a7b2e967a","display":"finaltest0914"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/c9f150c1-b208-4a36-bce1-06547ae60aae","display":"site4"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a1b63b75-aff4-4a9d-b500-e6802b823ea9","display":"site100"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/8b4e7b40-915d-4b16-9483-81b448495e2a","display":"s9"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/e1634ae9-ede8-4a86-817b-3fa6c944f305","display":"fgkg"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/600407a9-713b-4b0a-815e-0e550906f3eb","display":"site102"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/60e159c0-cc5b-4242-b0a9-15a58c103b03","display":"fsdfsdf"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/e8c25a32-f1bf-4463-ab5b-8e46f504aceb","display":"CTSData"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/c98fbec9-b136-4931-9137-d6d6bcb9bb13","display":"AutomationNewOrg06_Oct_04-57-33_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/a22efe8b-c32c-4847-a339-1b954842062e","display":"AutomationNewOrg06_Oct_04-58-03_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/2f77ef63-0f07-480f-bc70-7e0c9f630dcb","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/69191400-4ce2-4823-9f03-4d2298972901","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/cca11de3-afef-496f-8981-41377eec2321","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/0c75f95a-ca3f-4778-a59f-810b94bd8b34","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/d1886ae1-3760-434d-b21a-8a06496bacff","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/41cb5d8f-e919-4d79-9c5c-246f76ff771d","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/a089d5fc-d1a6-49cb-9304-f167c18966d3","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/1cbfb3d5-6a1c-47c8-950a-1ffd077fd52c","display":"AutomationNewSite06_Oct_12-11-59_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/9321a28a-8fac-45f2-a39a-3e7b0f2cf6c8","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/f635da16-4682-48a8-a3c2-ea208c3ca22f","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/f734293e-8dd8-4932-bab5-b449175604a3","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/d271fcbb-5edc-4689-bc66-aeb235af34de","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a1286fa2-c7aa-4dcf-bbe6-148cbd1cbbce","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/cc72df2f-c179-47f4-9655-746f95a73ed1","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/6264bde9-19ad-4628-af4d-2affd28776ac","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/09e1aba2-1f44-4793-b5be-cc72ba0d6627","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/fbf2b365-d15a-4484-87b3-83b4435751fc","display":"GE Healthcare"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/ba89b1a1-1058-4441-b856-046e31100958","display":"AutomationNewOrg06_Oct_05-45-17_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/ac1cc773-1ef1-4c7c-a6ae-9f03221e9add","display":"AutomationNewOrg06_Oct_05-45-50_PM(IST)"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/48de4de7-2e9f-4d37-90cc-eda8f75ac06b","display":"test2"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/32bffa8d-2d92-4fc7-bab4-a8f96f40f705","display":"autosite101"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/d5df9110-7191-4510-8608-e740c5fc174c","display":"Site"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ef57cabf-5594-4bf3-aebe-70affc7caa14","display":"newSite"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/ff90837c-1895-495d-8ff9-55d7b2ad9bb6","display":"CTSite_20167PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/65751894-45b5-43be-b2a4-eb4bd1009a55","display":"Site07Oct"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/90d6c42f-64b9-4617-bfde-ea306fdc92db","display":"CTSite_20167PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/de666138-3549-4ea7-83d3-81750526bb8d","display":"vnvbn"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/c96b9f7a-36ea-4b0d-bcec-3097c0602d00","display":"site210"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/4e8efed1-0bac-4ada-acd5-5f9cf44789f5","display":"SiteName_543PM"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/190ddf23-1336-482a-8ca2-223b302c0f3a","display":"LegalName"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/0cf5e367-1b12-4057-a148-c1562b25bdcf","display":"Site Legal Name*"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/1f5c10ed-cd25-417f-93b9-1dca7aeca836","display":"Site Legal Name*-RequiredFeild"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/e26c3f9b-aaa9-4271-ac03-767b7e85b562","display":"Site Legal Name*"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/86e9cc4f-39c3-4162-bdf3-7db61ee8904a","display":"Site Legal Name*3"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/8eb46eea-1626-4511-bc8a-d9d902617075","display":"site08oct01"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/6ef488b2-ebd7-4f44-813f-0651579a92ea","display":"CTSSite"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/7da2578f-23d0-4906-afb0-3fc60465705f","display":"CTSSite1"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/2dee0e97-febf-430d-a811-ca9663939c4c","display":"CTSSite2"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/6d8ce210-9492-4649-b917-ca4ca128ffed","display":"CTSSite4"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/e78696a0-a705-4881-808b-5c96dbc4bf12","display":"ghsdfgh"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/955b6344-d51d-4903-badf-9368139a07c6","display":"CTSite5"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/a8bb02a0-299b-42f2-a093-e35483f071c9","display":"CTSite6"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/bfa5c481-25ab-4b2d-923b-c172b1fded7f","display":"CTSSite7"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/661a4767-24f0-4e7a-a8aa-207d0408b2b1","display":"CTSite8"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/aae3628b-bdfc-4e31-86a3-c5a172b9469f","display":"CTSSIte9"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"organization/5031ec9f-f713-4586-a604-b117a23911eb","display":"R3J"},"status":"active"},{"code":[{"system":"urn:hc.ge.com/pfh/platform/user-role:V1","code":"administrator","display":"administrator"}],"scopingOrganization":{"reference":"site/455603f5-03d9-40ac-8af6-b13a54ebc087","display":"ctsit10"},"status":"active"}],"address":[{"line":["3300 Washtenaw Avenue, Suite 227"],"city":"Ann Arbor","state":"MI","zip":"48104","country":"USA"}],"telecom":[{"system":"phone","value":"(+1) 734-677-7777"},{"system":"email","value":"tushar.tari@ge.com"}],"preferredLanguage":"English","type":"Human","status":"active","comment":"This is an Hospital Practioner 1","principalName":"tushar.tari@ge.com","gender":{"coding":[{"system":"http://hl7.org/fhir/v3/AdministrativeGender","code":"M","display":"Male"}]},"acceptedAgreement":[{"agreementUri":"http://goodcare.org/devices/id","accepted":false}],"id":"034e2e9b-60b0-4856-85a7-c43779a11746","display":"Tushar K"}}));
                    _rootscope.$broadcast('$stateChangeStart');
                    chai.expect(modal.open).not.to.be.calledOnce;
                    done();
                });
                it('checks relaseStateChangeHandler method call on destroy', function (done) {
                    sinon.stub(scope, 'relaseStateChangeHandler');
                    scope.$broadcast('$destroy');
                    chai.expect(scope.relaseStateChangeHandler).to.be.calledOnce;
                    done();
                });
            });
            describe('Checks failure/reject senarios', function () {
                beforeEach(function (done) {
                    sinon.stub(_log, 'error');
                    done();
                });
                it('Check groupMgmtService.getGroupDetails reject case', function (done) {
                    scope.getGroupDetails();
                    deferred.reject(groupResultObject);
                    scope.$root.$digest();
                    chai.expect(_log.error).to.be.calledOnce;
                    done();
                });
                it('Check groupMgmtService.getLoggedInUserDetails reject case', function (done) {
                    getLoggedUserDeferred.reject({});
                    scope.$root.$digest();
                    chai.expect(_log.error).to.be.calledOnce;
                    done();
                });
            });

            describe('Checks typeahead functionality', function () {
                it('Check searchUserForMainContact function success, filtering in search result ', function (done) {
                    scope.searchUserForMainContact("nan");
                    deferred.resolve(searchUserResult);
                    scope.$root.$digest();
                    done();
                    var userResult = scope.searchUserForMainContact("nand");
                    chai.expect(userResult).to.not.be.empty;
                });

                it('Check searchUserForParticipant function success, filtering in search result ', function (done) {
                    scope.searchUserForParticipant("nan");
                    deferred.resolve(searchUserResult);
                    scope.$root.$digest();
                    done();
                    var userResult = scope.searchUserForParticipant("nand");
                    chai.expect(userResult).to.not.be.empty;
                });

                it('Check searchUserForAdmin function success, filtering in search result ', function (done) {
                    scope.searchUserForAdmin("nan");
                    deferred.resolve(searchUserResult);
                    scope.$root.$digest();
                    done();
                    var userResult = scope.searchUserForAdmin("nand");
                    chai.expect(userResult).to.not.be.empty;
                });
            });
        });
    });
