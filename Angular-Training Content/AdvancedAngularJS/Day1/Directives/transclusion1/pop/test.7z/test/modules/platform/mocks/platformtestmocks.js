angular.module('platform', []).constant('platformTestMocks', {
    logger : function() {

        return {
            'error' : function() {

            }
        };
    }

});
