define([ 'angular', 'angular-mocks', 'modules/xjtweb-platform/services/object-manipulator-factory' ], function(ng, mocks) {
    'use strict';

    describe('Object manipulator factory', function() {

        var objectmanipulator;

        function mockObjectManipulatorFactory() {
        }

        beforeEach(module('object-manipulator'));

        beforeEach(module(function($provide) {
            $provide.factory('$xjtweb', function() {
                return {
                    XJTWEB : {
                        ObjectManipulatorFactory : mockObjectManipulatorFactory
                    }
                };
            });
        }));

        beforeEach(inject(function(ObjectManipulatorFactory) {
            objectmanipulator = ObjectManipulatorFactory;
        }));

        it(' is defined', function() {
            expect(objectmanipulator instanceof mockObjectManipulatorFactory).to.equal(true);
        })
    });
});
