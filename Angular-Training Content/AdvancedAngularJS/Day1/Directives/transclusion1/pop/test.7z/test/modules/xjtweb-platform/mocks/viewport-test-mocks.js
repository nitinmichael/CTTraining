angular.module('viewport-test-mocks', []).constant('VpTestMocks', {

    viewportTemplateFactory: function() {

        return {

            'getViewportTemplate': function() {

                var testUrlString = 'test/modules/xjtweb-platform/mocks/viewport-template-mock.html';

                return testUrlString;
            }
        };
    },

    viewportParameterStorage: function() {

        function ViewportParameterObjMock() {

        }

        return {
            'ViewportParameterObj': ViewportParameterObjMock,

            'isViewportParameterObj': function() {
                return false;
            }
        };
    },

    logger: function() {

        return {
            'error': function() {

            }
        };
    },
    segmentationService: function() {

        return {
            'updateSegmentationMasks': function() {},
            'getSegmentationMasks': function() {},
            'segmentationMasks': function() {
                var segmentationMasks = {
                    'masks': [{
                        'name': 'mask1',
                        'id': '2'
                    }]
                }
                return JSON.stringify(segmentationMasks);
            }
        }
    },
    windowResizeService: function() {

        return {
            addCBforOnResize: function(newCBfunction) {
            }
        }
    }
});
