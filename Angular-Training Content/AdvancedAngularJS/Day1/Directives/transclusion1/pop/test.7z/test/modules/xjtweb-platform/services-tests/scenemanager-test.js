define([ 'angular', 'angular-mocks', 'postal', 'modules/xjtweb-platform/services/scene-manager' ], function(ng, mocks, postal) {
    'use strict';

    describe('Scene Manager', function() {
        var sceneManager;

        beforeEach(module('scene-manager'));

        beforeEach(module(function($provide) {
            $provide.factory('GraphicalObjectFactory', function() {
                return {
                    mock : 'Mocked_GraphicalObjectFactory'
                };
            });
            $provide.factory('RaycasterFactory', function() {
                return {
                    mock : 'Mocked_RaycasterFactory'
                };
            });
            $provide.factory('ObjectManipulatorFactory', function() {
                return {
                    mock : 'Mocked_ObjectManipulatorFactory'
                };
            });
            $provide.factory('$xjtweb', function() {
                return {
                    XJTWEB : {
                        SceneManagerBuilder : function(inPostal, inGraphicalObjectFactory, inRaycasterFactory, inObjectManipulatorFactory) {
                            return {
                                postal : inPostal,
                                GraphicalObjectFactory : inGraphicalObjectFactory,
                                RaycasterFactory : inRaycasterFactory,
                                ObjectManipulatorFactory : inObjectManipulatorFactory
                            };
                        }
                    }
                };
            });
        }));

        beforeEach(inject(function(SceneManager) {
            sceneManager = SceneManager;
        }));

        it('sceneManager should have been a type of object', function() {
            expect(typeof sceneManager).to.equal('object');
        });

        it('sceneManager should have a postal channel applied', function() {
            expect(sceneManager.postal).to.equal(postal);
        });

        it('sceneManager should have a mocked GraphicalObjectFactory', function() {
            expect(sceneManager.GraphicalObjectFactory.mock).to.equal('Mocked_GraphicalObjectFactory');
        });

        it('sceneManager should have a mocked RaycasterFactory', function() {
            expect(sceneManager.RaycasterFactory.mock).to.equal('Mocked_RaycasterFactory');
        });

        it('sceneManager should have a mocked ObjectManipulatorFactory', function() {
            expect(sceneManager.ObjectManipulatorFactory.mock).to.equal('Mocked_ObjectManipulatorFactory');
        });

    });

});
