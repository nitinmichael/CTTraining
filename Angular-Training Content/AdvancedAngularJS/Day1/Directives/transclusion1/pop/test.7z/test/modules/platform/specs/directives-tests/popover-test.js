define(['angular', 'angular-mocks', 'modules/platform/directives/popover'], function(angular) {
    describe('Test popover', function() {
        var $rootScope, $scope, $timeout, $window, element;

        beforeEach(function() {
            module('platform.directive.popover');
            module('templates');

            module(function($provide) {
                $provide.factory('$popupCloserService', function() {
                    return {};
                });

                $provide.factory('$logger', function() {
                    return {
                        error: sinon.spy()
                    };
                });
            });

            inject(function($compile, _$rootScope_, _$timeout_, _$window_) {
                $rootScope = _$rootScope_;
                $timeout = _$timeout_;
                $window = _$window_;

                var parentScope = $rootScope.$new();
                parentScope.myconfig = {
                    type: 'popover'
                };

                element = $compile('<div><popover config="myconfig" /></div>')(parentScope);
                parentScope.$digest();
                $scope = element.children().isolateScope();

                $timeout.flush();
            });
        });

        it('should replace the element with the appropriate content', function() {
            expect($scope).to.exist;
        });

        it('catch a close event should hide the popover', function() {
            $scope.config.display = true;

            $rootScope.$broadcast('close');
            $timeout.flush();

            expect($scope.config.display).to.equal(false);
        });

        it('catch a close event should not hide the popover if the clicked element is the popover button', function() {
            $scope.config.display = true;

            $rootScope.$broadcast('close', {
                parentElement: {
                    classList: {
                        contains: function() {
                            return true;
                        }
                    }
                }
            });

            $timeout.verifyNoPendingTasks();
        });

        it('set config.display to true should set the popover position', function() {
            var spy = sinon.spy($scope, 'setPopoverPosition');

            $scope.config.display = true;

            $scope.$apply();
            expect(spy.callCount).to.equal(1);

            $timeout.flush();
            expect(spy.callCount).to.equal(2);

            $scope.config.display = false;
            $scope.$apply();
            $scope.config.alignment = 'vertical';
            $scope.config.display = true;
            $scope.$apply();

            $scope.config.display = false;
            $scope.$apply();
            $scope.config.alignment = 'horizontal';
            $scope.config.display = true;
            $scope.$apply();

            spy.restore();
        });

        it('the popover position should be set when the window is resized', function() {
            var spy = sinon.spy($scope, 'setPopoverPosition');

            angular.element($window).trigger('resize');
            expect(spy.calledOnce).to.equal(true);

            spy.restore();
        });
    });
});
