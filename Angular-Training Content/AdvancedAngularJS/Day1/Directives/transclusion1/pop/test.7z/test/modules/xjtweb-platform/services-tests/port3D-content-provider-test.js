define(['angular', 'angular-mocks', 'uiRouter', 'modules/xjtweb-platform/services/port3D-content-provider', 'mocks/port3D-content-provider-mocks', 'mocks/viewer-models-mock'], function() {
    'use strict';

    /**
     * @ngdoc service
     * @name xjtweb-platform.provider:port3DContentFactory-test
     * @author Benjamin Beeman
     *
     * @description This file provides unit tests for the port3DContentFactory. It mocks all dependencies of that file.
     *
     * Copyright (c) 2015 by General Electric Company. All rights reserved.
     *
     * The copyright to the computer software herein is the property of General Electric Company. The software may be
     * used and/or copied only with the written permission of General Electric Company or in accordance with the terms
     * and conditions stipulated in the agreement/contract under which the software has been supplied.
     */
    describe('port3D-content-provider Unit Test, ', function() {

        var $q, $rootScope;
        var annotationService, annotationUIService, port3DContentFactory, SceneManager, xjtwebMock;

        var currentConfiguration = {
            ports: [{
                volumeInfo: {
                    modality: ''
                },
                rendererType: 'MPR',
                viewPortObject: {
                    renderEngine: {
                        getWindowLevel: function() {
                            return 1;
                        },
                        getWindowWidth: function() {
                            return 2;
                        }
                    }
                },
                groupId: 'groupId1'
            }]
        };

        function MockT3DViewport() {

            this.setVolume = function() {};
            this.setRenderStyle = function() {};
            this.setView = function() {};
            this.getViewHeight = function() {};
            this.getAspectRatio = function() {};
            this.getLookPoint = function() {};
            this.updateSlice = function() {};

            this.getImage = function() {
                return {
                    slice: {}
                };
            };

            this.annotationState = {
                selectedAnnotState: 'full'
            };
        }

        beforeEach(function() {

            module('port3DContent');
            module('port3DContent-test-mocks');
            module('ui.router');
            module('viewerModels');

            module(function($provide, TestMocks) {

                xjtwebMock = TestMocks.$xjtwebMock();
                SceneManager = TestMocks.SceneManagerMock();

                $provide.value('$xjtweb', xjtwebMock);
                $provide.value('SceneManager', SceneManager);

                $provide.factory('$windowResizeService', TestMocks.$windowResizeServiceMock);
                $provide.factory('portContentFactory', TestMocks.PortContentMock);
                $provide.factory('annotStateService', TestMocks.annotStateServiceMock);
                $provide.factory('MeasureManager', TestMocks.MeasureManagerMock);
                $provide.factory('linkingManager', TestMocks.linkingManagerMock);
                $provide.factory('renderingService', TestMocks.renderingServiceMock);

                $provide.factory('$viewportParameterStorage', function() {
                    return {
                        getGroup: function() {
                            return {
                                groupID: 'Group2',
                                seriesUID: 'UUID-2',
                                saveState: false,
                                secondaryCapture: true,
                                imageType: '2D',
                                modality: 'CT',
                                sliceSpacing: 2
                            };
                        },
                        getVolume: function() {
                            return {
                                groupUid: 'MockUID'
                            };
                        },
                        getRenderingUrl: function() {

                        },
                        getAnnotationUrl: function() {

                        },
                        getSaveState: function() {
                            return {
                                cursors: {
                                    filter: function() {
                                        return ['mockCursorOne', 'mockCursorTwo'];
                                    }
                                }
                            };
                        },
                        getCurrentConfiguration: function() {
                            return currentConfiguration;
                        }
                    };
                });

                $provide.factory('mouseModeStoreService', function() {
                    return {};
                });

                $provide.factory('CursorManager', function() {
                    return {
                        getCursor: function() {
                            return {
                                setPosition: function() {}
                            };
                        }
                    };
                });

                annotationService = {};
                $provide.value('annotationService', annotationService);

                annotationUIService = {};
                $provide.value('annotationUIService', annotationUIService);
            });
        });

        beforeEach(inject(function(_port3DContentFactory_, _$q_, _$rootScope_) {
            port3DContentFactory = _port3DContentFactory_;
            $q = _$q_;
            $rootScope = _$rootScope_;
        }));

        describe('Init port3DContentFactory:', function() {

            /**
             * @ngdoc method
             * @name InitPort3DContentFactory_Test
             * @methodOf xjtweb-platform.provider:port3DContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.$3DPortContentFactory port3DContentFactory} is created as an object.
             */
            it('port3DContentFactory should be a typeof object', function() {
                expect(typeof port3DContentFactory).to.equal('object');
            });

            /**
             * @ngdoc method
             * @name InitPort3DContent_setUp3DPort_Test
             * @methodOf xjtweb-platform.provider:port3DContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.$3DPortContentFactory port3DContentFactory} is created with a
             *              setUp3DPort function.
             */
            it('port3DContentFactory.setUp3DPort should be a typeof function', function() {
                expect(typeof port3DContentFactory.setUp3DPort).to.equal('function');
            });

            /**
             * @ngdoc method
             * @name set3DGroupOnPort_Test
             * @methodOf xjtweb-platform.provider:port3DContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.$3DPortContentFactory port3DContentFactory} is created with a
             *              set3DGroupOnPort function.
             */
            it('port3DContentFactory.set3DGroupOnPort ', function() {
                expect(typeof port3DContentFactory.set3DGroupOnPort).to.equal('function');

                var mockPort = {
                    getId: function() {

                    },
                    rendererType: 'mpr'
                };

                var mockGroup = {
                    groupID: '0'
                };

                // Called twice to go into the !Array.isArray(port.cbForOnReady) branche
                port3DContentFactory.set3DGroupOnPort(mockPort, mockGroup);
                port3DContentFactory.set3DGroupOnPort(mockPort, mockGroup);

                expect(typeof mockPort.cbForOnReady[0]).to.equal('function');
                mockPort.port3DReadyForSetup = true;
                mockPort.port3DSetup = true;
                mockPort.isSaveState = true;
                mockPort.applySaveState = sinon.spy();
                mockPort.cbForOnReady[0]();

                expect(mockPort.applySaveState.calledOnce).to.equal(true);
            });

            /**
             * @ngdoc method
             * @name set3DGroupOnPort_Test
             * @methodOf xjtweb-platform.provider:port3DContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.$3DPortContentFactory port3DContentFactory} will call
             *              SceneManager.requestRender when set2DGroupOnPort function is called.
             */
            it('port3DContentFactory.set2DGroupOnPort should call SceneManager.requestRender', function() {
                port3DContentFactory.set2DGroupOnPort();
                expect(SceneManager.requestRender.calledOnce).to.equal(true);
            });

            /**
             * @ngdoc method
             * @name set3DPPort_Test
             * @methodOf xjtweb-platform.provider:port3DContentFactory-test
             *
             * @description This test method determines that the
             *              {@link xjtweb-platform.$3DPortContentFactory port3DContentFactory} creates the webGl context
             *              with correct parameters in order to have working clipping
             */
            it('port3DContentFactory.set3DPPort on a MPR type, slice thickness should equals 2 ', function() {
                var mockPort = {
                    getId: sinon.stub().returns(1),
                    vp3Dcanvas: {
                        on: sinon.stub()
                    },
                    viewType: "Inferior",
                    volumeInfo: {
                        resampledSliceSpacing: 2
                    }
                };

                var createOrthographicCameraSpy = sinon.spy(xjtwebMock.CameraFactory, 'createOrthographicCamera');
                var createOrthographicCameraStub = sinon.stub(xjtwebMock.XJTWEB, 'T3DViewport');
                createOrthographicCameraStub.returns({
                    getViewHeight: sinon.stub().returns(128),
                    getAspectRatio: sinon.stub().returns(2),
                    annotationState: {
                        selectedAnnotState: 'full'
                    }
                });
                port3DContentFactory.setUp3DPort(mockPort);
                expect(createOrthographicCameraSpy.calledOnce).to.equal(true);
                var thicknessArg = createOrthographicCameraSpy.getCall(0).args[4];
                expect(thicknessArg).to.equal(2);
            });

        });

        it('port3DContentFactory.set3DPPort ', function(done) {
            var mockPort = {
                getId: sinon.stub().returns(1),
                vp3Dcanvas: {
                    on: sinon.stub(),
                    getContext: function() {
                        return {
                            drawImage: sinon.stub()
                        };
                    }
                },
                resizeViewport: function() {

                },
                viewType: "3D",
                volumeInfo: {}
            };

            var createCallBackCapture;

            xjtwebMock.XJTWEB.RmVolume.create = function(renderingUrl, volumeInfo, callback) {
                createCallBackCapture = callback;
            };

            xjtwebMock.XJTWEB.Annotation = {
                mapAnnotations: function(input) {
                    //identity mapping
                    return input;
                }
            };

            var renderCBCapture;

            function MockVolumeRenderEngine() {
                this.render = function(renderingUrl, renderCB) {
                    renderCBCapture = renderCB;
                };
            }

            var showAnnotations = sinon.spy();
            var loadAnnotCBCapture;
            xjtwebMock.XJTWEB.T3DViewport = MockT3DViewport;
            xjtwebMock.XJTWEB.volumeRenderEngine = MockVolumeRenderEngine;

            annotationService.loadAnnotations = function(annotParams) {
                loadAnnotCBCapture = annotParams.annotationCB;
            };
            annotationUIService.showAnnotations = showAnnotations;

            var createOrthographicCameraSpy = sinon.spy(xjtwebMock.CameraFactory, 'createOrthographicCamera');
            port3DContentFactory.setUp3DPort(mockPort);
            expect(createOrthographicCameraSpy.calledOnce).to.equal(true);
            var thicknessArg = createOrthographicCameraSpy.getCall(0).args[4];
            expect(thicknessArg).to.equal(null);

            expect(typeof createCallBackCapture).to.equal('function');

            var rmVolumeMock = {};
            createCallBackCapture(rmVolumeMock);

            expect(typeof mockPort.updateViewportImage).to.equal('function');
            mockPort.updateViewportImage();

            expect(typeof loadAnnotCBCapture).to.equal('function');
            loadAnnotCBCapture();

            var mockJsonView = {
                image: "data:image/gif;base64,R0lGODlhEAAOALMAAOazToeHh0tLS/7LZv/0jvb29t/f3//Ub//ge8WSLf/rhf/3kdbW1mxsbP//mf///yH5BAAAAAAALAAAAAAQAA4AAARe8L1Ekyky67QZ1hLnjM5UUde0ECwLJoExKcppV0aCcGCmTIHEIUEqjgaORCMxIC6e0CcguWw6aFjsVMkkIr7g77ZKPJjPZqIyd7sJAgVGoEGv2xsBxqNgYPj/gAwXEQA7"
            };

            expect(typeof renderCBCapture).to.equal('function');
            renderCBCapture(mockJsonView);

            setTimeout(function() {
                $rootScope.$apply();
                expect(showAnnotations.callCount).to.equal(1);
                done();
            }, 100);
        });
    });
});
