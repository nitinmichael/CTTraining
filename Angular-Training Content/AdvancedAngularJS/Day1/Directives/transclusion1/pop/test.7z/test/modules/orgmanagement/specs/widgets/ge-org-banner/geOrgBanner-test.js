define(['angular','postal','angular-mocks','orgMgmnt/widgets/ge-org-banner/geOrgBanner'],
    function (ng) {
        'use strict';
        describe('Tests ge-app-service controller', function(){
            var scope, geOrgBannerCtrl,event,rootScope,compile,templateCache,appServiceObj,_$timeout;
            var createControllerScopeUsingIsolatedScope=function(str){
                var ele=angular.element('<ge-org-banner bannerdata="'+str+'"></ge-org-banner>');
                inject(function($rootScope,$compile,$templateCache,$controller,$timeout){
                    var templateHtml = $templateCache.get('./modules/orgmanagement/widgets/ge-app-service/geOrgBanner.html');
                    if(!templateHtml) {
                       templateHtml = '<div data-ng-controller="geOrgBannerCtrl"></div>',
                        $templateCache.put('./modules/orgmanagement/widgets/ge-org-banner/geOrgBanner.html', templateHtml);
                    }
                    rootScope=$rootScope;
                    _$timeout = $timeout;
                    scope = $rootScope.$new();
                    scope.bannerdata=str;
                    $compile(ele)(scope);
					               geOrgBannerCtrl = $controller('geOrgBannerCtrl', {$scope:scope,$timeout:_$timeout});
                });
            };
            beforeEach( function(){
                module('geOrgBannerModule');
            });

            describe('Test mode type scenarios', function () {
              var obj1 ={"name":"John",
                                "subtext":"Status : Active",
                                "paramList":
                                [
                                  {"Role":"Health Care Provider"},
                                  {"E-mail Address":"john_smith@asdf.com"},
                                  {"Main Contact Phone Number":"(999) 456-7890"}

                              ]};

              it('checks mode type variable if context is specified', function(){
                createControllerScopeUsingIsolatedScope(obj1);

              });


                });

        });

    }
);
