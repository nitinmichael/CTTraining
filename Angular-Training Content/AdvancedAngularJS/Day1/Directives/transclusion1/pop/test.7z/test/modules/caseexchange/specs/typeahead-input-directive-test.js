﻿/*
 *  Gruntfile.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Chris Chike<christopher.chike@ge.com>
 */

/**
 * Spec file for Case Exchange > typeahead input directive module
 */

define(['angular', 'angular-mocks', 'widgets/typeahead-input/typeahead-input-directive', 'mocks/case-exchange-mock-service'], function () {
    'use strict';

    var expect = chai.expect;
    var $q;

    beforeEach(function () {

        // Load the module for the mock data first
        module('cloudav.caseExchange.mocks');

        module('Services.caseExchangeDataService');
        
        module('Directive.typeaheadInput', function($provide){
            $provide.value('nameFilter', function(names){
                return "Sample Name";
            })
        });

        // Load Templates
        module('templates');


    });

    describe('Typeahead Directive::', function() {
        var scope;
        var element;
        var compile;
        var rootScope;
        var GetActiveUsersService;
        var CaseExchangeDataService;
        var isolateScope;
        var usersJSON;
        var directive =
            '<typeahead-input ' +
                'service-url="{{usersURL}}" ' +
                'added-data="[]" ' +
                'is-multiple="true" ' +
                'input-placeholder="Please Enter Name or Email" ' +
                'inputfield-label="To*">  ' +
            '</typeahead-input>';

        beforeEach(inject(function($compile, $rootScope, _GetActiveUsersService_, _CaseExchangeDataService_, $templateCache, _$q_, CaseExchangeMocks) {
            $q = _$q_;
            compile = $compile;
            rootScope = $rootScope;
            GetActiveUsersService = _GetActiveUsersService_;
            CaseExchangeDataService = _CaseExchangeDataService_;
            scope = rootScope.$new();
            scope.usersURL = "mock.url";
            usersJSON = CaseExchangeMocks.getToUser();
            sinon.stub($, 'ajax').onFirstCall().yieldsTo('success', usersJSON);

            element = compile(directive)(scope);
            scope.$digest();
            isolateScope = element.isolateScope();
        }));

        it('should add recipient on Enter key press', function () {
            var user = $.extend({}, usersJSON.entry[0]);
            user.hover = true;
            isolateScope.usersInTypeahead = [user];
            isolateScope.handleKeyPress(13);
            expect(isolateScope.addedRecipients.length).to.equal(1);
        });

        it('should not add recipient when nothing highlighted on Enter key press', function () {
            var user = $.extend({}, usersJSON.entry[0]);
            user.hover = false;
            isolateScope.usersInTypeahead = [user];
            isolateScope.handleKeyPress(13);
            expect(isolateScope.addedRecipients.length).to.equal(0);
        });

        it('should highlight previous recipient on Up Arrow key press', function () {
            var user1 = $.extend({}, usersJSON.entry[0]);
            var user2 = $.extend({}, usersJSON.entry[1]);
            user1.hover = false;
            user2.hover = true;
            isolateScope.usersInTypeahead = [user1, user2];
            isolateScope.handleKeyPress(38);
            expect(user1.hover).to.be.true;
            expect(user2.hover).to.be.false;
        });

        it('should remain highlighted if first user highlighted on Up Arrow key press', function () {
            var user1 = $.extend({}, usersJSON.entry[0]);
            var user2 = $.extend({}, usersJSON.entry[1]);
            user1.hover = true;
            user2.hover = false;
            isolateScope.usersInTypeahead = [user1, user2];
            isolateScope.handleKeyPress(38);
            expect(user1.hover).to.be.true;
            expect(user2.hover).to.be.false;
        });

        it('should highlight next recipient on Down Arrow key press', function () {
            var user1 = $.extend({}, usersJSON.entry[0]);
            var user2 = $.extend({}, usersJSON.entry[1]);
            user1.hover = true;
            user2.hover = false;
            isolateScope.usersInTypeahead = [user1, user2];
            isolateScope.handleKeyPress(40);
            expect(user1.hover).to.be.false;
            expect(user2.hover).to.be.true;
        });

        it('should remain highlighted if last user highlighted on Down Arrow key press', function () {
            var user1 = $.extend({}, usersJSON.entry[0]);
            var user2 = $.extend({}, usersJSON.entry[1]);
            user1.hover = false;
            user2.hover = true;
            isolateScope.usersInTypeahead = [user1, user2];
            isolateScope.handleKeyPress(40);
            expect(user1.hover).to.be.false;
            expect(user2.hover).to.be.true;
        });

        it('should highlight first recipient if none highlighted on Down Arrow key press', function () {
            var user = $.extend({}, usersJSON.entry[0]);
            user.hover = false;
            isolateScope.usersInTypeahead = [user];
            isolateScope.handleKeyPress(40);
            expect(user.hover).to.be.true;
        });

        it('should have a controller > searching recipient > records found', function () {
            isolateScope.recipientsInput = "Peter";
            isolateScope.getActiveUsers(isolateScope.recipientsInput);
            rootScope.$apply();
            expect(isolateScope.noUsersFound).to.be.false;
            expect(isolateScope.usersInTypeahead.length).to.equal(2);
        });

        it('should have a controller > adding recipient', function () {
            isolateScope.addRecipient(usersJSON.entry[0]);
            expect(isolateScope.addedRecipients.length).to.equal(1);
        });

        it('should have a controller > selecting recipient > recipient already selected', function () {
            isolateScope.addedRecipients.push(usersJSON.entry[0]);
            isolateScope.addRecipient(usersJSON.entry[0]);
            expect(isolateScope.recipientAlreadySelected).to.be.true;
        });

        it('should have a controller > removing added recipient', function () {
            isolateScope.addedRecipients.push(usersJSON.entry[0]);
            isolateScope.addedRecipients.push(usersJSON.entry[1]);
            isolateScope.removeRecipient(usersJSON.entry[0]);
            expect(isolateScope.addedRecipients.length).to.equal(1);
        });

        it('should have a controller > hiding messages', function () {
            isolateScope.recipientsInput = "aaa";
            isolateScope.hideInfoMessages();
            expect(isolateScope.noUsersFound).to.be.false;
        });

        it('should have a controller > highlight To field on focus', function () {
            // Call highlightToField to mock the on focus behaviour
            isolateScope.highlightToField();
            // Assert if the variable has been set to "true" on focus
            expect(isolateScope.toFieldInputFocused).to.be.true;
        });

        it('should have a controller > de-highlight To field on tab out', function () {
            // Call hideInfoMessages to mock the tab out behaviour
            isolateScope.hideInfoMessages();
            // Assert if variable has been set to "false" on tab out
            expect(isolateScope.toFieldInputFocused).to.be.false;
        });

        // Restore jQuery's ajax method to its original state
        afterEach(function () {
            $.ajax.restore();
        });
    });
});
