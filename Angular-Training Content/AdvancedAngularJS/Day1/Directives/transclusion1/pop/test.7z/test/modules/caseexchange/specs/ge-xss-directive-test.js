/***************************************************************************************************
 * Copyright (c) 2015 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * Test suite for GeXSS directive
 *
 * @author
 * Henry Navarro <henry.navarro@ge.com>
 *
 ***************************************************************************************************/
define([
    'angular',
    'angular-mocks',
    'modules/caseexchange/widgets/ge-xss/ge-xss-directive'], function() {
    'use strict';
    describe('TestSuite.for.GeXss', function() {
        // $compile and $rootScope variable placeholders
        // $compile needed for directive application
        // $rootScope is used for template scope linking
        var compile, rootScope, scope, geXssCallbackSpy, geInvalidFormatCallbackSpy,
            directiveElem, xssCallCount = 0, formatCallCount = 0;

        beforeEach(function(){
            module('Directives.geXss');
        });

        // main suite preparation:
        // inject the $compile and $rootScope services,
        // add the callback functions for scripting and invalid format detection,
        // and add spies on the callback functions

        beforeEach(inject(function($compile, $rootScope) {
            // assign injected services to placeholders
            compile = $compile;
            rootScope = $rootScope;
            scope = rootScope.$new();

            // callback functions (placeholder/empty implementation, but definition needed)
            scope.geXssCallback = function (message) {
                scope.callbackMessage = message;
            };
            scope.geInvalidFormatCallback = function (message) {
                scope.formatMessage = message;
            };
        }));

        /* *****************************************************************************
         *
         * TEST FOR VALID VALUES
         *
         * *****************************************************************************
         */

        describe('Test for empty content', function() {
            it('should NOT call geXssCallback', function() {
                scope.callbackMessage = '';
                // create HTML element that uses directive, including template compilation and linking
                var el = angular.element('<input ge-xss on-script="geXssCallback"></input>');
                compile(el)(scope);
                scope.$digest();

                // change to safe value, which should NOT call on-script callback function
                el.val('');
                // trigger change event from element
                el.triggerHandler('change');
                scope.$digest();

                assert.equal(scope.callbackMessage, '', 'geXssCallback should not be called');
            });
        });

        describe('Test for valid email', function() {
            it('should NOT call geXssCallback', function() {
                scope.callbackMessage = '';
                // create HTML element that uses directive, including template compilation and linking
                var el = angular.element('<input ge-xss on-script="geXssCallback" ge-pattern="email"></input>');
                compile(el)(scope);
                scope.$digest();

                // change to safe value, which should NOT call on-script callback function
                el.val('first.last@domain.com');
                // trigger change event from element
                el.triggerHandler('change');
                scope.$digest();

                assert.equal(scope.callbackMessage, '', 'geXssCallback should not be called');
            });
        });

        describe('Test for valid date', function() {
            it('should NOT call geXssCallback', function() {
                scope.callbackMessage = '';
                // create HTML element that uses directive, including template compilation and linking
                var el = angular.element('<input ge-xss on-script="geXssCallback" ge-pattern="date"></input>');
                compile(el)(scope);
                scope.$digest();

                // change to safe value, which should NOT call on-script callback function
                el.val('Jan 01 1971');
                // trigger change event from element
                el.triggerHandler('change');
                scope.$digest();

                assert.equal(scope.callbackMessage, '', 'geXssCallback should not be called');
            });
        });

        describe('Test for empty data type', function() {
            it('should NOT call geXssCallback', function() {
                scope.callbackMessage = '';
                // create HTML element that uses directive, including template compilation and linking
                var el = angular.element('<input ge-xss on-script="geXssCallback" ge-pattern=""></input>');
                compile(el)(scope);
                scope.$digest();

                // change to safe value, which should NOT call on-script callback function
                el.val('Jan 01 1971');
                // trigger change event from element
                el.triggerHandler('change');
                scope.$digest();

                assert.equal(scope.callbackMessage, '', 'geXssCallback should not be called');
            });
        });

        describe('Test for absence of "<script>"', function() {
            it('should NOT call geXssCallback', function() {
                scope.callbackMessage = '';
                // create HTML element that uses directive, including template compilation and linking
                var el = angular.element('<input ge-xss on-script="geXssCallback"></input>');
                compile(el)(scope);
                scope.$digest();

                // change to safe value, which should NOT call on-script callback function
                el.val('< br />  ');
                // trigger change event from element
                el.triggerHandler('change');
                scope.$digest();

                assert.equal(scope.callbackMessage, '', '$rootScope.callbackMessage is empty');
            });
        });

        describe('Test for absence of "javascript:"', function() {
            it('should NOT call geXssCallback', function() {
                scope.callbackMessage = '';
                // create HTML element that uses directive, including template compilation and linking
                var el = angular.element('<input ge-xss on-script="geXssCallback"></input>');
                compile(el)(scope);
                scope.$digest();

                // change to safe value, which should NOT call on-script callback function
                el.val('abc  ');
                // trigger change event from element
                el.triggerHandler('change');
                scope.$digest();

                assert.equal(scope.callbackMessage, '', '$rootScope.callbackMessage is empty');
            });
        });


        /* *****************************************************************************
         *
         * TEST FOR INVALID VALUES
         *
         * *****************************************************************************
         */

        describe('Test for "reset-on-script" attribute', function() {
            it('should call geXssCallback', function() {
                scope.callbackMessage = '';
                var el = angular.element('<input ge-xss reset-on-script="true"></input>');
                compile(el)(scope);

                // change element value which should trigger appropriate callback function
                el.val('< script  >   ');
                el.triggerHandler('change');
                scope.$digest();

                assert.equal(el.val(), '', 'element should be empty');
            });
        });

        describe('Test for Presence of "<script>"', function() {
            it('should call geXssCallback', function() {
                scope.callbackMessage = '';
                var el = angular.element('<input ge-xss on-script="geXssCallback"></input>');
                compile(el)(scope);

                // change element value which should trigger appropriate callback function
                el.val('< script  >   ');
                el.triggerHandler('change');
                scope.$digest();

                assert.notEqual(scope.callbackMessage, '', 'on-script callback was not called');
            });
        });

        describe('Test for Presence of "javascript: without callback specified"', function() {
            it('should call geXssCallback', function() {
                scope.callbackMessage = '';
                var el = angular.element('<input ge-xss></input>');
                compile(el)(scope);

                // change element value which should trigger appropriate callback function
                el.val('javascript:');
                el.triggerHandler('change');
                scope.$digest();

                assert.equal(scope.callbackMessage, '', 'on-script callback was called');
            });
        });

        describe('Test for invalid name value', function() {
            it('should call geInvalidFormatCallback', function() {
                scope.formatMessage = '';
                var el = angular.element('<input ge-xss on-invalid="geInvalidFormatCallback" ge-pattern="name"></input>');
                compile(el)(scope);

                // change element value to invalid name string
                el.val('John D0e*^&');
                // trigger handling of change event
                el.triggerHandler('change');
                scope.$digest();
                assert.notEqual(scope.formatMessage, '', 'on-invalid callback was not called');
            });
        });

        describe('Test for invalid DATE value', function() {
            it('should call geInvalidFormatCallback', function() {
                scope.formatMessage = '';
                var el = angular.element('<input ge-xss on-invalid="geInvalidFormatCallback" ge-pattern="date"></input>');
                compile(el)(scope);

                // change element value to invalid name string
                el.val('asasdflkjsdlfkj');
                // trigger handling of change event
                el.triggerHandler('change');
                scope.$digest();
                assert.notEqual(scope.formatMessage, '', 'on-invalid callback was not called');
            });
        });

    });
});
