define(['angular'],function(angular){
angular.module('deviceManagerServiceMock', [])
    .service('$deviceManagerService', function () {

        var supportedDevices = {
            'iPad': 'tablet',
            'iPhone': 'tablet'
        };

        var deviceUserAgent = function (device) {
            var mobiles = {
                Android: function() {
                    return navigator.userAgent.match(/Android/i);
                },
                BlackBerry: function() {
                    return navigator.userAgent.match(/BlackBerry/i);
                },
                iOS: function() {
                    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
                },
                Opera: function() {
                    return navigator.userAgent.match(/Opera Mini/i);
                },
                Windows: function() {
                    return navigator.userAgent.match(/IEMobile/i);
                },
                any: function() {
                    return (mobiles.Android() || mobiles.BlackBerry() || mobiles.iOS() || mobiles.Opera() || mobiles.Windows());
                }
            };

            return mobiles[device]();
        };

        this.getFileUrl = function(fileName) {
            if (!fileName || typeof fileName !== 'string') {
                throw new TypeError('the parameter should be a string');
            }

            var currentUserAgent = deviceUserAgent('any');
            if(typeof(currentUserAgent) === 'object' && currentUserAgent !== null && typeof(supportedDevices[currentUserAgent[0]]) === 'string') {
                var name = fileName.substr(0, fileName.lastIndexOf('.'));
                var extension = fileName.substr(fileName.lastIndexOf('.'), fileName.length - 1);
                return name + '-' + supportedDevices[currentUserAgent[0]] + extension;
            }

            return fileName;
        };

        this.getSupportedDeviceName = function () {
            var currentUserAgent = deviceUserAgent('any');
            if(typeof(currentUserAgent) === 'object' && currentUserAgent !== null && typeof(supportedDevices[currentUserAgent[0]]) === 'string') {
                return currentUserAgent[0];
            }

            return 'desktop';
        };

        this.isMobile = function () {
            return deviceUserAgent('any') !== null;
        };
    });
});
