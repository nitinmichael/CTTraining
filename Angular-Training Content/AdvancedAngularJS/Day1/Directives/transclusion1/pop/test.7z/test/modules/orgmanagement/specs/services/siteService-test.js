define(['angular','angular-mocks', 'orgMgmnt/services/siteService'], function () {
    'use strict';

    describe('Test Site Service', function () {
        beforeEach(function(){
            module(function($provide){
                $provide.service('masterDataModel', function(){
                    this.getGatewayUrl= sinon.spy();
                });
            });
            module('Orgmanagement.Services.SiteService');});


        var siteMgmtService, _masterDataModel;
        var $httpBackend, uomServiceUrl;
        var q, defer,deviceDeferred,deferredAppServices,deferredDevices,deferredAppServicesLevel2;

        beforeEach(inject(function(_siteMgmtService_, _$httpBackend_,_$q_,masterDataModel) {
            siteMgmtService = _siteMgmtService_;
            $httpBackend = _$httpBackend_;
            _masterDataModel = masterDataModel;
            q = _$q_;
            defer = q.defer();
            deviceDeferred = q.defer();
            deferredAppServices = q.defer();
            deferredDevices= q.defer();
            deferredAppServicesLevel2 = q.defer();
            uomServiceUrl = _masterDataModel.getGatewayUrl();
        }));


        describe('Create Site service', function(){
            it('should test createSite is called successfully ', function () {
                var site = {"value":"GEHC"};
                var url = uomServiceUrl+'/v1/site';
                $httpBackend.expectPOST(url,site).respond(200);
                defer.resolve();
                siteMgmtService.createSite(site);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test createSite is not called  successfully ', function () {
                var site = {"value":"GEHC"};
                var url=uomServiceUrl+'/v1/site';
                $httpBackend.expectPOST(url,site).respond(400);
                defer.resolve();
                siteMgmtService.createSite(site);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });



        });

        describe('Retrieve device by Id', function(){
            it('should test retrieve device is called successfully ', function () {
                var url=uomServiceUrl+'/v1/device/123';
                $httpBackend.expectGET(url).respond(200);
                deviceDeferred.resolve('123');
                siteMgmtService.retrieveDeviceById('123');
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });


            it('should test retrieve device is called failed ', function () {

                var url=uomServiceUrl+'/v1/device/12345';
                $httpBackend.expectGET(url).respond(400);
                deviceDeferred.reject(12345);
                siteMgmtService.retrieveDeviceById('12345');
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

        });

        describe('Get Site details service',function(){
            it('should test getSiteDetails is called successfully',function(){
                var url = uomServiceUrl+'/v1/site/1234';
                $httpBackend.expectGET(url).respond(200);
                defer.resolve('123');
                siteMgmtService.getSiteDetail('1234');
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest;
            });

            it('should test getSiteDetails is not called successfully',function(){
                var url = uomServiceUrl+'/v1/site/123456';
                $httpBackend.expectGET(url).respond(400);
                defer.reject('1234');
                siteMgmtService.getSiteDetail('123456');
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest;
            });

        });

        describe('Update site Settings service', function(){
            it('should test UpdatesiteSettings is called successfully ', function () {
                var extensions={};
                var siteSettings={};
                siteSettings.siteId = '123456';
                siteSettings.extension = extensions;
                var url=uomServiceUrl+"/v1/site/"+siteSettings.siteId+"/"+"networksettings";
                $httpBackend.expectPUT(url,extensions).respond(200);
                defer.resolve();
                siteMgmtService.updateSiteSettings(siteSettings);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test Update site Settings is not called successfully ', function () {
                var extensions={};
                var siteSettings={};
                siteSettings.siteId = '123456';
                siteSettings.extension = extensions;
                var url=uomServiceUrl+"/v1/site/"+siteSettings.siteId+"/"+"networksettings";
                $httpBackend.expectPUT(url,extensions).respond(400);
                defer.reject();
                siteMgmtService.updateSiteSettings(siteSettings);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test updateSiteAdmins is called successfully ', function () {
                var siteAdminDetail =[{
                    "op": "replace",
                    "path": "scopingOrganization",
                    "value": '232'
                },
                    {
                        "op": "replace",
                        "path": "",
                        "value": ['12', '45']
                    }];
                var url= uomServiceUrl + "/v1/user/scopedRole";
                $httpBackend.expectPATCH(url).respond(200);
                defer.resolve();
                siteMgmtService.updateSiteAdmins(siteAdminDetail);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test updateSiteAdmins is not called successfully ', function () {
                var siteAdminDetail =[{
                    "op": "replace",
                    "path": "scopingOrganization",
                    "value": '232'
                },
                    {
                        "op": "replace",
                        "path": "",
                        "value": ['12', '45']
                    }];
                var url= uomServiceUrl + "/v1/user/scopedRole";
                $httpBackend.expectPATCH(url).respond(400);
                defer.reject();
                siteMgmtService.updateSiteAdmins(siteAdminDetail);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('UpdateSiteDetails service', function(){
            it('should test UpdateSiteDetails is called successfully', function(){
                var siteSettingDetail ={extension:"GEHC", siteId:"123"};
                var url= uomServiceUrl+"/v1/site/"+siteSettingDetail.siteId+"/sitedetails";
                $httpBackend.expectPUT(url).respond(200);
                defer.resolve();
                siteMgmtService.updateSiteDetail(siteSettingDetail);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test UpdateSiteSettings is not called successfully', function(){
                var siteSettingDetail ={extension:"GEHC", siteId:"123"};
                var url= uomServiceUrl+"/v1/site/"+siteSettingDetail.siteId+"/sitedetails";
                $httpBackend.expectPUT(url).respond(400);
                defer.reject();
                siteMgmtService.updateSiteDetail(siteSettingDetail);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('updateDevice service', function(){
            it('should test updateDevice is called successfully', function(){
                var deviceDetails={};
                var deviceObj={
                };
                deviceDetails.deviceId = '123456';
                deviceDetails.deviceObj = deviceObj;
                var url= uomServiceUrl+"/v1/device/"+deviceDetails.deviceId+"/deviceDetails";
                $httpBackend.expectPUT(url).respond(200);
                deviceDeferred.resolve();
                siteMgmtService.updateDevice(deviceDetails);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test updateDevice is not called successfully', function(){
                var deviceDetails={};
                var deviceObj={
                };
                deviceDetails.deviceId = '123456';
                deviceDetails.deviceObj = deviceObj;
                var url=uomServiceUrl+ "/v1/device/"+deviceDetails.deviceId+"/deviceDetails";
                $httpBackend.expectPUT(url).respond(400);
                deviceDeferred.reject();
                siteMgmtService.updateDevice(deviceDetails);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });


        describe('Create device service', function() {
            it('should test create device is called successfully ', function () {
                var device = {"value": "GEHC"};
                var url = uomServiceUrl+'/v1/device';
                $httpBackend.expectPOST(url, device).respond(200);
                deviceDeferred.resolve();
                siteMgmtService.createDevice(device);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test createdevice is not called  successfully ', function () {
                var device = {"value": "GEHC"};
                var url = uomServiceUrl+'/v1/device';
                $httpBackend.expectPOST(url, device).respond(400);
                deviceDeferred.resolve();
                siteMgmtService.createDevice(device);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

        });

        describe('Create Application service', function(){
            it('should test createApplicationService is called successfully**** ', function () {
                var deviceEndPointsObj = {"value":"GEHC"};
                var siteId = '1234';
                var url = uomServiceUrl+"/v1/site/" + siteId + "/applicationservice";
                var deviceEndPointsJson = JSON.stringify(deviceEndPointsObj);
                $httpBackend.expectPUT(url,deviceEndPointsJson).respond(200);
                deferredDevices.resolve();
                siteMgmtService.createUpdateApplicationServices(deviceEndPointsObj,siteId,true);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test createApplicationService is called successfully but call failed to return data**** ', function () {
                var deviceEndPointsObj = {"value":"GEHC"};
                var siteId = '1234';
                var url = uomServiceUrl+"/v1/site/" + siteId + "/applicationservice";
                var deviceEndPointsJson = JSON.stringify(deviceEndPointsObj);
                $httpBackend.expectPUT(url,deviceEndPointsJson).respond(400);
                deferredDevices.reject();
                siteMgmtService.createUpdateApplicationServices(deviceEndPointsObj,siteId,true);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });


            it('should test createApplicationService is called successfully with error**** ', function () {
                var deviceEndPointsObj = {"value":"GEHC"};
                var siteId = '1234';
                var url = uomServiceUrl+"/v1/site/" + siteId + "/applicationservice";
                var deviceEndPointsJson = JSON.stringify(deviceEndPointsObj);
                $httpBackend.expectPOST(url,deviceEndPointsJson).respond(200);
                deferredDevices.resolve();
                siteMgmtService.createUpdateApplicationServices(deviceEndPointsObj,siteId,false);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test createApplicationService  is called successfully with error and returns with data ', function () {
                var deviceEndPointsObj = {"value":"GEHC"};
                var siteId = '1234';
                var url = uomServiceUrl+"/v1/site/" + siteId + "/applicationservice";
                var deviceEndPointsJson = JSON.stringify(deviceEndPointsObj);

                $httpBackend.expectPOST(url,deviceEndPointsJson).respond(400);
                deferredDevices.reject();
                siteMgmtService.createUpdateApplicationServices(deviceEndPointsObj,siteId,false);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });


        });

        describe('get all application services by site Id', function(){
            it('should test get all application services is called successfully ', function () {
                var siteId = '1234';
                var url = uomServiceUrl+"/v1/site/" + siteId + "/applicationservice";
                $httpBackend.expectGET(url).respond(200);
                deferredAppServices.resolve('1234');
                siteMgmtService.getApplicationServices(siteId);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });


            it('should test get all application services is not called  successfully ', function () {
                var siteId = '1234';
                var url = uomServiceUrl+"/v1/site/" + siteId + "/applicationservice";
                $httpBackend.expectGET(url).respond(400);
                deferredAppServices.reject(1234);
                siteMgmtService.getApplicationServices(siteId);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

        });

        describe('GetAllSite Service', function(){
            it('should test GetAllSite is called successfully ', function () {
                var url=uomServiceUrl+'/v1/organization/'+'1234'+'/site';
                $httpBackend.expectGET(url).respond(200);
                defer.resolve('1234');
                siteMgmtService.getAllSite('1234');
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test GetAllSite is not called successfully ', function () {
                var url=uomServiceUrl+'/v1/organization/'+'1234'+'/site';
                $httpBackend.expectGET(url).respond(400);
                defer.reject('1234');
                siteMgmtService.getAllSite('1234');
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('GetList of devices Service', function(){
            it('should test get device list is called successfully ', function () {
                var siteId = '1234';
                var url = uomServiceUrl+'/v1/site/'+siteId+"/device";
                $httpBackend.expectGET(url).respond(200);
                deviceDeferred.resolve();
                siteMgmtService.getListOfDevices(siteId);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test createdevice is not called  successfully ', function () {
                var siteId = '1234';
                var url = uomServiceUrl+'/v1/site/'+siteId+"/device";
                $httpBackend.expectGET(url).respond(400);
                deviceDeferred.reject();
                siteMgmtService.getListOfDevices(siteId);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('Delete Application Service', function(){
            it('should test applicationService is deleted successfully ', function () {
                var url=uomServiceUrl+'/v1/site/'+'1234'+'/applicationservice/'+'3241';
                $httpBackend.expectDELETE(url).respond(200);
                deferredAppServices.resolve('1234');
                siteMgmtService.deleteApplicationService('1234','3241');
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test GetAllSite is not called successfully ', function () {
                var url=uomServiceUrl+'/v1/site/'+'1234'+'/applicationservice/'+'3241';
                $httpBackend.expectDELETE(url).respond(400);
                deferredAppServices.reject({data:'1234',status:400});
                siteMgmtService.deleteApplicationService('1234','3241');
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('list of application services for a site', function(){
            it('should test applicationService is loaded successfully ', function () {
                var siteId = '1234';
                var url=uomServiceUrl +"/v1/site/" + siteId + "/applicationservice";
                $httpBackend.expectGET(url).respond(200);
                deferredAppServicesLevel2.resolve('1234');
                siteMgmtService.getApplicationServices(siteId);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it('should test applicationService is deleted successfully ', function () {
                var siteId = '1234';
                var url=uomServiceUrl +"/v1/site/" + siteId + "/applicationservice";
                $httpBackend.expectGET(url).respond(400);
                deferredAppServicesLevel2.reject('1234');
                siteMgmtService.getApplicationServices(siteId);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('Validate Site Legal Name service', function(){
            it("checks Validate Site Legal Name service is called successfully", function(){
                var url = uomServiceUrl+"/v1/site?validateOnly=true";
                var siteObj = {
                    "resourceType": "ResourcesUserGroup",
                    "member": [],
                    "managingOrganization": {},
                    "partOf": {},
                    "name": "test"
                };
                $httpBackend.expectPOST(url,siteObj).respond(200);
                defer.resolve();
                siteMgmtService.isValidSiteLegalName(siteObj);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });

            it("checks Validate Site Legal Name service is not called successfully", function(){
                var url = uomServiceUrl+"/v1/site?validateOnly=true";
                var siteObj = {
                    "resourceType": "ResourcesUserGroup",
                    "member": [],
                    "managingOrganization": {},
                    "partOf": {},
                    "name": "test"
                };
                $httpBackend.expectPOST(url,siteObj).respond(400);
                defer.reject();
                siteMgmtService.isValidSiteLegalName(siteObj);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe('Validate getting site admins service working properly', function(){
            it("get site admins details service is called successfully", function(){
                var siteId = "12-s23",
                    url = uomServiceUrl+ "/v1/organization/"+siteId+"/administrator";
                $httpBackend.expectGET(url).respond(200);
                defer.resolve();
                siteMgmtService.getSiteAdmins(siteId);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
            it("get site admins details service is not called successfully", function(){
                var siteId = "12-s23",
                    url = uomServiceUrl+ "/v1/organization/"+siteId+"/administrator";
                $httpBackend.expectGET(url).respond(400);
                defer.reject();
                siteMgmtService.getSiteAdmins(siteId);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });

        describe("Site list depending upon text given", function(){
            it("get site list from server for typeahead, success", function(){
                var searchParam ='test',
                    SITE_SEARCH_URL = uomServiceUrl + '/v1/site/_search?name=test',
                    res=JSON.parse(JSON.stringify({data: "", status: 200,statusText: "OK"}));
                    
                $httpBackend.expectGET(SITE_SEARCH_URL).respond(200);
                defer.resolve(res);
                siteMgmtService.findSite(searchParam);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });


            it("get organization list from server for typeahead, failure", function(){
                var searchParam ='test',
                    SITE_SEARCH_URL = uomServiceUrl + '/v1/site/_search?name=test';
                    
                $httpBackend.expectGET(SITE_SEARCH_URL).respond(400);
                defer.reject();
                siteMgmtService.findSite(searchParam);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });
        describe('Get user details', function(){
            it("get user details service is called successfully", function(){
                var siteId = "12-s23",
                    url = uomServiceUrl+ "/v1/user/"+siteId;
                $httpBackend.expectGET(url).respond(200);
                defer.resolve();
                siteMgmtService.getUserDetails(siteId);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
            it("get user details service is not called successfully", function(){
                var siteId = "12-s23",
                    url = uomServiceUrl+ "/v1/user/"+siteId;
                $httpBackend.expectGET(url).respond(400);
                defer.reject();
                siteMgmtService.getUserDetails(siteId);
                $httpBackend.flush();
                $httpBackend.verifyNoOutstandingExpectation();
                $httpBackend.verifyNoOutstandingRequest();
            });
        });
    });
});



