/*
 *  morpheus-controller.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * A Morpheus controller to handle case related operations.
 */
define(['angular', 'postal', '../module'],
    function (ng) {
        'use strict';

        var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
        var eventer = window[eventMethod];
        var messageEvent = (eventMethod === "attachEvent") ? "onmessage" : "message";

        // Listen to message from child window
        eventer(messageEvent,function() {
            try{
                var iframe = $("iframe")[0].contentDocument;
                var rightPanel = $(iframe).find("[data-ui-view='rightview']");

                if(rightPanel && rightPanel.css("display") === "block"){
                    $(iframe).find("[data-ui-view='rightview'] .pane-collapser").trigger("click");
                }
            }catch(e){
                console.log("Error hiding the right panel of dashboard iframe");
            }
        },false);

        // morpheus Controller module
        var morpheus = ng.module('cloudav.caseExchange.morpheusCtrl', ['Services.morpheusServices', 'Services.caseExchangeDataService']);
        var hasRole = function(roles, matchRole){
            var hasRole = false;
            if(roles !== undefined){
                for(var b= 0, bEnd = roles.length; b<bEnd; b++){
                    var role = roles[b];
                    for(var c= 0, cEnd = role.code.length; c<cEnd; c++){
                        if(role.code[c].code === matchRole){
                            hasRole = true;
                            break;
                        }
                    }
                }
            }
            return hasRole;
        };

        var routeToSubModules = function($rootScope, $scope, $state, $stateParams, isOnLoad, data){
            if(hasRole(data.role, 'administrator')){
                $state.transitionTo('caseexchange.morpheus.morpheusAdmin', {id : $stateParams.id});
            }else if(hasRole(data.role, 'practitioner')){
                $state.transitionTo('caseexchange.morpheus.morpheusUser', {id : $stateParams.id, onLoad: isOnLoad});
            }else{
                if(isOnLoad){
                    $rootScope.onLoad = false;
                    $scope.$emit('error', {page: 'caseexchange.caseinbox', type: 'error.redirectToInbox'});
                }else{
                    $scope.$emit('error', {page: 'caseexchange.morpheus.errorPage', type: 'error.noPrivilege'});
                }
            }
        };

        // morpheus Controller
        morpheus.controller('MorpheusCtrl', ['$rootScope', '$scope', '$state', '$stateParams', 'MorpheusServices', 'CaseExchangeDataService', function ($rootScope, $scope, $state, $stateParams, morpheusServices, caseExchangeDataService) {
            $scope.$state = $state;
            var isOnLoad = ($rootScope.onLoad === undefined);

            $scope.$on('error', function( event, data ){
                if(isOnLoad){
                    $state.transitionTo('caseexchange.caseinbox', {id : $stateParams.id, type: 'error.redirectToInbox'});
                }else{
                    $state.transitionTo(data.page, {id : $stateParams.id, type: data.type});
                }
            });

            morpheusServices.getLoggedInUserDetails().then(function(data){
                caseExchangeDataService.setCurrentUser(data);

                if($state.current.name.indexOf("errorPage") === -1){
                    routeToSubModules($rootScope, $scope, $state, $stateParams, isOnLoad, data);
                }else{
                    if(isOnLoad && $stateParams.type === "error.redirectToInbox"){
                        $scope.$emit('error', {page: 'caseexchange.caseinbox', type: 'error.redirectToInbox'});
                    }
                    $rootScope.onLoad = false;
                }
            }, function(){
                $rootScope.onLoad = false;
                $scope.$emit('error', {page: 'caseexchange.morpheus.errorPage', type: 'error.errorOccurred'});
            });

        }]);

        return morpheus;
    }
);