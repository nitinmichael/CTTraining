/*
 *  pacs-search-controller.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * A Pacs Search controller to handle pacs search related operations.
 */
define(['angular',
    'angularTranslate',
    'angularTranslatePartialLoader',
    '../../../module'], function (ng) {
    'use strict';

    // Module dependencies
    var dependencies = ['ui.bootstrap',
        'pascalprecht.translate',
        'Services.pacsSearchMarshaller',
        'Services.pacsSearchService',
        'Services.getPacsServices',
        'Services.selectedStudyListService',
        'Services.caseExchangeDataService'
    ];

    // Pacs Search controller module
    var pacssearch = ng.module('cloudav.caseExchange.createCase.pacsSearchCtrl', dependencies);

    //Pacs search controller
    //Pacs search controller
    pacssearch.controller('PacsSearchCtrl', ['$scope', '$timeout', '$state', '$stateParams', '$filter', '$modal', '$log', '$location', 'PacsSearchMarshaller', 'PacsSearchService', 'GetPacsServices', 'SelectedStudyListService', 'CaseExchangeDataService',
        function ($scope, $timeout, $state, $stateParams, $filter, $modal, $log, $location, PacsSearchMarshaller, PacsSearchService, GetPacsServices, SelectedStudyListService, CaseExchangeDataService) {

            $scope.showPacsSearchError = false;

            $scope.searchPacsFormSubmitted = true;

            //used for form validation.  User must select at least one device.
            $scope.deviceSelected = false;

            //allDevicesSelected - set to true when user clicks "selectAll" devices button
            $scope.allDevicesSelected = false;

            //Displays the error message for DICOM devices
            $scope.showDeviceError = false;

            $scope.disablePatientField = false;

            $scope.datepicker = {
                opened: false,
                format: 'dd MMM yyyy',
                maxDate: new Date()
            };

            var pacsSearchXHR;

            /**
             * Function to pre select pacs devices if user goes back from
             * patient list page to search page
             */
            $scope.isPacsSelected = function (dicomDeviceId) {
                var pacsSelected=false;
                var selectedPacs = PacsSearchService.getPacsSearchParams().dicomDevices;
                if(selectedPacs && selectedPacs.length>0){
                    for (var i = 0; i < selectedPacs.length; i++){
                        if(selectedPacs[i].id===dicomDeviceId){
                            pacsSelected=true;
                            break;
                        }
                    }
                }
                return pacsSelected;
            };

            /**
             * Service call to get the Pacs device data
             * initiated selected & expanded properties for dicom devices
             * used to apply different css if the user selects or expands a dicom device
             */
            GetPacsServices.getPacsDevices().then(function (data) {
                $scope.dicomDevices = [];
                _.each(data.entry, function (dicomDevice) {
                    dicomDevice.selected = $scope.isPacsSelected(dicomDevice.id);
                    dicomDevice.expanded = false;
                    $scope.dicomDevices.push(dicomDevice);
                });

                //sort dicom devices alphabetically
                $scope.dicomDevices = _.sortBy($scope.dicomDevices, function (currDevice) {
                    return currDevice.content.name;
                });

                var selectedPacs = PacsSearchService.getPacsSearchParams().dicomDevices;
                if(selectedPacs && selectedPacs.length === $scope.dicomDevices.length){
                    $scope.selectDeselectChecked=true;
                    $scope.allDevicesSelected=true;
                }
                PacsSearchMarshaller.marshalDicomDevice($scope.dicomDevices);
            }, function () {
                $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
            });

            /**
             * Sets deviceSelected scope variable used for form validation
             * if at least one dicom device is selected, $scope.deviceSelected is set to true
             */
            var setDeviceSelected = function () {
                $scope.deviceSelected = $scope.pacsData.dicomDevices.length > 0;
                $scope.showDeviceError = !$scope.deviceSelected;
            };

            /**
             * A function to toggle the device selection.
             * Used to apply different style if user clicks a dicom device
             * @param
             *   dicomDevice - passed in ng-repeat directive
             * if device is selected, push into $scope.pacsData.devices array,
             * else remove (using underscore helper function)
             */
            $scope.toggleDeviceSelected = function (dicomDevice) {
                dicomDevice.selected = !dicomDevice.selected;
                if (dicomDevice.selected) {
                    if (!$scope.pacsData.dicomDevices) {
                        $scope.pacsData.dicomDevices = [];
                    }
                    $scope.pacsData.dicomDevices.push(dicomDevice);
                } else {
                    var device = _.find($scope.pacsData.dicomDevices, function (device) {
                        return dicomDevice.id === device.id;
                    });

                    if (device) {
                        var index = $scope.pacsData.dicomDevices.indexOf(device);
                        if (index > -1) {
                            $scope.pacsData.dicomDevices.splice(index, 1);
                        }
                    }
                }
                setDeviceSelected();
                // Set the "all device selected" flag to true if all the devices has been selected one by one manually.
                $scope.allDevicesSelected = $scope.pacsData.dicomDevices && $scope.dicomDevices && $scope.pacsData.dicomDevices.length === $scope.dicomDevices.length;
                $scope.selectDeselectChecked = $scope.allDevicesSelected;
            };

            /**
             * A function to select / De-select all the devices(PACS).
             * used to apply different style to all dicom devices if the user clicks "Select All"
             */
            $scope.toggleSelectAllDevices = function () {
                // Toggle the variable to Select / De-Select all devices
                $scope.allDevicesSelected = !$scope.allDevicesSelected;
                // reset pacsData.devices array
                $scope.pacsData.dicomDevices = [];
                _.each($scope.dicomDevices, function (device) {
                    device.selected = $scope.allDevicesSelected;
                    //if all devices are selected, push them to pacsData.devices array
                    if ($scope.allDevicesSelected) {
                        $scope.pacsData.dicomDevices.push(device);
                    }
                });
                setDeviceSelected();
            };

            // A function to assign a default values to search PACS data.
            // If $state.params has a "true" value for "resetSearchData", then it will assign the default values.
            // Else it will merge the data with values available in factory
            $scope.initializePacsData = function () {
                var defaultPacsData = {
                    patientLastName: '',
                    patientFirstName: '',
                    patientMiddleName: '',
                    studyId: '',
                    dicomDevices: []
                };
                var selectedPatient = SelectedStudyListService.getSelectedPatient();
                if (typeof selectedPatient.identifier !== 'undefined') {
                    defaultPacsData.patientLastName = selectedPatient.name && selectedPatient.name.family &&
                    selectedPatient.name.family instanceof Array ? selectedPatient.name.family.join(' ') : '';
                    defaultPacsData.patientFirstName = selectedPatient.name.given && selectedPatient.name.given instanceof Array ? selectedPatient.name.given[0] : '';
                    defaultPacsData.patientMiddleName = selectedPatient.name.given && selectedPatient.name.given instanceof Array ? selectedPatient.name.given[1] : '';
                    defaultPacsData.birthDate = selectedPatient.birthDate;
                    defaultPacsData.gender = selectedPatient.gender;
                    defaultPacsData.patientId = selectedPatient.identifier;
                    defaultPacsData.dicomDevices=PacsSearchService.getPacsSearchParams().dicomDevices;
                    $scope.pacsData = defaultPacsData;
                    $scope.disablePatientField = true;
                } else {
                    var pacSearchParams = PacsSearchService.getPacsSearchParams();
                    if (pacSearchParams) {
                        $scope.pacsData = pacSearchParams;
                    } else {
                        $scope.pacsData = defaultPacsData;
                    }
                }
            };

            // A function to be called on load of a controller to initialize the basic values
            $scope.initializePacsData();

            /**
             * send pacs search form data to pacs search service for submitting
             * it to respective micro service
             */
            $scope.submitPacsSearch = function () {
                if ($scope.validatePacsSearchData()) {
                    var patientBirthDate = $scope.pacsData.birthDate;
                    //Convert patient birth date into UTC format, if present
                    if(patientBirthDate){
                        $scope.pacsData.birthDate = CaseExchangeDataService.convertDateToUTC($filter('date')(patientBirthDate, 'yyyyMMdd'));
                    }
                    $state.transitionTo('caseexchange.pacspatientlist', {id: $stateParams.id, pacsSearchData:$scope.pacsData});
                }
            };

            /**
             * Validation for Empty Search field Data
             */
            var isSearchFieldEmpty = function (pacsData) {
                if (!pacsData) {
                    return true;
                }
                else {
                    var patientName = pacsData.patientFirstName + pacsData.patientLastName;
                    if (patientName === "" && pacsData.studyId === "") {
                        return true;
                    }
                }
                return false;
            };

            /**
             * Validation for Patient First, Last and Middle names
             */
            var isPatientNameEmpty = function (pacsData) {
                if (!pacsData) {
                    return true;
                }
                //if all three names are blank then its a invalid condition
                return pacsData.patientLastName + pacsData.patientFirstName + pacsData.patientMiddleName === '';
            };

            /**
             *Regex validation for *,\,?,^ as unsupported character
             */
            var validatePatientNameChar = function (pacsData) {
                return new RegExp('(\\*|\\?|\\\\|\\^)').test(pacsData.patientLastName + pacsData.patientFirstName + pacsData.patientMiddleName);
            };

            /**
             *Regex validation for *,? as unsupported character for PatientId
             */
            var validatePatientIdChar = function (pacsData) {
                return new RegExp('(\\*|\\?|\\\\)').test(pacsData.patientId);
            };
            /**
             * If patient first and last name less than 2 then its an invalid scenario
             */
            var validatePatientNameLength = function (pacsData) {
                return (pacsData.patientLastName + pacsData.patientFirstName).length < 2;
            };

            /**
             *Regex allow only for a-z,A_Z and 0-9 characters
             */
            var validateStudyIdChar = function (pacsData) {
                return new RegExp('(\\*|\\?|\\\\)').test(pacsData.studyId);
            };

            /**
             * Study Id length should be less than or equal to 16 characters.
             */
            var validateStudyIdLength = function (pacsData) {
                return pacsData.studyId.length <= 16;
            };

            /**
             * Patient Id length should be less than or equal to 64 characters.
             */
            var validatePatientIdLength = function (pacsData) {
                return pacsData.patientId.length <= 64;
            };

            /**
             * Validation for Study Id & patient id
             */
            var validatePatientStudyId = function(){
                var isValid = true;
                if ($scope.pacsData.studyId) {
                    if (!validateStudyIdLength($scope.pacsData)) {
                        $scope.setErrorMsg($filter("translate")("pacssearch.studyIdLengthError"));
                        $scope.showPacsSearchError = true;
                        isValid = false;
                    } else if (validateStudyIdChar($scope.pacsData)) {
                        $scope.setErrorMsg($filter("translate")("pacssearch.studyIdError"));
                        $scope.showPacsSearchError = true;
                        isValid = false;
                    }
                }

                if ($scope.pacsData.patientId) {
                    if (!validatePatientIdLength($scope.pacsData)) {
                        $scope.setErrorMsg($filter("translate")("pacssearch.patientIdLengthError"));
                        $scope.showPacsSearchError = true;
                        isValid = false;
                    } else if(validatePatientIdChar($scope.pacsData)) {
                        $scope.setErrorMsg($filter("translate")("pacssearch.patientIdUnsupportedCharError"));
                        $scope.showPacsSearchError = true;
                        isValid = false;
                    }
                }
                return isValid;
            };

            /**
             * Validation for whole pacs search
             */
            $scope.validatePacsSearchData = function () {
                $scope.showDeviceError = false;
                $scope.showPacsSearchError = false;
                var isValid = validatePatientStudyId();

                if (isSearchFieldEmpty($scope.pacsData)) {
                    $scope.setErrorMsg($filter("translate")("pacssearch.atLeastOneFieldError"));
                    $scope.showPacsSearchError = true;
                    isValid = false;
                } else if (!isPatientNameEmpty($scope.pacsData)) {
                    if (validatePatientNameLength($scope.pacsData)) {
                        $scope.setErrorMsg($filter("translate")("pacssearch.twoCharError"));
                        $scope.showPacsSearchError = true;
                        isValid = false;
                    } else if (validatePatientNameChar($scope.pacsData)) {
                        $scope.setErrorMsg($filter("translate")("pacssearch.unsupportedCharError"));
                        $scope.showPacsSearchError = true;
                        isValid = false;
                    }
                }

                if (!$scope.pacsData.dicomDevices || $scope.pacsData.dicomDevices.length === 0) {
                    $scope.showDeviceError = true;
                    isValid = false;
                }

                return isValid;
            };

            /**
             * Function to set the validation error message.
             */
            $scope.setErrorMsg = function (errorMsg) {
                $scope.pacsSearchErrorMsg = errorMsg;
            };

            /**
             * Cancels pacs search and routes to create case
             */
            $scope.cancelPacsSearch = function () {
                if (pacsSearchXHR) {
                    pacsSearchXHR.xhr.abort();
                }

                if(!$scope.disablePatientField){
                    PacsSearchService.clearPacsSearchParams();
                }

                /**
                 * Identify the correct screen to navigate to.
                 * Possible entry points for PACS Search Screen: 1. Create case 2. Add to case
                 * The value will only be present in the case exchange data service in case of Add to case OR Add users.
                 * Hence, checking if the value is set in the service will help identifying the correct screen to navigate to.
                 */
                if (CaseExchangeDataService.getCaseUpdateType() === 'ADDCASE') {
                    $state.transitionTo('caseexchange.updatecase', {id: $stateParams.id});
                } else {
                    $state.transitionTo('caseexchange.createcase', {id: $stateParams.id});
                }

            };

            $scope.open = function (event) {
                event.preventDefault();
                event.stopPropagation();
                $scope.datepicker.opened = true;
            };

            /*
            * Function called on click of radio button
            * The radio button will be selected if it is not selected & vice versa
            */
            $scope.onGenderRadioGroupChange=function(event){
                var selectedValue = event.target.value;

                //If current gender is already selected then deselected it
                if($scope.pacsData.gender === selectedValue){
                    event.target.checked = false;
                    $scope.pacsData.gender = null;
                }
                else{
                    $scope.pacsData.gender = selectedValue;
                }
            };
        }]);
});
