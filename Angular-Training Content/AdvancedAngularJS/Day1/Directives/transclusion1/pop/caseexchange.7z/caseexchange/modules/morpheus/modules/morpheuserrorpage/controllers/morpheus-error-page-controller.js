/*
 *  morpheus-error-page-controller.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * A morpheusErrorPage controller to handle case related operations.
 */
define(['angular', 'postal', '../module'],
    function (ng) {
        'use strict';

        // morpheusErrorPage Controller module
        var morpheus = ng.module('cloudav.caseExchange.morpheusErrorPageCtrl', ['morpheus']);

        // morpheusErrorPage Controller
        morpheus.controller('MorpheusErrorPageCtrl', ['$scope', '$state', '$stateParams', function ($scope, $state, $stateParams) {
        	$scope.type = $stateParams.type;
        }]);

        return morpheus;
    }
);