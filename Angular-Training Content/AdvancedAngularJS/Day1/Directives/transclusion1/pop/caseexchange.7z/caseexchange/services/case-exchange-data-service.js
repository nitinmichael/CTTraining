/*
 *  case-exchange-data-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular'], function () {
    // Module Dependencies
    var dependencies = [];

    // Module Definition
    var mod = angular.module('Services.caseExchangeDataService', dependencies);

    /**
     * @name CaseExchangeDataService
     * @type factory
     *
     * @description
     * A factory/service contains all the getter & setter methods to hold data.
     */
    mod.factory('CaseExchangeDataService', ['$q', function ($q) {

        var ME_URL = '/userregistry/v1/user/me?level.value=2';

        // API gateway URL to be stored retrieved from config file
        var serviceURL = "";

        // Selected case data will be stored
        var selectedCase = {};

        // Case update type will be stored (ADDCASE/ADDUSERS)
        var caseUpdateType = "";

        // Email address of currently logged in user
        var email = "";

        // UOM ID of currently logged in user
        var currentID = "";

        // User object of currently logged in user
        var currentUser;

        // Object to store selected case id
        var selectedCaseData = {};

        /**
         * Sets service url
         * @param url
         */
        function setServiceURL(url) {
            serviceURL = url;
        };

        /**
         * Gets service url
         * @returns serviceURL
         */
        function getServiceURL() {
            return serviceURL;
        };

        /**
         * Sets selected case data
         * @param caseData
         */
        function setSelectedCaseData(caseData) {
            selectedCase = caseData;
        };

        /**
         * Gets selected case data
         * @returns selectedCase
         */
        function getSelectedCaseData() {
            return selectedCase;
        };

        /**
         * Resets selected case data
         */
        function resetSelectedCaseData() {
            selectedCase = {};
        };

        /**
         * Sets case update type (ADDCASE/ADDUSERS)
         * @param type
         */
        function setCaseUpdateType(type) {
            caseUpdateType = type;
        }

        /**
         * Gets case update type
         * @returns caseUpdateType
         */
        function getCaseUpdateType() {
            return caseUpdateType;
        }

        /**
         * Resets case update type
         */
        function resetCaseUpdateType() {
            caseUpdateType = "";
        }

        /**
         * Function to make an API call to get logged in user object
         * @returns Promise object for API call.
         */
        function queryCurrentUser() {
            var deferred = $q.defer();
            $.ajax({
                async: true,
                contentType: 'application/json',
                type: 'get',
                url: serviceURL + ME_URL,
                success: function (data) {
                    return deferred.resolve(data);
                },
                error: function () {
                    console.error('Error retrieving current user\'s information');
                    deferred.reject();
                }
            });
            return deferred.promise;
        }

        /**
         * Retrieves and stores the email address of the current user
         */
        function setCurrentUserEmail(data) {
            var emailFound = false;
            if (data.externalId && data.externalId instanceof Array) {
                for (var idlength = data.externalId.length, i = 0; i < idlength; i++) {
                    var current = data.externalId[i];
                    if (current._id) {
                        emailFound = true;
                        email = current._id;
                        break;
                    }
                }
            }
            if (!emailFound) {
                console.error('Current user\'s email address not found');
            }
        }

        /**
         * Returns the email address of the current user
         * @returns email address
         */
        function getCurrentUserEmail() {
            return email;
        }

        /**
         * @ngdoc function
         * @name setCurrentUserID
         * @description Sets current user's UOM ID
         * @param {object} user object
         */
        function setCurrentUserID(data) {
            if (data.externalId && data.externalId instanceof Array) {
                for (var i = 0; i < data.externalId.length; i++) {
                    var curr = data.externalId[i];
                    if (curr.system === "UOM") {
                        currentID = curr.value;
                        break;
                    }
                }
            }
        }

        /**
         * @ngdoc function
         * @name getCurrentUserID
         * @description Returns the UOM ID of the current user
         * @returns {string} user ID
         */
        function getCurrentUserID() {
            return currentID;
        }

        /**
         * Converts to date object from the string date format "yyyy.MM.dd"
         * @param:
         * date: Date string in "yyyy.MM.dd" format
         */
        var convertToDate = function (date) {
            var formattedDate = date && (date.indexOf('.') > -1) ? date.replace(/\./g, '') : date;

            if (formattedDate) {
                var year = formattedDate.substring(0, 4);
                var month = formattedDate.substring(4, 6);
                var day = formattedDate.substring(6, 8);
                if (year && month && day) {
                    var newDate = new Date(month + '/' + day + '/' + year);
                }
            }
            return newDate;
        };

        /**
         * Converts date into UTC date and returns it in milliseconds
         * @param date date string in "yyyy.MM.dd" or "yyyymmdd" format
         * @returns {Number|number}
         */
        var convertDateToUTC = function (date) {
            var formattedDate = date && (String(date).indexOf('.') > -1) ? date.replace(/\./g, '') : date;
            if (formattedDate.length === 8) {
                var year = formattedDate.slice(0, 4),
                // UTC allows months from 0-11, thus month - 1
                    month = Number(formattedDate.slice(4, 6)) - 1,
                    day = formattedDate.slice(6, 8);
                return Date.UTC(year, month, day);
            } else {
                return formattedDate;
            }
        };

        /**
         * Calculates patient's Age from patient's Date of Birth
         * @param:
         * patientDob: Patient's DOB
         */
        var calculatePatientAge = function (patientDob) {
            var currentDate = new Date();
            var utcCurrentDate = new Date(Date.UTC(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate(), currentDate.getHours(), currentDate.getMinutes()));
            var DOB = new Date(patientDob);

            var month = DOB.getMonth();
            var years = utcCurrentDate.getFullYear() - DOB.getFullYear();

            DOB.setFullYear(DOB.getFullYear() + years);

            if (DOB.getMonth() !== month) {
                DOB.setDate(0);
            }

            return DOB > utcCurrentDate ? --years : years;
        };

        /**
         * Retrieves the cached user object.
         * @returns Current user object
         */
        function getCurrentUser() {
            return currentUser;
        }

        /**
         * Cache the user object to the factory for re-usability.
         * @param data: User object
         */
        function setCurrentUser(data) {
            if (data) {
                currentUser = data;
                setCurrentUserEmail(currentUser);
                setCurrentUserID(currentUser);
                currentUser.isPatient = function () {
                    var isPatient = false;
                    if (this.role && this.role.length > 0) {
                        for (var i = 0, iEnd = this.role.length; i < iEnd; i++) {
                            isPatient = hasPatientRole(this.role[i]);
                            if (isPatient) {
                                break;
                            }
                        }
                    }
                    return isPatient;
                };
                currentUser.isAdmin = function () {
                    var isAdmin = false;
                    if (!this.role || this.role.length === 0) {
                        return isAdmin;
                    }
                    for (var i = 0, iEnd = this.role.length; i < iEnd; i++) {
                        isAdmin = hasAdminRole(this.role[i]);
                        if (isAdmin) {
                            break;
                        }
                    }
                    return isAdmin;
                };
            }

            /**
             * Loop through the role codes and identifies if current user is patient.
             * @param role: Current role object
             * @returns boolean: True if user has patient role, else false.
             */
            function hasPatientRole(role) {
                var hasPatientRole = false;
                if (role.code) {
                    for (var c = 0, cEnd = role.code.length; c < cEnd; c++) {
                        if (role.code[c].code === 'patient') {
                            hasPatientRole = true;
                            break;
                        }
                    }
                }
                return hasPatientRole;
            };

            /**
             * Loop through the role codes and identifies if current user is Admin.
             * @param role: Current role object
             * @returns boolean: True if user has Admin role, else false.
             */
            function hasAdminRole(role) {
                var hasAdminRole = false;
                if (role.code) {
                    for (var c = 0, cEnd = role.code.length; c < cEnd; c++) {
                        if (role.code[c].code === 'administrator') {
                            hasAdminRole = true;
                            break;
                        }
                    }
                }
                return hasAdminRole;
            };
        }

        /**
         * Sets selected case details
         * @param id
         * @param position
         * @param searchText
         * @param caseTransactionCount
         */
        var setSelectedCaseDetails = function (id, position, searchText, caseTransactionCount) {
            selectedCaseData = {
                id: id || null,
                scrollPosition: position || null,
                searchText: searchText || null,
                caseTransactionCount: caseTransactionCount
            };
        };

        /**
         * Returns selected case details
         * @returns {{}}
         */
        var getSelectedCaseDetails = function () {
            return selectedCaseData;
        };

        /**
         * Resets selected case details
         */
        var resetSelectedCaseDetails = function () {
            selectedCaseData = {};
        };

        return {
            setServiceURL: setServiceURL,
            getServiceURL: getServiceURL,
            setSelectedCaseData: setSelectedCaseData,
            getSelectedCaseData: getSelectedCaseData,
            resetSelectedCaseData: resetSelectedCaseData,
            setCaseUpdateType: setCaseUpdateType,
            getCaseUpdateType: getCaseUpdateType,
            resetCaseUpdateType: resetCaseUpdateType,
            convertToDate: convertToDate,
            calculatePatientAge: calculatePatientAge,
            setCurrentUserEmail: setCurrentUserEmail,
            getCurrentUserEmail: getCurrentUserEmail,
            getCurrentUser: getCurrentUser,
            setCurrentUser: setCurrentUser,
            queryCurrentUser: queryCurrentUser,
            setSelectedCaseDetails: setSelectedCaseDetails,
            getSelectedCaseDetails: getSelectedCaseDetails,
            resetSelectedCaseDetails: resetSelectedCaseDetails,
            getCurrentUserID: getCurrentUserID,
            convertDateToUTC: convertDateToUTC
        };

    }]);
});
