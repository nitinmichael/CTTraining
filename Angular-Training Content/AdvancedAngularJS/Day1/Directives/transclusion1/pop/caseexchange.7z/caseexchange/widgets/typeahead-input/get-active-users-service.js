/***************************************************************************************************
 *
 * get-active-users-service.js
 *
 * Copyright (c) 2015 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * A factory that provides a method to gets an array of users from the server.
 *
 * @author
 * Monique Shotande <moniqueshotande@ge.com>
 *
 ***************************************************************************************************/
define(['angular'], function() {

  // Module Dependencies
  var dependencies = [];

  // Module Definition
  var mod = angular.module('Services.GetActiveUsers', dependencies);

  /**
   * @name getActiveUsers
   * @type factory
   *
   * @description
   * A factory that provides a method to gets an array of users from the server.
   */
  mod.factory('GetActiveUsersService', ['$q', '$log', function($q, $log) {
    /**
     * Public API
     */
    return {
      // GET
      getUsers: getUsers
    };

    /**
     * Gets an array of users from the server.
     *
     * @param email
     *    The email of the user to retrieve.
     *
     * @param usersURL
     *    The base url for requests to the Users REST API.
     *
     * @return
     *    A promise that will be resolved/rejected once a response is received.
     */
    function getUsers(usersURL, email) {
      var deferred = $q.defer();

        $.ajax({
            async: true,
            contentType: 'application/json',
            dataType:'json',
            data: {firstname: email + '~#OR', lastname: email + '~#OR', email: email},
            type: 'get',
            url: usersURL,
            success: success,
            error: error
        });

      return deferred.promise;

      function success(data) {
        $log.log('Success: getActiveUsers: GET "' + usersURL + '"');
        var users = data || { data: [], next: 0, offset: 0, total: 0 };
		deferred.resolve(users);
      }

      function error(jqXHR, textStatus, errorThrown) {
        var errorMsg = 'Error: getActiveUsers: GET "' + usersURL + '" (failed): ' + errorThrown;
        $log.error(errorMsg + '\njqXHR: \n' + jqXHR.responseText + '\ntextStatus: ' + textStatus);
        deferred.reject(errorMsg);
      }

    }
  }]);
});
