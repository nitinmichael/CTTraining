/***************************************************************************************************
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * Provides a directive for creating a Bootstrap 2.3.2 control-group that wraps around an input
 * and provides validation for said input.
 *
 * @author
 * Eric Steele <eric.steele@ge.com>
 *
 ***************************************************************************************************/
define(['angular'
    , '../ge-form-submitted/ge-form-submitted-directive'
    // TODO: Check if still required and in use. If not, remove the same.
    //, '../../3rdparty/angular-ui-utils/ui-utils'
], function () {

    // Module Dependencies
    var dependencies = [
        // vendor
        // TODO: Check if still required and in use. If not, remove the same.
        //'ui.utils',
        // app
        'Directives.geFormSubmitted'
    ];

    // Module Definition
    var mod = angular.module('Directives.geControlGroup', dependencies);

    // Handles error expressions
    function handleErrorExpression(scope, isInvalid, isDirty, isSubmitted) {
        var errorExpression;

        if(scope.errorOnSubmit === true && scope.errorOnDirty === true) {
            errorExpression = isInvalid + ' && (' + isDirty + ' || ' + isSubmitted + ')';
        } else if(scope.errorOnDirty === true) {
            errorExpression = isInvalid + ' && ' + isDirty;
        } else if(scope.errorOnSubmit === true) {
            errorExpression = isInvalid + ' && ' + isSubmitted;
        }

        return errorExpression;
    };

    // Handles success expressions
    function handleSuccessExpression(scope, isValid, isDirty, isSubmitted) {
        var successExpression;

        if(scope.successOnSubmit === true && scope.successOnDirty === true) {
            successExpression = isValid + ' && (' + isDirty + ' || ' + isSubmitted + ')';
        } else if(scope.successOnDirty === true) {
            successExpression = isValid + ' && ' + isDirty;
        } else if(scope.successOnSubmit === true) {
            successExpression = isValid + ' && ' + isSubmitted;
        }

        return successExpression;
    };

    /**
     * @name geControlGroup
     * @type directive
     * @element DIV within a FORM or ngForm
     *
     * @param {label} text content to be inserted into the control group's `<label>`
     * @param {errorOnDirty}    show validation error when invalid AND dirty
     * @param {errorOnSubmit}   show validation error when invalid AND form has been submitted
     * @param {successOnDirty}  show validation success when valid AND dirty
     * @param {successOnSubmit} show validation success when valid AND form has been submitted
     *
     * @description
     * When applied to a `<div>` that contains an `<input>`, this directive adds the `.control-group`
     * class to the `<div>` and adds a `<label>` for the `<input>` based on its `id` attribute. If the
     * `<input>` has the `required` attribute, the directive will add validation to the `<input>` to
     * ensure that the user has provided a value. In order for the validation to be applied on when
     * the `<form>` is submitted, the `<form>` must be using the `geFormSubmitted` directive.
     *
     * @example
     * <ge-control-group label='Example Field' error-on-dirty="true" success-on-dirty="true">
     *   <input control-group
     *          id       ='example'
     *          name     ='example'
     *          type     ='text'
     *          ng-model ='formData.example'
     *          required>
     * </ge-control-group>
     *
     */
    mod.directive('geControlGroup', function() {
        return {
            /**
             * Use the restrict option to specify how this directive can be applied to HTML elements.
             *  'A' = Attribute (e.g. <div my-directive>)
             *  'C' = Class     (e.g. <div class='my-directive'>)
             *  'E' = Element   (e.g. <my-directive>)
             *  'M' = Comment   (e.g. <!-- directive: my-directive -->)
             */
            restrict: 'E',
            /**
             * Use the replace option to replace the matched element completely with its template. The replacement
             * process migrates all of the attributes/classes from the old element to the new one.
             */
            replace: true,
            /**
             * Use the templateUrl option to specify the directive element's content.
             */
            templateUrl: function(elem, attrs) {
                var path = '';
                if(angular.isDefined(attrs.horizontalControls)){
                    path = 'modules/caseexchange/widgets/ge-control-group/ge-control-group-horizontal.html';
                } else {
                    path = attrs.nestedInput ? 'modules/caseexchange/widgets/ge-control-group/ge-control-group-nested-input.html'
                            : 'modules/caseexchange/widgets/ge-control-group/ge-control-group.html';
                }
                return path;
            },
            /**
             * Use the transclude option to have the existing content of the directive's element included in its
             * template. The transcluded content will be inserted into the template within the element marked with
             * the `ng-transclude` directive.
             */
            transclude: true,
            /**
             * Use the require option to have a controller injected into the link function as an additional argument.
             * Prefix this option's value with '^' if the controller belongs to a parent element. If the '^' prefix
             * is not included, the directive will look for the controller on its own element.
             */
            require: '^form',
            /**
             * Use the scope option to isolate this directive's scope from its parent's scope, allowing only the
             * specified data to be accessible within this directive's scope. This data is passed to the directive
             * via HTML element attributes.
             *
             *  '@' = Text binding    (data is a string; can use {{ }} syntax to evaluate expressions)
             *  '&' = One-way binding (data is a function; changes to data in the directive do not affect the parent)
             *  '=' = Two-way binding (data is of any type; changes to data in the directive affect the parent)
             */
            scope: {
                label:           '@',
                tooltipMsg:      '@',
                errorOnSubmit:   '=',
                errorOnDirty:    '=',
                successOnDirty:  '=',
                successOnSubmit: '=',
                hideValidation:  '='
            },
            /**
             * Use the link function to make changes to the directive's HTML after the directive's
             * scope has been attached to it. Normally, this function is used for registering DOM
             * listeners (i.e., $watch expressions on the scope) as well as updating the DOM.
             *
             * @param scope - the directive's scope object.
             * @param element - the jqLite-wrapped element that this directive matches.
             * @param attrs - the matched element's attributes and their corresponding values.
             */
            link: function (scope, element, attrs, formCtrl) {
                // The <label> should have a 'for' attribute that links it to the input.
                // Get the 'id' attribute from the input element and add it to the scope
                // so our template can access it.
                var $input = $(element).find(':input:not([ge-ignore])');

                scope.for  = $input.attr('id');

                // Show error styling when field is invalid
                var inputName = $input.attr('name');
                if(inputName) {
                    // Build the scope expression that contains the validation status
                    var isValid      = [formCtrl.$name, inputName, '$valid'].join('.'),
                        isInvalid    = [formCtrl.$name, inputName, '$invalid'].join('.'),
                        isDirty      = [formCtrl.$name, inputName, '$dirty'].join('.'),
                        isSubmitted  = [formCtrl.$name, '$submitted'].join('.');

                    // Handles error expressions
                    var errorExpression = handleErrorExpression(scope, isInvalid, isDirty, isSubmitted);

                    // Handles success expressions
                    var successExpression = handleSuccessExpression(scope, isValid, isDirty, isSubmitted);

                    // Figure out which scope to watch
                    // Note: We watch a parent scope, because current scope is isolated.
                    var scopeToWatch = scope.$parent;
                    while(scopeToWatch.hasOwnProperty(formCtrl.$name) === false) {
                        scopeToWatch = scopeToWatch.$parent;
                    }

                    // Watch for errors if needed
                    if(errorExpression) {
                        scopeToWatch.$watch(errorExpression, function(isError) {
                            scope.isError = isError;
                        });
                    }
                    // Watch for success if needed
                    if(successExpression) {
                        scopeToWatch.$watch(successExpression, function(isSuccess) {
                            scope.isSuccess = isSuccess;
                        });
                    }
                }
            }
        };
    });
});
