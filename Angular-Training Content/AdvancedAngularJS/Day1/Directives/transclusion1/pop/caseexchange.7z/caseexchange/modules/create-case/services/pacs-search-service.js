/*
 *  pacs-search-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular'], function () {

    // Module Dependencies
    var dependencies = ['Services.caseExchangeDataService'];

    // Module Definition
    var mod = angular.module('Services.pacsSearchService', dependencies);

    /**
     * @name PacsSearchService
     * @type factory
     *
     * @description
     * A factory that provides methods for making request to the Pacs Search REST API to post the data.
     */
    mod.factory('PacsSearchService', ['CaseExchangeDataService', '$q', '$log', function (caseExchangeDataService, $q, $log) {
        /**
         * Base url for making request to the Pacs Search REST API.
         */

        var PACS_SEARCH_DATA, PACS_SEARCH_PARAMS;

        // Function to retrieve Pacs Device Data
        function pacsSearch(data){

            var PACS_SEARCH_URL = caseExchangeDataService.getServiceURL() + '/patientstudyquery/v1/patient/search';

            // validate arguments
            if(!angular.isObject(data)) {
                var errorMsg = 'Error: PacsSearchService: invalid parameter: data = ' + data;
                $log.error(errorMsg);
                return $q.reject(errorMsg);
            }

            var deferred = $q.defer();
            //timeout of 60 seconds for each devices
            var timeout=60;
            if (data.deviceList) {
                timeout = data.deviceList.length*timeout*1000;
            }

            // send the request
            var xhr = $.ajax({
                async: true,
                contentType: 'application/json',
                type: 'post',
                url: PACS_SEARCH_URL,
                data: JSON.stringify(data),
                success: success,
                error: error,
                timeout:timeout
            });

            return { xhr: xhr, promise: deferred.promise };

            //success Callback functionality
            function success(data) {
                $log.log('Success: PacsSearchService: pacsSearch');
                var response = data || null;
                deferred.resolve(response);
            }

            //Error Callback functionality
            function error(jqXHR, textStatus, errorThrown) {
                var errorMsg = 'Error: PacsSearchService: pacsSearch: ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }
        }

        //Function to get Pacs search Data
        function getPacsSearchResultData() {
            return PACS_SEARCH_DATA;
        }

        //Function to set Pacs Search Data
        function setPacsSearchResultData(patients) {
            PACS_SEARCH_DATA=patients;
        }

        //Function to set Pacs Search CRITERIA
        function setPacsSearchParams(searchParams) {
            PACS_SEARCH_PARAMS = searchParams;
        }

        //Function to get Pacs Search CRITERIA
        function getPacsSearchParams() {
            return PACS_SEARCH_PARAMS;
        }

        //Function to clear Pacs Search CRITERIA
        function clearPacsSearchParams() {
            PACS_SEARCH_PARAMS = "";
        }

        return {
            pacsSearch         :         pacsSearch,
            getPacsSearchResultData  :   getPacsSearchResultData,
            setPacsSearchResultData  :   setPacsSearchResultData,
            getPacsSearchParams : getPacsSearchParams,
            setPacsSearchParams : setPacsSearchParams,
            clearPacsSearchParams : clearPacsSearchParams
        };
    }]);
});