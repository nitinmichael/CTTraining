/*
 *  module.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * A module config file to load case inbox as a default module for case exchange.
 */
define(
    ['angular', 'postal', 'uiRouter', './widgets/ge-xss/ge-xss-directive',
        './controllers/case-exchange-controller',
        './services/case-exchange-data-service',
        './services/get-pacs-service',
        './services/get-sites-service',
        './services/get-clinical-reasons-service',
        './filters/name-filter',
        './modules/case-inbox/controllers/case-inbox-controller',
        './modules/case-inbox/controllers/normalization-controller',
        './modules/create-case/controllers/create-case-controller',
        './modules/create-case/controllers/pacs-search-controller',
        './modules/create-case/controllers/pacs-patient-list-controller',
        './modules/case-inbox/controllers/download-to-premise-controller',
        './modules/case-automation/services/case-automation-service',
        './modules/case-automation/services/case-automation-data-service',
        './modules/case-automation/services/instruction-condition-marshaller-service',
        './modules/case-automation/services/create-instruction-marshaller-service',
        './modules/case-automation/services/get-instruction-conditions-service',
        './modules/case-automation/controllers/case-automation-controller',
        './modules/case-automation/controllers/create-instruction-controller',
        './modules/morpheus/controllers/morpheus-controller',
        './modules/morpheus/modules/admindashboard/controllers/morpheus-admin-controller',
        './modules/morpheus/modules/userdashboard/controllers/morpheus-user-controller',
        './modules/morpheus/modules/analytics/controllers/analytics-dashboard-controller',
        './modules/morpheus/modules/morpheuserrorpage/controllers/morpheus-error-page-controller',
		'./modules/case-automation/services/post-processing-condition-marshaller-service'
    ],
    function (ng) {
        'use strict';

        // Case Exchange module
        var caseexchange = ng.module('cloudav.caseExchange',
            ['uaf.appshell', 'ui.router',
                'cloudav.caseExchange.caseExchangeCtrl',
                'Services.caseExchangeDataService',
                'Filters.name',
                'cloudav.caseExchange.caseInbox',
                'cloudav.caseExchange.caseInboxCtrl',
                'cloudav.caseExchange.caseInbox.normalizationCtrl',
                'cloudav.caseExchange.caseInbox.downloadToPremiseCtrl',
                'cloudav.caseExchange.createCaseCtrl',
                'cloudav.caseExchange.createCase.pacsSearchCtrl',
                'cloudav.caseExchange.createCase.pacsPatientListCtrl',
                'cloudav.caseExchange.caseAutomationCtrl',
                'cloudav.caseExchange.createInstructionCtrl',
                'cloudav.caseExchange.morpheusCtrl',
                'cloudav.caseExchange.morpheusAdminCtrl',
                'cloudav.caseExchange.morpheusUserCtrl',
                'cloudav.caseExchange.analyticsDashboardCtrl',
                'cloudav.caseExchange.morpheusErrorPageCtrl',
                'Directives.geXss']);

        // Register externalized strings for all the sub modules of case exchange.
        caseexchange
            .config([
                '$translatePartialLoaderProvider',
                function ($translatePartialLoaderProvider) {
                    $translatePartialLoaderProvider
                        .addPart('./modules/caseexchange/modules/case-inbox/i18n')
                        .addPart('./modules/caseexchange/modules/create-case/i18n')
                        .addPart('./modules/caseexchange/modules/case-automation/i18n')
						.addPart('./modules/caseexchange/modules/morpheus/i18n');
                }]);

        // Register Case Exchange module with the application shell
        caseexchange
            .config(['uaf.appshell.AppConfigProvider', function (AppConfigProvider) {
                // After all modules are loaded, every apps register
                // themselves with the shell by using the shell's
                // appConfigProvider
                AppConfigProvider
                    .addAppDescriptor({
                        // the title "caseexchange" is used as a key for i18n
                        title: "caseexchange",
                        // the name "caseinbox" is used as the json
                        // object name in the i18n files
                        name: "caseexchange",
                        templateUrl: "./modules/caseexchange/views/case-exchange.html",
                        controller: "CaseExchangeCtrl",
                        href: "/caseexchange",
                        autoStart: "true",
                        // This will postponed any child module initialization until "apiGatewayURL" is available.
                        resolve: {
                            apiGateWayURL: ['$Endpoint','CaseExchangeDataService', function ($Endpoint, CaseExchangeDataService) {
                                // Set the API Gateway URL through factory.
                                return $Endpoint.getEndpointAsync('apiGatewayUrl').then(function (value) {
                                    CaseExchangeDataService.setServiceURL(value);
                                    return value;
                                });
                            }]
                        }

                    });
            }]);

        // Angular router configuration to provide routes for case inbox and create case
        caseexchange
            .config(['$stateProvider', function ($stateProvider) {
                $stateProvider
                    .state('caseexchange.createcase', {
                        params: {
                            mode: 'CREATE',
                            redirectTo: 'caseexchange.caseinbox',
                            billingOrganizationList: []
                        },
                        url: '/createcase',
                        templateUrl: './modules/caseexchange/modules/create-case/views/create-case.html',
                        controller: 'CreateCaseCtrl',
                        onEnter: ['CaseExchangeDataService', '$state', '$stateParams', '$timeout', function (CaseExchangeDataService, $state, $stateParams, $timeout) {
                            checkAccess(CaseExchangeDataService, $state, $stateParams, $timeout, false);
                        }]
                    })
                    .state('caseexchange.updatecase', {
                        params: {
                            mode: 'UPDATE',
                            redirectTo: 'caseexchange.caseinbox'
                        },
                        url: '/updatecase',
                        templateUrl: './modules/caseexchange/modules/create-case/views/create-case.html',
                        controller: 'CreateCaseCtrl',
                        onEnter: ['CaseExchangeDataService', '$state', '$stateParams', '$timeout', function (CaseExchangeDataService, $state, $stateParams, $timeout) {
                            checkAccess(CaseExchangeDataService, $state, $stateParams, $timeout, false);
                        }]
                    })
                    .state('caseexchange.caseinbox', {
                        url: '/caseinbox',
                        params: {
                            selectedCaseId: null,
                            resetSelectedCase: false
                        },
                        templateUrl: './modules/caseexchange/modules/case-inbox/views/case-inbox.html',
                        controller: 'CaseInboxCtrl'
                    })
                    .state('caseexchange.pacsquery', {
                        url: '/pacsquery',
                        templateUrl: './modules/caseexchange/modules/create-case/views/pacs-search.html',
                        controller: 'PacsSearchCtrl',
                        onEnter: ['CaseExchangeDataService', '$state', '$stateParams', '$timeout', function (CaseExchangeDataService, $state, $stateParams, $timeout) {
                            checkAccess(CaseExchangeDataService, $state, $stateParams, $timeout, true);
                        }]
                    })
                    .state('caseexchange.pacspatientlist', {
                        params: {
                            pacsSearchData: {}
                        },
                        url: '/pacspatientlist',
                        templateUrl: './modules/caseexchange/modules/create-case/views/patient-list.html',
                        controller: 'PacsPatientListCtrl',
                        onEnter: ['CaseExchangeDataService', '$state', '$stateParams', '$timeout', function (CaseExchangeDataService, $state, $stateParams, $timeout) {
                            checkAccess(CaseExchangeDataService, $state, $stateParams, $timeout, true);
                        }]
                    })
                    .state('caseexchange.caseinbox.normalization', {
                        title: 'Normalization',
                        name: 'normalization',
                        templateUrl: './modules/caseexchange/modules/case-inbox/views/normalization.html',
                        controller: 'NormalizationCtrl',
                        onEnter: ['CaseExchangeDataService', '$state', '$stateParams', '$timeout', function (CaseExchangeDataService, $state, $stateParams, $timeout) {
                            checkAccess(CaseExchangeDataService, $state, $stateParams, $timeout, false);
                        }]
                    })
                    .state('caseexchange.caseinbox.downloadToPremise', {
                        title: 'Download To Premise',
                        name: 'downloadToPremise',
                        templateUrl: './modules/caseexchange/modules/case-inbox/views/download-to-premise.html',
                        controller: 'DownloadToPremiseCtrl',
                        onEnter: ['CaseExchangeDataService', '$state', '$stateParams', '$timeout', function (CaseExchangeDataService, $state, $stateParams, $timeout) {
                            checkAccess(CaseExchangeDataService, $state, $stateParams, $timeout, false);
                        }]
                    })
                    .state('caseexchange.caseautomation', {
                        params: {
                            selectedSite: {}
                        },
                        url: '/caseautomation',
                        templateUrl: 'modules/caseexchange/modules/case-automation/views/case-automation-list.html',
                        controller: 'CaseAutomationCtrl',
                        onEnter: ['CaseExchangeDataService', '$state', '$stateParams', '$timeout', function (CaseExchangeDataService, $state, $stateParams, $timeout) {
                            checkAccess(CaseExchangeDataService, $state, $stateParams, $timeout, false);
                        }]
                    })
                    .state('caseexchange.createinstruction', {
                        params: {
                            mode: 'AUTOCREATE'
                        },
                        url: '/createinstruction',
                        templateUrl: 'modules/caseexchange/modules/case-automation/views/case-creation-instruction.html',
                        controller: 'CreateInstructionCtrl',
                        onEnter: ['CaseExchangeDataService', '$state', '$stateParams', '$timeout', function (CaseExchangeDataService, $state, $stateParams, $timeout) {
                            checkAccess(CaseExchangeDataService, $state, $stateParams, $timeout, false);
                        }]
                    })
                    .state('caseexchange.morpheus', {
                        url: '/insights',
                        params:{loadType:null},
                        templateUrl: './modules/caseexchange/modules/morpheus/views/morpheus.html',
                        controller: 'MorpheusCtrl'
                    })
                    .state('caseexchange.morpheus.morpheusUser', {
                        url: '',
                        templateUrl: './modules/caseexchange/modules/morpheus/modules/userdashboard/views/morpheusUser.html',
                        controller: 'MorpheusUserCtrl'
                    })
                    .state('caseexchange.morpheus.morpheusAdmin', {
                        url: '',
                        templateUrl: './modules/caseexchange/modules/morpheus/modules/admindashboard/views/morpheusAdmin.html',
                        controller: 'MorpheusAdminCtrl'
                    })
                    .state('caseexchange.morpheus.errorPage', {
                        url: '/error',
                        params:{type:null},
                        templateUrl: './modules/caseexchange/modules/morpheus/modules/morpheuserrorpage/views/morpheusErrorPage.html',
                        controller: 'MorpheusErrorPageCtrl'
                    })
                    .state('caseexchange.analytics', {
                        url: '/analytics',
                        templateUrl: './modules/caseexchange/modules/morpheus/modules/analytics/views/analytics-dashboard.html',
                        controller: 'analyticsDashboardCtrl'
                    });;

                /**
                 * Function to check user access rights
                 * @param CaseExchangeDataService: Factory object of CaseExchangeDataService
                 * @param $state: Object of UI Router State
                 * @param $stateParams: State parameters
                 * @param $timeout: AngularJS timeout utility object
                 * @param checkPatientRole: Boolean flag which indicate if patient role check needs to be executed or not.
                 */
                function checkAccess(CaseExchangeDataService, $state, $stateParams, $timeout, checkPatientRole) {
                    var currentUser = CaseExchangeDataService.getCurrentUser();

                    /**
                     * Checks if current user information is available and user has at-least one role present
                     */
                    if (!currentUser || !currentUser.role || currentUser.role.length === 0) {
                        navigateToHome();
                    }

                    /**
                     * Check if current user is Patient.
                     * By default, if there is a service call on page, it will automatically will redirect it to /home as without current user token service will return 401
                     * But, still added some preventive check as relying on service call & waiting to get 401 might not be a good idea.
                     */
                    if (checkPatientRole && CaseExchangeDataService.getCurrentUser().isPatient()) {
                        navigateToHome();
                    }

                    /**
                     * Function to navigate to home page of case exchange
                     */
                    function navigateToHome() {
                        /**
                         * Since UI-Router state transition is in progress and we are trying to attempt another state transition,
                         * it will throw the error.(Refer to the UI-Router bug: https://github.com/angular-ui/ui-router/issues/1434)
                         * Hence, wrapping it to $timeout as a workaround solution.
                         */
                        $timeout(function () {
                            $state.transitionTo('caseexchange.caseinbox', {id: $stateParams.id});
                        }, 100);
                    }

                }


            }]);

        /**
         * Handles State change start event/mode to reset last selected case
         */
        caseexchange
            .run(['$rootScope', '$state', 'CaseExchangeDataService', function ($rootScope, $state, CaseExchangeDataService) {
                $rootScope.$on('$stateChangeStart',
                    function (event, toState, toParams, fromState) {
                        //TODO:: We need to add state(s) in caseRelatedStates array if the state/feature/functionality will be based on the existing case
                        var caseRelatedStates = ['caseexchange.updatecase', 'caseexchange.pacsquery', 'caseexchange.pacspatientlist', 'caseexchange.caseinbox.normalization',
                            'caseexchange.caseinbox.downloadToPremise', 'viewer.start', 'virtualViewer', 'mdt-session.send-to-mdt'];
                        var found = false;
                        if (toState.name === 'caseexchange.caseinbox') {
                            for (var i = 0; i < caseRelatedStates.length; i++) {
                                if (fromState.name === caseRelatedStates[i] && CaseExchangeDataService.getSelectedCaseDetails().id) {
                                    found = true;
                                }
                            }
                            if (!found) {
                                CaseExchangeDataService.resetSelectedCaseDetails();
                            }
                        }
                    }
                );
            }]
        );

        return caseexchange;
    });