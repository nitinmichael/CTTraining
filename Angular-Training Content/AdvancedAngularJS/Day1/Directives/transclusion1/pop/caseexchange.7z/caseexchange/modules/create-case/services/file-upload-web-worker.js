/***************************************************************************************************
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * Web workers implementation for file upload.
 *
 * @author
 * Jignesh Parekh <jignesh.parekh@ge.com>
 ***************************************************************************************************/
/**
 * ##################################################################################################
 * This is a Web Worker implementation file.
 * Since, web workers don't understand AngularJS or jQuery, it's a plain JavaScript implementation.
 * Also, it's not wrapped under the RequireJS as this will be a "load on demand" through JavaScript.
 * ##################################################################################################
 */

/*
 * This method will be called every time main thread tries to communicates to web wrokers
 * Every time main thread send any message, "onmessage" method will be called.
 * The object "self" here represents the web worker instance.
 */
'use strict';

var BOUNDARY_DELIMITER = "--";
var CARRIAGE_RETURN = "\r\n";

self.onmessage = function (event) {
    /*
     * The method to send the files as a chunks of bytes.
     * "event.data" here will represents the actual data passed from main UI thread
     */

    if (event.data.command === "addFilesToUploadPool") {
        buildMultiPartRequest(event.data.blobServiceUrl, event.data.caseId, event.data.metaPart, event.data.filePartList, event.data.boundary, event.data.securityToken);
    }
};

function buildMultiPartRequest(blobServiceUrl, caseId, metaPart, filePartList, boundary, securityToken) {
    var postBody = new Blob( [buildMetaPart(BOUNDARY_DELIMITER + boundary, metaPart), buildFilePart(BOUNDARY_DELIMITER + boundary, filePartList)] );
    var xhr = new XMLHttpRequest();
    xhr.open('POST', blobServiceUrl + "/" + caseId, true);
    xhr.setRequestHeader('Content-type', 'multipart/related; boundary="' + boundary + '"; type="Application/Json"');
    var token = JSON.parse(securityToken);
    token = token.token_type + ' ' + token.access_token;
    xhr.setRequestHeader('Authorization', token);
    xhr.send(postBody);

    xhr.onreadystatechange = function() {
        if (this.readyState === 4) {
            var message = {
                status: '',
                statusCode: this.status,
                msg: xhr.statusText,
                responseText: this.responseText
            };
            if (this.status === 200) {
                message.status = "SUCCESS";
            }
            else if (this.status === 202) {
                message.status = "SUCCESS";
            }
            else if (this.status === 400) {
                message.status = "ERROR";
            }
            else if (this.status === 409) {
                message.status = "ERROR";
            }
            else {
                message.status = "ERROR";
            }

            self.postMessage(message);
        }
    };
}

/**
 *
 * @param boundary
 * @param metaPart
 * {
 *     contentType : "",
 *     contentId : "",
 *     contentLocation : "",
 *     metaContent : ""
 * }
 */
function buildMetaPart(boundary, metaPart) {
    var result = "";

    result += (CARRIAGE_RETURN + boundary + CARRIAGE_RETURN);
    result += buildMetaPartHeader("application/json");
    var metadata = {};
    metadata.metadata = metaPart;
    result += buildMetaPartBody(metadata);

    return result;
}

/**
 *
 * @param boundary
 * @param filePartList
 * [
 *  {
 *      contentType : "",
 *      contentLocation : "",
 *      fileContent : ""
 *  },
 *  ...
 * ]
 */
function buildFilePart(boundary, filePartList) {
    var result = new Blob();

    if (filePartList.length > 0) {
        for (var i = 0; i < filePartList.length; i++) {
            var filePart = filePartList[i];
            result = new Blob( [ result,
                                 (boundary + CARRIAGE_RETURN),
                                 buildFilePartHeader(filePart.contentType, filePart.contentLocation, filePart.contentLength),
                                 buildFilePartBody(filePart.fileContent) ] );
        }
        result = new Blob( [ result, (boundary + BOUNDARY_DELIMITER + CARRIAGE_RETURN) ] );
    }
    return result;
}

function buildMetaPartHeader(contentType) {
    return "Content-Type:" + contentType;
}

function buildMetaPartBody(metaContent) {
    return CARRIAGE_RETURN + CARRIAGE_RETURN + JSON.stringify(metaContent) + CARRIAGE_RETURN + CARRIAGE_RETURN;
}

function buildFilePartHeader(contentType, contentLocation, contentLength) {
    return "Content-Type:" + contentType + CARRIAGE_RETURN +
        "Content-Location:" + contentLocation + CARRIAGE_RETURN +
            "Content-Length:" + contentLength;
}

function buildFilePartBody(fileContent) {
    return new Blob( [CARRIAGE_RETURN, CARRIAGE_RETURN, fileContent, CARRIAGE_RETURN] );
}