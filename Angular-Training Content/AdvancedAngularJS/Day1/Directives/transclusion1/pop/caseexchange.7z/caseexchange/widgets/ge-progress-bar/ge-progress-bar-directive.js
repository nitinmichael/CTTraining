/***************************************************************************************************
 *
 * ge-progress-bar-directive.js
 *
 * Copyright (c) 2015 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * Provides progress bar functionality
 *
 ***************************************************************************************************/

define(['angular'],function(){

    // Module Definition
    var mod=angular.module('Directive.geProgressBar',[]);

    /**
     * A directive for displaying progress bar.
     * @example
     * <ge-progress-bar percentage="progressPercentage"></ge-progress-bar>
     */
    mod.directive('geProgressBar',function(){

        return{
            restrict:'E',
            scope :{
                percentage : '='
            },

            template: '<div class="ge-progress-bar" style="height: 15px; width: 100%"></div>',

            link : function(scope, element){
                scope.$watch('percentage', function() {
                    scope.progress=scope.percentage;
                    element.find(".ge-progress-bar").css("background","linear-gradient(90deg, #0096d8 "+scope.progress+"%, #f3f3f3 "+scope.progress+"%)");
                });
            }
        };

    });

});