/*
 *  get-sites-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular'], function () {

    // Module Dependencies
    var dependencies = ['Services.caseExchangeDataService'];

    // Module Definition
    var mod = angular.module('Services.getSitesService', dependencies);

    /**
     * @name GetSitesService
     * @type factory
     *
     * @description
     * A factory that provides methods for making request to the get sites details for login in user.
     */
    mod.factory('GetSitesServices', ['CaseExchangeDataService', '$q', '$log', function (caseExchangeDataService, $q, $log) {

        /**
         * Makes a call to API to retrieve site detail list
        */
        function getSiteList() {
            /**
             * Base url for making request to the get sites REST API.
             */
            var GET_SITE_DETAILS = caseExchangeDataService.getServiceURL() + '/v1/user/me/site?role=administrator&level.value=2';

            var deferred = $q.defer();

            // Calls the PACS devices application service, upon successful
            // result from the 'me' service called in getUserKey()
                $.ajax({
                    async: true,
                    contentType: 'application/json',
                    type: 'get',
                    url: GET_SITE_DETAILS,
                    success: success,
                    error: error
                });

            return deferred.promise;

            // Error handler for the API call
            function error(jqXHR, errorThrown) {
                var errorMsg = 'Error: GetPacsService: getSiteList: ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }

            // Success handler for API call
            function success(data) {
                $log.log('Success: GetPacsService: getSiteList');
                var response = data || null;
                deferred.resolve(response);
            }
        }

        return {
            getSiteList: getSiteList
        };
    }]);
});