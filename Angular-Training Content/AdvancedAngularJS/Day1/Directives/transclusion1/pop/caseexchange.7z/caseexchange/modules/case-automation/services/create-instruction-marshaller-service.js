/*
 * create-instruction-marshaller-service.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */

define([ 'angular' ], function() {
    // Module Definition
    var dependencies = ['Services.instructionConditionMarshallerService'];

    var mod = angular.module('Services.createInstructionMarshallerService', dependencies);

    mod.factory('CreateInstructionMarshallerService', ['InstructionConditionMarshallerService', function(instructionConditionMarshallerService) {

        function createInstructionMarshal(autoCreate, addedRecipients) {
            var createInstructionValues,
                condition,
                participants = [];

            for (var i = 0; i < addedRecipients.length; i++) {
                var participientsValue = {
                    "user" : {
                        "identifier" : addedRecipients[i].id
                    },
                    "reviewed" : true
                };
                participants.push(participientsValue);
            }
            condition = instructionConditionMarshallerService.marshalCondition(autoCreate.instCondition);
            createInstructionValues = {
                "name" : autoCreate.instructionName,
                "type" : "AUTO_CREATE",
                "message" : autoCreate.impression,
                "site" : {id:autoCreate.site.id, name:autoCreate.siteName},
                "clinicalReason" : autoCreate.clinicalReason.id,
                "otherClinicalReason": autoCreate.otherClinicalReason,
                "deleted": false,
                "phiAgreement" : autoCreate.acknowledge,
                "participants" : participants,
                "condition": condition["condition"]
            };
            return createInstructionValues;
        }

        return {
            createInstructionMarshal : createInstructionMarshal
        };
    }]);
});