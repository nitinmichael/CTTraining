/*
 *  normalization-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define([ 'angular' ], function() {

    // Module Dependencies
    var dependencies = ['Services.caseExchangeDataService'];

    // Module Definition
    var mod = angular.module('Services.normalizationService', dependencies);

    /**
     * @name NormalizationService
     * @type factory
     *
     * @description A factory that provides methods for making request to get Patient list for comparison.
     */
    mod.factory('NormalizationService', ['CaseExchangeDataService', '$q', '$log', function(caseExchangeDataService, $q, $log) {

        var selectedCase, selectedStudies, selectedDicomDevices;
        var NORMALIZATION_SERVICE_URL =caseExchangeDataService.getServiceURL() + '/caseattachment/v1/case/';

        /**
         * setter for the selected case from case inbox
         * @param: caseDetails: selected caseDetails
         */
        function setSelectedCase(caseDetails) {
            selectedCase = caseDetails;
        }

        /**
         * getter the selected case
         */
        function getSelectedCase() {
            return selectedCase;
        }

        /**
         * setter for the case studies from download to premise page
         * @param: studies: selected studies
         */
        function setSelectedCaseStudies(studies) {
            selectedStudies = studies;
        }

        /**
         * getter the selected selected studies based on selectedForDownload attribute value
         */
        function getSelectedCaseStudies() {
            for (var i = selectedStudies.length - 1; i >= 0; i--) {
                if (!selectedStudies[i].selectedForDownload) {
                    selectedStudies.splice(i, 1);
                }
            }
            return selectedStudies;
        }

        /**
         * setter for the dicom devices from download to premise page
         * @param: devices: selected dicom devices
         */
        function setSelectedDicomDevices(devices) {
            selectedDicomDevices = devices;
        }

        /**
         * getter the selected selected studies based on selectedForDownload attribute value
         */
        function getSelectedDicomDevices() {
            for (var i = selectedDicomDevices.length - 1; i >= 0; i--) {
                if (!selectedDicomDevices[i].selectedForDownload) {
                    selectedDicomDevices.splice(i, 1);
                }
            }
            return selectedDicomDevices;
        }

        function normalizeSave(caseId, data){
            // validate arguments
            if(!angular.isObject(data)) {
                var errorMsg = 'Error: normalizeSave: invalid parameter: data = ' + data;
                $log.error(errorMsg);
                return $q.reject(errorMsg);
            }

            var deferred = $q.defer();

            // send the request
            var xhr = $.ajax({
                async: true,
                contentType: 'application/json',
                type: 'post',
                url: NORMALIZATION_SERVICE_URL + caseId + '/attachment/store',
                data: JSON.stringify(data),
                success: success,
                error: error
            });

            return { xhr: xhr, promise: deferred.promise };

            //success Callback functionality
            function success(data) {
                $log.log('Success: normalizeSave: normalizeSave');
                var response = data || null;
                deferred.resolve(response);
            }

            //Error Callback functionality
            function error(jqXHR, textStatus, errorThrown) {
                var errorMsg = 'Error: normalizeSave: normalizeSave: ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }
        }

        return {
            setSelectedCase : setSelectedCase,
            getSelectedCase : getSelectedCase,
            setSelectedCaseStudies : setSelectedCaseStudies,
            getSelectedCaseStudies : getSelectedCaseStudies,
            setSelectedDicomDevices : setSelectedDicomDevices,
            getSelectedDicomDevices : getSelectedDicomDevices,
            normalizeSave : normalizeSave
        };
    } ]);
});