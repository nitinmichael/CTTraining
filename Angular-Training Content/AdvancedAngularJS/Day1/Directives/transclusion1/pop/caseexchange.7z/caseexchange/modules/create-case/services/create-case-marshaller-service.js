/*
 *  create-case-marshaller-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * A factory that provides methods for marshaling case data to be shared into the format expected by the microservice.
 */
define(['angular'], function () {

    // Create Case marshaller Module
    var mod = angular.module('Services.createCaseMarshallerService', ['Services.pacsSearchMarshaller','Services.selectedStudyListService']);

    /**
     * A factory that provides method for marshaling data related to selected patient and selected studies
     * of that patient to be shared into the format expected by the REST API.
     */
    mod.factory('CreateCaseMarshallerService', ['$filter', 'PacsSearchMarshaller','SelectedStudyListService', function ($filter, PacsSearchMarshaller, SelectedStudyListService) {

        // Json for Constants
        var ATTACHMENTJSON = {
            "attachmentType" : "ImagingStudy"
        };

        var operationTypeUpload = "UPLOAD";
        var API_DATE_FORMAT = 'yyyyMMdd';

        // The id defined in DB for Clinical Reason Other
        // Note:: Need to update the value if DB value changes
        var CLINICAL_REASON_OTHER_ID = '9';

        // String constants for transaction type
        var transactionType = {
            ADD_TO_CASE: 'ADD_TO_CASE',
            ADD_USERS: 'ADD_USERS',
            CREATE_CASE: 'CREATE_CASE'
        };

        // Returns the proper transaction type according to the case update type
        var getTransactionType = function(caseUpdateType){
            if (!caseUpdateType){
                return transactionType.CREATE_CASE;
            }
            else if (caseUpdateType === 'ADDUSERS'){
                return transactionType.ADD_USERS;
            }
            else if (caseUpdateType === 'ADDCASE'){
                return transactionType.ADD_TO_CASE;
            }
        };

        /**
         * Marshals the provided Create Case form data into the format expected by the REST API.
         *
         * @param formData
         *    The form data to be marshaled.
         */
        function marshalCreateCase(formData) {
            /*
             * String constants
             */
            var CASE_TYPE_NORMAL = "NORMAL";

            return {
                subject: formData.subjectInput,
                type: CASE_TYPE_NORMAL,
                clinicalReason: formData.clinicalReason.id,
                otherClinicalReason: formData.clinicalReason.id === CLINICAL_REASON_OTHER_ID && formData.otherClinicalReason.trim() !== "" ? formData.otherClinicalReason : "",
                caseOrganization: {
                    id: formData.selectedBillingOrganization.reference,
                    name: formData.selectedBillingOrganization.display
                },
                transaction: null
            };
        }

        /**
         * Marshals the case transaction data to be pushed into main Create Case JSON.
         * @param caseMessage: Message field value
         * @param selectedPatient: Selected patient object
         * @param studyList: List of studies to attach with transaction.
         * @returns Marshaled transaction object
         */
        function marshalCaseTransaction(caseMessage, selectedPatient, studyList, caseUpdateType, priority) {
            var attachedStudies=[], patient;
            if(selectedPatient && studyList && studyList.length!==0){
                for(var i=0;i< studyList.length; i++){
                    var study={
                        "type":ATTACHMENTJSON.attachmentType,
                        "started":$filter('date')(studyList[i].started, API_DATE_FORMAT),
                        "description":studyList[i].description,
                        "accession":studyList[i].accession,
                        "studyId":studyList[i].identifier,
                        "uid":studyList[i].uid,
                        "saveStateSuid":"123123",
                        "sourceId":"PACS_SR",
                        "uri":"/test",
                        "cloudObjectId":"Cloud_id",
                        "referrer":studyList[i].referrer,
                        "performingPhysician":studyList[i].performingPhysician,
                        "anatomicRegion":studyList[i].anatomicRegion,
                        "procedure":studyList[i].procedure,
                        "modalityList":studyList[i].modalityList
                    };
                    attachedStudies.push(study);
                }
                patient = marshalPatientData(selectedPatient);

                /**
                 *  Since the age is calculated on the fly on front-end, the object also contains "age" property.
                 *  But, since, API doesn't expect the same, we need to remove the property.
                 */
                delete patient.age;
            }

            var type = getTransactionType(caseUpdateType);

            return {
                patient: patient,
                message: caseMessage || null,
                addedParticipants: [],
                attachments: attachedStudies,
                type: type,
                priority: priority
            };
        }

        /**
         * Marshalling the patient data for create case request as need to pass specific props for patient in request payload
         * Function to marshall patient data
         * @param patient: Patient object returned from PACS
         * @returns: patientData: Marshaled patient data
         */
        function marshalPatientData(patient){
            if(!patient || !patient.name) {
                return;
            }

            var patientData = {
                "identifier": patient.identifier,
                "name": {
                    "given": _.compact(patient.name.given),
                    "family": _.compact(patient.name.family)
                },
                "birthDate": $filter('date')(patient.birthDate, API_DATE_FORMAT, 'UTC'),
                "gender": patient.gender
            };
            return patientData;
        }

        /**
         * Get all sourceIds from all transactions of a case
         *
         * @param studyAttachments
         *    study attachments Object.
         */
        function getSourceId(studyAttachments){
            var sourceIdArr = [];
            for(var i = 0; i< studyAttachments.length; i++){
                if(studyAttachments[i].type === ATTACHMENTJSON.attachmentType){
                    var tempSourceId = studyAttachments[i].sourceId;
                    if(sourceIdArr.indexOf(tempSourceId) === -1){
                        sourceIdArr.push(tempSourceId);
                    }
                }
            }
            return sourceIdArr;
        }

        /**
         * Get all study Attachments from all transactions of a case
         *
         * @param createdCase
         *    createdCase Object.
         */
        function getAllAttachments(transactions){
            var studyAttachments = [];
            for( var temp = 0; temp< transactions.length; temp++){
                studyAttachments =studyAttachments.concat(transactions[temp].attachments);
            }
            return studyAttachments;
        }

        /**
         * Marshals the case attachment data to be pushed into attachment upload JSON.
         *
         * @param createdCase
         *    createdCase to be added in attachment upload object.
         */
        function marshallDicomAttachment(transactions) {
            var selectedStudies = SelectedStudyListService.getList();
            var studyAttachments = getAllAttachments(transactions);
            var appIdMap = {};
            var studyMap = {};
            var appServices = [];
            var sourceIdArr = [];

            if (studyAttachments) {
                sourceIdArr = getSourceId(studyAttachments);
            }

            //creating a map app id vs studyids
            for (var i = 0; i < selectedStudies.length; i++) {
                var studyArray = [];
                if (appIdMap[selectedStudies[i].appid]) {
                    studyArray = appIdMap[selectedStudies[i].appid];
                }
                studyArray.push(selectedStudies[i].uid);
                appIdMap[selectedStudies[i].appid] = studyArray;
            }

            //creating a map studyid with respective study details
            for (var k = 0; k < studyAttachments.length; k++) {
                studyMap[studyAttachments[k].uid] = studyAttachments[k];
            }

            _.each(appIdMap, function(value, key) {
                var attachments = [];
                var studyList = value;
                for (var j = 0; j < sourceIdArr.length; j++) {
                    for (var i = 0; i < studyList.length; i++) {
                        if (sourceIdArr[j] === studyMap[studyList[i]].sourceId) {
                            var study = {
                                "type" : studyMap[studyList[i]].type,
                                "identifier" : studyMap[studyList[i]].identifier,
                                "uid" : studyMap[studyList[i]].uid
                            };
                            attachments.push(study);
                        }
                    }
                }

                var applicationService = PacsSearchMarshaller.getDicomDetail(key);

                var appService = {
                    "id" : key,
                    "attachments" : attachments,
                    "endpoint" : applicationService && applicationService.content ? applicationService.content.endpoint : ''
                };
                appServices.push(appService);
            });

            var data = {
                "operationType" : operationTypeUpload,
                "operationId" : transactions && transactions.length ? transactions[0].id : null,
                "applicationServices" : appServices
            };
            return data;

        }

        /**
         * Marshals the provided participant data to be pushed into main Create Case JSON.
         *
         * @param participant
         *  The participant to be marshaled.
         * @returns:
         *  JSON: Marshaled JSON object for participant.
         */
        function marshalParticipants(participant) {
            return buildParticipantJSON(participant.id);
        }

        /**
         * Builds the JSON object for participant data.
         * @param:
         *  participantId: Participant ID
         *  name: Name object for participant
         * @returns:
         *  JSON: Marshaled JSON object for participant.
         */
        function buildParticipantJSON(participantId){
            return {
                user: {
                    identifier: participantId
                }
            };
        }

        function marshalFileAttachment(file) {
            var data = marshalAttachment(file);
            data.type = 'DocumentReference';
            data.size = file.size;
            data.created = $filter('date')(file.lastModifiedDate, API_DATE_FORMAT);
            data.linkedStudyId = null;
            return data;
        }

        function marshalAttachment(file) {
            return {
                description: file.name
            };
        }

        /**
         * Function to prepare the JSON object to update attachment upload status
         * @returns: Array of JSON object
         */
        function marshalAttachmentUploadStatus(){
            return [{
                'op': 'replace',
                'path':'/uploadStatus',
                'value': 'FAILED'
            }];
        }

        return {
            marshalCreateCase: marshalCreateCase,
            marshalParticipants: marshalParticipants,
            marshalCaseTransaction: marshalCaseTransaction,
            marshalFileAttachment: marshalFileAttachment,
            marshallDicomAttachment: marshallDicomAttachment,
            marshalPatientData: marshalPatientData,
            marshalAttachmentUploadStatus: marshalAttachmentUploadStatus
        };
    }]);

});
