/***************************************************************************************************
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * An AngularJS directive that watches input elements for any XSS attempt and can also validate
 * user input against a positive list of accepted formats.
 *
 * @author
 * Henry Navarro <henry.navarro@ge.com>
 *
 * @name geXss
 *
 * @param {gePattern}       data pattern that the input can be restricted to
 * @param {onInvalid}       outer method the directive will call upon invalid input value
 * @param {onScript}        outer method the directive will call upon scripting detection
 * @param {resetOnScript}   if present this attribute tells the directive to clear the input field
 *                            when scripting is detected
 *
 * @description
 * An AngularJS directive that watches input elements for any XSS attempt.  It can also validate
 * input value for these data types defined in the 'Services.InputPatterns' angular module:
 * 'name',
 * 'phone',
 * 'email',
 * 'usZip',
 * 'ipAddress',
 * 'url',
 * 'integer',
 * 'float',
 * 'currency',
 * 'date'
 *
 * This directive watches for scripting attempts by attaching listeners for the 'change' and 'blur'
 * events emitted by an input element when the user changes the element's value and then moves
 * the focus from it.  The event listener checks if any scripting is present (looking for the
 * first occurrence of strings such as '<script ...>' or 'javascript:').  If scripting was
 * found, the directive calls any callback function provided by name in the 'on-script' attrubute.
 * It passes the 'SCRIPTING_DETECTED' literal and the element node value to the said callback.
 * Without an 'on-script' callback, the directive emits a root-scope 'SHOW_FAILURE_MESSAGE*' event,
 * passing the localized string message assigned for this case.
 * If no scripting was detected, and if the 'ge-pattern' was provided, the directive will validate
 * the element value against the specified pattern.  If an invalid pattern was detected and if the
 * name of a callback function was provided in 'on-valid', the directive will invoke the said
 * callback, the 'INVALID_FORMAT' string literal and the element node value.
 *
 * @dependencies
 * 'Services.InputPatterns', 'Directives.GeXss.i18n'
 *
 * @example
 * <input ge-xss ge-data-type="phone" on-script="onScript" on-invalid="onInvalid" reset-on-script/>
 ***************************************************************************************************/

define(['angular', './input-patterns-service', './i18n-directive'], function () {

    // Module Dependencies
    var dependencies = ['Services.inputPatterns', 'Directives.geXss.i18n', 'Platform.Services.NotificationService'];

    function hasScript(content) {
        var scriptMarkupRegExps = ['<[ ]*script[^>]*>', 'javascript:', '<[ ]*a[^>]*>', '<[ ]*input[^>]*>', '<[ ]*html[^>]*>', '<[ ]*img[^>]*>', 'href[^>]*>'];
        var lowerCasedContent =
            (typeof content === 'string' ? content.toLowerCase() :
                (content + '').toLowerCase()
            );
        for (var i = 0; i < scriptMarkupRegExps.length; i++) {
            var regExp = new RegExp(scriptMarkupRegExps[i]);
            if (lowerCasedContent.match(regExp) !== null) {
                return true;
            }
        }
        // if this point is reached, no script or markup was found
        return false;
    }

    // function checks arg for valid data type
    function hasValidDataType (content, datatype) {
        if (
            typeof datatype === 'undefined' ||
            (typeof datatype === 'string' && datatype === '')
        ) {
            // valid content if no format imposed
            return true;
        }
        // validate for date string input by creating a date instance
        // with the provided string and inspecting its status
        if (datatype === 'date') {
            var date = new Date(content);
            if (isNaN(date.getDate())) {
                return false;
            } else {
                return true;
            }
        };
        return false;
    };

    // function checks arg for valid input pattern
    function hasValidInputPatterns(content, inputPatterns, datatype) {
        var formatRegExp = inputPatterns[datatype];
        // if no datatype string was passed in
        if (typeof formatRegExp === 'undefined') {
            // return true (i.e., no format violation)
            return true;
        }
        // if valid datatype string was passed
        // return the result of regexp test for that format
        return formatRegExp.test(content + '');
    }

    // Module Definition
    var mod = angular.module('Directives.geXss', dependencies);

    // Directive definition
    mod.directive('geXss', ['$rootScope', 'InputPatterns', 'Directives.geXss.i18n', '$filter', 'NotificationService', '$timeout',
        /**
         * Finds the selected user in the list of added users.
         *
         * @return
         *      name: 'geXss',  // controller name, prevents collisions with other directives
         *      restrict: 'A',  // apply to occurrences 'ge-xss' attribute
         */
        function ($rootScope, inputPatterns, i18n, $filter, NotificationService, $timeout) {
            return {
                name: 'geXss',
                restrict: 'A',
                /**
                 * gePattern = <input pattern>
                 * onScript = <callback function>
                 * onInvalid = <callback function>
                 * resetOnScript = <boolean to reset input field if scripting detected>
                 */
                scope: {
                    gePattern: '@',
                    onScript: '&',
                    onInvalid: '&',
                    resetOnScript: '@'
                },
                link: function (scope, iElement) {
                    scope['model'] = iElement.val();
                    // function that scans arg for any scripting or markup content
                    // Detect changes to input fields by attaching
                    // a listener on 'change' or 'blur' event on the element where
                    // the directive is applied
                    var thatElement = iElement;

                    function handleCallback(formEl, scriptsources) {
                        // if scripting callback was provided
                        // Using scope.onScript()
                        if (typeof scope.onScript() !== 'undefined') {
                            // call scripting callback
                            // passing SCRIPTING DETECTED string literal and element node
                            scope.onScript()(i18n.getMessages()['scriptingDetectedCAPS'], thatElement[0]);
                        }
                        // else if scripting call back was not provided
                        // emit rootscope-level event that will be handled there
                        else {
                            $rootScope.$emit("SHOW_FAILURE_MESSAGE_NO_TIMEOUT",
                                i18n.getMessages()['scriptingDetected']);
                        }
                        // invalidate parent form (if found)
                        // by adding/removing the ng-invalid/ng-valid classes
                        if (formEl && formEl[0] && formEl[0].tagName === 'FORM') {
                            scriptsources.push(thatElement[0].name);
                            formEl.addClass('ng-invalid').removeClass('ng-valid');
                            formEl.data('scriptsources', scriptsources);
                        }
                        // if reset-on-script attribute is present
                        // reset input field value to empty
                        if (typeof scope.resetOnScript !== 'undefined') {
                            iElement.val('');
                            // calling notification service to display script error message
                            $timeout(function () {
                                NotificationService.addErrorMessage($filter('translate')('common.script.error'));
                            });
                        }
                    };

                    // set form class to ng-valid/invalid depending on
                    // the absence of scripting in other child input fields
                    function updateClassOfChildElements(formEl, scriptsources) {
                        // if there is a parent form
                        if (formEl && formEl[0] && formEl[0].tagName === 'FORM') {

                            for (var i = 0; i < scriptsources.length; i++) {
                                if (thatElement[0].name === scriptsources[i]) {
                                    scriptsources.splice(i, 1);
                                    break;
                                }
                            }
                            // if the array of names of elements
                            // containing script is non-empty
                            if (scriptsources.length > 0) {
                                // mark the form as invalid
                                formEl.removeClass('ng-valid').addClass('ng-invalid');
                            }
                            else {
                                // else mark the form as valid
                                formEl.removeClass('ng-invalid').addClass('ng-valid');
                            }
                            // update the data of array of element
                            // names and attach to the form element
                            formEl.data('scriptsources', scriptsources);
                        }
                    };

                    // Validates the value of element against inputPatterns
                    function checkInvalidFormat(val, thatElement) {
                        var datatype = scope.gePattern;
                        // if valid pattern was provided and invalid format was detected and invalid format callback was provided
                        if (typeof datatype !== 'undefined' &&
                            (  !hasValidInputPatterns(val, inputPatterns, datatype) ||
                               !hasValidDataType(val, datatype)
                            ) &&
                            typeof scope.onInvalid() !== 'undefined') {
                            // call invalid callback
                            // passing INVALID FORMAT string literal and element node
                            scope.onInvalid()(i18n.getMessages()['invalidFormatCAPS'], thatElement[0]);
                        }
                    };

                    // locate parent form for later use on
                    // determining its enable/disable state
                    function locateParentElement(formEl, scriptsources) {
                        while ( formEl && formEl[0] && formEl[0].tagName !== 'FORM') {
                            formEl = formEl.parent();
                        }
                        // if parent form was located
                        if (formEl && formEl[0] && formEl[0].tagName === 'FORM') {
                            scriptsources = formEl.data('scriptsources');
                            scriptsources = scriptsources || [];
                        }
                    };

                    iElement.on('change blur', function () {
                        var val = thatElement.val();
                        if (typeof val === 'undefined' || val === '') {
                            return;
                        }

                        var formEl = thatElement.parent();
                        var scriptsources = [];

                        // locate parent form for later use on
                        // determining its enable/disable state
                        locateParentElement(formEl, scriptsources);

                        // if scripting was detected
                        if (hasScript(val)) {

                            // if scripting callback was provided
                            // Using scope.onScript()
                            handleCallback(formEl, scriptsources);

                            // set form class to ng-valid/invalid depending on
                            // the absence of scripting in other child input fields
                            updateClassOfChildElements(formEl, scriptsources);

                            // skip format validation if scripting was detected
                            return;
                        }

                        // Validates the value of element against inputpatterns
                        checkInvalidFormat(val, thatElement);
                    });
                }
            };
        }
    ]);
});