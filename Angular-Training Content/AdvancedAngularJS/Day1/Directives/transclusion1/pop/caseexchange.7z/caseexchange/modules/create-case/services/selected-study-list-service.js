/*
 * selected-study-list-service.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */

define([ 'angular' ], function() {

    // Module Dependencies
    var dependencies = [];

    // Module Definition
    var mod = angular.module('Services.selectedStudyListService', dependencies);

    /**
     * @name SelectedStudyListService
     * @type factory
     *
     * @description A factory that provides methods for storing selected study details with patient information.
     */
    mod.factory('SelectedStudyListService', function() {
        var selectedPatient = {}, setList = function(datum) {
            selectedPatient.studyList=datum;
        }, getList = function() {
            return (selectedPatient.studyList === undefined) ? [] : selectedPatient.studyList;
        }, removeItem = function(identifier) {
            var i = selectedPatient.studyList.length;
            while (i--) {
                if (selectedPatient.studyList[i].identifier === identifier) {
                    selectedPatient.studyList.splice(i, 1);
                }
            }
        }, clearList = function() {
            selectedPatient.studyList = [];
        },

        setSelectedPatient = function(datum) {
            if (selectedPatient.identifier !== datum.identifier) {
                selectedPatient = datum;
            }

            /**
             * Since we need to pass the applicationServiceId in Add to case as well as Create case both, comparing the application service id and assigning if it's different
             */
            if(datum.applicationServiceId && selectedPatient.applicationServiceId !== datum.applicationServiceId){
                selectedPatient.applicationServiceId = datum.applicationServiceId;
            }

        }, getSelectedPatient = function() {
            return selectedPatient;
        }, clearSelectedPatient = function() {
            selectedPatient = {};
        };

        return {
            setList : setList,
            getList : getList,
            removeItem : removeItem,
            clearList : clearList,
            setSelectedPatient : setSelectedPatient,
            getSelectedPatient : getSelectedPatient,
            clearSelectedPatient : clearSelectedPatient
        };

    });
});
