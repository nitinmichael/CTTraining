/*
 *  get-clinical-reasons-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular'], function () {

    // Module Dependencies
    var dependencies = ['Services.caseExchangeDataService'];

    // Module Definition
    var mod = angular.module('Services.clinicalReasonsService', dependencies);

    /**
     * @name ClinicalReasonsService
     * @type factory
     *
     * @description
     * A factory that provides methods for making request to the REST API to get the Clinical Reasons.
     */
    mod.factory('ClinicalReasonsService', ['CaseExchangeDataService', '$q', '$log', function (caseExchangeDataService, $q, $log) {
        /**
         * Base url for making request to the GET Clinical Reasons REST API.
         */
        var GET_CLINICAL_REASONS_URL = caseExchangeDataService.getServiceURL() + '/casereader/v1/case/clinicalreasons';

        /**
         * A method to retrieve Clinical Reasons from an API
         */
        function getClinicalReasons() {

            var deferred = $q.defer();

            $.ajax({
                async: true,
                contentType: 'application/json',
                dataType: 'json',
                type: 'get',
                url: GET_CLINICAL_REASONS_URL,
                success: success,
                error: error
            });

            return deferred.promise;

            function success(data) {
                $log.log('Success: ClinicalReasonService: getClinicalReasons');
                var response = data || null;
                deferred.resolve(response);
            }

            function error(jqXHR, textStatus, errorThrown) {
                var errorMsg = 'Error: ClinicalReasonService: getClinicalReasons: ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }
        }

        return {
            getClinicalReasons: getClinicalReasons
        };
    }]);
});
