/*
 * get-instruction-conditions-service.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */

define(['angular'], function() {
    // Module Definition
    var dependencies = ['Services.caseExchangeDataService'],
        mod = angular.module('Services.getInstructionConditionsService', dependencies);

    mod.factory('GetInstructionConditionsService', ['$q', '$log', 'CaseExchangeDataService',
        function($q, $log, caseExchangeDataService) {

            function getConditionKeyList() {
                var GET_INSTRUCTIONS_URL = caseExchangeDataService.getServiceURL() + '/caseautomation/v1/instruction/dicomattributes',
                    deferred = $q.defer(),
                    xhr = $.ajax({
                        async: true,
                        contentType: 'application/json',
                        dataType: 'json',
                        type: 'get',
                        url: GET_INSTRUCTIONS_URL,
                        success: success,
                        error: error
                    });

                return {
                    xhr: xhr,
                    promise: deferred.promise
                };

                function success(data) {
                    $log.log('Success: getConditionKeyList ');
                    var response = data || null;
                    deferred.resolve(response);
                }

                function error(jqXHR, textStatus, errorThrown) {
                    var errorMsg = 'Error: getConditionKeyList ' + errorThrown;
                    $log.error(errorMsg);
                    deferred.reject(jqXHR);
                }
            };

            return {
                getConditionKeyList: getConditionKeyList
            };
        }
    ]);
});