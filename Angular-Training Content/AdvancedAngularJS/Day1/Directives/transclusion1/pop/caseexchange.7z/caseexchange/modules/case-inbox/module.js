/*
 *  module.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * A module config file to load case inbox and case creation related files.
 */
define([
    'angular',
    'postal',
    '../../widgets/ge-infinite-scroll/ge-infinite-scroll-directive',
    './services/normalization-service',
    './services/case-data-service',
    './services/download-case-service',
    './services/dicom-app-services-marshaller-service',
    './services/normalization-marshaller-service'],
    function (ng) {
        'use strict';

        // Create case module
        var caseinbox = ng.module('cloudav.caseExchange.caseInbox', ['InfiniteScrollDirective']);

        return caseinbox;
    }
);