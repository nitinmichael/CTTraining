/***************************************************************************************************
 *
 * ge-patient-list-directive.js
 *
 * Copyright (c) 2015 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * Provides the patient list functionality
 *
 ***************************************************************************************************/

define([ 'angular',
         'jquery',
         'angularTranslate',
         'angularTranslatePartialLoader'
 ], function() {

    // Module Dependencies
    var dependencies = ['pascalprecht.translate'];

    // Module Definition
    var mod = angular.module('Directive.gePatientList', dependencies);

    // Register externalized strings
    mod.config([ '$translatePartialLoaderProvider', function ($translatePartialLoaderProvider) {
        $translatePartialLoaderProvider.addPart('../modules/caseexchange/widgets/ge-patient-list/i18n');
    }]);

    /**
     * A directive for displaying patient list.
     * @example
     * <ge-patient-list
     *     list="PatientsList"
     *     click-action="method(arg1,arg2);">
     * </ge-patient-list>
     */
    mod.directive('gePatientList', ['$filter', function($filter) {
        return {
            restrict : 'E',
            scope : {
                list : '=',
                totalPatientCount: '=',
                clickAction : '&',
                showMsg: '&',
                getAllPatients: '&getAllPatients'
            },
            controller : function ($scope, PacsSearchService, PacsSearchMarshaller) {
                $scope.pacsSearchService = PacsSearchService;
                $scope.pacsSearchMarshaller = PacsSearchMarshaller;
                $scope.requestData=$scope.pacsSearchMarshaller.getpacsSearchData();
            },
            templateUrl : "modules/caseexchange/widgets/ge-patient-list/ge-patient-list.html",

            link : function(scope) {
                scope.$watch('list', function() {
                    scope.patients = scope.list;
                });

                scope.numPatientsFound = 0;
                // Patient List object
                scope.patients = scope.list;

                // JSON object holding the types of alert messages.
                // Possible values: success, error.
                scope.alertTypes = {
                    success: 'success',
                    error: 'error'
                };

                // flag for active patient microservice call
                scope.isFetchingPatients = false;

                scope.lastPatientFetched = (scope.totalPatientCount < scope.requestData.limit)? true : false;

                var pacsSearchXHR;
                var isPatientFetched = false;

                /**
                 * Concatinate patient first name, middle name, last name for display purpose only
                 */
                scope.updatedPatientName = function(patient) {
                    var patientName = "";
                    if (patient && patient.name) {
                        patientName = $filter('name')(patient.name);
                    }
                    return patientName;
                };

                /**
                 * function display error message
                 */
                var errorDisplay = function(requestData, success) {
                    if (requestData !== null) {
                        if(!success){
                            scope.showMsg({msg: $filter("translate")('pacsPatientList.errorOccured'),alertType: scope.alertTypes.error});
                        }
                    } else {
                        scope.showMsg({msg: $filter("translate")('pacsPatientList.noPatientsAvailable'),alertType: scope.alertTypes.error});
                    }
                };

                /**
                 * function for pagination of patient data
                 */
                scope.showPatients = function() {
                    isPatientFetched = false;
                    if(scope.totalPatientCount === scope.patients.length){
                        scope.lastPatientFetched = true;
                    }

                    if (!(scope.lastPatientFetched || scope.isFetchingPatients)) {
                        //To set offset for patient fetch
                        //TODO : Need to replace digits with actual offset value
                        var len = (scope.patients.length % 10) ? scope.patients.length : (scope.patients.length-1);
                        var offset = Math.floor(len/10) * 10 ;
                        var requestData = scope.requestData;
                        offset += requestData.limit;
                        requestData.offset = offset;

                        scope.patientSearchMessage = '';
                        pacsSearchXHR = scope.pacsSearchService.pacsSearch(requestData);
                        pacsSearchXHR.promise.then(function(data) {
                            data = data.responseList;
                            scope.numPatientsFound = (data != null && data instanceof Array ? data.length : 0);
                            if (scope.numPatientsFound === 0) {
                                errorDisplay(requestData,true);
                                requestData.offset -= requestData.limit;
                            }else{
                                scope.patients = scope.patients.concat(data);
                                var fetchedPatients = scope.patients;
                                isPatientFetched = true;
                                scope.getAllPatients({allPatientlist : fetchedPatients, isFetched: isPatientFetched});
                            }

                            scope.lastPatientFetched = (scope.totalPatientCount === scope.patients.length);
                            scope.isFetchingPatients = false;
                        }, function() {
                            errorDisplay(requestData, false);
                            requestData.offset -= requestData.limit;
                            scope.lastPatientFetched = false;
                            scope.isFetchingPatients = false;
                        });
                        scope.isFetchingPatients = true;
                    }
                    if(scope.lastPatientFetched){
                        scope.patientSearchMessage = $filter("translate")('pacsPatientList.noMoreRecordsOnServer');
                    }
                };
            }
        };
    }]);
});
