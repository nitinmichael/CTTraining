/*
 *  get-pacs-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular'], function () {

    // Module Dependencies
    var dependencies = ['Services.caseExchangeDataService'];

    // Module Definition
    var mod = angular.module('Services.morpheusServices', dependencies);

    /**
     * @name GetPacsService
     * @type factory
     *
     * @description
     * A factory that provides methods for making request to the Get Pacs Devices REST API to post the data.
     */
    mod.factory('MorpheusServices', ['CaseExchangeDataService', '$q', '$log', '$http', function (caseExchangeDataService, $q, $log, $http) {


        function getLoggedInUserDetails () {
            loggedInUserDeferred = $q.defer();
            var serviceUrl = caseExchangeDataService.getServiceURL();
            var ME_URL = '/userregistry/v1/user/me?level.value=2';

            var GET_LOGGED_IN_USER_URL = serviceUrl + ME_URL;
            $.ajax({
                async: true,
                contentType: 'application/json; charset=UTF-8',
                type: 'get',
                url: GET_LOGGED_IN_USER_URL,
                success: function (data) {
                    loggedInUserDeferred.resolve(data, status);
                },
                error: function () {
                    console.error('Error retrieving current user\'s information');
                    loggedInUserDeferred.reject(data, status);
                }
            });

            return loggedInUserDeferred.promise;
        }

        /**
         * Makes a call to API to retrieve PACS device list and details
        */
        function getClinicianData(userIdentifier, numberOfDays) {

            /**
             * Base url for making request to the Create Case REST API.
             */
            var GET_CLINICIAN_DATA_URL = caseExchangeDataService.getServiceURL() + '/analyticdata/v1/analyticdata?uomUserId='+userIdentifier+'&days='+numberOfDays;
            var deferred = $q.defer();

            $http.get(GET_CLINICIAN_DATA_URL, {
                headers: {'Content-Type': 'application/json; charset=UTF-8'}
            })
			.success(success)
			.error(error);

            return deferred.promise;

            // Error handler for the API call
            function error(jqXHR, errorThrown) {
                var errorMsg = 'Error: MorpheusServices: getClinicianData: ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }

            // Success handler for API call
            function success(data) {
                $log.log('Success: MorpheusServices: getClinicianData');
                var response = data || null;
                deferred.resolve(response);
            }
        }

        return {
            getLoggedInUserDetails: getLoggedInUserDetails,
			getClinicianData: getClinicianData
        };
    }]);
});