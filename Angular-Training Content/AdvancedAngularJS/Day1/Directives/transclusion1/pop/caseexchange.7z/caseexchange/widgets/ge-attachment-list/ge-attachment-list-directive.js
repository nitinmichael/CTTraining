/***************************************************************************************************
 *
 * ge-attachment-list-directive.js
 *
 * Copyright (c) 2015 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * Provides the attachment list functionality
 *
 ***************************************************************************************************/

define(['angular','jquery', 'angularTranslate', 'angularTranslatePartialLoader'],function(){

    // Module Dependencies
    var dependencies=['pascalprecht.translate'];

    // Module Definition
    var mod=angular.module('Directive.geAttachmentList',dependencies);

    // Register externalized strings
    mod.config(['$translatePartialLoaderProvider',function ($translatePartialLoaderProvider){
        $translatePartialLoaderProvider.addPart('../modules/caseexchange/widgets/ge-attachment-list/i18n');
    }]);

    /**
     * A directive for displaying attachment list.
     * @example
     * <ge-attachment-list
     *     id="attachmentListId"
     *     header-text="header text of attachment list container"
     *     file-list="list of files (attachments) to display"
     *     view="Hide/View More remove button"
     *     attachment-type="Type of attachment array (Non-Dicom/Dicom)"
     *     callback="Callback method to execute controller method on item removal">
     * </ge-attachment-list>
     */
    mod.directive('geAttachmentList',function(){

        return{
            restrict:'E',
            scope :{
                id : '@',
                fileList : '=',
                headerText : '@',
                view : '=',
                attachmentType : '@',
                callback: '&'
            },

            templateUrl: "modules/caseexchange/widgets/ge-attachment-list/ge-attachment-list.html",

            link : function(scope){

                scope.ATTACHMENT_TYPES = {
                    document: 'DocumentReference',
                    image: 'ImagingStudy'
                };
                scope.calculateTotalSize = function() {
                    return _.reduce(scope.fileList, function (sum, file) {
                        return (sum + file.size);
                    }, 0);
                };

                scope.byteToMB = function (input) {
                    if (input) {
                        return (input / ( 1024 * 1024)).toFixed(2) + ' MB';
                    }
                };

                scope.deleteFile = function (file) {
                    _.pull(scope.fileList, file);
                    scope.callback();
                };

                scope.hasAttachedFile = function () {
                    return scope.fileList.length;
                };
            }
        };

    });

});