/*
 *  case-exchange-controller.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * A Case Exchange controller to handle case related operations.
 */
define(['angular', 'postal', '../module'],
    function (ng) {
        'use strict';

        // case exchange Controller module
        var caseexchange = ng.module('cloudav.caseExchange.caseExchangeCtrl', ['Platform.Services.NotificationService']);

        // case exchange Controller
        caseexchange.controller('CaseExchangeCtrl', ['$scope', '$state', '$stateParams', 'NotificationService',
            function ($scope, $state, $stateParams, NotificationService) {

            // JSON object holding the types of alert messages.
            // Possible values: success, error.
            $scope.alertTypes = {
                success: 'success',
                error: 'error'
            };


            /**
             * Function to turn on visibility of alert message
             * @param msgText: Text to be displayed.
             * @param type: Type of the alert message. Possible values: success, error.
             */
            $scope.showAlertMessage = function (msgText, type) {
                if(type === $scope.alertTypes.error){
                    NotificationService.addErrorMessage(msgText);
                } else if(type === $scope.alertTypes.success){
                    NotificationService.addSuccessMessage(msgText);
                }
            };
        }]);

        return caseexchange;
    }
);