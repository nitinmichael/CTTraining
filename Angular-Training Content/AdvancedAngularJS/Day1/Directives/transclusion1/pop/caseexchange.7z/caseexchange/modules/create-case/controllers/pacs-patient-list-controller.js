/*
 *  pacs-patient-list-ctrl.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */
/**
 * A Pacs Patient List controller to handle case creation operations.
 */
define([ 'angular',
         'angularTranslate',
         'angularTranslatePartialLoader',
         '../../../module' ], function(ng) {
    'use strict';
    // Module dependencies
    var dependencies = [
        'pascalprecht.translate',
        'Services.pacsSearchService',
        'Services.studyListService',
        'Services.selectedStudyListService',
        'Directive.gePatientList',
        'Directive.geProgressBar',
        'Services.pacsSearchMarshaller',
        'Services.caseExchangeDataService'
    ];
    // Pacs patient list Controller module
    var pacsPatientList = ng.module('cloudav.caseExchange.createCase.pacsPatientListCtrl', dependencies);
    // Filter to provide date in dd MMM yyyy format functionality.
    pacsPatientList.filter('dateFormat', [ '$filter', function($filter) {
        return function(date) {
            var formattedDate = $filter("translate")("pacsPatientList.notAvailable");
            if (date) {
                var year = date.substring(0, 4);
                var month = date.substring(4, 6);
                var day = date.substring(6, 8);
                if (year && month && day) {
                    var newDate = new Date(month + '/' + day + '/' + year);
                    formattedDate = returnThreeCharMonth($filter('date')(newDate.getTime(), 'dd MMM yyyy'));
                }
            }
            return formattedDate;
            // Validates date properly and returns date with proper three char month.
            function returnThreeCharMonth(date) {
                if (date.length > 11) {
                    var position = 7;
                    return date.substring(0, position - 1) + date.substring(position, date.length);
                }
                return date;
            }
        };
    }]);

    // Pacs Patient List Controller
    pacsPatientList.controller('PacsPatientListCtrl', [ '$scope', '$state', '$stateParams', '$filter', '$location',
        'PacsSearchService', 'StudyListService', 'SelectedStudyListService', 'PacsSearchMarshaller', 'CaseExchangeDataService',
        function($scope, $state, $stateParams, $filter, $location, PacsSearchService, StudyListService,
            SelectedStudyListService, PacsSearchMarshaller, CaseExchangeDataService) {
            // Disabling Attach Studies button
            $scope.setSubmitDisabledFlag = true;
            // Default count of selected studies
            $scope.selectedStudiesCount = 0;
            $scope.isAttachedFinally = false;
            $scope.isStudyFetchingComplete = true;
            $scope.selectedStudy=[];
            var studyListXHR;

            // Title text for patient list
            $scope.detailsDisplay = $filter("translate")("pacsPatientList.select");
            // List type: Patient(s)
            $scope.type = $filter("translate")("pacsPatientList.patient");
            // Flag to indicate that study list is being displayed.
            $scope.studyListDisplayed = false;
            // Count of already attached studies
            var attachedStudiesCount = 0;

            var pacsSearchXHRList=[];

            /**
             * abort all pacs search ajax call that are in progress when user
             * navigate from patient list screen to any other screen
             */
            var abortPacsSearchCall = function(){
                if(pacsSearchXHRList){
                    for (var i = 0, len = pacsSearchXHRList.length; i < len; i++) {
                        pacsSearchXHRList[i].xhr.abort();
                    }
                }
            };

            /**
             * Set the isAttached variable true for selected studies
             */
            var setAttachment = function(data, selectedStudies){
                $scope.isAttachedFinally=true;
                for (var i = 0, len = data.length; i < len; i++) {
                    for (var j = 0, len2 = selectedStudies.length; j < len2; j++) {
                        if (data[i].uid === selectedStudies[j].uid) {
                            data[i].isAttached=true;
                        }
                    }
                }
                return data;
            };

            // call back for clicking on patient header in patients list
            $scope.clickedOnPatient = function(patientData,index) {
                var dicomDevice=[];
                $scope.isPatientClicked=true;
                var pacsSearch=PacsSearchService.getPacsSearchParams();
                var selectedDicomDeviceList=pacsSearch.dicomDevices;
                dicomDevice.push(PacsSearchMarshaller.getDicomDetail(patientData.applicationServiceId));
                pacsSearch.dicomDevices=dicomDevice;

                var pacsSearchData = PacsSearchMarshaller.marshalStudySearchData(patientData,pacsSearch);
                $scope.togglePatients(patientData, index);
                pacsSearch.dicomDevices=selectedDicomDeviceList;
                if($scope.isStudyFetchingComplete){
                    $scope.isStudyFetchingComplete=false;
                    studyListXHR = StudyListService.studyList(pacsSearchData);
                    studyListXHR.promise.then(function (data) {
                        processStudyData(data);
                        $scope.isStudyFetchingComplete=true;
                    }, function () {
                        $scope.isStudyFetchingComplete=true;
                        $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
                    });
                }
            };

            /**
             * Function to process study list data JSON for the following tasks:
             *  1. Assign the flag for already existing studies
             *  2. Add application ID to study
             *  3. Get patient study details
             * @param data: Response JSON from get study list API call.
             */
            function processStudyData(data){
                if(data) {
                    data = JSON.parse(JSON.stringify(data.responseList));
                    var selectedStudies = SelectedStudyListService.getList() || [];
                    var selectedPatient = SelectedStudyListService.getSelectedPatient();
                    if(selectedPatient.existingStudies){
                        selectedStudies = selectedStudies.concat(selectedPatient.existingStudies);
                    }
                    data = selectedStudies.length >= 1 ? setAttachment(data, selectedStudies) : data;
                    StudyListService.setStudyListData(data);
                    SelectedStudyListService.setSelectedPatient($scope.selectedPatient);
                    $scope.addAppIdToStudy();
                    $scope.getPatientStudyDetails();
                }
            }

            /**
             * togglePatients function
             *
             * @params patientData - First patient from the list
             * @params index - First Toggle patients css & show/hide
             */
            $scope.togglePatients = function(patientData, index) {
                // Disable showing patient list when clicking on active patient header info
                if (patientData.active && (typeof patientData.identifier === 'undefined')) {
                    return;
                }
                $scope.patientDataIsActive = patientData.active = !patientData.active;
                // Reset all studies when patient visibility is false
                for (var x = 0, xEnd = $scope.patients.length; x < xEnd; x++) {
                    if (patientData.active) {
                        // a patient was selected, so hide other patients
                        if (x !== index) {
                            $scope.patients[x].visible = false;
                        }
                    }
                    // patient was de-selected, so show all patients
                    else {
                        $scope.patients[x].visible = true;
                    }
                }
                // Enables the Attach Studies button on study selection
                $scope.setSubmitDisabledFlag = true;
                // if a patient was selected
                if ($scope.patientDataIsActive) {
                    $scope.currentPatientIndex = index;
                    $scope.search = $filter("translate")("pacsPatientList.patientList");
                    $scope.detailsDisplay = $filter("translate")("pacsPatientList.studyResults");
                    $scope.count = 0;
                    $scope.type = $filter("translate")("pacsPatientList.studies");
                    // Retrieves the patient studies by passing selected patient details
                    $scope.getPatientStudies(patientData);
                }
                // else - returning to patients list
                else {
                    $scope.search = $filter("translate")("pacsPatientList.search");
                    $scope.detailsDisplay = $filter("translate")("pacsPatientList.select");
                    $scope.count = $scope.patientCount;
                    $scope.type = $filter("translate")("pacsPatientList.patient");
                    // Hiding button on Patient list
                    $scope.isLocalPatientStudies = false;
                    // empty studies results
                    $scope.patientStudies = {};
                }
            };

            /**
             * Concatenate patient first name, middle name, last name for display purpose only
             */
            $scope.updatedPatientName = function(patient) {
                var patientName = "";
                if (patient && patient.name) {
                    patientName = $filter('name')(patient.name);
                }
                return patientName;
            };

            /**
             * getPatientStudies function @params:: patientData Gets studies of a patient
             */
            $scope.getPatientStudies = function(patientData) {
                $scope.studyListDisplayed = true;
                $scope.selectedPatient = patientData;
                $scope.selectedPatient.studyList=[];
                var dicomDevice=[];
                var pacsSearch=PacsSearchService.getPacsSearchParams();
                var selectedDicomDeviceList=pacsSearch.dicomDevices;
                dicomDevice.push(PacsSearchMarshaller.getDicomDetail(patientData.applicationServiceId));
                pacsSearch.dicomDevices=dicomDevice;
                if($scope.patientCount === 1){
                    var pacsSearchData = PacsSearchMarshaller.marshalStudySearchData(patientData,pacsSearch);
                    pacsSearch.dicomDevices=selectedDicomDeviceList;
                    if($scope.isStudyFetchingComplete){
                        $scope.isStudyFetchingComplete=false;
                        studyListXHR = StudyListService.studyList(pacsSearchData);
                        studyListXHR.promise.then(function (data) {
                            processStudyData(data);
                            $scope.isStudyFetchingComplete=true;
                        }, function () {
                            $scope.isStudyFetchingComplete=true;
                            $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
                        });
                    }
                }
            };

            /*
             * get Patient Studies
             */
            $scope.getPatientStudyDetails = function(){
                $scope.patientStudies = StudyListService.getStudyListData();
                $scope.count = $scope.patientStudies ? $scope.patientStudies.length : 0;
                $scope.type = ($scope.count === 1 ? $filter("translate")("pacsPatientList.study") : $filter("translate")("pacsPatientList.studies"));
                if ($scope.patients.length > 1) {
                    $scope.isLocalPatientStudies = true;
                } else {
                    $scope.isLocalPatientStudies = false;
                }
            };

            /**
             * toggle studies to select and unselect
             */
            var toggleStudies = function(selectedStudy) {
                if (selectedStudy.selected) {
                    $scope.selectedStudiesCount++;
                    // Disables the Attach Studies button on no study selection
                    $scope.setSubmitDisabledFlag = false;
                    $scope.selectedStudy.push(selectedStudy);
                } else {
                    var i = $scope.selectedStudy.length;
                    while (i--) {
                        if ($scope.selectedStudy[i].uid === selectedStudy.uid) {
                            $scope.selectedStudy.splice(i, 1);
                            $scope.selectedStudiesCount--;
                        }
                    }
                }
                if ($scope.selectedStudiesCount > attachedStudiesCount) {
                    $scope.setSubmitDisabledFlag = false;
                } else {
                    $scope.setSubmitDisabledFlag = true;
                }
            };

            /**
             * clickStudy function
             *
             * @params:: studyId - study id of a selected study
             * @params:: selected - Boolean value true(selected)/false(de-selected)
             */
            $scope.clickStudy = function(selectedStudy) {
                if (!selectedStudy.isAttached && $scope.patientStudies) {
                    selectedStudy.selected = !selectedStudy.selected;
                    for (var s = 0; s < $scope.patientStudies.length; s++) {
                        if ($scope.patientStudies[s].identifier === selectedStudy.identifier) {
                            $scope.patientStudies[s].isSelected = selectedStudy.selected;
                            toggleStudies(selectedStudy);
                            return;
                        }
                    }
                }
            };

            /**
             * navigateUp function Take user to the Patient List & Search screen on basis of condition
             */
            $scope.navigateUp = function() {
                if (!$scope.patientDataIsActive || (typeof $scope.patientDataIsActive === 'undefined') || ($scope.patientCount === 1)) {
                    PacsSearchMarshaller.resetOffset();
                    $state.transitionTo('caseexchange.pacsquery', {id : $stateParams.id});
                    //Cancel ongoing patient search ajax call
                    abortPacsSearchCall();
                } else {
                    if (studyListXHR) {
                        studyListXHR.xhr.abort();
                    }
                    // if a patient instance is active
                    $scope.selectedStudiesCount = $scope.selectedStudy ? $scope.selectedStudy.length : 0;
                    $scope.studyListDisplayed = false;
                    // Reset the study selection
                    $scope.deselectAllStudies();
                    if($scope.patientStudies){
                        for(var i=0; i< $scope.patientStudies.length;i++){
                            toggleStudies($scope.patientStudies[i]);
                        }
                    }

                    // Calling a method to display Patient list and unloads patient studies
                    $scope.togglePatients($scope.patients[$scope.currentPatientIndex], -1);
                    // Resets the offset before making API call
                    PacsSearchMarshaller.resetOffset();
                }
                if(!$scope.isAttachedFinally && SelectedStudyListService.getList().length===0){
                    SelectedStudyListService.clearSelectedPatient();
                }
            };

            /**
             * To show the error messages of ge patient list directive.
             */
            $scope.showMsg = function(msg, alertType){
                $scope.showAlertMessage(msg, alertType);
            };

            /**
             * To get all patients fetched in ge patient list directive
             */
            $scope.getAllPatients = function(allPatientlist, isFetched){
                if(isFetched){
                    $scope.patients = allPatientlist;
                }
            };

            /**
             * Function to de-select all the selected studies(if any)
             */
            $scope.deselectAllStudies = function() {
                if ($scope.patientStudies && $scope.patientStudies.length > 0) {
                    for (var i = 0, iEnd = $scope.patientStudies.length; i < iEnd; i++) {
                        // Set both the flag "isSelected" and "selected" as false
                        $scope.patientStudies[i].isSelected = false;
                        $scope.patientStudies[i].selected = false;
                    }
                }
            };

            /**
             * attachStudies function Attaches selected studies with the case and routes to main Create case screen
             */
            $scope.attachStudies = function() {
                if ($scope.selectedStudiesCount > 0) {
                    $scope.isAttachedFinally = true;
                    $scope.selectedStudy=$scope.selectedStudy.concat(SelectedStudyListService.getList());
                    SelectedStudyListService.setList($scope.selectedStudy);
                    //Cancel ongoing patient search ajax call
                    abortPacsSearchCall();
                    // Navigate back to Create case / Add to case screen.
                    $scope.navigateToCaseScreen();
                }
            };

            /**
             * Cancels pacs search and routes to create case
             */
            $scope.cancelPacsList = function() {
                //Cancel ongoing patient search ajax call
                abortPacsSearchCall();
                // Cancel the ongoing ajax call on click of cancel
                if (studyListXHR) {
                    studyListXHR.xhr.abort();
                }

                if(SelectedStudyListService.getSelectedPatient().studyList && SelectedStudyListService.getSelectedPatient().studyList.length > 0){
                    $scope.isAttachedFinally=true;
                }

                if(!$scope.isAttachedFinally){
                    SelectedStudyListService.clearSelectedPatient();
                    PacsSearchService.clearPacsSearchParams();
                }

                // Navigate back to Create case / Add to case screen.
                $scope.navigateToCaseScreen();
            };

            /**
             * Function to navigate to Create case OR Add to case screen based on mode.
             * Possible mode: 1. Create case  2. Add to case
             */
            $scope.navigateToCaseScreen = function(){
                /**
                 * Identify the correct screen to navigate to.
                 * Possible entry points for PACS Search Screen: 1. Create case 2. Add to case
                 * The value will only be present in the case exchange data service in case of Add to case OR Add users.
                 * Hence, checking if the value is set in the service will help identifying the correct screen to navigate to.
                 */
                if(CaseExchangeDataService.getCaseUpdateType() === 'ADDCASE'){
                    $state.transitionTo('caseexchange.updatecase', {id : $stateParams.id});
                } else {
                    $state.transitionTo('caseexchange.createcase', {id : $stateParams.id});
                }
            };

            /**
             * Add app id to each study details of the source PACS
             */
            $scope.addAppIdToStudy = function(){
                var studyList = StudyListService.getStudyListData()||[];

                for (var i = 0, len = studyList.length; i < len; i++) {
                    studyList[i].appid=$scope.selectedPatient.applicationServiceId;
                }
                StudyListService.setStudyListData(studyList);
            };

            /**
             * get name of pacs by pacs id from list of pacs
             */
            var getPacsName = function(pacsList,pacsId){
                if(pacsList){
                    for (var i = 0; i < pacsList.length; i++) {
                        if(pacsList[i].id===pacsId){
                            return pacsList[i].content.name;
                        }
                    }
                }
            };

            /**
             * display status of each pacs after all pacs search ajax call is completed
             * @param noRcrdPacsList: array with pacs name that didn't fetched any patient records
             * @param errorPacsList: array with pacs name which had issue while fetching records
             * @param successPacsList array with pacs name which successfully fetched records
             */
            var displayPacsStatusMsg = function(noRcrdPacsList, errorPacsList, successPacsList){
                var pacsStatusMsg="";
                //display name of pacs which didn't fetched any records
                if(noRcrdPacsList.length>0){
                    pacsStatusMsg=$filter('translate')('pacssearch.noRecordsFound',{
                        PACSNAME:noRcrdPacsList.toString().replace(/,/g,", ")
                    });
                }
                // display name of pacs which was not successfull
                if(errorPacsList.length>0 && successPacsList.length===0){
                    pacsStatusMsg=pacsStatusMsg+$filter('translate')('pacssearch.errorAccessingPacs',{
                        PACSNAME:errorPacsList.toString().replace(/,/g,", ")
                    });
                }
                //display name of pacs with error msg for pacs with resulted to unsuccesful seacrh action along with successfull pacs name
                if(errorPacsList.length>0 && successPacsList.length>0){
                    pacsStatusMsg=pacsStatusMsg+$filter('translate')('pacssearch.recordWithPartialSucess',{
                        SUCCESSPACS:successPacsList.toString().replace(/,/g,", "),
                        ERRORPACS:errorPacsList.toString().replace(/,/g,", ")
                    });
                }
                if(pacsStatusMsg!==""){
                    $scope.showAlertMessage(pacsStatusMsg, $scope.alertTypes.error);
                }

                if($scope.patients.length===0){
                    $state.transitionTo('caseexchange.pacsquery', {id : $stateParams.id});
                }

                if($scope.patients.length===1 && !$scope.isPatientClicked){
                    $scope.togglePatients($scope.patients[0], 0);
                }
            };

            /**
             * function that will return array of pacs name which failed while making ajax call
             */
            var getFailedPacs = function(){
                var errorPacs=[];
                var successPacsList=[];
                var totalPacsList=[];
                var pacsList=$stateParams.pacsSearchData.dicomDevices;
                for (var i = 0; i < pacsList.length; i++) {
                    totalPacsList.push(pacsList[i].content.name);
                }
                for (var j = 0; j < $scope.dicomStatusList.length; j++) {
                    successPacsList.push($scope.dicomStatusList[j].name);
                }
                errorPacs=totalPacsList.filter(function(i) { return successPacsList.indexOf(i) < 0; });
                return errorPacs;
            };

            /**
             * on bases of status of each pacs filter it to no record, error and succes arrays
             */
            var processPacsStatusMsg = function(){
                var noRcrdPacsList=[];
                var errorPacsList=[];
                var successPacsList=[];

                for (var i = 0; i < $scope.dicomStatusList.length; i++) {
                    if($scope.dicomStatusList[i].statusCode==="200"){
                        //success in ajax call but no record fetch
                        if($scope.dicomStatusList[i].count===0){
                            noRcrdPacsList.push($scope.dicomStatusList[i].name);
                        }
                        //success in ajax call and able to fetch data from pacs
                        if($scope.dicomStatusList[i].count>0){
                            successPacsList.push($scope.dicomStatusList[i].name);
                        }
                    }else if($scope.dicomStatusList[i].statusCode==="500"){
                        //succes in ajax call but micro service failed to get data from HCIG
                        errorPacsList.push($scope.dicomStatusList[i].name);
                    }
                }
                errorPacsList=errorPacsList.concat(getFailedPacs());
                displayPacsStatusMsg(noRcrdPacsList, errorPacsList, successPacsList);
            };

            /**
             * function to display count of pacs that has been processed
             */
            var setSinglePacsStatusMsg = function(count, pacsTotalCount){
                //show below message if all pacs search is not completed
                if(count!==pacsTotalCount){
                    $scope.consolidatedPacsStatusMsg=$filter('translate')('pacssearch.totalPacsSearchProcessing',{
                        ACTUALCOUNT:count,
                        TOTALCOUNT:pacsTotalCount
                    });
                }else {
                    //show below message if all pacs search is completed
                    $scope.consolidatedPacsStatusMsg=$filter('translate')('pacssearch.totalPacsSearchCompleted',{
                        ACTUALCOUNT:count,
                        TOTALCOUNT:pacsTotalCount
                    });
                }
            };

            /**
             * function to display message when any one of pacs return more than max
               allowed records that can be fetched
             */
            var displayLimitedPacsResultsetMsg = function(pacsName, pacsTotalCount){
                if(pacsTotalCount>PacsSearchMarshaller.getMaxAllowedPatient()){
                    $scope.pacsNameList.push(pacsName);
                    $scope.limitedPatientListMsg=$filter('translate')('pacssearch.limitedResultDisplayed',{
                        PACSNAME:$scope.pacsNameList.toString().replace(/,/g,", ")
                    });
                }
            };

            /**
             * function to display message when any one of pacs return more than max
               allowed records that can be fetched
             */
            var invokePacsSearchAPI = function(pacsSearchQuery, dicomDevice){
                var pacsSingleDicomSearch = angular.copy(pacsSearchQuery);
                pacsSingleDicomSearch.dicomDevices=[dicomDevice];

                var pacsSearchData = PacsSearchMarshaller.marshalPacsSearchData(pacsSingleDicomSearch);
                var pacsSearchXHR = PacsSearchService.pacsSearch(pacsSearchData);
                pacsSearchXHRList.push(pacsSearchXHR);

                pacsSearchXHR.promise.then(function (data) {
                    var dicomStatus={
                            id:"",
                            name:"",
                            statusCode:"",
                            count:0
                           };
                    //create a dicom status object to display pacs status message
                    _.each(data.errorCodeMap, function(value, key) {
                        dicomStatus.id=key;
                        dicomStatus.name=getPacsName(pacsSearchQuery.dicomDevices,key);
                        dicomStatus.statusCode=value;
                    });
                    dicomStatus.count=data.totalCount;
                    $scope.dicomStatusList.push(dicomStatus);

                    $scope.patients=$scope.patients.concat(data.responseList);
                    $scope.count=$scope.patientCount=$scope.patients.length;
                    $scope.dicomFetchCount++;
                    setSinglePacsStatusMsg($scope.dicomFetchCount,pacsSearchQuery.dicomDevices.length);
                    displayLimitedPacsResultsetMsg(dicomStatus.name,data.totalCount);
                    //calculate pacs progess completion in %
                    $scope.progressPercentage=($scope.dicomFetchCount/pacsSearchQuery.dicomDevices.length)*100;
                    //if all pacs search call is completed then process each pacs status for displaying on UI
                    if($scope.dicomFetchCount===pacsSearchQuery.dicomDevices.length){
                        processPacsStatusMsg();
                    }
                },function (error) {
                    if (error.statusText !== 'abort') {
                        $scope.dicomFetchCount++;
                        setSinglePacsStatusMsg($scope.dicomFetchCount,pacsSearchQuery.dicomDevices.length);
                        //calculate pacs progess completion in %
                        $scope.progressPercentage=($scope.dicomFetchCount/pacsSearchQuery.dicomDevices.length)*100;
                        //if all pacs search call is completed then process each pacs status for displaying on UI
                        if($scope.dicomFetchCount===pacsSearchQuery.dicomDevices.length){
                            processPacsStatusMsg();
                        }
                    }
                });
            };

            /**
             * function to make parallel pacs search ajax call
             */
            $scope.getPatientList = function(pacsSearchQuery) {
                $scope.patients=[];
                $scope.pacsNameList=[];
                $scope.limitedPatientListMsg="";
                $scope.count=0;
                $scope.dicomFetchCount=0;
                $scope.dicomStatusList = [];
                $scope.progressPercentage=0;
                for (var i = 0; i < pacsSearchQuery.dicomDevices.length; i++) {
                    invokePacsSearchAPI(pacsSearchQuery,pacsSearchQuery.dicomDevices[i]);
                }
            };

            /**
             * navigate user back to pacs search screen
             */
            $scope.goToPacsSearchScreen = function() {
                $state.transitionTo('caseexchange.pacsquery', {id : $stateParams.id});
            };

            /**
             * init function Displying study list if only one patient after DICOMDIR parsing
             */
            $scope.init = function() {
                var pacsSearchQuery = $stateParams.pacsSearchData;
                PacsSearchService.setPacsSearchParams(pacsSearchQuery);
                $scope.getPatientList(pacsSearchQuery);
            };

            $scope.init();
        }]);
});
