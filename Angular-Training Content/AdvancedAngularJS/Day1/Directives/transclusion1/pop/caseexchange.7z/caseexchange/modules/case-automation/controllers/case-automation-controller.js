/*
 * case-automation-controller.js
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */

/**
 * A Case Automation controller to handle case automation related operations.
 */
define(['angular', 'postal',
    '../../../module'], function (ng) {
    'use strict';

    // Module dependencies
    var dependencies = ['Services.caseAutomationService',
                        'Services.getSitesService',
                        'Services.caseAutomationDataService',
                        'Services.instructionConditionMarshallerService',
                        'Services.getInstructionConditionsService',
                        'Services.caseExchangeDataService'];

    var caseInstruction = ng.module('cloudav.caseExchange.caseAutomationCtrl',dependencies);

    caseInstruction.controller('CaseAutomationCtrl',['$scope', '$state', '$stateParams', '$filter', 'CaseAutomationService', 'GetSitesServices', 'CaseAutomationDataService', '$modal', 'InstructionConditionMarshallerService', 'GetInstructionConditionsService', 'CaseExchangeDataService', function($scope, $state, $stateParams, $filter, caseAutomationService, getSitesServices, caseAutomationDataService, $modal, instructionConditionMarshallerService, getInstructionConditionsService, caseExchangeDataService) {
        var getCaseIntsListXHR;

       /**
        * load existing case instruction list
        */
        $scope.getCaseInstList = function() {
            $scope.showCaseListSpinner=true;
            $scope.isFetchingInstList=true;
            caseAutomationDataService.setSelectedSite($scope.selectedSite);
            if(getCaseIntsListXHR) {
                getCaseIntsListXHR.xhr.abort();
            }
            getCaseIntsListXHR = caseAutomationService.getCaseAutomationInstructions($scope.getCaseInstOffsetVal, $scope.getCaseInstLimitVal, $scope.selectedSite.id);
            getCaseIntsListXHR.promise.then(function(data) {
                if(data){
                    data=$scope.getCaseInstDescription(data);
                    $scope.caseInstructionList=$scope.caseInstructionList.concat(data);
                    if(data.length<$scope.getCaseInstLimitVal || data.length===0){
                        $scope.lastInstListFetched=true;
                    }
                }
                $scope.getCaseInstOffsetVal=$scope.getCaseInstOffsetVal+$scope.getCaseInstLimitVal;
                $scope.showCaseListSpinner=false;
                $scope.isFetchingInstList=false;
            },
                function(error) {
                    if(error.statusText!=='abort'){
                        $scope.showCaseListSpinner=false;
                        $scope.isFetchingInstList=false;
                        $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
                    }
            });
        };

        /**
         * function to receive pending case instruction on scroll
         */
        $scope.getPendingCaseInstList = function() {
            if (!($scope.lastInstListFetched || $scope.isFetchingInstList) && $scope.selectedSite) {
                $scope.getCaseInstList();
            }
        };

        /**
         * open case instruction page
         */
        $scope.openCreateInstruction = function() {
            $state.transitionTo('caseexchange.createinstruction', {id : $stateParams.id});
        };


        /**
         * function to get site details
         */
        $scope.getSiteDetails = function() {
            $scope.showsiteListSpinner=true;
            getSitesServices.getSiteList().then(function(data) {
                $scope.siteList=data.entry;
                $scope.showsiteListSpinner=false;
                $scope.resetSiteInstList();
            }, function(){
                $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
                $scope.showsiteListSpinner=false;
            });
        };

        /**
         * function which will pre load site drop down and it respective
         * instruction if site id is present in state param
         */
         $scope.resetSiteInstList = function(){
             if($stateParams.selectedSite.id && $scope.siteList){
                 for(var i = 0; i < $scope.siteList.length; i++){
                     if($stateParams.selectedSite.id===$scope.siteList[i].id){
                         $scope.selectedSite=$scope.siteList[i];
                         $scope.getCaseInstList();
                     }
                 }
             }
         };

        /**
         * function to get instruction based on sites
         */
        $scope.showInstructionList = function(){
            $scope.caseInstructionList=[];
            $scope.getCaseInstLimitVal=10;
            $scope.getCaseInstOffsetVal=0;
            $scope.lastInstListFetched=false;
            if($scope.selectedSite){
                $scope.getCaseInstList();
            }
        };

        /**
         * function to show activate/suspend modal on click of activate/suspend button click
         */
        $scope.openActivateSuspendPopup=function(instruction){
            $scope.modalInstance=$modal.open({
                templateUrl : './modules/caseexchange/modules/case-automation/views/case-activate-suspend-popup.html',
                scope : $scope
            });

            $scope.instruction = instruction;
            $scope.statusOfInstruction = instruction.status === 'ACTIVE' ? $filter('translate')('caseAutoInstrList.suspend'): $filter('translate')('caseAutoInstrList.activate');

            $scope.title=$filter('translate')('activateSuspendPopup.title',{STATUSOFINSTRUCTION:$scope.statusOfInstruction});

            $scope.confirmationText=$filter('translate')('activateSuspendPopup.confimationText',{
                STATUSOFINSTRUCTION:$scope.statusOfInstruction,
                INSTRUCTIONNAME:instruction.name
            });
        };

       /**
        * function to activate or suspend instruction
        */
        $scope.saveInstructionState = function() {
            var status = $scope.instruction.status.toUpperCase()==="SUSPENDED" ? "ACTIVE":"SUSPENDED";
            var success = $scope.instruction.status.toUpperCase()==="SUSPENDED" ? 'activeSuccess' : 'suspendSuccess';
            $scope.close();

            var setStatusInstXHR = caseAutomationService.caseInstructionCurdOperation('PATCH', $scope.instruction.id,
                    [{"op": "replace", "path": "/status", "value": status}]);
            setStatusInstXHR.promise.then(function() {
                $scope.instruction.status = status;
                $scope.showAlertMessage($filter('translate')('activateSuspendPopup.'+ success), $scope.alertTypes.success);
            },
            function() {
                $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
            });
        };

        /*
         * close normalization confirmation dialog box
         */
        $scope.close=function(){
            $scope.modalInstance.dismiss();
        };

        /**
         * method to call service to get supported diocm condition.
         */
        $scope.getDicomCondition = function() {
            var getConditionKeyListXHR = getInstructionConditionsService.getConditionKeyList();
            getConditionKeyListXHR.promise.then(function(data) {
                $scope.conditionKeyList = data;
            }, function() {
                $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
            });
        };

        var getValueFromKey = function(condition, conditionAttribute){
            for(var k = 0; k < conditionAttribute.length; k++){
                if(condition === conditionAttribute[k].key){
                    return conditionAttribute[k].value;
                }
            }
        };

        /**
         * method to create instruction description based on condition and post processing condition
         * saved by user.
         */
        $scope.getCaseInstDescription = function(data) {
            var instList = data;
            var description = "";
            var condition = [];

            for (var i = 0; i < instList.length; i++) {
                description = "";
                condition = instructionConditionMarshallerService.unmarshalCondition(instList[i].condition);
                for (var j = 0; j < condition.length; j++) {
                    description = description + " " + getValueFromKey(condition[j].key, $scope.conditionKeyList);
                    description = description + " " + getValueFromKey(condition[j].type, $scope.ConditionTypeList).toLowerCase();
                    description = description + " " + condition[j].value;

                    if (condition[j + 1]) {
                        description = description + " " + getValueFromKey(condition[j + 1].boolean, $scope.conditionBooleanList).toLowerCase();
                    }
                }
                instList[i].description = $filter('translate')('createInstruction.instDescription', {
                    INSTDESCRIPTION : description
                });
            }
            return instList;
        };

        /*
        * Function to show case automation to admin users.
        */
        var proceedToCaseAutomation = function() {
            $scope.getCaseInstLimitVal = 10;
            $scope.getCaseInstOffsetVal = 0;
            $scope.caseInstructionList = [];
            $scope.getSiteDetails();
            $scope.getDicomCondition();
            //conditions boolean list
            $scope.conditionBooleanList = instructionConditionMarshallerService.getBooleanCondition();
            //conditions type list
            $scope.ConditionTypeList = instructionConditionMarshallerService.getConditionTypes();
        };

        /*
        * Function to checking role of current user.
        * Only Admin users will be allowed to access case automation, other users will be redirected to case inbox.
        */
        var checkCurrentUserRole = function() {
            var currentUser = caseExchangeDataService.getCurrentUser();
            if (!currentUser) {
                caseExchangeDataService.queryCurrentUser().then(function(currentUser) {
                        if (!hasRoles(currentUser)) {
                            return redirectToCaseInbox();
                        }
                        caseExchangeDataService.setCurrentUser(currentUser);

                        //Checks if logged in user is Administrator
                        if (currentUser.isAdmin()) {
                            proceedToCaseAutomation();
                        }
                    },
                    function() {
                        $scope.showAlertMessage($filter('translate')('common.accessDenied'), $scope.alertTypes.error);
                    });
            } else {
                // Checks if logged in user is Administrator
                if (hasRoles(currentUser) && currentUser.isAdmin()) {
                    proceedToCaseAutomation();
                } else {
                    return redirectToCaseInbox();
                }
            }

            /**
             * Check if user has any roles assigned
             * @param currentUser: Current user object
             * @returns boolean: true if there is at-least one role assigned to user, else false.
             */
            function hasRoles(currentUser) {
                return currentUser && currentUser.role && currentUser.role.length > 0;
            }

            /**
             * Function to redirect to case inbox
             */
            function redirectToCaseInbox() {
                $state.transitionTo('caseexchange.caseinbox', {
                    id: $stateParams.id
                });
                $scope.showAlertMessage($filter('translate')('common.accessDenied'), $scope.alertTypes.error);
            }

        };
        $scope.init = function() {
            checkCurrentUserRole();
        };

        $scope.init();
        }
    ]);

});