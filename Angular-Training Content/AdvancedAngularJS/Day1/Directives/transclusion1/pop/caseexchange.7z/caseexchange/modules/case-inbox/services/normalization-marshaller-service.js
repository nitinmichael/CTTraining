/*
 *  normalization-marshaller-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * A factory that provides methods for marshaling normalized patient and study to be shared into the format expected by the microservice.
 */
define(['angular'], function () {

    // Normalization marshaller Module
    var mod = angular.module('Services.normalizationMarshallerService', []);

    /**
     * A factory that provides method for marshaling data related to selected device and selected studies
     * of that patient to be shared into the format expected by the REST API.
     */
    mod.factory('NormalizationMarshallerService', [function () {

        /**
         * Marshals the case attachment data to be pushed into download case JSON.
         *
         * @param studyAttachments
         *    studyAttachments to be added in download case object.
         * @param pacsDevices
         *    pacsDevices to be added in download case object.
         */
        function marshallNormalizeServices(selectedPatient, studyAttachments, pacsDevices) {
            var data, patient, applicationService;
            var attachments = [];

            data={
                      "operationId": "",
                      "operationType": "NORMALIZE"
                 };

            if(selectedPatient){
                patient ={
                             "identifier": selectedPatient.patientId,
                              "birthDate": new Date(selectedPatient.dob).getTime(),
                              "gender": selectedPatient.gender,
                              "name": {
                                  "firstName": selectedPatient.name.firstName,
                                  "middleName": selectedPatient.name.middleName,
                                  "lastName": selectedPatient.name.lastName
                              }
                         };
            }

            if (studyAttachments && studyAttachments.length !== 0) {
                for (var i = 0; i< studyAttachments.length; i++) {

                    var study = {
                                    "type": "ImagingStudy",
                                    "identifier": studyAttachments[i].identifier,
                                    "uid": studyAttachments[i].uid,
                                    "accessionNo": studyAttachments[i].accession
                                };
                    attachments.push(study);
                }
            }

            if (pacsDevices) {
                applicationService = {
                                          "id": pacsDevices.id,
                                          "endpoint": pacsDevices.content.endpoint,
                                          "attachments": attachments
                                     };
            }

            data.patient=patient;
            data.applicationService=applicationService;

            return data;
        }

        /**
         * Convert FHIR patient json to normalization json.
         *
         * @param patient
         *    patient json in FHIR format.
         */
        function convertFHIRToPatientJson(patient) {
            var newPatient={};
            if(patient){
                if(patient.name){
                    newPatient.lastName = (patient.name.family && patient.name.family instanceof Array) ? patient.name.family.join(' ') : '';
                    newPatient.firstName = (patient.name.given && patient.name.given instanceof Array) ? patient.name.given[0] : '';
                    newPatient.middleName = (patient.name.given && patient.name.given instanceof Array && patient.name.given.length > 1) ? patient.name.given[1] : '';
                }
                newPatient.id=patient.identifier;
                newPatient.age=patient.age;
                newPatient.dob=patient.birthDate;
                newPatient.gender=patient.gender;
            }
            return newPatient;
        }

        return {
            marshallNormalizeServices: marshallNormalizeServices,
            convertFHIRToPatientJson : convertFHIRToPatientJson
        };
    }]);
});