/*
 * instruction-condition-marshaller-service.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */

define([ 'angular' ], function() {
    // Module Definition
    var mod = angular.module('Services.instructionConditionMarshallerService', []);

    mod.factory('InstructionConditionMarshallerService', [ '$filter', function($filter) {

        // convert condition array to condition json as expected by microservice
        function marshalCondition(conditionJson) {
            var conditionList = conditionJson;
            var condition = {};
            var currentCondition = {};

            for (var i = 0; i < conditionList.length; i++) {
                var perviousCondition = currentCondition["conditionOne"];

                condition = {
                    "type" : conditionList[i].type.key,
                    "key" : conditionList[i].key.key,
                    "value" : conditionList[i].value
                };

                if(condition.key ==="00080090" || condition.key==="00081050"){
                    condition.value=condition.value.replace(/[\s]*,[\s]*/g,"^").trim();
                }

                if (i > 0) {
                    currentCondition = {
                        "conditionOne" : {
                            "type" : conditionList[i].boolean.key,
                            "conditionOne" : perviousCondition,
                            "conditionTwo" : condition
                        }
                    };
                }else {
                    currentCondition = {
                        "conditionOne" : condition
                    };
                }
            }

            condition = currentCondition["conditionOne"];
            condition = {
                "condition" : condition
            };
            return condition;
        };

       /*
        * Function to replace caret with comma
        */
        function caretReplace(key,value) {
            if(key ==="00080090" || key==="00081050"){
                return value.replace(/\^/g,",");
             }
            return value;
        };

        // convert condition json as received from microservice to condition array
        function unmarshalCondition(conditionJson) {
            var conditionList = [];
            var conditionOne = conditionJson;
            while (conditionOne["conditionTwo"]) {
                var conditionTwo = conditionOne["conditionTwo"];

                var instCondition = {
                    boolean : conditionOne.type,
                    key : conditionTwo.key,
                    type : conditionTwo.type,
                    value : conditionTwo.value
                };

                instCondition.value = caretReplace(instCondition.key, instCondition.value);

                conditionList.push(instCondition);
                conditionOne = conditionOne["conditionOne"];
            }

            instCondition = {
                boolean : "",
                key : conditionOne.key,
                type : conditionOne.type,
                value : conditionOne.value
            };

            instCondition.value = caretReplace(instCondition.key, instCondition.value);

            conditionList.push(instCondition);
            return conditionList.reverse();
        };

        // retrun condition skeleton json
        function getConditionSkeleton() {
            return {
                boolean : "",
                booleanInvalid : false,
                key : "",
                keyInvalid : false,
                type : "",
                typeInvalid : false,
                value : "",
                valueInvalid : false,
                maxlength :"",
                errormsg:"",
                conditionTypeList:""
            };
        };

        // get boolean condition list
        function getBooleanCondition() {
            return [{
                key: "AND",
                value: $filter('translate')('instructionConditions.andCondition')
            }, {
                key: "OR",
                value: $filter('translate')('instructionConditions.orCondition')
            }];
        };

     // get condition type list
        function getConditionTypes() {
            return [{
                key: "EQUALS",
                value: $filter('translate')('instructionConditions.equalsCondition')
            }, {
                key: "CONTAINS",
                value: $filter('translate')('instructionConditions.containsCondition')
            }, {
                key: "ISNOT",
                value: $filter('translate')('instructionConditions.isNotCondition')
            }];
        };

        // get dicom attribute validation parameter
        function getDicomAttrValidationParam() {
            return {
            "00080060": {
                "maxlength": "",
                "minlength":""
              },
              "00080090": {
                "maxlength": "200",
                "minlength":"64"
              },
              "00081030": {
                "maxlength": "64",
                "minlength":""
              },
              "00081050": {
                "maxlength": "200",
                "minlength":"64"
              }
            };
        };

        // get dicom attribute validation parameter
        function getValidDicomValues() {
            return ["CT","MR","SCPT","US"];
        };

        return {
            marshalCondition : marshalCondition,
            unmarshalCondition : unmarshalCondition,
            getConditionSkeleton : getConditionSkeleton,
            getBooleanCondition : getBooleanCondition,
            getConditionTypes : getConditionTypes,
            getDicomAttrValidationParam : getDicomAttrValidationParam,
            getValidDicomValues : getValidDicomValues
        };
    }]);
});