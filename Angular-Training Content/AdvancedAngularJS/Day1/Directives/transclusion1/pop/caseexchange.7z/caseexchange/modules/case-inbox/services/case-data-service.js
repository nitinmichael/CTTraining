/*
 *  case-data-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular'], function () {

    // Module Dependencies
    var dependencies = ['Services.caseExchangeDataService'];

    // Module Definition
    var mod = angular.module('CaseDataSvc', dependencies);

    /**
     * @name CaseDataService
     * @type factory
     *
     * @description
     * A factory that provides methods for making request to the Create Case REST API to post the data.
     */
    mod.factory('CaseDataService', ['CaseExchangeDataService', '$q', '$log', function (caseExchangeDataService, $q, $log) {
        // String constant for case priority
        var casePriority = {
            HIGH: 'HIGH'
        };

        /**
         * Makes a call to case reader service to retrieve case list, passing
         * inboxtype, offset and limit parameters
         */
        function getCaseHeaders(inboxType, offset, limit, searchString, caseFilters, caseType) {
            /**
             * Base url for making request to the Create Case REST API.
             */
            var CASE_DATA_URL = caseExchangeDataService.getServiceURL() + '/casereader/v1/case?';

            var inboxTypeParam = inboxType || 'ALL';
            // default offset value
            var offsetParam = offset || 0;
            // default size query result
            var limitParam = limit || 20;
            //default case type value
            var caseTypeParam = caseType || 'NORMAL';
            var requestURL = CASE_DATA_URL
                + 'inboxtype=' + inboxTypeParam
                + '&offset=' + offsetParam
                + '&limit=' + limitParam
                + '&casetype=' + caseTypeParam
                + (searchString !== null ? '&search=' + searchString : '')
                + (caseFilters.HIGH_PRIORITY_CASES ? '&priority=' + casePriority.HIGH : '')
                + (caseFilters.CASE_STATE !== "ALL_STATES" ? (caseFilters.CASE_STATE === "REVIEWED" ? '&reviewed=' + true : '&reviewed=' + false) : '');

            var deferred = $q.defer();

            $.ajax({
                async: true,
                contentType: 'application/json',
                type: 'get',
                url: requestURL,
                success: success,
                error: error
            });

            return deferred.promise;

            function success(data) {
                $log.log('Success: CaseDataService: getCaseHeaders');
                var response = data || null;
                deferred.resolve(response);
            }

            function error(jqXHR, textStatus, errorThrown) {
                var errorMsg = 'Error: CaseDataService: getCaseHeaders : ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }
        }

        /**
         * Makes a call to case reader service to retrieve case details by passing caseId
         */
        function getCaseDetails(caseId) {

            var deferred = $q.defer();

            // Case Details URL
            var CASE_DETAILS_URL = caseExchangeDataService.getServiceURL() + '/casereader/v1/case/';

            $.ajax({
                async: true,
                contentType: 'application/json',
                type: 'get',
                url: CASE_DETAILS_URL + caseId,
                success: success,
                error: error
            });

            return deferred.promise;

            function success(data) {
                $log.log('Success: CreateCaseService: caseDetails');
                var response = data || null;
                deferred.resolve(response);
            }

            function error(jqXHR, errorThrown) {
                var errorMsg = 'Error: CreateCaseService: caseDetails: ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }
        }

        /**
         * Makes a call to case writer service to mark a case as reviewed
         */
        function markCaseAsReviewed(caseId) {

            var deferred = $q.defer();

            // Mark Case As Reviewed URL
            var MARK_CASE_AS_REVIWED_URL = caseExchangeDataService.getServiceURL() + '/casewriter/v1/case/' + caseId + '/reviewed';

            $.ajax({
                async: true,
                contentType: 'application/json',
                type: 'post',
                url: MARK_CASE_AS_REVIWED_URL,
                success: success,
                error: error
            });

            return deferred.promise;

            function success(data) {
                $log.log('Success: CaseDataService: markCaseAsReviewed');
                var response = data || null;
                deferred.resolve(response);
            }

            function error(jqXHR, errorThrown) {
                var errorMsg = 'Error: CaseDataService: markCaseAsReviewed: ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }
        }

        return {
            getCaseHeaders: getCaseHeaders,
            getCaseDetails: getCaseDetails,
            markCaseAsReviewed: markCaseAsReviewed
        };
    }]);
});
