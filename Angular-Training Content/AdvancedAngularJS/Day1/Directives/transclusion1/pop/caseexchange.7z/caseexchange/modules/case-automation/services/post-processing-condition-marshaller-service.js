/*
 * post-processing-condition-marshaller-service.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */

define(['angular'], function() {
    // Module Definition
    var mod = angular.module('Services.postProcessingConditionMarshallerService', []);

    mod.factory('PostProcessingConditionMarshallerService', function() {
            // convert condition array to condition json as expected by microservice
            function marshalCondition(condition) {
                var currentCondition = {
                    "type": "AND",
                    "conditionOne": {
                        "type": "AND",
                        "conditionOne": {
                            "type": "CONTAINS",
                            "key": "00080090",
                            "value": condition.modality
                        },
                        "conditionTwo": {
                            "type": "CONTAINS",
                            "key": "00081030",
                            "value": condition.description
                        }
                    },
                    "conditionTwo": {
                        "type": "EQUALS",
                        "key": "Algorithm",
                        "value": condition.algorithm.value
                    }
                };
                return currentCondition;
            };

            // convert condition json as received from microservice to condition array
            function unmarshalCondition(currentCondition) {
                var condition,
                    conditionOne = currentCondition.conditionOne.conditionOne,
                    conditionTwo = currentCondition.conditionOne.conditionTwo;

                    condition = {
                        "algorithm": currentCondition.conditionTwo.value,
                        "modality": conditionOne.value,
                        "description": conditionTwo.value
                    };

                return condition;
            };

            // get condition type list
            function getAlgoTypes() {
                return [{
                    "key": "ALGO1",
                    "value": "Neuroquant",
                    "modality":"MR"
                }, {
                    "key": "ALGO2",
                    "value": "CortexID",
                    "modality":"PET"
                }];
            };

            return {
                marshalCondition: marshalCondition,
                unmarshalCondition: unmarshalCondition,
                getAlgoTypes: getAlgoTypes
            };
        });
});