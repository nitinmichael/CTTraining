/*
 *  case-automation-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular'], function(){

    // Module Dependencies
    var dependencies = ['Services.caseExchangeDataService'];

    //Module Definition
    var mod = angular.module('Services.caseAutomationService',dependencies);

    mod.factory('CaseAutomationService', ['CaseExchangeDataService', '$q', '$log', function(caseExchangeDataService, $q, $log){

        //Ajax call to fetch case automation instruction list
        function getCaseAutomationInstructions(offset, limit, siteid) {
            var CASE_AUTO_INSTRUCTION_URL = caseExchangeDataService.getServiceURL() + '/caseautomation/v1/instruction';

            var deferred = $q.defer();

            var xhr = $.ajax({
                async: true,
                contentType: 'application/json',
                dataType: 'json',
                data:{limit:limit, offset:offset , siteId:siteid},
                type: 'get',
                url: CASE_AUTO_INSTRUCTION_URL,
                success: success,
                error: error
            });

            return { xhr: xhr, promise: deferred.promise };

            function success(data) {
                $log.log('Success: CaseAutomationService: getCaseAutomationInstructions');
                var response = data || null;
                deferred.resolve(response);
            }

            function error(jqXHR, textStatus, errorThrown) {
                var errorMsg = 'Error: CaseAutomationService: getCaseAutomationInstructions: ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }

        };

        // AJAX call for instruction create, update, read and delete
        function caseInstructionCurdOperation(operation, instructionId, instructionJson) {
            var INSTRUCTION_CRUD_URL = caseExchangeDataService.getServiceURL() + '/caseautomation/v1/instruction';
            var xhr;

            var deferred = $q.defer();

            if (instructionId) {
                INSTRUCTION_CRUD_URL = INSTRUCTION_CRUD_URL+"/"+instructionId;
            }

            if (instructionJson) {
                xhr = $.ajax({
                    async : true,
                    contentType : 'application/json',
                    data : JSON.stringify(instructionJson),
                    type : operation,
                    url : INSTRUCTION_CRUD_URL,
                    success : success,
                    error : error
                });
            } else {
                xhr = $.ajax({
                    async : true,
                    contentType : 'application/json',
                    type : operation,
                    url : INSTRUCTION_CRUD_URL,
                    success : success,
                    error : error
                });
            }

            return { xhr : xhr, promise : deferred.promise };

            function success(data) {
                $log.log('Success: CaseAutomationService: caseInstructionCurdOperation');
                var response = data || null;
                deferred.resolve(response);
            }

            function error(jqXHR, textStatus, errorThrown) {
                var errorMsg = 'Error: CaseAutomationService: caseInstructionCurdOperation: ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }
        };

        return {
            getCaseAutomationInstructions : getCaseAutomationInstructions,
            caseInstructionCurdOperation : caseInstructionCurdOperation
        };
    }]);
});