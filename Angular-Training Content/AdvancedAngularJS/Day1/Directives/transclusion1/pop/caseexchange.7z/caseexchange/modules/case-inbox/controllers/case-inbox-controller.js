/*
 *  case-inbox-controller.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * A Case Inbox controller to handle case related operations.
 */
define(
    ['angular', 'angularTranslate', '../../../module'],
    function (ng) {
        'use strict';

        // Case Inbox Controller module
        var caseinbox = ng.module('cloudav.caseExchange.caseInboxCtrl', [
            'CaseDataSvc',
            'Services.pacsSearchService',
            'Services.selectedStudyListService',
            'Services.createCaseDataService',
            'pascalprecht.translate',
            'Services.caseExchangeDataService',
            'Services.getPacsServices',
            'Services.getBillingOrganizationsService'
        ]);

        // Case Inbox Controller
        caseinbox.controller('CaseInboxCtrl', [
            '$scope',
            '$filter',
            '$state',
            '$stateParams',
            '$location',
            '$timeout',
            'CaseDataService',
            'PacsSearchService',
            'SelectedStudyListService',
            'CreateCaseDataService',
            'CaseExchangeDataService',
            'GetPacsServices',
            'GetBillingOrganizationsService',
            function ($scope,
                      $filter,
                      $state,
                      $stateParams,
                      $location,
                      $timeout,
                      caseDataService,
                      PacsSearchService,
                      SelectedStudyListService,
                      CreateCaseDataService,
                      caseExchangeDataService,
                      GetPacsServices,
                      getBillingOrganizationsService) {
                // Value will be assigned when user selects a case from case list
                $scope.selectedCase = null;

                // Object to get the selected case from generic case list.
                $scope.selectedItemObj = {value: ''};

                // Holds patient data available in case
                $scope.patientData = null;

                // An array to store case list fetched from API
                $scope.cases = [];

                // An object to hold case detailes
                $scope.caseDetails = null;

                // flag for active case microservice call
                $scope.isFetchingCases = false;

                $scope.lastCaseFetched = false;

                // Flag to display the Case Summary View
                $scope.showDetails = false;

                // initial download to premise state
                $scope.downloading = false;

                // flag to load 'module' class during loading of Normalization screen
                $scope.normalize = false;

                // Search text from input field
                $scope.search = {"text": null};

                // Tracks what the current inbox search query is
                $scope.lastQuery = null;

                // Initializing blank error message
                $scope.errorMessage = '';

                // Boolean determining whether or not the current user is a patient
                $scope.isCurrentUserPatient = false;

                // String constants for case update type
                $scope.caseUpdateType = {
                    ADD_CASE: 'ADDCASE',
                    ADD_USERS: 'ADDUSERS'
                };

                // Object containing case filter types
                $scope.caseFilterTypes = {
                    CASE_TYPE: 'ALL',
                    CASE_STATE: 'ALL_STATES',
                    HIGH_PRIORITY: false
                };

                // variable to hide/show the case summary details
                $scope.isFetchingCase = false;

                // Attachment Types
                $scope.attachmentType = {
                    DICOM: 'ImagingStudy',
                    NONDICOM: 'DocumentReference'
                };

                // Flag to turn on/off case inbox display
                $scope.loadUI = false;

                // Number of particpants left to mark case as reviewed
                $scope.participantsLeftToReview = -1;

                var status = {
                    COMPLETED: 'COMPLETED'
                };

                /**
                 * Boolean flag to indicate if patient banner is showing more details
                 * @type boolean
                 */
                $scope.showingMoreDetailsOnPatientBanner = false;

                $scope.loadingInProgress = $scope.isFetchingCases || $scope.isSearchingCases;

                /**
                 * Function to toggle the visibility of extra details on patient module.
                 */
                $scope.togglePatientBannerDetails = function () {
                    $scope.showingMoreDetailsOnPatientBanner = !$scope.showingMoreDetailsOnPatientBanner;
                };


                /**
                 * Function to redirect to case inbox
                 */
                function redirectToCaseInbox() {
                    $state.transitionTo('caseexchange.caseinbox', {
                        id: $stateParams.id
                    });
                    $scope.showAlertMessage($filter('translate')('createcase.noOrganizationWarning'), $scope.alertTypes.error);
                }

                /**
                 * checks whether logged in user have at list 1 organization,
                 * if not then it will redirect to case inbox page
                 */
                $scope.launchCreateCase = function () {
                    getBillingOrganizationsService.getOrganizationsForLoggedInUser().then(function(data){
                        $scope.billingOrganizationList = _.map(data.role, function(val){
                            return val.scopingOrganization;
                        });
                        //redirect to Case Inbox if no organization is present, else open up create case page
                       ($scope.billingOrganizationList.length < 1)?redirectToCaseInbox():$scope.launchCreateCaseView();
                    }, function(){
                        redirectToCaseInbox();
                    });
                };

                /**
                 * Routes to create case page
                 */
                $scope.launchCreateCaseView = function(){
                    SelectedStudyListService.clearSelectedPatient();
                    PacsSearchService.clearPacsSearchParams();
                    CreateCaseDataService.clearCreateCaseData();
                    caseExchangeDataService.resetSelectedCaseData();
                    caseExchangeDataService.resetCaseUpdateType();
                    caseExchangeDataService.resetSelectedCaseDetails();
                    $state.transitionTo('caseexchange.createcase', {
                        id: $stateParams.id,
                        billingOrganizationList: $scope.billingOrganizationList
                    });
                };

                /**
                 * show add attachments form
                 */
                $scope.updateCase = function (caseType) {
                    if($scope.selectedCase.status === status.COMPLETED) {
                        SelectedStudyListService.clearSelectedPatient();
                        PacsSearchService.clearPacsSearchParams();
                        CreateCaseDataService.clearCreateCaseData();

                        //TODO show add attachments form
                        // Sets the case update type for case update purpose
                        caseExchangeDataService.setCaseUpdateType(caseType);

                        caseExchangeDataService.setSelectedCaseData($scope.selectedCase);
                        $state.transitionTo('caseexchange.updatecase', {id: $stateParams.id});
                    }
                };

                // default values for offset and limit
                $scope.offset = 0;
                $scope.limit = 20;

                // Gets the current user's ID
                var getCurrentUserId = function () {
                    var currentUser = caseExchangeDataService.getCurrentUser();

                    // Extract the current user's ID
                    if (currentUser.externalId && currentUser.externalId instanceof Array) {
                        for (var idlength = currentUser.externalId.length, i = 0; i < idlength; i++) {
                            var current = currentUser.externalId[i];
                            if (current.system === "UOM") {
                                return current.value;
                            }
                        }
                    }
                };

                // Sets whether or not the current user has reviewed the selected case
                // (This is for when we get case details)
                var setHasCurrentUserReviewedCase = function (currentCase) {
                    var currentUserId = getCurrentUserId();

                    if (currentUserId) {
                        // Find the ID within the list of participants
                        $(currentCase.participants).each(function (i, e) {
                            if (e.user.identifier === currentUserId) {
                                currentCase.hasCurrentUserReviewedCase = e.reviewed;
                                return false;
                            }
                        });
                    }
                };

                // Counts the number of participants who have yet to review the case
                var setParticipantsLeftToReview = function (data) {
                    var result = 0;
                    $(data.participants).each(function (i, e) {
                        if (!e.reviewed) {
                            result++;
                        }
                    });
                    $scope.participantsLeftToReview = result;
                };

                // Method for marking a case as reviewed
                $scope.markCaseAsReviewed = function () {
                    if (!$scope.selectedItemObj.selectedItem.hasCurrentUserReviewedCase) {
                        caseDataService.markCaseAsReviewed($scope.selectedItemObj.selectedItem.id).then(function (data) {
                            setParticipantsLeftToReview(data);
                            $scope.selectedItemObj.selectedItem.hasCurrentUserReviewedCase = true;
                            $scope.selectedCase.hasCurrentUserReviewedCase = true;
                        },function(){
                            $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
                        });
                    }
                };

                // For each case, track whether or not the current user has reviewed that case
                // (This is for when we get all cases)
                var setWhichCasesCurrentUserHasReviewed = function (cases) {
                    $(cases).each(function (index, element) {
                        setHasCurrentUserReviewedCase(element);
                    });
                };

                /**
                 * Searches for last selected case and open it
                 */
                var findLastSelectedCase = function () {
                    var caseFound = false;
                    $scope.loadingCases = true;
                    for (var i = 0, iEnd = $scope.cases.length; i < iEnd; i++) {
                        if ($scope.cases[i].id === caseExchangeDataService.getSelectedCaseDetails().id) {
                            caseFound = true;
                            $scope.loadingCases = false;
                            break;
                        }
                    }
                    if (!caseFound) {
                        $scope.showCases();
                    } else {
                        $timeout(function () {
                            $('#case_' + caseExchangeDataService.getSelectedCaseDetails().id).click();
                        }, 10);
                    }
                };

                // handlers for the Shared Cases and All Cases buttons
                $scope.showCases = function () {
                    if (!($scope.lastCaseFetched || $scope.isFetchingCases)) {
                        //Get the list of shared cases defined in the caselist's case data service
                        if (caseExchangeDataService.getSelectedCaseDetails().searchText) {
                            $scope.search.text = caseExchangeDataService.getSelectedCaseDetails().searchText;
                        }
                        $scope.transformedSearchText = ( $scope.search.text !== null ?
                            $scope.search.text.toLowerCase().substring(0, 250) : null );
                        $scope.lastQuery = $scope.transformedSearchText;
                        $scope.caseSearchMessage = '';
                        caseDataService.getCaseHeaders(
                            $scope.inboxType, $scope.offset, $scope.limit, $scope.transformedSearchText, $scope.caseFilterTypes).then(
                            function (data) {
                                var numCasesFound = ( data != null && data instanceof Array ? data.length : 0);
                                if (numCasesFound === 0) {
                                    if ($scope.search.text !== null) {
                                        $scope.caseSearchMessage = $filter("translate")('caseinbox.noCasesFound');
                                    }
                                    else {
                                        $scope.caseSearchMessage = $filter("translate")('caseinbox.noCasesAvailable');
                                    }

                                    //Clear case summary module
                                    $scope.showDetails = false;
                                    $scope.selectedCase = null;
                                    $scope.patientData = null;
                                    $scope.selectedItemObj.value = '';
                                }
                                $scope.lastCaseFetched = (numCasesFound < $scope.limit);
                                // if search result is for first page
                                if ($scope.offset === 0) {
                                    // replace current case list model
                                    $scope.cases = data;
                                    // move scrollbar to top
                                    angular.element('#caselistScroller').scrollTop(0);
                                }
                                else if (numCasesFound !== 0) {
                                    // append to current case list model
                                    $scope.cases = $scope.cases.concat(data);
                                }
                                // adjust offset for next scroll-initiated query
                                $scope.offset += numCasesFound;
                                $scope.isFetchingCases = false;
                                setWhichCasesCurrentUserHasReviewed($scope.cases);
                                if ($scope.cases && $scope.cases.length > 0 && caseExchangeDataService.getSelectedCaseDetails().id) {
                                    findLastSelectedCase();
                                }
                            }
                            , function (error) {
                                if (error.status === 200) {
                                    $scope.caseSearchMessage = $filter("translate")('caseinbox.noCasesFound');
                                    $scope.cases = [];
                                }
                                else {
                                    $scope.caseSearchMessage = $filter("translate")('caseinbox.errorFetchingCases');
                                }
                                $scope.lastCaseFetched = true;
                                $scope.isFetchingCases = false;
                                $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
                            }
                        );
                        $scope.isFetchingCases = true;
                    }
                };

                // Resets case slection while switching between All and Shared cases
                var resetCaseSelection = function () {
                    $scope.cases = [];
                    $('#searchCaseInput').val(null);
                    $scope.search.text = null;
                    $scope.offset = 0;
                    $scope.lastCaseFetched = false;
                    $scope.caseDetails = null;
                    $scope.selectedCase = null;
                    $scope.patientData = null;
                    $scope.selectedItemObj.value = '';
                    $scope.errorMessage = '';
                    $scope.showDetails = false;
                    // This is to fix empty element scroll issue.
                    $('.ge-generic-list-container').scrollTop(0);
                };

                var isUnderTwoCharacters = function (searchText, lastQuery) {
                    var isSearchTextNullOrLessThanTwoChar = (searchText === null) || (searchText.length < 2);
                    return (isSearchTextNullOrLessThanTwoChar)&& (lastQuery === null || (searchText !== null && searchText.length === 1));
                };

                $scope.searchCases = function () {
                    if (!$scope.isFetchingCases) {
                        // Consider empty string to be null input
                        if ($scope.search.text === "") {
                            $scope.search.text = null;
                        }

                        // if search text has any character other than
                        // alphanumeric and dash and double-quotes
                        if (/[^a-zA-Z\d\u00BF-\u1FFF\u2C00-\uD7FF\w\-', ]/.test($scope.search.text)) {
                            $scope.errorMessage = $filter("translate")('caseinbox.pleaseEnterValidCharacters');
                            return;
                        }

                        //if the search text is less than 2 characters, and either the user hasn't previously searched or the search text is only 1 character
                        if (isUnderTwoCharacters($scope.search.text, $scope.lastQuery)) {
                            $scope.errorMessage = $filter("translate")('caseinbox.searchMinimum2Chars');
                            return;
                        }
                        $scope.cases = [];
                        $scope.offset = 0;
                        $scope.lastCaseFetched = false;
                        $scope.errorMessage = '';
                        $scope.selectedItemObj.value = '';
                        $scope.showDetails = false;
                        $scope.selectedCase = null;
                        $scope.patientData = null;
                        caseExchangeDataService.resetSelectedCaseDetails();
                        // This is to fix empty element scroll issue.
                        $('.ge-generic-list-container').scrollTop(0);
                        $scope.showCases();
                    }
                };

                /**
                 * Setup Case List scroll position on navigating back from Add to case, Add Users to case, Document Viewer, Dicom Viewer etc.
                 * @param selectedCaseId
                 * @param caseTransactionsCount
                 */
                var setupCaseListScrollPosition = function (selectedCaseId, caseTransactionsCount) {
                    if (!caseExchangeDataService.getSelectedCaseDetails().id || (caseExchangeDataService.getSelectedCaseDetails().id && caseExchangeDataService.getSelectedCaseDetails().id !== selectedCaseId)) {
                        caseExchangeDataService.setSelectedCaseDetails(selectedCaseId, $('.ge-generic-list-container').scrollTop(), $scope.transformedSearchText, caseTransactionsCount);
                    }
                    else {
                        if(caseTransactionsCount !== caseExchangeDataService.getSelectedCaseDetails().caseTransactionCount){
                            $('.ge-generic-list-container').scrollTop(0);
                        }
                        else {
                            $('.ge-generic-list-container').scrollTop(caseExchangeDataService.getSelectedCaseDetails().scrollPosition);
                        }
                    }
                };

                /**
                 * Makes a call to service by passing selected caseId to retrieve case details
                 * @param:
                 * selectedCase: Selected case object for which Case Summary need to be displayed
                 */
                $scope.showCaseDetails = function (selectedCase) {
                    if (!selectedCase || !selectedCase.id) {
                        return;
                    }
                    $scope.showDetails = true;

                    if ($scope.selectedCase && $scope.selectedCase.id === selectedCase.id) {
                        $scope.selectedCase = null;
                        $scope.patientData = null;
                        $scope.showDetails = false;
                    }
                    else {
                        $scope.selectedCase = null;
                        $scope.patientData = null;
                        $scope.isFetchingCase = true;
                        $('.case-transaction-scroll').scrollTop(0);

                        caseDataService.getCaseDetails(selectedCase.id).then(function (data) {
                            var caseTransactionsCount = data && data.transactions ? data.transactions.length : 1,
								userName,j,jEnd,
                                setParticipantString = function(transaction){
                                    if(transaction.addedParticipants){
                                        for(j= 0,jEnd=transaction.addedParticipants.length; j<jEnd;j++){
                                            userName = $filter('name')(transaction.addedParticipants[j].user.name);
                                            transaction.participantString += userName + '; ';
                                        }
                                        transaction.participantString = transaction.participantString.replace(/;\s*$/, "");
                                    }
                                };
                            setupCaseListScrollPosition(selectedCase.id, caseTransactionsCount);

                            setParticipantsLeftToReview(data);
                            setHasCurrentUserReviewedCase(data);
                            $scope.selectedCase = data;
                            $scope.patientData = $scope.selectedCase && $scope.selectedCase.patient ? angular.copy($scope.selectedCase.patient) : null;

                            if ($scope.patientData && $scope.patientData.birthDate) {
                                $scope.patientData.birthDate = caseExchangeDataService.convertToDate($scope.patientData.birthDate);
                                $scope.patientData.age = caseExchangeDataService.calculatePatientAge($scope.patientData.birthDate);
                            }

                            // Reset the flag on selection of case to hide extra details on Patient Module.
                            $scope.showingMoreDetailsOnPatientBanner = false;

                            // get a flattened list of studies attachments
                            // from the selected case's transactions
                            $scope.getCaseAttachments();

                            //For loop getting tooltip data
                            for(var i= 0,iEnd = $scope.selectedCase.transactions.length; i<iEnd;i++){
                                var transaction = $scope.selectedCase.transactions[i];
                                transaction.participantString = '';
                                setParticipantString(transaction);
                            }

                            $scope.isFetchingCase = false;

                        }, function () {
                            $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
                            $scope.isFetchingCase = false;
                        });
                    }
                };

                /**
                 * To get the case attachments from the current case context OR process it for Download to Premise scenario
                 */
                $scope.getCaseAttachments = function () {
                    $scope.selectedCaseStudies = [];
                    $scope.isCaseTxnStatusCompleted = false;
                    var tl = ( $scope.selectedCase.transactions ? $scope.selectedCase.transactions.length : 0);
                    for (var t = 0; t < tl; t++) {
                        var currentTransaction = $scope.selectedCase.transactions[t],
                            al = (currentTransaction.attachments instanceof Array ? currentTransaction.attachments.length : 0);
                        // check if the first case Txn status is 'COMPLETED' then set the flag to true else false
                        for (var a = 0; a < al; a++) {
                            var currentAttachment = currentTransaction.attachments[a];
                            if (currentAttachment.type === $scope.attachmentType.DICOM) {
                                currentAttachment.started = caseExchangeDataService.convertToDate(currentAttachment.started);
                                currentAttachment.selectedForDownload = false;
                                // if the case txn status is 'COMPLETED' & DICOM status is 'COMPLETED' then set the flag to true which is used to enable/disable the Download To Premise option
                                $scope.isCaseTxnStatusCompleted = verifyCaseTxnStatus(currentTransaction, currentAttachment);
                                // if the Txn status is 'COMPLETED' then only push the study in array
                                currentTransaction.status === status.COMPLETED ? $scope.selectedCaseStudies.push(currentAttachment) : '';
                            } else if (currentAttachment.type === $scope.attachmentType.NONDICOM) {
                                currentAttachment.created = caseExchangeDataService.convertToDate(currentAttachment.created);
                            }
                        }
                    }
                };

                /**
                 * Check if case txn and case dicom attachment status is 'COMPLETED' then return true
                 * @param currentTransaction
                 * @param currentAttachment
                 * @returns {*}
                 */
               function verifyCaseTxnStatus(currentTransaction, currentAttachment) {
                    if (!$scope.isCaseTxnStatusCompleted) {
                        return (currentTransaction.status === status.COMPLETED && currentAttachment.uploadStatus === status.COMPLETED) ? true : false;
                    } else {
                        return $scope.isCaseTxnStatusCompleted;
                    }

                };

                /**
                 * Function to open the DICOM / DOC Viewer based on attachment type.
                 * @params:
                 * attachment: Attachment object containing information regarding attachment type and other params like ID, etc.
                 */
                $scope.openViewer = function (attachment) {
                    if (attachment.type === $scope.attachmentType.NONDICOM && !attachment.notSupportedByDocViewer) {
                        var uriParts = attachment.uri ? attachment.uri.split('/') : [];
                        if (uriParts.length > 0) {
                            $location.path('/virtual-viewer/3')
                                .search({
                                    caseId: uriParts[4],
                                    attachmentId: uriParts[6],
                                    attachmentName: attachment.description
                                });
                        }
                    }

                    // If it's a DICOM attachment, then, navigate to viewer module
                    if (attachment.type === $scope.attachmentType.DICOM) {
                        // Open viewer module
                        $state.go('viewer.start', {
                            caseuuid: $scope.selectedCase.id.replace(/\./g, '-'),
                            studyuid: attachment.uid.replace(/\./g, '-')
                        });
                    }
                };

                /**
                 * Get the Pacs devices by calling API service
                 */
                $scope.getPacsDevices = function () {
                    $scope.pacsDevices = null;
                    GetPacsServices.getPacsDevices().then(function (data) {
                        var addedDeviceIDs = [], uniqueDevices = [];
                        data.entry.map(
                            function (currentDevice) {
                                if (addedDeviceIDs.indexOf(currentDevice.id) === -1) {
                                    addedDeviceIDs.push(currentDevice.id);
                                    currentDevice.selectedForDownload = false;
                                    uniqueDevices.push(currentDevice);
                                }
                            }
                        );
                        $scope.pacsDevices = uniqueDevices;
                    }, function (xhr) {
                        if (xhr && xhr.status !== 401) {
                            $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
                        }
                    });
                };

                /**
                 * Method for launching and cancelling the Download-to-Premise UI
                 */
                $scope.launchDownloadToPremise = function () {
                    var hasPacsDevice = ($scope.pacsDevices && $scope.pacsDevices.length > 0);
                    if ($scope.isCaseTxnStatusCompleted && $scope.selectedCaseStudies.length > 0 && hasPacsDevice) {
                        $scope.downloading = true;
                        $scope.normalize = false;
                        $state.go('caseexchange.caseinbox.downloadToPremise');
                    }
                };

                $scope.sendToMDT = function () {
                    $state.transitionTo('mdt-session.send-to-mdt', {selectedCaseId: $scope.selectedCase.id});
                };

                /**
                 * Finds the document extension and adds property 'notSupportedByDocViewer' to true/false
                 * @param attachment
                 */
                $scope.isDocumentNotSupportedByDocViewer = function (attachment) {
                    if (attachment && attachment.type === $scope.attachmentType.NONDICOM && attachment.description) {
                        var unsupportedExtensions = ['xml', 'mp4', 'mov'];
                        var fileDetails = attachment.description.split('.');
                        attachment.notSupportedByDocViewer = _.contains(unsupportedExtensions, fileDetails[fileDetails.length - 1].toLowerCase());
                    }
                };

                /**
                 * Filters cases as per user selection
                 */
                $scope.showFilterCases = function (source) {
                    $scope.inboxType = $scope.caseFilterTypes.CASE_TYPE;
                    resetCaseSelection();
                    if (!caseExchangeDataService.getSelectedCaseDetails().id || !source || $stateParams.resetSelectedCase) {
                        caseExchangeDataService.resetSelectedCaseDetails();
                    }
                    $scope.showCases();
                };

                /**
                 * Keeps the dropdown window open while clicking options from it
                 */
                $scope.keepDropdownOpen = function () {
                    $('#filterList').addClass('show');
                };

                /**
                 * Loads the case inbox data.
                 */
                function loadData() {
                    $scope.showFilterCases("pageLoad");

                    /**
                     * fetch the devices list on page load
                     * Calling from caseinbox module to show/hide 'Download To Premise' icon
                     * based on user role. ApplicationServices are not applicable for user 'Patient'
                     */
                    if (!$scope.isCurrentUserPatient) {
                        $scope.getPacsDevices();
                    }

                }

                // Loading all cases on Inbox page load
                $timeout(function () {
                    if (!caseExchangeDataService.getCurrentUser()) {
                        caseExchangeDataService.queryCurrentUser().then(function (currentUser) {
                            if (!hasRoles(currentUser)) {
                                return blockUI();
                            } else {
                                $scope.loadUI = true;
                            }

                            caseExchangeDataService.setCurrentUser(currentUser);
                            // Checks if logged in user is Patient
                            $scope.isCurrentUserPatient = currentUser.isPatient();
                            loadData();
                        }, function () {
                            $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
                        });
                    } else {
                        // Checks if logged in user is Patient
                        var currentUser = caseExchangeDataService.getCurrentUser();

                        if (!hasRoles(currentUser)) {
                            return blockUI();
                        } else {
                            $scope.loadUI = true;
                        }

                        $scope.isCurrentUserPatient = currentUser.isPatient();
                        loadData();
                    }

                    /**
                     * Check if user has any roles assigned
                     * @param currentUser: Current user object
                     * @returns boolean: true if there is at-least one role assigned to user, else false.
                     */
                    function hasRoles(currentUser) {
                        return currentUser && currentUser.role && currentUser.role.length > 0;
                    }

                    /**
                     * Function to block UI load
                     */
                    function blockUI() {
                        $scope.showAlertMessage($filter('translate')('common.accessDenied'), $scope.alertTypes.error);
                        $scope.loadUI = false;
                    }

                    /**
                     * Closes the dropdown window when clicking on body area excluding drodown window
                     */
                    $('body').on('click', function (e) {
                        if (!($('#filterList').is(e.target)) && !($('#filterList').find('*').is(e.target))) {
                            $('#filterList').removeClass('show');
                        }
                    });

                }, 150);

                /***
                 * $watch to keep track of any changes in selection of case.
                 * This is to be in sync with generic list directive implementation.
                 */
                $scope.$watch('selectedItemObj', function (newValue, oldValue) {
                    if (newValue.value !== oldValue.value) {
                        $scope.showCaseDetails($scope.cases[$scope.selectedItemObj.value]);
                    }
                }, true);
            }
        ]);
    });
