/*
 *  create-case-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular'], function () {

    // Module Dependencies
    var dependencies = [];

    // Module Definition
    var mod = angular.module('Services.fileUploadService', dependencies);

    /**
     * @name CreateCaseService
     * @type factory
     *
     * @description
     * A factory that provides methods for making request to the Create Case REST API to post the data.
     */
    mod.factory('FileUploadService', ['$q', '$log', '$filter', '$Endpoint', '$window', function ($q, $log, $filter, $Endpoint, $window) {
        var webWorker = new Worker('/modules/caseexchange/modules/create-case/services/file-upload-web-worker.js');

        var fileContentList = [];
        var DEFAULT_FILE_LIMIT = 1024*1024*100;
        var DEFAULT_FILE_LIST_LIMIT = 1024*1024*200;
        var DEFAULT_ALLOWED_EXTENSIONS = [
            "pdf", "doc", "docx", "xls", "xlsx", "csv", "rtf", "tiff", "tif", "txt", "bmp", "jpeg", "jpg", "ppt", "pptx", "dcm", "xml", "mp4", "mov"
        ];

        /**
         * Function to create a unique GUID
         * @returns: Unique GUID
         */
        var generateGuid = (function () {
            function s4() {
                return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
            }

            return function () {
                return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
            };
        })();

        var produceMultiParts = function (files) {
            var metadata = [];
            var fileParts = [];
            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                var contentType = file.type;
                var contentLocation = file.uuid;
                var contentLength = file.size;
                var fileContent = file.value;
                fileParts.push({
                    contentType : contentType,
                    contentLocation : contentLocation,
                    contentLength : contentLength,
                    fileContent : fileContent
                });

                metadata.push( {
                    "object-reference": contentLocation,
                    "meta-data": []
                });
            }

            return {
                metaPart : metadata,
                fileParts : fileParts
            };
        };

        var startFileUpload = function(caseId, files, fileUploadSuccessCallback, fileUploadErrorCallback) {
            var multiparts = produceMultiParts(files);
            var messageData = {
                caseId : caseId,
                command: "addFilesToUploadPool",
                metaPart: multiparts.metaPart,
                filePartList: multiparts.fileParts,
                blobServiceUrl: $Endpoint.getEndpoint('blobServiceUrl'),
                boundary : generateGuid(),
                securityToken: $window.sessionStorage.getItem('ngStorage-token')
            };
            webWorker.onmessage = function (event) {
                var workerMessage = event.data;
                if (workerMessage.status === "SUCCESS") {
                    var responseObject = {};
                    try {
                        responseObject = JSON.parse(workerMessage.responseText);
                    }
                    catch (e) {
                        //
                    }
                    fileUploadSuccessCallback(responseObject);
                }
                else if (workerMessage.status === "ERROR") {
                    fileUploadErrorCallback();
                }
            };
            webWorker.postMessage(messageData);
        };

        function readFileEndCallback(file, fileNum, caseId, fileUploadSuccessCallback, fileUploadErrorCallback) {
            return function (event) {
                file.value = event.target.result;
                fileContentList.push(file);
                if (fileContentList.length === fileNum) {
                    startFileUpload(caseId, fileContentList, fileUploadSuccessCallback, fileUploadErrorCallback);
                }
            };
        };

        var readAndUploadFiles = function (caseId, files, fileUploadSuccessCallback, fileUploadErrorCallback) {
            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                var reader = new FileReader();
                reader.onloadend = readFileEndCallback(file, files.length, caseId, fileUploadSuccessCallback, fileUploadErrorCallback);
                reader.readAsArrayBuffer(file);
            }
        };

        var addErrorMessageWithLineBreak = function(msg, errorWithDuplicatedName, errorWithUnsupportedExtension) {
            if (errorWithDuplicatedName) {
                if (msg !== "") {
                    msg += "\n";
                }
                msg += $filter("translate")("createcase.duplicatedFileName");
            }

            if (errorWithUnsupportedExtension) {
                if (msg !== "") {
                    msg += "\n";
                }
                msg += $filter("translate")("createcase.supportedExtensions");
            }

            return msg;
        };

        return {
            generateGuid : generateGuid,
            doUploadFiles: function(caseId, files, fileUploadSuccessCallback, fileUploadErrorCallback) {
                fileContentList = [];
                readAndUploadFiles(caseId, files, fileUploadSuccessCallback, fileUploadErrorCallback);
            },
            isFileSizeUnderLimit: function(file, limitToCheck) {
                var limit = ((typeof limitToCheck === "number") && (limitToCheck > 0)) ? limitToCheck : DEFAULT_FILE_LIMIT;
                var hasValidSizeProperty = file && (typeof file.size === "number");
                if (hasValidSizeProperty) {
                    return file.size <= limit;
                }
                else {
                    return false;
                }
            },
            isFileListSizeUnderLimit: function(alreadySelectedFileList, freshlySelectedFileList, sizeLimitToCheck, sumSizeLimitToCheck) {
                var self = this;
                var sumSizeLimit = ((typeof sumSizeLimitToCheck === "number") && (sumSizeLimitToCheck > 0)) ? sumSizeLimitToCheck : DEFAULT_FILE_LIST_LIMIT;
                var sizeLimit = ((typeof sizeLimitToCheck === "number") && (sizeLimitToCheck > 0)) ? sizeLimitToCheck : DEFAULT_FILE_LIMIT;
                this.sumSize = 0;
                this.freshlySelectedFilesSumSize = 0;

                //summarize freshly selected files size
                _.each(freshlySelectedFileList, function(file) {
                    if (file && (typeof file.size === "number")) {
                        self.freshlySelectedFilesSumSize += file.size;
                    }
                    else {
                        //FIXME
                        // how to handle wrong object?
                        // at the moment it means sum size is too big instead of wrong file
                        return false;
                    }
                }, self);

                //summarize already selected files size
                _.each(alreadySelectedFileList, function(file) {
                    if (file && (typeof file.size === "number") && (file.size <= sizeLimit)) {
                        self.sumSize += file.size;
                    }
                    else {
                        //FIXME
                        // how to handle wrong object?
                        // at the moment it means sum size is too big instead of wrong file
                        return false;
                    }
                }, self);

                this.sumSize += this.freshlySelectedFilesSumSize;
                return (this.sumSize) <= sumSizeLimit;
            },
            /**
             * method to check if file's extension is on a whitelist or not
             * @param file : JS file object
             * @param validExtensionArray : optional, if not used, DEFAULT_ALLOWED_EXTENSIONS will be used
             * @returns {boolean}
             */
            isFileExtensionValid: function(file, validExtensionArray) {
                var extensionArray = DEFAULT_ALLOWED_EXTENSIONS;
                if (Array.isArray(validExtensionArray) ) {
                    extensionArray = validExtensionArray;
                }

                //convert every extensions to lowercase
                for (var i = 0; i < extensionArray.length; i++) {
                    extensionArray[i] = (extensionArray[i] + "").toLowerCase();
                }

                //non existing or empty file name is invalid
                if (!file || !file.name) {
                    return false;
                }

                //get the extension. If the filename does not have any extension, it returns the original filename
                var fileExt = file.name.split('.').pop();
                if (fileExt === file.name) {
                    return false;
                }

                //ignore case for comparison
                fileExt = (fileExt + "").toLowerCase();

                //searching in extension whitelist for any match
                if (extensionArray.indexOf(fileExt) !== -1 ) {
                    return true;
                }

                return false;
            },

            /**
             * Checks if the passed file's name already exists in the passed filelist
             * @param fileToCheck   file object
             * @param fileList      list of file objects
             * @returns {boolean}
             */
            isFileNameAlreadyExistInList: function (fileToCheck, fileList) {
                var self = this;
                self.fileNameExists = false;
                self.fileToCheck = fileToCheck;
                //non existing or empty file name is invalid
                if (!fileToCheck || !fileToCheck.name) {
                    return false;
                }

                _.each(fileList, function(file) {
                    if (!file || !file.name) {
                        return false;
                    }
                    if (file.name === self.fileToCheck.name) {
                        self.fileNameExists = true;
                    }
                }, self);

                return self.fileNameExists;
            },

            /**
             *  Converts file validation error objects to error messages, according to the following priorities
             *      1. sum of file sizes exceeded the limit -> one error message with this error
             *      2. if NOT 1. AND a file has exceeds the individual file limit -> error message for every file with this error
             *      3. if NOT 1. AND NOT 2. AND a file has invalid extension -> one error message with supported extensions message
             *
             * @param errors List of following objects expected
             *          {
                            file: file, //name
                            invalidSize: !isValidSize,     //file has invalid size
                            invalidExtension: !isValidExtensions,       //file has invalid extension
                            duplicatedName: alreadyExistingFileName,    //file with same name already selected
                            sizeLimit: sizeLimit    //file size limit
                        }
             * @param sumSizeLimitReached   summarized file size limit exceeded
             * @param sizeLimit     size limit for individual files
             * @param sumSizeLimit      size limit for sum
             * @returns {*}     internationalized validation error message
             */
            convertFileValidationErrorsToErrorMessages: function(errors, sumSizeLimitReached, sizeLimit, sumSizeLimit) {
                var errorWithUnsupportedExtension = false;
                var errorWithDuplicatedName = false;
                var msg = "";

                //summarized file size limit has the highest priority
                if (sumSizeLimitReached) {
                    msg = $filter("translate")(
                            "createcase.sumFilesSizeValidationError",
                            {
                                //we need the limit in MB
                                sizeLimit: parseInt(sumSizeLimit/(1024*1024))
                            }
                    );

                    return msg;
                }
                else if (errors.length > 0) {
                    for (var i = 0; i < errors.length; i++) {
                        var error = errors[i];
                        if (error.duplicatedName) {
                            errorWithDuplicatedName = true;
                        }
                        else if (error.invalidSize) {
                            msg +=$filter("translate")(
                                    "createcase.fileSizeValidationError",
                                    {
                                        fileName: error.file.name,
                                        //we need the limit in MB
                                        sizeLimit: parseInt(sizeLimit/(1024*1024))
                                    }
                            );
                        }
                        else if (error.invalidExtension) {
                            errorWithUnsupportedExtension = true;
                        }
                    }

                    msg = addErrorMessageWithLineBreak(msg, errorWithDuplicatedName, errorWithUnsupportedExtension);

                    return msg;
                }
            }
        };
    }]);
});