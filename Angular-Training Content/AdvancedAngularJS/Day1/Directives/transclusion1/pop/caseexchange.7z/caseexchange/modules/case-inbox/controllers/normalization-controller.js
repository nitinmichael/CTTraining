/*
 *  normalization-controller.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * A Normalization controller to handle normalization related operations.
 */
define([ 'angular',
         'angularTranslate',
         'angularTranslatePartialLoader',
         '../../../module' ], function(ng) {
    'use strict';

    // Module dependencies
    var dependencies = [ 'pascalprecht.translate',
                         'Services.normalizationService',
                         'Services.pacsSearchMarshaller',
                         'Services.pacsSearchService',
                         'Services.normalizationMarshallerService'];

    // Normalization controller module
    var normalization = ng.module('cloudav.caseExchange.caseInbox.normalizationCtrl', dependencies);

    //normalization controller
    normalization.controller('NormalizationCtrl', [ '$scope', '$state', '$stateParams', '$filter', 'NormalizationService', 'PacsSearchMarshaller', 'PacsSearchService', '$modal', 'NormalizationMarshallerService', 'CaseExchangeDataService',
                             function($scope, $state, $stateParams, $filter, NormalizationService, PacsSearchMarshaller, PacsSearchService, $modal, NormalizationMarshallerService, CaseExchangeDataService) {

        var comparePatientListXHR, normalizeSaveXHR;
        var normalizationPatientSearch={};

        /**
         * on click of patient apply border and display compare button and show tick icon for respective patient
         */
        $scope.selectPatientForCompare = function(comparePatient) {
            var isSelected = comparePatient.isSelected;

            for (var i = 0; i < $scope.patientCompareList.length; i++) {
                $scope.patientCompareList[i].isSelected = false;
            }

            $scope.showNomlizCmpreBtn = !isSelected;
            comparePatient.isSelected = !isSelected;

            if(comparePatient.isSelected){
                $scope.comparePatient = angular.copy(comparePatient);
                $scope.comparePatient = NormalizationMarshallerService.convertFHIRToPatientJson($scope.comparePatient);
            }else{
                $scope.comparePatient = null;
            }

        };

        /**
         * make call to get list of patient for comparison
         */
        $scope.getComparePatientList = function() {
            var searchJson;
            $scope.fetchingComparePatient = true;

            normalizationPatientSearch.patientLastName=$scope.selectedPatient.lastName;
            normalizationPatientSearch.birthDate=$scope.selectedPatient.dob;
            normalizationPatientSearch.dicomDevices=[];
            normalizationPatientSearch.dicomDevices.push(NormalizationService.getSelectedDicomDevices());

            searchJson=PacsSearchMarshaller.marshalPacsSearchData(normalizationPatientSearch);
            comparePatientListXHR = PacsSearchService.pacsSearch(searchJson);
            comparePatientListXHR.promise.then(function(data) {
                if(data.totalCount>0){
                    $scope.patientCompareList = data.responseList;
                }else{
                    $scope.normalizePatient = $scope.selectedPatient;
                    $scope.continueNormalizationForm();
                }
                $scope.fetchingComparePatient = false;
            }, function () {
                   $scope.fetchingComparePatient = false;
                   $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
               });
        };

        /**
         * link back to download to premise page
         */
        $scope.backToDownloadPage = function() {
            $state.transitionTo('caseexchange.caseinbox.downloadToPremise', {id : $stateParams.id});
            $scope.$parent.normalize = false;

        };

        /**
         * call function on click of continue button
         */
        $scope.continueNormalizationForm = function() {
            $scope.enableNormalizationForm=true;

            if($scope.comparePatient){
                $scope.normalizePatient = angular.copy($scope.comparePatient);
            }else{
                $scope.normalizePatient = angular.copy($scope.selectedPatient);
            }

            $scope.normalizeStudyList = angular.copy($scope.selectedStudyList);
            $scope.formatNomalizationPatientData();
            $scope.formatNomalizationStudyData();
            $scope.studyPagination();
            $scope.disableGenderRadioButton();
        };

        /**
         * format patient normalization data with required attributes
         */
        $scope.formatNomalizationPatientData = function() {
            if($scope.normalizePatient && $scope.normalizePatient.dob){
                $scope.normalizePatient.dob=$filter('date')($scope.normalizePatient.dob, 'dd MMM yyyy', 'UTC');
                $scope.disablePatientDob=true;
                $scope.calculatePatientAge();
            }else{
                $scope.disablePatientDob=false;
            }

            if(!$scope.normalizePatient.name){
                $scope.normalizePatient.name={};
                $scope.normalizePatient.name.firstName = $scope.normalizePatient.firstName;
                $scope.normalizePatient.name.lastName = $scope.normalizePatient.lastName;
                $scope.normalizePatient.name.middleName = $scope.normalizePatient.middleName;
            }

            if ($scope.normalizePatient.id) {
                $scope.normalizePatient.patientId=$scope.normalizePatient.id;
            }

            if ($scope.normalizePatient.sex) {
                $scope.normalizePatient.gender=$scope.normalizePatient.sex;
            }
        };

        /**
         * calculate Patient Age
         */
        $scope.calculatePatientAge = function() {
            if($scope.normalizePatient.dob){
                $scope.normalizePatient.age=CaseExchangeDataService.calculatePatientAge($scope.normalizePatient.dob);
            }
            else {
                $scope.normalizePatient.age="";
            }
        };

        /**
         * format patient study normalization data with required attributes
         */
        $scope.formatNomalizationStudyData = function() {
            for (var i = 0; i < $scope.normalizeStudyList.length; i++) {
                if ($scope.normalizeStudyList[i].started){
                    $scope.normalizeStudyList[i].started = $filter('date')($scope.normalizeStudyList[i].started, 'dd MMM yyyy h:mm');
                }
            }
        };

        /**
         * link back to main normalization select screen
         */
        $scope.backToSelection = function() {
            $scope.enableNormalizationForm = false;
        };

        /**
         * link back to main normalization select screen
         */
        $scope.studyPagination = function() {
            $scope.selectStudy = $scope.selectedStudyList[$scope.paginationCount];
            $scope.normalizeStudy = $scope.normalizeStudyList[$scope.paginationCount];
        };

        /**
         * on click of pagination right arrow get next study
         */
        $scope.getNextStudy = function() {
            $scope.paginationCount++;
            $scope.studyPagination();
        };

        /**
         * on click of pagination left arrow get previous study
         */
        $scope.getPreviousStudy = function() {
            $scope.paginationCount--;
            $scope.studyPagination();
        };

        /**
         * disable gender radio button if gender is not null or empty or others
         */
        $scope.disableGenderRadioButton = function() {
            $scope.disableGender=false;
            if($scope.normalizePatient.gender && $scope.normalizePatient.gender!==""){
                $scope.disableGender=true;
            }
        };

        /**
         * go back to case summary page on click of cancel button
         */
        $scope.cancelNormalizationFlow = function() {
            var studiesLength = $scope.selectedCaseStudies.length;
            for (var s = 0; s < studiesLength; s++) {
                $scope.selectedCaseStudies[s].selectedForDownload = false;
            }
            var devicesLength = $scope.pacsDevices.length;
             for (var d = 0; d < devicesLength; d++) {
                $scope.pacsDevices[d].selectedForDownload = false;
            }
            $state.go('caseexchange.caseinbox');
            $scope.$parent.downloading = false;
            $scope.$parent.normalize = false;
        };

        /**
         * open confirmation modal on click of complete button
         */
        $scope.openNormalizeConfirmationModal = function() {
            $scope.checkForUpdatedStudy();

            $scope.modalInstance = $modal.open({
                templateUrl : './modules/caseexchange/modules/case-inbox/views/normalization-confirmation.html',
                scope : $scope
            });
        };

        /**
         * function to check the patient fields for study updated count value
         */
        var checkPatientUpdatedDetails = function() {

            if(!$scope.patientData.name.given || $scope.patientData.name.given.length === 0) {
                $scope.patientData.name.given=["",""];
            }

            if(!$scope.patientData.name.family) {
                $scope.patientData.name.family=[];
            }

            if($scope.patientData.name.family[0] !== $scope.normalizePatient.name.lastName || $scope.patientData.name.given[0] !== $scope.normalizePatient.name.firstName ||
                    ($scope.patientData.name.given[1] || '') !== $scope.normalizePatient.name.middleName) {
                return true;
            }
            return false;
        };

        /**
        *  function to check the patient gender and age for study updated count
        */
        var checkPatientAgeGenderDetail = function() {

            if(!$scope.patientData.age) {
                $scope.patientData.age="";
            }

            if(!$scope.patientData.gender) {
                $scope.patientData.gender="";
            }

            if($scope.patientData.age !== $scope.normalizePatient.age || $scope.patientData.gender !== $scope.normalizePatient.gender) {
                return true;
            }
            return false;
        };

        /**
         * check studies that are updated and increment editedStudyCount count
         */
        $scope.checkForUpdatedStudy = function() {
            $scope.editedStudyCount = 0;
            for (var s = 0; s < $scope.selectedStudyList.length ; s++) {

                if(!$scope.selectedStudyList[s].accession){
                    $scope.selectedStudyList[s].accession="";
                }

                if(!$scope.normalizeStudyList[s].accession){
                    $scope.normalizeStudyList[s].accession="";
                }

                if(!$scope.patientData.identifier) {
                    $scope.patientData.identifier="";
                }

                if($scope.selectedStudyList[s].accession !== $scope.normalizeStudyList[s].accession || $scope.patientData.identifier !== $scope.normalizePatient.patientId ||
                    checkPatientUpdatedDetails() || checkPatientAgeGenderDetail()) {
                    $scope.editedStudyCount++;
                }
            }
        };


        /**
         * close normalization confirmation dialog box
         */
        $scope.close=function(){
            $scope.modalInstance.dismiss();
        };

        /**
         * submit Normalization data on click of continue button
         */
        $scope.saveNormalization=function(){
            var data = NormalizationMarshallerService.marshallNormalizeServices($scope.normalizePatient, $scope.normalizeStudyList, NormalizationService.getSelectedDicomDevices());
            normalizeSaveXHR = NormalizationService.normalizeSave($scope.selectedCase.id, data);
            normalizeSaveXHR.promise.then(function() {
                $scope.showAlertMessage($filter('translate')('sendToDicom.inProgress'), $scope.alertTypes.success);
                $scope.cancelNormalizationFlow();
            }, function () {
                   $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
                   $scope.cancelNormalizationFlow();
               });
            $scope.modalInstance.dismiss();
        };

        /**
         * function to setup components on call of normalization screen
         */
        $scope.init = function() {
            $scope.showNomlizCmpreBtn = false;
            $scope.fetchingComparePatient = true;
            $scope.selectedPatient = NormalizationMarshallerService.convertFHIRToPatientJson(NormalizationService.getSelectedCase().patient);
            $scope.selectedPatient.age = CaseExchangeDataService.calculatePatientAge(CaseExchangeDataService.convertToDate($scope.selectedPatient.dob));
            if($scope.selectedPatient.dob){
                $scope.selectedPatient.dob=new Date($scope.selectedPatient.dob.slice(0,4)+"-"+$scope.selectedPatient.dob.slice(4,6)+"-"+$scope.selectedPatient.dob.slice(6,8)).getTime();
            }
            $scope.normalizePatient = angular.copy($scope.selectedPatient);
            $scope.selectedStudyList = NormalizationService.getSelectedCaseStudies();
            $scope.paginationCount=0;
            $scope.patientCompareList=[];
            $scope.dateFormat = 'dd MMM yyyy';
            $scope.todayDate = new Date();
            $scope.isCalOpen = false;
            $scope.getComparePatientList();
        };

        $scope.init();

    }]).directive('datePickerChange',function(){
        return {

            restrict: "A",
            link: function(scope,ele){
                ele.on('click tap',function(){
                    ele.next().css({left: 'auto',right: '0'});
                    scope.$apply();
                });

                ele.parent().css({position : 'relative'});

                ele.on('keydown',function(e){
                    e.preventDefault();
                    return false;
                });
            }
        };
    });

});
