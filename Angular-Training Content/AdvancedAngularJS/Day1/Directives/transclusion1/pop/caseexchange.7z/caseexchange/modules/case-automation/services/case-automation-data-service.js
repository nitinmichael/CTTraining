/*
 *  case-automation-data-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular'], function(){

    var dependencies = [];

    /**
     * This module contains all the getter & setter methods to hold data for case automation.
     */
    var mod = angular.module('Services.caseAutomationDataService',dependencies);

    /**
     * @name CaseAutomationDataService
     * @type factory
     *
     * @description
     * A factory/service contains all the getter & setter methods to hold data for case automation.
     */
    mod.factory('CaseAutomationDataService', function() {

        // variable to hold selected site for case automation Instruction
        var SELECTED_SITE ="";

        /**
         * Function to get the site of ccase automation Instruction object
         */
        function getSelectedSite() {
            return SELECTED_SITE;
        };

        /**
         * Function to set the site to case automation Instruction object
         */
        function setSelectedSite(site){
            SELECTED_SITE = site;
        }

        // Public API
        return {
            getSelectedSite : getSelectedSite,
            setSelectedSite : setSelectedSite
        };
    });

});