/*
 *  ge-form-submitted-directive.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * Provides a directive that tracks when a form has been submitted.
 *
 * @author
 * Eric Steele <eric.steele@ge.com>
 *
 ***************************************************************************************************/
define(['angular'], function() {

  // Module Definition
  var mod = angular.module('Directives.geFormSubmitted', []);

  /**
   * @name geFormSubmitted
   * @type directive
   * @element FORM
   *
   * @description
   * When applied to a `<form>`, this directive will keep track of whether or not the `<form>`
   * has been submitted. This is done by adding a `$submitted` property to the `<form>` controller
   * and watching for the `submit` event. This directive was created to assist with the validation of
   * the `<form>`. It is used by the `geControlGroup` directive to ensure that the various controls
   * within the `<form>` are put into the `error` state if they are invalid when the `<form>` is submitted.
   *
   * @example
   * <form name="exampleForm" ng-submit="submitExampleForm()" form-submitted novalidate></form>
   *
   */
  mod.directive('geFormSubmitted', [function () {
    return {
      /**
       * Use the restrict option to specify how this directive can be applied to HTML elements.
       *  'A' = Attribute (e.g. <div my-directive>)
       *  'C' = Class     (e.g. <div class="my-directive">)
       *  'E' = Element   (e.g. <my-directive>)
       *  'M' = Comment   (e.g. <!-- directive: my-directive -->)
       */
      restrict: 'A',
      /**
       * Use the require option to have a controller injected into the link function as an
       * additional argument. Prefix this option's value with '^' if the controller belongs
       * to a parent element. If the '^' prefix is not included, the directive will look for
       * the controller on its own element.
       */
      require: 'form',
      /**
       * Use the link function to make changes to the directive's HTML after the directive's
       * scope has been attached to it. Normally, this function is used for registering DOM
       * listeners (i.e., $watch expressions on the scope) as well as updating the DOM.
       *
       * @param scope   - the directive's scope object.
       * @param element - the jqLite-wrapped element that this directive matches.
       * @param attrs   - the matched element's attributes and their corresponding values.
       */
      link: function (scope, element, attrs, formCtrl) {
        // Add an additional property to the form's controller to track submission
        formCtrl.$submitted = false;

        // Watch for the submit event and update the $submitted property
        element.on('submit', function () {
            scope.$apply(function () {
                formCtrl.$submitted = true;
            });
        });
      }
    };
  }]);

});
