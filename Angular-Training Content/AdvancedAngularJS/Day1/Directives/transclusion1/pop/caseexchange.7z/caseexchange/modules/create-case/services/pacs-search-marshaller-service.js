/*
 *  pacs-search-marshaller-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * A factory that provides methods for marshalling pacs search data to be shared into the format expected by the microservice.
 */
define(['angular'], function () {

    // Create Case marshaller Module
    var mod = angular.module('Services.pacsSearchMarshaller', []);

    /**
     * A factory that provides method for marshalling pacs search data to be shared into the format
     * expected by the REST API.
     */
    mod.factory('PacsSearchMarshaller', ['CaseExchangeDataService', function (CaseExchangeDataService) {

        /**
         * Marshals the provided Pacs Search form data into the format expected by the REST API.
         *
         * @param formData
         *    The form data to be marshalled.
         */
        var pacsSearchData = '';
        var dicomMap = {};

        //max patient data that can be fetched from each pacs
        var MAX_ALLOWED_PATIENT_DATA=25;

        /**
         * function to construct name attribute of patientCriteria in PACS SEARCH
         */
        function getNameJson(formData) {
            var name = {};
            if (formData.patientLastName) {
                name.family = _.compact([formData.patientLastName]);
            }

            if (formData.patientFirstName) {
                name.given = _.compact([formData.patientFirstName]);
            }

            if (formData.patientMiddleName) {
                if (name.given) {
                    name.given.push(formData.patientMiddleName);
                } else {
                    name.given = _.compact([formData.patientMiddleName]);
                }
            }
            return name;
        }

        /**
         * function to check if patient criteria is empty incase if its empty then
         * delete patient criteria from Pacs Search Json
         */
        function checkPatientCriteria(pacsSearchJson) {
            var pacsSearchData = pacsSearchJson;
            if (_.isEmpty(pacsSearchData.patientCriteria.name)) {
                delete pacsSearchData.patientCriteria.name;
            }
            if (!pacsSearchData.patientCriteria.birthDate) {
                delete pacsSearchData.patientCriteria.birthDate;
            }
            if (!pacsSearchData.patientCriteria.gender) {
                delete pacsSearchData.patientCriteria.gender;
            }
            if (_.isEmpty(pacsSearchData.patientCriteria)) {
                delete pacsSearchData.patientCriteria;
            }
            return pacsSearchData;
        }

        /**
         * Creates and returns an array of DICOM devices to be added in the json object for search operation
         * @param dicomDevices
         * @returns {Array}
         */
        var getDevices = function (dicomDevices) {
            var devices = [];
            if (dicomDevices) {
                for (var i = 0; i < dicomDevices.length; i++) {
                    var device = {
                        identifier: dicomDevices[i].id ? dicomDevices[i].id : '',
                        uri: dicomDevices[i].content ? dicomDevices[i].content.endpoint ? dicomDevices[i].content.endpoint : '' : '',
                        name: dicomDevices[i].content ? dicomDevices[i].content.name ? dicomDevices[i].content.name : '' : ''
                    };
                    devices.push(device);
                }
            }
            return devices;
        };

        function marshalPacsSearchData(formData) {

            /*
             * String constants
             */
            var PACS_SEARCH_OFFSET = 0;
            var PACS_SEARCH_LIMIT = MAX_ALLOWED_PATIENT_DATA;

            //device details array
            var deviceArray = [];

            //add selected devices into device details array
            deviceArray = getDevices(formData.dicomDevices);

            //generate pacs search data that is submitted
            pacsSearchData = {
                offset: PACS_SEARCH_OFFSET,
                limit: PACS_SEARCH_LIMIT,

                patientCriteria: {
                    name: {},
                    birthDate: formData.birthDate ? CaseExchangeDataService.convertDateToUTC(formData.birthDate) : null,
                    gender: formData.gender ? formData.gender : null,
                    identifier: formData.identifier ? formData.identifier : null
                },
                studyCriteria: {
                    identifier: formData.studyId
                },
                deviceList: deviceArray
            };

            pacsSearchData.patientCriteria.name = getNameJson(formData);
            pacsSearchData = checkPatientCriteria(pacsSearchData);

            if (_.isEmpty(pacsSearchData.studyCriteria.identifier)) {
                delete pacsSearchData.studyCriteria;
            }

            return pacsSearchData;
        }

        /**
         * Marshals the provided Pacs Study Search form data into the format expected by the REST API.
         *
         * @param formData
         *    The form data to be marshalled.
         */
        function marshalStudySearchData(formData, pacsData) {

            /*
             * String constants
             */
            var PACS_SEARCH_OFFSET = 0;
            var PACS_SEARCH_LIMIT = 10;

            //device details array
            var deviceArray = [];

            //add selected devices into device details array
            deviceArray = getDevices(pacsData.dicomDevices);

            //generate pacs search data that is submitted
            var data = {
                offset: PACS_SEARCH_OFFSET,
                limit: PACS_SEARCH_LIMIT,

                patientCriteria: {
                    name: {
                        family: formData.name.family !== null ? formData.name.family : null,
                        given: formData.name.given !== null ? formData.name.given : null
                    },
                    identifier: formData.identifier !== null ? formData.identifier : null,
                    birthDate: formData.birthDate ? CaseExchangeDataService.convertDateToUTC(formData.birthDate) : null,
                    gender: formData.gender ? formData.gender : null
                },
                studyCriteria: {
                    identifier: pacsData.studyId
                },
                deviceList: deviceArray
            };

            if (_.isEmpty(data.studyCriteria.identifier)) {
                delete data.studyCriteria.identifier;
            }

            return data;
        }

        /**
         * Get marshaller data that is set to be send to micro service
         */
        function getpacsSearchData() {
            return pacsSearchData;
        }

        /**
         * Resets the offset for the search data
         */
        function resetOffset() {
            pacsSearchData.offset = 0;
        }

        /**
         * create a map of dicom devices
         */
        function marshalDicomDevice(dicomDevices) {
            for (var i = 0; i < dicomDevices.length; i++) {
                dicomMap[dicomDevices[i].id] = {
                    id: dicomDevices[i].id,
                    content: dicomDevices[i].content
                };
            }
        }

        /**
         * retrive dicom details from key
         */
        function getDicomDetail(key) {
            return dicomMap[key];
        }

        /**
         * retrive max patient data that can be fetched from each pacs
         */
        function getMaxAllowedPatient() {
            return MAX_ALLOWED_PATIENT_DATA;
        }

        return {
            marshalPacsSearchData: marshalPacsSearchData,
            marshalStudySearchData: marshalStudySearchData,
            getpacsSearchData: getpacsSearchData,
            resetOffset: resetOffset,
            marshalDicomDevice: marshalDicomDevice,
            getDicomDetail: getDicomDetail,
            getMaxAllowedPatient: getMaxAllowedPatient
        };
    }]);
});
