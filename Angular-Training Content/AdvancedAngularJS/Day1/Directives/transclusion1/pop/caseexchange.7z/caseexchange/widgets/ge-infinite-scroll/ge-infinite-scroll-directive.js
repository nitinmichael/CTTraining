/***************************************************************************************************
 * Copyright (c) 2015 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 **
 * @author
 * Henry Navarro <henry.navarro@ge.com>
 *
 * @name geInfiniteScroll
 **
 * @param {geisCallback}   the function to invoke upon a scroll event, when geisAvailable is truthy
 * @param {geisBottomDistance} distance of scroll from bottom edge that will trigger handler
 *
 * @description
 *
 * An AngularJS directive that provides 'infinite' scrolling for an HTML element.  This directive is
 * applied as an attribute, along with the attribute 'geisCallback'.  geisCallback expects a function
 * that will be applied by the directive when a scroll event is detected on the element.  The callback
 * function will normally involve fetching content that is be appended to the element, thus changing
 * its scroll values (scrollTop).  geisBottomDistance is the distance of the scrollbar from the
 * bottom edge that will trigger the handler (any greater distance will not trigger the handler).  For
 * example. to trigger the handler when the scrollbar reaches the bottom edge, give the value of
 * zero to geisBottomDistance.  The default value for geisBottomDistance is 100.
 *
 * USAGE:
 *
 *   <div ge-infinite-scroll geis-callback="callbackFunction" geis-bottom-distance="100">...</div>
 *
 * NOTE:
 * This directive will call the callback function upon each 'scroll' event where the bottom edge of
 * the scrolled element is reached.  It is up to the callback function to manage the logic of actually
 * responding to the event.
 *
 * @dependencies
 *
 *     angular, $timeout
 *
 ***************************************************************************************************/
define(['angular'], function () {

    var mod = angular.module('InfiniteScrollDirective', []);

    mod.directive('geInfiniteScroll', ['$timeout',
        function ($timeout) {
            return {
                restrict: 'A',
                scope: {
                    callback: '=geisCallback',
                    distanceFromBottom: '@geisBottomDistance'
                },
                link: function (scope, elem) {
                    var handler = null, theElement = null;
                    if (typeof scope.distanceFromBottom === 'undefined' ||
                        scope.distanceFromBottom === null) {
                        scope.distanceFromBottom = 100;
                    }

                    // the element (as jQuery object) this directive is used on
                    theElement = angular.element(elem);

                    scope.callHandler = function() {
                        // apply the callback function
                        // ( Safer way of calling the provided callback per discussion in
                        //   http://stackoverflow.com/questions/20263118/what-is-phase-in-angularjs
                        // )
                        $timeout(function () {
                            scope.$apply(scope.callback);
                        });
                    };

                    // handler function for 'scroll' event on theElement
                    handler = function () {
                        // get the raw HTML element this directive is used on
                        var htmlElement = theElement[0];
                        // if element is scrolled bottomDistance or less from bottom edge
                        if (htmlElement.scrollTop +
                            $(htmlElement).innerHeight() +
                            parseInt(scope.distanceFromBottom) >= htmlElement.scrollHeight) {
                            scope.callHandler();
                        }
                    };

                    // listen for scroll event
                    // and detach handler when element is removed/destroyed
                    theElement.on('scroll', handler);
                    scope.$on('$destroy', function () {
                        theElement.off('scroll', handler);
                    });
                }
            };
        }
    ]);
});
