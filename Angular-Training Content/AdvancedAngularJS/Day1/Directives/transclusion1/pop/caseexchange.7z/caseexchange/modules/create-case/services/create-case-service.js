/*
 *  create-case-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular'], function () {

    // Module Dependencies
    var dependencies = ['Services.caseExchangeDataService'];

    // Module Definition
    var mod = angular.module('Services.createCaseService', dependencies);

    /**
     * @name CreateCaseService
     * @type factory
     *
     * @description
     * A factory that provides methods for making request to the Create Case REST API to post the data.
     */
    mod.factory('CreateCaseService', ['CaseExchangeDataService', '$q', '$log', function (caseExchangeDataService, $q, $log) {
        /**
         * Base url for making request to the Create Case REST API.
         */
        var CREATE_CASE_URL = caseExchangeDataService.getServiceURL() + '/casewriter/v1/case';

        var STUDY_ATTACHMENT = caseExchangeDataService.getServiceURL() + '/caseattachment/v1/case';

        function createCase(data) {
            // validate arguments
            if (!angular.isObject(data)) {
                var errorMsg = 'Error: CreateCaseService: invalid parameter: data = ' + data;
                $log.error(errorMsg);
                return $q.reject(errorMsg);
            }
            var deferred = $q.defer();

            // send the request
            $.ajax({
                async: true,
                contentType: 'application/json',
                type: 'post',
                url: CREATE_CASE_URL,
                data: JSON.stringify(data),
                success: success,
                error: error
            });

            return deferred.promise;

            function success(data) {
                var caseData;
                var message = '';

                try {
                    if( angular.isObject(data)) {
                        caseData = data;
                    } else {
                        caseData = JSON.parse(data);
                    }
                } catch( e ) {
                    message = JSON.toString(e);
                }
                if( caseData === undefined ) {
                    $log.error('Error: CreateCaseService: createCase: Case Object error: ' + data + ' parsing problem: ' + message);
                    deferred.reject('Wrong case object returned');
                } else {
                    $log.log('Success: CreateCaseService: createCase');
                    deferred.resolve(caseData);
                }
            }

            function error(jqXHR, textStatus, errorThrown) {
                var errorMsg = 'Error: CreateCaseService: createCase: ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }
        }

        function createTransaction(data, caseId) {
            // validate arguments
            if (!angular.isObject(data)) {
                var errorMsg = 'Error: CreateCaseService: invalid parameter: data = ' + data;
                $log.error(errorMsg);
                return $q.reject(errorMsg);
            }
            var deferred = $q.defer();

            // send the request
            $.ajax({
                async: true,
                contentType: 'application/json',
                type: 'post',
                url: CREATE_CASE_URL + "/" + caseId + "/transaction" ,
                data: JSON.stringify(data),
                success: success,
                error: error
            });

            return deferred.promise;

            function success(data) {
                $log.log('Success: CreateCaseService: createTransaction');
                var response = data || null;
                deferred.resolve(response);
            }

            function error(jqXHR, textStatus, errorThrown) {
                var errorMsg = 'Error: CreateCaseService: createTransaction: ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }

        }

        /**
         * Upload the attachments of a case on dicom devices
         */
        function uploadCaseAttachment(data, caseId) {
            var errorMsg;
            if (!angular.isObject(data)) {
                errorMsg = 'Error: CreateCaseService: invalid parameter: data = ' + data;
                $log.error(errorMsg);
                return $q.reject(errorMsg);
            }

            if (!caseId || caseId === "" ) {
                errorMsg = 'Error: CreateCaseService: invalid parameter: caseId = ' + caseId;
                $log.error(errorMsg);
                return $q.reject(errorMsg);
            }

            var deferred = $q.defer();

            // send the request
            $.ajax({
                async: true,
                contentType: 'application/json',
                dataType: 'text',
                type: 'post',
                url: STUDY_ATTACHMENT + "/" + caseId +"/attachment/retrieve",
                data: JSON.stringify(data),
                success: success,
                error: error
            });

            return deferred.promise;

            function success(data) {
                $log.log('Success: CreateCaseService: uploadCaseAttachment');
                var response = data || null;
                deferred.resolve(response);
            }

            function error(jqXHR, errorThrown) {
                var errorMsg = 'Error: CreateCaseService: uploadCaseAttachment: ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }
        }

        /**
         * Updates the attachment upload status
         * @params: caseId: ID of the case
         * @params: attachmentId: ID of the attachment for which we need to update the status
         * @params: data: JSON payload to send
         */
        function updateUploadStatus(caseId, attachmentId, data){
            var deferred = $q.defer();

            // send the request
            $.ajax({
                async: true,
                contentType: 'application/json',
                type: 'PATCH',
                url: CREATE_CASE_URL + "/" + caseId +"/attachment/" + attachmentId,
                data: JSON.stringify(data),
                success: success,
                error: error
            });

            return deferred.promise;

            function success(data) {
                $log.log('Success: CreateCaseService: updateUploadStatus');
                var response = data || null;
                deferred.resolve(response);
            }

            function error(jqXHR, errorThrown) {
                var errorMsg = 'Error: CreateCaseService: updateUploadStatus: ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }
        }


        return {
            createCase: createCase,
            createTransaction: createTransaction,
            uploadCaseAttachment: uploadCaseAttachment,
            updateUploadStatus: updateUploadStatus
        };

    }]);
});
