/***************************************************************************************************
 *
 * typeahead-input-directive.js
 *
 * Copyright (c) 2015 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * Provides the Type Ahead Functionality for a typeahead input field
 *
 * @author
 * Monique Shotande <moniqueshotande@ge.com>
 *
 ***************************************************************************************************/

define(['angular', 'angularTranslate', 'angularTranslatePartialLoader', './get-active-users-service', 'angular-ui'], function () {

    // Module Dependencies
    var dependencies = [
        'Services.GetActiveUsers',
        'ui.bootstrap',
        'pascalprecht.translate'
    ];

    // Module Definition
    var mod = angular.module('Directive.typeaheadInput', dependencies);

    // Register externalized strings
    mod.config([
        '$translatePartialLoaderProvider',
        function ($translatePartialLoaderProvider) {
            $translatePartialLoaderProvider
                .addPart('../modules/caseexchange/widgets/typeahead-input/i18n');
        }]);

    /**
     * A directive for the typeahead input field with the url containing the data for the GET request
     * Sample:: <typeahead-input
     service-url = "<users url>"
     added-data = "<data[]>"
     is-multiple = "<true/false>" <!-- enable selection of multiple inputs-->
     input-placeholder = "<place holder string>"
     no-data-check="<boolean to check added data>"
     ></typeahead-input>
     */
    mod.directive('typeaheadInput', ['$filter', '$timeout', 'GetActiveUsersService', function ($filter, $timeout, GetActiveUsersService) {

        return {
            restrict: 'E',
            scope: {
                serviceUrl: '@',
                isMultiple: '@',
                inputPlaceholder: '@',
                addedData: '=',
                noDataCheck: '='
            },
            templateUrl: "modules/caseexchange/widgets/typeahead-input/typeahead-input.html",

            //scope: {},

            link: function (scope) {

                // Array of users shown in the email input typeahead
                scope.usersInTypeahead = [];

                // Hides/Displays message as per API response
                scope.noUsersFound = false;

                // Hides/Displays message as per the selection of the recipient
                scope.recipientAlreadySelected = false;

                // Hides/Displays message as per the selection of the recipient
                scope.noMultipleUsers = false;

                // Array of added recipients
                scope.addedRecipients = scope.addedData;

                // Highlight to field on focused
                scope.toFieldInputFocused = false;

                scope.$watch('noDataCheck', function (newValue, oldValue) {
                    if (newValue !== oldValue) {
                        // A boolean flag to indicate error on custom control for user search
                        scope.displayNoRecipientError = scope.noDataCheck;
                    }
                });

                /**
                 * Hiding recipients dropdown if recipient input value is less than 2.
                 */
                scope.$watch('recipientsInput', function (newValue) {
                    if (newValue && newValue.length < 2) {
                        scope.usersInTypeahead = [];
                    }
                });

                /**
                 * Gets an array of users for the UI-Bootstrap Typeahead that is attached to the input field.
                 *
                 * @param email
                 *    The current value of the input field.
                 */
                scope.getActiveUsers = function (email) {
                    if (email && email.length >= 2) {
                        scope.fetchingUserList = true;

                        //prevent resetting the flag when the typeahead is working,
                        //this might accidentally submit the form with fake email id
                        scope.noUsersFound = scope.noUsersFound || false;

                        scope.recipientAlreadySelected = false;
                        scope.noMultipleUsers = false;
                        // Request possible matches from the server (note: the '*' is a wildcard)
                        return GetActiveUsersService.getUsers(scope.serviceUrl, email).then(
                            //The success function
                            function (data) {
                                var users = data.entry;
                                scope.fetchingUserList = false;

                                if (users.length > 0) {
                                    if (email === scope.recipientsInput) {
                                        scope.usersInTypeahead = users;
                                        scope.noUsersFound = false;
                                    }
                                }
                                else {
                                    scope.usersInTypeahead = [];
                                    scope.noUsersFound = true;
                                }
                                return users;
                            },
                            //The error function
                            function () {
                                scope.fetchingUserList = false;
                                scope.usersInTypeahead = [];
                                scope.noUsersFound = true;
                                return [];
                            });
                    } else {
                        scope.usersInTypeahead = [];
                        return [];
                    }
                };

                /**
                 * Finds the selected user in the list of added users.
                 *
                 * @param user
                 *    The selected user for adding/removing
                 */
                var findRecipient = function (user) {
                    return _.find(scope.addedRecipients, function (recipient) {
                        return recipient.id === user.id;
                    });
                };

                /**
                 * Adds the recipient in the list of added users.
                 *
                 * @param user
                 *    The selected user for adding into the list
                 */
                scope.addRecipient = function (user) {
                    scope.recipientsInput = "";
                    scope.toFieldInputFocused = true;
                    scope.usersInTypeahead = [];
                    if (scope.isMultiple === 'false' && scope.addedRecipients.length >= 1) {
                        scope.noMultipleUsers = true;
                    }
                    else if (findRecipient(user)) {
                        scope.recipientAlreadySelected = true;
                    }
                    else {
                        scope.addedRecipients.push(user);
                        scope.tempRecipients = scope.addedRecipients;
                        // Hide the error if there is at least one recipient
                        scope.displayNoRecipientError = false;
                    }
                    $('#recipientsInput').focus();
                };

                /**
                 * Removes the recipient from the list of added users.
                 *
                 * @param user
                 *    The selected user for removing from the list
                 */
                scope.removeRecipient = function (user) {
                    var recipient = findRecipient(user);
                    if (recipient) {
                        scope.addedRecipients.splice(scope.addedRecipients.indexOf(recipient), 1);
                        scope.tempRecipients = scope.addedRecipients;
                        // If there are no more recipient, then display the error.
                        scope.displayNoRecipientError = scope.addedRecipients.length === 0;
                    }
                };

                /**
                 * Hides all the information messages on input field tab out.
                 */
                scope.hideInfoMessages = function () {
                    scope.toFieldInputFocused = false;
                    if (scope.recipientsInput === undefined || scope.recipientsInput.length < 2) {
                        scope.recipientAlreadySelected = false;
                        scope.noUsersFound = false;
                        scope.noMultipleUsers = false;
                    }
                };

                /**
                 * Highlighting To field on focus
                 */
                scope.highlightToField = function () {
                    scope.toFieldInputFocused = true;
                };

                /**
                 * Handles up arrow key press
                 */
                var handleUpArrowKey = function (){
                    var i;
                    for (i = 0; i < scope.usersInTypeahead.length; i++) {
                        if (scope.usersInTypeahead[i].hover) {
                            if (i > 0) {
                                scope.usersInTypeahead[i].hover = false;
                                scope.usersInTypeahead[i - 1].hover = true;
                            }
                            return;
                        }
                    }
                };

                /**
                 * Handles down arrow key press
                 */
                var handleDownArrowKey = function (){
                    var i;
                    var highlightedFound = false;
                    for (i = 0; i < scope.usersInTypeahead.length; i++){
                        if (scope.usersInTypeahead[i].hover){
                            highlightedFound = true;
                            if (i < scope.usersInTypeahead.length - 1){
                                scope.usersInTypeahead[i].hover = false;
                                scope.usersInTypeahead[i+1].hover = true;
                            }
                            return;
                        }
                    }
                    if (scope.usersInTypeahead.length > 0 && !highlightedFound){
                        scope.usersInTypeahead[0].hover = true;
                    }
                };

                /**
                 * Handles when arrow and enter keys are pressed
                 */
                scope.handleKeyPress = function (keyCode){
                    // Enter key
                    if (keyCode === 13 || keyCode === 9){
                        scope.usersInTypeahead.forEach(function(e){
                            if (e.hover){
                                delete e.hover;
                                scope.addRecipient(e);
                            }
                        });
                        return;
                    }
                    // Up arrow key
                    else if (keyCode === 38){
                        handleUpArrowKey();
                    }
                    // Down arrow key
                    else if (keyCode === 40){
                        handleDownArrowKey();
                    }
                };


            }
        };
    }]);
});
