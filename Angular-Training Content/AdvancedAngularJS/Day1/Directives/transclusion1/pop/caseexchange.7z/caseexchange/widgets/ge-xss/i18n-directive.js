/***************************************************************************************************
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * A factory that provides i18n messages for the 'geXss' directive.
 *
 * @author
 * Henry Navarro   <henry.navarro@ge.com>
 *
 ***************************************************************************************************/
define(['angular', 'angularTranslate', 'angularTranslatePartialLoader'], function () {

    // Module Dependencies
    var dependencies = ['pascalprecht.translate'];

    // Module Creation
    var mod = angular.module('Directives.geXss.i18n', dependencies);

    // Register externalized strings for all the sub modules of case exchange.
    mod.config([
        '$translatePartialLoaderProvider',
        function ($translatePartialLoaderProvider) {
            $translatePartialLoaderProvider
                .addPart('./modules/caseexchange/widgets/ge-xss/i18n');
        }]);

    /**
     * @name Directives.GeXss.i18n
     * @type factory
     *
     * @description
     * A factory that provides i18n messages for the 'geXss' directive.
     */
    mod.factory('Directives.geXss.i18n', ['$filter', function ($filter) {

        /**
         * Gets all the messages for the 'geXss' directive.
         */
        function getMessages() {
            return {
                scriptingDetected: $filter('translate')('gexss.scriptingDetected'),
                scriptingDetectedCAPS: $filter('translate')('gexss.scriptingDetectedCAPS'),
                invalidFormatCAPS: $filter('translate')('gexss.invalidFormatCAPS')
            };
        }

        // Public API
        return {
            getMessages: getMessages
        };

    }]);

});