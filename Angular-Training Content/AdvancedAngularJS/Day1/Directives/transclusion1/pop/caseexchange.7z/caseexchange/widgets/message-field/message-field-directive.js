/***************************************************************************************************
 *
 *  message-field-directive.js
 *
 * Copyright (c) 2015 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * Provides a directive for message field with text length limit for the field.
 *
 * @author
 * Harshit Desai <harshit.desai@ge.com>
 * Monique Shotande <moniqueshotande@ge.com>
 *
 ***************************************************************************************************/
define(['angular', '../caseexchange/../ge-xss/ge-xss-directive'], function () {

    // Module Dependencies
    var dependencies = ['Directives.geXss'];

    // Module Definition
    var mod = angular.module('Directive.messageField', dependencies);

    /**
     * A directive for description field with text length limit for the field.
     * Sample:: <message-field
     field-id        = "<element id>"
     field-name      = "<element name>"
     field-model     = "<ng-model value>"
     field-maxlength = "<max allowed characters i.e. 500>"
     field-disabled  = "<false/true>"
     field-empty-check="<boolean to check message entered or not>"></message-field>
     */
    mod.directive('messageField', function () {
        return {
            replace: false,
            restrict: 'E',
            scope: {
                fieldModel: '=',
                fieldId: '@',
                fieldName: '@',
                fieldMaxlength: '@',
                fieldDisabled: '=',
                fieldEmptyCheck: '='
            },
            templateUrl: "modules/caseexchange/widgets/message-field/message-field.html",
            link: function (scope, elem) {
                var _this = elem.find('textarea');
                scope.remainingCharacters = scope.fieldMaxlength || "500";

                scope.$watch('fieldEmptyCheck', function (newValue, oldValue) {
                    if (newValue !== oldValue) {
                        scope.noMessageAdded = scope.fieldEmptyCheck;
                    }
                });

                scope.$watch('fieldModel', function (newValue, oldValue) {
                    if (newValue !== oldValue && newValue !== '') {
                        if (!newValue) {
                            scope.noMessageAdded = true;
                        }
                        else {
                            scope.noMessageAdded = false;
                        }
                    }
                    var newLines = _this.val().match(/(\r\n|\n|\r)/g);
                    if (newLines !== null) {
                        scope.remainingCharacters = (scope.fieldMaxlength - (_this.val().length + newLines.length));
                    }
                    else {
                        scope.remainingCharacters = (scope.fieldMaxlength - _this.val().length);
                    }
                    if (scope.remainingCharacters <= 50) {
                        if (scope.remainingCharacters <= 0) {
                            scope.remainingCharacters = 0;
                        }
                        scope.fewCharsLeft = true;
                    }
                    else {
                        scope.fewCharsLeft = false;
                    }
                });
            }
        };
    });

});