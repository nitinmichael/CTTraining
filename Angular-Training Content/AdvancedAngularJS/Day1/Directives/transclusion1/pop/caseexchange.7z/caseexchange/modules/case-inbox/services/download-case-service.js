/*
 *  case-data-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

define(['angular'], function () {

    // Module Dependencies
    var dependencies = ['Services.caseExchangeDataService'];

    // Module Definition
    var mod = angular.module('Services.downloadCaseService', dependencies);

    /**
     * @name DownloadCaseService
     * @type factory
     *
     * @description
     * A factory that provides methods for making request to the Download Case REST API to post the data.
     */
    mod.factory('DownloadCaseService', ['CaseExchangeDataService', '$q', '$log', function (caseExchangeDataService, $q, $log) {

         var DOWNLOAD_CASE_ATTACHMENT_URL = caseExchangeDataService.getServiceURL() + '/caseattachment/v1/case/';

        /**
         * Makes a call to service to send request payload
        */
        function downloadCaseAttachment(data, caseId) {
            // validate arguments
            if (!angular.isObject(data)) {
                var errorMsg = 'Error: DownloadCaseService: downloadCaseAttachment: invalid parameter: data = ' + data;
                $log.error(errorMsg);
                return $q.reject(errorMsg);
            }

            if (!caseId || caseId === "" ) {
                errorMsg = 'Error: DownloadCaseService: downloadCaseAttachment: invalid parameter: caseId = ' + caseId;
                $log.error(errorMsg);
                return $q.reject(errorMsg);
            }

            var deferred = $q.defer();

            $.ajax({
                async: true,
                contentType: 'application/json',
                type: 'post',
                url: DOWNLOAD_CASE_ATTACHMENT_URL  + caseId +'/attachment/store',
                data: JSON.stringify(data),
                success: success,
                error: error
            });

            return deferred.promise;

             function success(data) {
                $log.log('Success: DownloadCaseService: downloadCaseAttachment');
                var response = data || null;
                deferred.resolve(response);
            }

            function error(jqXHR, errorThrown) {
                var errorMsg = 'Error: DownloadCaseService: downloadCaseAttachment : ' + errorThrown;
                $log.error(errorMsg);
                deferred.reject(jqXHR);
            }
        }

        return {
            downloadCaseAttachment: downloadCaseAttachment
        };
    }]);
});