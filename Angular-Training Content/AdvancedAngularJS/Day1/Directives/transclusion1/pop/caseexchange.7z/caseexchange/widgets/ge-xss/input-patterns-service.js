/***************************************************************************************************
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * A factory that provides input field patterns: i.e. <input pattern="xxx">.
 *
 * @author
 * Eric Steele <eric.steele@ge.com>
 *
 ***************************************************************************************************/
define(['angular'], function() {

  // Module Definition
  var mod = angular.module('Services.inputPatterns', []);

  /**
   * @name inputPatterns
   * @type factory
   *
   * @description
   * A factory that provides input field patterns: i.e. <input pattern="xxx">.
   */
  mod.factory('InputPatterns', function() {

    function matches (str, pattern) {
      if (typeof str === 'undefined' || typeof pattern === 'undefined' || str === null || str === '') {
        return false;
      }
      var regex = (typeof pattern === 'string' ? new RegExp(pattern) : pattern.constructor.toString().match(/function (\w*)/)[1] === 'RegExp' ? pattern : null);
      if (regex == null) {
        return false;
      }
      return regex.test(str + '');
    }

    return {

      matches: matches,

      // #####
      zipCode: /(^\d{5}$)/,

      // ##### or #####-####
      zipCodePlus4: /(^\d{5}$)|(^\d{5}-\d{4}$)/,

      // +# or +# ### or +###
      phoneCountryCode: /^\+\d\s\d+$|^\+\d+$/,

      password: /^((?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%\"!#$%&'()*+,-.\/:;<=>?@\\ ^_`{|}~]).{8,32})$/,

      integer: /^[-+]?[0-9]+$/,

      float: /^[-+]?[0-9]*\.?[0-9]+$/,

      currency: /^[0-9]*\.[0-9]{2,2}$/,

      // from http://stackoverflow.com/questions/2385701/regular-expression-for-first-and-last-name
      name: /^[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]+$/,

      // from http://stackoverflow.com/questions/4338267/validate-phone-number-with-javascript
      phone: /^[(]{0,1}[0-9]{3}[)]{0,1}[-\s\. ]{0,1}[0-9]{3}[-\s\. ]{0,1}[0-9]{4}$/,

      // from http://blog.trojanhunter.com/2012/09/26/the-best-regex-to-validate-an-email-address/
      email: /^[-0-9a-zA-Z.+_]+@[-0-9a-zA-Z.+_]+\.[a-zA-Z]{2,4}$/,

      usZip: /^[1-9]{5}(-[0-9]{4})?$/,

      ipAddress: /^((([2][5][0-5]|([2][0-4]|[1][0-9]|[0-9])?[0-9])\.){3})([2][5][0-5]|([2][0-4]|[1][0-9]|[0-9])?[0-9])$/,

      // from https://www.owasp.org/index.php/OWASP_Validation_Regex_Repository
      url: /^((((file?|https?|ftps?|gopher|telnet|nntp):\/\/)|(mailto:|news:))(%[0-9A-Fa-f]{2}|[-()_.!~*';\/?:@&=+$,A-Za-z0-9])+)([).!';\/?:,][[:blank:]])?$/
    };

  });

});