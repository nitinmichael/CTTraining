/*
 *  dicom-attachment-marshaller-service.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * A factory that provides methods for marshaling case dicom study and device data to be shared into the format expected by the microservice.
 */
define(['angular'], function () {

    // Create Case marshaller Module
    var mod = angular.module('Services.dicomAppServicesMarshallerService', []);

    /**
     * A factory that provides method for marshaling data related to selected device and selected studies
     * of that patient to be shared into the format expected by the REST API.
     */
    mod.factory('DicomAppServicesMarshallerService', [function () {

        /**
         * Marshals the case attachment data to be pushed into download case JSON.
         *
         * @param studyAttachments
         *    studyAttachments to be added in download case object.
         * @param pacsDevices
         *    pacsDevices to be added in download case object.
         */
        function marshallDicomAppServices(studyAttachments, pacsDevices) {
            // list of study attachment and appservice
            var attachments = [];
            var appService = null;

            if (studyAttachments && studyAttachments.length !== 0) {
                for (var i = 0; i< studyAttachments.length; i++) {

                    var study = {
                        "type": studyAttachments[i].type,
                        "identifier": studyAttachments[i].identifier,
                        "uid": studyAttachments[i].uid
                        };
                    attachments.push(study);
                }
            }

            if (pacsDevices) {
                    appService = {
                        "id": pacsDevices.id,
                        "endpoint": pacsDevices.content && pacsDevices.content.endpoint ? pacsDevices.content.endpoint : '',
                        "attachments": attachments
                    };
            }

            var data ={
                "applicationService": appService
            };
            return data;
        }

        return {
            marshallDicomAppServices: marshallDicomAppServices
        };
    }]);
});