﻿/*
 * create-case-data-service.js
 *
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 *
 *  @author:
 *  Jignesh Parekh<jignesh.parekh@ge.com>
 *
 *  @description:
 *  Module for Create case data service which provides the factory that retains the data between create case and PACS Query search module.
 */

define(['angular'], function () {

    // Module Dependencies
    var dependencies = [];

    // Module Definition
    var mod = angular.module('Services.createCaseDataService', dependencies);

    /**
     * @name CreateCaseDataService
     * @type factory
     *
     * @description
     * A factory that provides methods for storing a data for create-case screen
     */
    mod.factory('CreateCaseDataService', function () {
        // variable to hold create case data
        var createCaseData;

        /**
         * Function to set the new value to create case data object
         */
        function setCreateCaseData(data) {
            createCaseData = data;
        }

        /**
         * Function to get the value of create case data object
         */
        function getCreateCaseData() {
            return createCaseData;
        }

        /**
         * Function to clear the value of create case data object
         */
        function clearCreateCaseData() {
            createCaseData = null;
        }

        // Public API
        return {
            getCreateCaseData: getCreateCaseData,
            setCreateCaseData: setCreateCaseData,
            clearCreateCaseData: clearCreateCaseData
        };

    });
});