/*
 *  download-to-premise-controller.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * AngularJS controller module for the Download To Premise (Send To DICOM)
 * functionality for a case's DICOM attachments.
 */
define(
    ['angular',
        'angularTranslate',
        '../../../module'],
    function (ng) {
        'use strict';

        // define module dependencies
        var dependencies = [ 'pascalprecht.translate', 'Services.dicomAppServicesMarshallerService', 'Services.downloadCaseService','Services.normalizationService'];

        // define module
        var module = ng.module('cloudav.caseExchange.caseInbox.downloadToPremiseCtrl', dependencies);

        // define module controller
        module.controller('DownloadToPremiseCtrl', ['$scope', '$state', '$filter', 'DicomAppServicesMarshallerService', 'DownloadCaseService',
                                                    'NormalizationService',
            function($scope, $state, $filter, DicomAppServicesMarshallerService, DownloadCaseService, NormalizationService) {

                $scope.studySelected = false;
                $scope.deviceSelected = false;

                // operation type for Download to premise
                var operationType = "DOWNLOAD";

                // variable to hold the selected studies
                var selectedDicomStudies = [];

                /**
                 * Called when user clicks on 'Cancel' button in Download To Premise UI
                 * De-selects all studies for download,
                 * unsets the variable used by Angular to hide the case list and summary
                 * and finally navigates back to the caseinbox ui-router state
                 */
                $scope.cancelDownloadToPremise = function() {
                    var studiesLength = $scope.selectedCaseStudies.length;
                    for (var s = 0; s < studiesLength; s++) {
                        $scope.selectedCaseStudies[s].selectedForDownload = false;
                    }
                    var devicesLength = $scope.pacsDevices.length;
                     for (var d = 0; d < devicesLength; d++) {
                        $scope.pacsDevices[d].selectedForDownload = false;
                    }
                    $state.go('caseexchange.caseinbox');
                    $scope.$parent.downloading = false;
                };

                /**
                 *
                 * Toggles the selection mode of a study for Send To DICOM
                 *
                 * Date: 09/2/2015
                 * @author: 502449103 - changed to attachment identifier for comparison
                 * and toggling to work based on uique id
                 */
                $scope.toggleStudySelection = function(identifier) {
                    var studiesLength = $scope.selectedCaseStudies.length, currentStudy;
                    for (var s = 0; s < studiesLength; s++) {
                        currentStudy = $scope.selectedCaseStudies[s];
                        if (identifier === currentStudy.identifier) {
                            currentStudy.selectedForDownload = !currentStudy.selectedForDownload;
                        }
                    }

                    // scope variable to enable/disable the "Download" button
                    $scope.studySelected = false;
                    for (var study = 0; study < studiesLength; study++) {
                        currentStudy = $scope.selectedCaseStudies[study];
                        if (currentStudy.selectedForDownload) {
                            $scope.studySelected = true;
                            break;
                        }
                     }
                };

                $scope.selectedDevice = null;

                /**
                 *
                 * Toggles the selection of a device for Send To DICOM
                 */
                $scope.toggleDeviceSelection = function(device) {
                    var pacsDevicesLength;
                    if (device.selectedForDownload) {
                        device.selectedForDownload = false;
                        $scope.deviceSelected = false;
                    }
                    else {
                        pacsDevicesLength = $scope.pacsDevices.length;
                        for ( var d = 0; d < pacsDevicesLength; d++) {
                            $scope.pacsDevices[d].selectedForDownload = false;
                        }
                        device.selectedForDownload = true;
                        $scope.deviceSelected = true;
                        $scope.selectedDevice = device;
                    }
                };

                /**
                 * Initiates download to premise api call by passing study(s) and
                 * device data to Send to Dicom REST service api
                 */
                $scope.downloadCase = function () {

                    selectedDicomStudies = addSelectedStudies($scope.selectedCaseStudies);
                    var dicomAppServiceData = DicomAppServicesMarshallerService.marshallDicomAppServices(selectedDicomStudies, $scope.selectedDevice);
                    dicomAppServiceData.operationType = operationType;
                    DownloadCaseService.downloadCaseAttachment(dicomAppServiceData, $scope.selectedCase.id).then(function () {
                        $scope.showAlertMessage($filter('translate')('sendToDicom.inProgress'), $scope.alertTypes.success);
                    }, function () {
                        $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
                    });
                    deselectStudies($scope.selectedCaseStudies.length);
                    deselectDevices($scope.pacsDevices.length);
                    $state.go('caseexchange.caseinbox');
                    $scope.$parent.downloading = false;
                };

                /**
                 * Function to add the Dicom studies selected by user
                 */
                function addSelectedStudies(selectedCaseStudies) {
                    for (var i=0; i<selectedCaseStudies.length; i++) {
                        var currentStudy = $scope.selectedCaseStudies[i];
                        if(currentStudy.selectedForDownload) {
                            selectedDicomStudies.push(currentStudy);
                        }
                    }
                    return selectedDicomStudies;
                }

                /**
                 * deselect the studies when download to premise operation completed
                 */
                 function deselectStudies(studiesLength) {
                        for (var s = 0; s < studiesLength; s++) {
                            $scope.selectedCaseStudies[s].selectedForDownload = false;
                        }
                     }

                 /**
                 * deselect the devices when download to premise operation completed
                 */
                 function deselectDevices(pacsDevicesLength) {
                        for (var d = 0; d < pacsDevicesLength; d++) {
                            $scope.pacsDevices[d].selectedForDownload = false;
                        }
                     }

                 /**
                  * Load Normalization Screen if case has patient details
                  */
                 $scope.loadNormalizationScreen = function () {
                     if ($scope.selectedCase.patient) {
                         $scope.$parent.normalize = true;
                         $state.go('caseexchange.caseinbox.normalization');
                         NormalizationService.setSelectedCase($scope.selectedCase);
                         NormalizationService.setSelectedCaseStudies(angular.copy($scope.selectedCaseStudies));
                         NormalizationService.setSelectedDicomDevices($scope.selectedDevice);
                     }
                 };

                /**
                 * check if selected study list is already selected
                 */
                 $scope.isStudyAlreadySeleted = function() {
                    if ($scope.selectedCaseStudies) {
                        for (var i = 0; i < $scope.selectedCaseStudies.length; i++) {
                            if ($scope.selectedCaseStudies[i].selectedForDownload) {
                                $scope.studySelected = true;
                                break;
                            }
                        }
                    }
                };

                /**
                 * check if dicom device is already selected
                 */
                 $scope.isDicomAlreadySeleted = function() {
                    if ($scope.pacsDevices) {
                        for (var i = 0; i < $scope.pacsDevices.length; i++) {
                            if ($scope.pacsDevices[i].selectedForDownload) {
                                $scope.deviceSelected = true;
                                $scope.selectedDevice = $scope.pacsDevices[i];
                                break;
                            }
                        }
                    }
                };

                $scope.isStudyAlreadySeleted();
                $scope.isDicomAlreadySeleted();

            }
        ]);
    });
