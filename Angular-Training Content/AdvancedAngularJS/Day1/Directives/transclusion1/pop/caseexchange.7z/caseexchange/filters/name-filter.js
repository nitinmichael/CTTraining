/***************************************************************************************************
 *
 * typeahead-input-directive.js
 *
 * Copyright (c) 2015 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 *
 ***************************************************************************************************
 *
 * @description
 * Converts given and family name arrays to plain text
 *
 * @author
 * Chris Chike <christopher.chike@ge.com>
 *
 ***************************************************************************************************/

define(['angular'], function () {

    // Module Dependencies
    var dependencies = [];

    // Module Definition
    var mod = angular.module('Filters.name', dependencies);

    mod.filter('name', function () {

        return function(names) {
            if (!names){
                return "";
            }

            var given = "";
            var family = "";

            if (names.given) {
                names.given.forEach(function (e) {
                    if (!given) {
                        given = e;
                    }
                    else {
                        given = given + " " + e;
                    }
                });
            }

            if (names.family) {
                names.family.forEach(function (e) {
                    if (!family) {
                        family = e;
                    }
                    else {
                        family = family + " " + e;
                    }
                });
            }

            if (!given){
                return family;
            }
            return family + ", " + given;
        };

    });
});

