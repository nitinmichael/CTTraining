/*
 * create-instruction-controller.js
 * Copyright (c) 2015 by General Electric Company. All rights reserved.
 * The copyright to the computer software herein is the property of General Electric Company. The software may be used
 * and/or copied only with the written permission of General Electric Company or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the software has been supplied.
 */

/**
 * A Create Instruction Controller to handle Create Instruction related operations.
 */
define([ 'angular', 'postal', '../../../module' ], function(ng) {
    'use strict';

    // Module dependencies
    var dependencies = [
        'Directives.geControlGroup',
        'Directive.typeaheadInput',
        'Services.caseExchangeDataService',
        'Services.caseAutomationDataService',
        'Services.caseAutomationService',
        'Services.instructionConditionMarshallerService',
        'Services.postProcessingConditionMarshallerService',
        'Services.createInstructionMarshallerService',
        'Services.clinicalReasonsService',
        'Directive.messageField',
        'Services.getInstructionConditionsService'
    ];

    var createInstruction = ng.module('cloudav.caseExchange.createInstructionCtrl', dependencies),
        getConditionKeyListXHR;

    createInstruction.controller('CreateInstructionCtrl', ['$scope', '$state', '$stateParams', '$filter', 'CaseExchangeDataService', 'CaseAutomationDataService', 'InstructionConditionMarshallerService', 'PostProcessingConditionMarshallerService', 'CreateInstructionMarshallerService', 'ClinicalReasonsService', 'CaseAutomationService', 'GetInstructionConditionsService',
            function($scope, $state, $stateParams, $filter, caseExchangeDataService, caseAutomationDataService, instructionConditionMarshallerService, postProcessingConditionMarshallerService, createInstructionMarshallerService, clinicalReasonsService, caseAutomationService, getInstructionConditionsService) {

        $scope.usersURL = caseExchangeDataService.getServiceURL() + "/userregistry/v2/user/_search";

        // Switch for creating or updating instruction
        $scope.mode = $state.current.params.mode;

        // List of added recipients will be pushed into this array
        $scope.addedRecipients = [];

        // Boolean to verify recipients added or not
        $scope.noRecipientsAdded = false;

        //Auto create instruction input object
        $scope.autoCreate = {};

        // Array of Clinical Reasons filled with API response
        $scope.clinicalReasons = [];

        // The id defined in DB for Clinical Reason Other
        // Note:: Need to update the value if DB value changes
        $scope.clinicalReasonOtherId = '9';

        // Boolean to verify impression added or not
        $scope.noImpressionAdded = false;

        // Boolean to verify other clinical reason is unique or not
        $scope.uniqueOtherClinicalReason = false;

        var caseAutomationServiceXHR;

        // Post condition Object
        $scope.autoCreate.postCondition = {};

        //maximum procedure Description length
        var MAX_DESCRIPTION_LENGTH = "64";

        /**
         * Validate Clinical Reason
         */
        var validateClinicalReason =function() {
            var isValid = true;
            if(!$scope.autoCreate.clinicalReason){
                isValid =false;
            }else {
                if(!$scope.validateOtherClinicalReason()){
                    isValid =false;
                }
            }
            return isValid;
        };

        /**
         * Validate Other Clinical Reason
         */
        $scope.validateOtherClinicalReason = function() {
            var isValid = true;
            if(($scope.autoCreate.clinicalReason.id === $scope.clinicalReasonOtherId && $scope.autoCreate.otherClinicalReason)){
                $scope.uniqueOtherClinicalReason = false;
                isValid = $scope.autoCreate.otherClinicalReason.trimLeft().length === 0 ? false : true;
                _.each($scope.clinicalReasons, function (reason){
                    if(reason.value === $scope.autoCreate.otherClinicalReason){
                        isValid = false;
                        $scope.uniqueOtherClinicalReason = true;
                    }
                });
            }
            return isValid;
        };

        /**
         * Validate Impression
         */
        var validateImpression = function() {
            var isValid = true;
            if(!$scope.autoCreate.impression || ($scope.autoCreate.impression && ($scope.autoCreate.impression.length === 0 || $scope.autoCreate.impression.length > 201))) {
                isValid =false;
                $scope.noImpressionAdded = true;
                $scope.toogleCarotIconImpression = true;
            }
            return isValid;
        };

        /**
         * Update Error Message For Post Prossessing Condition
         */
        var updateErrorMessage = function(){
            if($scope.invalidDescription){
                $scope.postProcessingerrormsg=$filter('translate')('createInstruction.conditionSpecialCharError');
            }
            else{
                $scope.postProcessingerrormsg = "";
            }
        };

        /**
         * Validate Post Condition
         */
        $scope.validatePostCondition = function() {
            var isValid = true,
                postConditionDescription = $scope.autoCreate.postCondition.description,
                postConditionModality = $scope.autoCreate.postCondition.modality;

            isValid = $scope.validatePostConditionDescription();
            $scope.missingDescription = false;
            if(!postConditionDescription && postConditionModality){
                isValid = false;
                $scope.missingDescription = true;
            }

            $scope.invalidAlgo = false;
            if(postConditionDescription && !postConditionModality){
                isValid = false;
                $scope.invalidAlgo = true;
            }

            if(!isValid){
              $scope.toggleCarotIconPostProcessing = true;
            }
            return isValid;
        };

        /**
         * Validate Post Condition description for special character and max no of characters
         */
        $scope.validatePostConditionDescription = function() {
            var isValid = true,
                postConditionDescription = $scope.autoCreate.postCondition.description;

            $scope.invalidDescription = false;
            if(postConditionDescription && postConditionDescription.match(/[*,?,\\,^]/g) != null) {
                isValid = false;
                $scope.invalidDescription = true;
                $scope.postProcessingerrormsg=$filter('translate')('createInstruction.conditionSpecialCharError');
            }
            if(postConditionDescription && postConditionDescription.length > MAX_DESCRIPTION_LENGTH){
                isValid = false;
                $scope.invalidDescription = true;
            }

            updateErrorMessage();

            return isValid;
        };

        /**
         * Validation instruction and Post Processing Conditions
         */
        var validateInstrAndPostCondition = function(){
            var isInstrValid = $scope.validateInstructionCondition(),
                isPostConditionValid = $scope.validatePostCondition();
            return (isInstrValid && isPostConditionValid);
        };

        /**
         * validate create instruction input fields.
         * TODO:Error messages display is remaining.
         */
        var validateCreateInstruction = function() {
            var isValid = true;

            if( !$scope.autoCreate.instructionName || ($scope.autoCreate.instructionName && ($scope.autoCreate.instructionName.trimLeft().length > 50 || $scope.autoCreate.instructionName.trimLeft().length < 1))) {
                isValid =false;
            }
            if($scope.addedRecipients.length === 0) {
                isValid =false;
                $scope.noRecipientsAdded = true;
            }
            if($scope.autoCreate.siteName.trimLeft().length === 0) {
                isValid =false;
            }
            if(!validateClinicalReason()){
                isValid =false;
            }
            if(!validateImpression()) {
                isValid =false;
            }
            if(!validateInstrAndPostCondition()) {
                isValid =false;
            }
            return isValid;
        };

        /**
         * Creates or updates the Instruction.
         * TODO: save functionality
         */
        var createInstruction = function() {
            if(validateCreateInstruction()) {
                var createInstructionJson=createInstructionMarshallerService.createInstructionMarshal($scope.autoCreate,$scope.addedRecipients);
                caseAutomationServiceXHR=caseAutomationService.caseInstructionCurdOperation("POST", null, createInstructionJson);
                caseAutomationServiceXHR.promise.then(function() {
                    $scope.showAlertMessage($filter('translate')('createInstruction.createInstSuccess'), $scope.alertTypes.success);
                    $state.transitionTo('caseexchange.caseautomation', {id : $stateParams.id, selectedSite:$scope.autoCreate.site});
                },
                function() {
                    $scope.showAlertMessage($filter('translate')('createInstruction.createInstError'), $scope.alertTypes.error);
                });
            }
        };

        /**
         * Creates or updates the Instruction.
         */
        $scope.submitInstruction = function (mode) {
            if (mode === 'AUTOCREATE') {
                createInstruction();
            }
        };

        /**
         * Function to add max 3 condition instruction
         */
        $scope.addCondition = function () {
            if($scope.autoCreate.instCondition.length < 3){
                var instCondition = instructionConditionMarshallerService.getConditionSkeleton();
                $scope.autoCreate.instCondition.push(instCondition);
            }
        };

        /**
         * Function to remove condition instruction
         */
        $scope.removeCondition = function (condition) {
            if($scope.autoCreate.instCondition.length>1){
                var pos = $scope.autoCreate.instCondition.indexOf(condition);
                if (pos > -1) {
                    $scope.autoCreate.instCondition.splice(pos, 1);
                }
            }
        };

        /**
         * set modality on change of algorithm
        */
        $scope.setModality =function (algoKey){
            $scope.autoCreate.postCondition.modality = algoKey ?_.find($scope.postProcessingConditionTypeList, function(algoObj){return algoObj.key === algoKey.key;}).modality :"";
        };

        /**
         * Function to remove post processing condition
         */
        $scope.removePostProcessingCondition = function () {
            $scope.autoCreate.postCondition.modality = "";
            $scope.autoCreate.postCondition.algorithm = "";
            $scope.autoCreate.postCondition.description = "";
            $scope.missingDescription = false;
            $scope.invalidDescription = false;
            $scope.invalidAlgo = false;
            $scope.postProcessingerrormsg = "";
            $scope.toggleCarotIconPostProcessing =false;
        };

        /**
         * Called on cancel Button, which get redirected to the case automation instruction list page.
         */
        $scope.cancelButton = function() {
            $state.transitionTo('caseexchange.caseautomation', {id : $stateParams.id, selectedSite:$scope.autoCreate.site});
        };

        /**
         * Makes an API call to retrieve Clinical Reasons and populate Dropdown box
         */
        var populateClinicalReasons = function() {
            clinicalReasonsService.getClinicalReasons().then(function (response) {
                if (response && response instanceof Array) {
                    $scope.clinicalReasons = response;
                }
            }, function () {
                $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
            });
        };

        /**
         * method to call service to get supported diocm condition.
         */
        $scope.getDicomCondition = function() {
            getConditionKeyListXHR = getInstructionConditionsService.getConditionKeyList();
            getConditionKeyListXHR.promise.then(function(data) {
                $scope.conditionKeyList = data;
            }, function() {
                $scope.showAlertMessage($filter('translate')('common.genericError'), $scope.alertTypes.error);
            });
        };

        /**
         * method to validate instruction condition attribute are empty.
         */
         var isInstConditionFieldEmpty = function(instConditionField) {
             var isInvalid;
             if(!instConditionField || instConditionField===""){
                 isInvalid=true;
             }
             else {
                 isInvalid=false;
             }
             return isInvalid;
         };

         /**
          * method to validate all conditions when dicom attribute is modality.
          */
          var validateModalityAttrValue = function(instConditionList, valueList) {
              if(valueList.toString()===""){
                  instConditionList.errormsg=$filter('translate')('createInstruction.conditionModalityCommaSepratedError');
                  instConditionList.valueInvalid=true;
                  return;
              }else{
                 for (var i = 0; i < valueList.length; i++){
                      if(valueList[i].trim()===""){
                          instConditionList.errormsg=$filter('translate')('createInstruction.conditionModalityCommaSepratedError');
                          instConditionList.valueInvalid=true;
                      }
                      else if(!_.contains(instructionConditionMarshallerService.getValidDicomValues(), valueList[i].trim())){
                          instConditionList.errormsg=$filter('translate')('createInstruction.conditionModalityInvalidDicomVal');
                          instConditionList.valueInvalid=true;
                      }else{
                          instConditionList.errormsg="";
                          instConditionList.valueInvalid=false;
                      }
                 }
              }
          };

          /**
           * method to validate all conditions when dicom attribute is referring phy or performing phy.
           */
           var validateNameAttrValue = function(instConditionList, valueList) {
              var totalAllowedNameComponent=3;
              var nameMaxLength=64;
              if(valueList.toString()===""){
                      instConditionList.errormsg=$filter('translate')('createInstruction.conditionNameCommaSepratedError');
                      instConditionList.valueInvalid=true;
                      return;
                  }
                  else{
                      if(valueList.length>totalAllowedNameComponent){
                          instConditionList.errormsg=$filter('translate')('createInstruction.conditionNameCommaSepratedError');
                          instConditionList.valueInvalid=true;
                          return;
                      }
                      for (var i = 0; i < valueList.length; i++){
                          if(valueList[i].trim().length>nameMaxLength){
                              instConditionList.errormsg=$filter('translate')('createInstruction.conditionNameMaxLengthError');
                              instConditionList.valueInvalid=true;
                              return;
                          }
                          if(valueList[i].trim()===""){
                              instConditionList.errormsg=$filter('translate')('createInstruction.conditionNameCommaSepratedError');
                              instConditionList.valueInvalid=true;
                              return;
                          }
                      }
                  }
           };

        /**
         * method to validate instruction condition boolean attribute.
         */
         $scope.validateBooleanIntCondition = function(instConditionList) {
             if(isInstConditionFieldEmpty(instConditionList.boolean)){
                 instConditionList.booleanInvalid=true;
             }
             else {
                 instConditionList.booleanInvalid=false;
             }
             return instConditionList.booleanInvalid;
         };

        /**
         * method to validate instruction condition key attribute.
         */
         $scope.validateKeyIntCondition = function(instConditionList) {
             if(isInstConditionFieldEmpty(instConditionList.key)){
                 instConditionList.keyInvalid=true;
             }
             else {
                 instConditionList.keyInvalid=false;
             }
             return instConditionList.keyInvalid;
         };

        /**
         * method to validate instruction condition type attribute.
         */
         $scope.validateTypeIntCondition = function(instConditionList) {
             if(isInstConditionFieldEmpty(instConditionList.type)){
                 instConditionList.typeInvalid=true;
             }
             else {
                 instConditionList.typeInvalid=false;
             }
             return instConditionList.typeInvalid;
         };

        /**
         * method to validate instruction condition value attribute.
         */
          $scope.validateValueIntCondition = function(instConditionList) {
             var valueVaildRegex = new RegExp('(\\*|\\?|\\\\|\\^)');
             instConditionList.errormsg="";
             instConditionList.valueInvalid=false;
             if(!instConditionList.value || instConditionList.value===""){
                 instConditionList.value="";
                 instConditionList.valueInvalid=true;
             }

             if(valueVaildRegex.test(instConditionList.value)){
                 instConditionList.valueInvalid=true;
                 instConditionList.errormsg=$filter('translate')('createInstruction.conditionSpecialCharError');
             }else{
                 var valueList = instConditionList.value.split(",");
                 if(instConditionList.key){
                     var key = instConditionList.key.key;
                     if(key==="00080060"){
                         validateModalityAttrValue(instConditionList, valueList);
                     }
                     else if(key==="00080090" || key==="00081050"){
                         validateNameAttrValue(instConditionList, valueList);
                     }
                 }
             }
             return instConditionList.valueInvalid;
         };

        /**
         * method to validate instruction condition.
         */
        $scope.validateInstructionCondition = function() {
            var instConditionList = $scope.autoCreate.instCondition;
            var isInstConditionValid=true;
            if(instConditionList){
                for (var i = 0; i < instConditionList.length; i++){
                    if(i!==0){
                        var isBooleanValid = $scope.validateBooleanIntCondition(instConditionList[i]);
                    }
                    var isKeyValid = $scope.validateKeyIntCondition(instConditionList[i]);
                    var isTypeValid = $scope.validateTypeIntCondition(instConditionList[i]);
                    var isValueValid = $scope.validateValueIntCondition(instConditionList[i]);

                    if(isBooleanValid || isKeyValid || isTypeValid || isValueValid){
                        isInstConditionValid = false;
                        $scope.toogleCarotIcon = true;
                    }
                }
            }

            return isInstConditionValid;
        };

        /**
         * method to validate for maxlength based on seleted attribute
         */
        $scope.validateInstOnDicomAttr = function(dicomAttr, index) {
            if(dicomAttr){
                var dicomAttrValidationMap = instructionConditionMarshallerService.getDicomAttrValidationParam();
                $scope.autoCreate.instCondition[index].type="";
                $scope.autoCreate.instCondition[index].maxlength=dicomAttrValidationMap[dicomAttr.key].maxlength;
                $scope.autoCreate.instCondition[index].conditionTypeList = $scope.conditionTypeOriginalList;
                // Removes "Contains" when Referring or Performing Physician is selected
                if(dicomAttr.key ==="00080090" || dicomAttr.key==="00081050"){
                    $scope.autoCreate.instCondition[index].conditionTypeList = _.filter($scope.autoCreate.instCondition[index].conditionTypeList, function(obj){
                            return obj.key!=="CONTAINS";
                        });
                }
            }

            else{
                $scope.autoCreate.instCondition[index].maxlength="";
            }
            $scope.autoCreate.instCondition[index].value="";
            $scope.autoCreate.instCondition[index].errormsg="";
            $scope.validateKeyIntCondition($scope.autoCreate.instCondition[index]);
        };

        var init = function() {
            $scope.autoCreate.clinicalReasons =null;
            $scope.autoCreate.postCondition.algorithm = {};
            // Populates clinical reasons dropdown
            populateClinicalReasons();
            $scope.autoCreate.site = caseAutomationDataService.getSelectedSite()|| "";
            $scope.autoCreate.siteName = $scope.autoCreate.site ? $scope.autoCreate.site.content? $scope.autoCreate.site.content.name : "" :"";
            $scope.autoCreate.instCondition=[];
            $scope.autoCreate.instCondition.push(instructionConditionMarshallerService.getConditionSkeleton());
            $scope.disableConditionInstruction=true;

            $scope.getDicomCondition();
            //conditions boolean list
            $scope.conditionBooleanList = instructionConditionMarshallerService.getBooleanCondition();
            //conditions type list
            $scope.conditionTypeOriginalList = instructionConditionMarshallerService.getConditionTypes();

            $scope.postProcessingConditionTypeList = postProcessingConditionMarshallerService.getAlgoTypes();

            var condition = instructionConditionMarshallerService.marshalCondition($scope.autoCreate.instCondition);
            instructionConditionMarshallerService.unmarshalCondition(condition);
        };

        init();
    }]);

});