/*
 *  morpheus-user-controller.js
 *
 *  Copyright (c) 2015 by General Electric Company. All rights reserved.
 *
 *  The copyright to the computer software herein is the property of
 *  General Electric Company. The software may be used and/or copied only
 *  with the written permission of General Electric Company or in accordance
 *  with the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */

/**
 * A morpheus user controller to handle user related operations.
 */
define(['angular', 'postal', '../module'],
    function (ng) {
        'use strict';

        // morpheus user Controller module
        var morpheus = ng.module('cloudav.caseExchange.morpheusUserCtrl', ['Services.morpheusServices', 'analyticsChart', 'Services.caseExchangeDataService']);

        var convertToUTC = function(dateString){
            dateString = new Date(dateString);
            return Date.UTC(dateString.getFullYear(), dateString.getMonth(), dateString.getDate(),  dateString.getHours(), dateString.getMinutes(), dateString.getSeconds());
        };

        var parseData = function(caseData, chartType){
            var data = [];
            $.each(caseData, function(index, obj){
                    if(chartType === "casesByReason"){
                        data.push([obj.clinicalReason, obj.numOfCases]);
                    }
                    if(chartType === "transactionByDay"){
                        data.push([convertToUTC(obj.dateOfTransaction), obj.numOfTransactions]);
                    }
                    if(chartType === "transactionByType"){
                        data.push([obj.transactionType, obj.numOfTransactions]);
                    }
            });

            data.sort(function(a,b){
                if(chartType === "transactionByDay"){
                    return a[0] - b[0];
                }else{
                    return a[0] > b[0];
                }
            });

            return data;
        };

        var isDataEmpty = function(data){
            return (data[0] && data[0].casesByClinicalReason &&
                        data[0].casesByClinicalReason.length === 1 && (data[0].casesByClinicalReason[0].clinicalReason === null
                        || data[0].casesByClinicalReason[0].clinicalReason === undefined));
        };

        var handleError = function($rootScope, $scope){
            if($rootScope.onLoad === undefined){
                $rootScope.onLoad = false;
                $scope.$emit('error', {page: 'caseexchange.morpheus.errorPage', type: 'error.redirectToInbox'});
            }else{
                $scope.$emit('error', {page: 'caseexchange.morpheus.errorPage', type: 'error.errorOccurred'});
            }
        };

        // morpheus user Controller
        morpheus.controller('MorpheusUserCtrl', ['$rootScope', '$scope', '$state', '$stateParams', '$timeout', 'MorpheusServices', 'CaseExchangeDataService',
        function ($rootScope, $scope, $state, $stateParams, $timeout, morpheusServices, caseExchangeDataService) {

            $scope.reportData = [];
            $scope.morpheusReportDataReady = false;
            $scope.filterOptions = [{id:"7", name:"Last 7 Days"}, {id:"30", name:"Last 30 Days"}];
            $scope.selectedFilter = {id:"30", name:"Last 30 Days"};

            $scope.filterChange = function(newVal){
                if(newVal !== undefined){
                    $scope.updateData(newVal.id);
                }
            };

            var createChartConfig = function(data){

                $scope.reportData = _.cloneDeep(data[0]);

                var caseByClinicianChartConfig = {
                        chart: {
                            renderTo: 'caseByClinicianChartContainer',
                            type: 'pie'
                        },
                        legend: {
                            enabled: true
                        },
                        title: {
                            text: 'Cases By Clinical Reason'
                        },
                        tooltip: {
                            shared: true,
                            useHTML: true,
                            headerFormat: '<small>{point.key}</small><br>',
                            pointFormat: '<small>Number Of Cases : <b>{point.y}</b></small>'
                        },
                        series: [{
                            data: parseData($scope.reportData.casesByClinicalReason, "casesByReason"),
                            size: '100%',
                            innerSize: '40%',
                            showInLegend:true,
                            dataLabels: {
                                enabled: true
                            }
                        }]
                };
                $scope.caseByClinicianChartConfig = caseByClinicianChartConfig;

                var transactionByTypeChartConfig = {
                        chart: {
                            renderTo: 'transactionByTypeChartContainer',
                            type: 'pie'
                        },
                        legend: {
                            enabled: true
                        },
                        title: {
                            text: 'Transaction By Type'
                        },
                        tooltip: {
                            shared: true,
                            useHTML: true,
                            headerFormat: '<small>{point.key}</small><br>',
                            pointFormat: '<small>Number Of Cases : <b>{point.y}</b></small>'
                        },
                        series: [{
                            data: parseData($scope.reportData.transactionByType, "transactionByType"),
                            size: '100%',
                            innerSize: '40%',
                            showInLegend:true,
                            dataLabels: {
                                enabled: true
                            }
                        }]
                };
                $scope.transactionByTypeChartConfig = transactionByTypeChartConfig;

                var transactionByDayChartConfig = {
                        chart: {
                            renderTo: 'transactionByDayChartContainer',
                            type: 'line'
                        },
                        xAxis: {
                            type: 'datetime',
                            tickInterval: 24 * 3600 * 1000
                        },
                        yAxis: {
                            title: {
                                text: '# of transactions'
                            }
                        },
                        legend: {
                            enabled: false
                        },
                        tooltip: {
                            shared: true,
                            useHTML: true,
                            headerFormat: '<small>{point.key}</small><br>',
                            pointFormat: '<small>Number Of Transactions : <b>{point.y}</b></small>'
                        },
                        title: {
                            text: 'Transaction By Day'
                        },
                        series: [{
                            data: parseData($scope.reportData.transactionByDay, "transactionByDay")
                        }]
                };
                $scope.transactionByDayChartConfig = transactionByDayChartConfig;
            };

            var currentUser = caseExchangeDataService.getCurrentUser();
            $scope.updateData = function(days){
                var promise = morpheusServices.getClinicianData(currentUser.externalId[1].value, days);
                promise.then(function(data){
                    if(isDataEmpty(data) && $rootScope.onLoad === undefined){
                        $rootScope.onLoad = false;
                        $scope.$emit('error', {page: 'caseexchange.morpheus.errorPage', type: 'error.redirectToInbox'});
                    }else if(isDataEmpty(data)){
                        $rootScope.onLoad = false;
                        $scope.$emit('error', {page: 'caseexchange.morpheus.errorPage', type: 'error.noPrivilege'});
                    }
                    createChartConfig(data);
                    $scope.morpheusReportDataReady = true;
                },  function(){
                    handleError($rootScope, $scope);
                });
            };
            $scope.updateData("30");
        }]);
        return morpheus;
    }
);